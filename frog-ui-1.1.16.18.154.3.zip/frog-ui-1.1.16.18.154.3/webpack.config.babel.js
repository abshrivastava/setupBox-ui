//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import path from "path"
// eslint-disable-next-line no-unused-vars
import babelPolyfill from "babel-polyfill" // used for Object.assign
import webpack from "webpack"
import postcssImport from "postcss-import"
import postcssUrl from "postcss-url"
import postcssCssnext from "postcss-cssnext"
import postcssAssets from "postcss-assets"
import StyleLintPlugin from "stylelint-webpack-plugin"
import webpackConfig from "./config.webpack.json"

try {
  const localWebpackConfig = require("./config.webpack.local.json")

  Object.assign(webpackConfig, localWebpackConfig)
} catch (e) {
}

// Production flag, turned on with the command-line flag
const PRODUCTION = process.argv.includes("--production")

// -- Webpack configuration --
const _webpackConfig = {

  // Developer tool to enhance debugging
  devtool : (PRODUCTION) ? "source-map" : "eval-source-map",

  // Configure the behaviour of webpack-dev-server
  devServer : Object.assign({}, webpackConfig.devServer, {
    publicPath: "/",
    headers: {"Access-Control-Allow-Origin": "*"},
    stats: "minimal",
  }),

  // The entry point for the bundle(s)
  entry : "./src/index.js",

  // Options affecting the output
  output : {
    path: path.join(__dirname, "build"),
    filename: "[name].js",
    publicPath: "./",
    sourceMapFileName: "[file].map",
  },

  // Include polyfills or mocks for various node stuff
  node : {
    fs: "empty",
  },

  // Options affecting the normal modules
  module: {

    // Array of automatically applied preloaders
    preLoaders: [

      // Use babel and eslint to build and validate JavaScript
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loaders: [
          "babel",
          "eslint",
        ],
      },
    ],

    // Array of automatically applied loaders
    loaders: [

      // Allow loading of JSON files
      {
        test: /\.json$/,
        loader: "json",
      },

      // Use cssnext to build CSS
      {
        test: /\.css$/,
        loader: "style?singleton!css!postcss?from=src/index.css",
      },

      // Copy images
      {
        test: /\.(ico|jpe?g|png|gif)$/,
        loader: "file-loader?name=[path][name].[ext]&context=./src",
      },

      // Copy web fonts
      {
        test: /\.(woff|ttf|otf|eot\?#.+|svg#.+)$/,
        loader: "file?name=[path][name].[ext]&context=./src",
      },

      // Copy HTML files
      {
        test: /\.html$/,
        loader: "file?name=[path][name].[ext]&context=./src",
      },
    ],
  },

  plugins : [
    // Deduplicate code
    new webpack.optimize.DedupePlugin(),
    new StyleLintPlugin({
      webpackConfigFile: ".stylelintrc",
      files: "src/**/**.css",
      failOnError: false,
    }),
  ],

  // cssnext-specific webpackConfiguration
  postcss : (loader) => {
    return [
      postcssImport({
        path: ["src"],
      }),
      postcssUrl,
      postcssCssnext,
      postcssAssets({
        loadPaths: ["src/app/"],
        relative: true,
      }),
    ]
  },
}

// Optimize build in production
if (PRODUCTION) {
  _webpackConfig.plugins.push(
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        "warnings": true,
        "dead_code": true,
        "drop_debugger": true,
        "drop_console": true,
        "screw_ie8": true,
      },
      mangle: false,
    })
  )
}

export default _webpackConfig
