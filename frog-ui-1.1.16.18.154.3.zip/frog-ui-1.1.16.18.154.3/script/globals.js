//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import XMLHttpRequest from "xhr2"

let localConfig

try {
  localConfig = require("./globals.custom")
} catch (err) {
  localConfig = {}
}

GLOBAL.__KEYMAP__ = localConfig.__KEYMAP__ || "pc"
GLOBAL.__STB_IP__ = localConfig.__STB_IP__ || "127.0.0.1"
GLOBAL.__DEBUG__ = localConfig.__DEBUG__ || false
GLOBAL.__BROADCAST__ = localConfig.__BROADCAST__ || "dvbs"
GLOBAL.__FREQ_START__ = localConfig.__FREQ_START__ || false
GLOBAL.__FREQ_END__ = localConfig.__FREQ_END__ || false
GLOBAL.__LOG_IP__ = localConfig.__LOG_IP__ || "127.0.0.1"
GLOBAL.__CHANNEL_LIST_STYLE__ = localConfig.__CHANNEL_LIST_STYLE__ || "textOnly"
GLOBAL.__LOGO_BASE__ = localConfig.__LOGO_BASE__ || ""
GLOBAL.XMLHttpRequest = XMLHttpRequest
GLOBAL.window = {location: {search: ""}}
