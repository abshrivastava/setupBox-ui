- dev-python/wyrest greater or equal than 6.2.1

- dev-python/wyrest-frog-plugin greater or equal than 2.0.1

- net-www/webkitlauncher greater or equal than 3.4.0

At least one of the following:

- virtual/initng-runlevels

- sys-boot/initng-runlevels-wms

