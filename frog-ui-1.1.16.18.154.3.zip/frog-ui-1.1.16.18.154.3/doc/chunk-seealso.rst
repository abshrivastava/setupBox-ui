.. fragment: list of related documents outside of the component documentation
   expected by the component overview

.. .....................................................................
   only contains a seealso directive and links, like in the example below:

   .. seealso::

      :ref:`TV Developer's Guide <global_guide_tv>`
         How to develop new TV features

   no other content!

   links should be to document titles, not sections
   .....................................................................

.. .. seealso::





