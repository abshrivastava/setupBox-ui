.. fragment: general description of a component
   expected by ./overview.rst

.. .....................................................................
   The first sentence should act as a short description for the component and be emphasized (=between stars).
   You can also add the rationale, aka explain why this component exists.
   (do not confuse with the rationale of its API)
   There can be several paragraphs explaining what the component is about, but no sections.
   .....................................................................

*Frog Turnkey UI is the new reference Frog UI.*

It's a web application written in HTML5 (HTML, JavaScript, CSS and XHR) to provide you with a rich and responsive example of user interface. 

When you interact with the interface, Frog Turnkey UI sends/receive HTTP requests/responses to/from the middleware, through a REST server called :wy:component:`wyrest`.

Frog Turnkey UI relies on :wy:component:`webkitlauncher` and is designed according to the capabilities of `Webkit <http://www.webkit.org>`_.
