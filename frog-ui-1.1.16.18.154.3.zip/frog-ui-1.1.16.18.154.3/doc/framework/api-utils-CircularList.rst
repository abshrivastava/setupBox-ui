######################
utils/CircularList API
######################

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  class:: CircularList(items)


    :param Array<> items: Items.

..  function:: getRange(start, length)

   Return Items in the specified range

     :param Int start: Index
     :param Int length: Number of items to return
     :returns Array:

   .. code-block:: js

      const list = new List(["a", "b", "c", "d", "e", "f"])
      list.getRange(5, 2) //=> ["f", "a"]

