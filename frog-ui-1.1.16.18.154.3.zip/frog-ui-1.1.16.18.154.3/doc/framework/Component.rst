Component
=========

Components abstract the DOM and make it easy to manipulate and animate.

They provide the following features:

-  `JSX based HTML generation <#jsx>`__
-  `BEM state manipulation <#bem>`__
-  `CSS animations handling through transitions <#animations>`__
-  `One-way data binding <#one-way-data-binding>`__

JSX
---

Components use a
`JSX <https://facebook.github.io/react/docs/jsx-in-depth.html>`__-like
language for rendering. This means you will not have to manually write a
bunch of ``document.createElement`` calls, but instead use an HTML-like
syntax to declare the component's structure.

JSX looks like HTML, except that it differentiates standard HTML tags using
lowercase names from components, using capitalized tag names:

.. code-block:: html

   <div> // An HTML tag
   <Component /> // A component instance


Attributes on component tags will be passed to the component constructor as an
object.

Thus, the following JSX code:

.. code-block:: html

   <SomeComponent value="1" otherValue="2" />

Will roughly translate to:

.. code-block:: js

   new SomeComponent({value: "1", otherValue: "2"})

Computed properties
~~~~~~~~~~~~~~~~~~~

You can use JavaScript to compute values of a property. Simply use curly
brackets (``{}``) instead of quotes around the attribute name.

.. code-block:: text

   <Component value={1 + 1} />

Special attributes
~~~~~~~~~~~~~~~~~~

``ref``
^^^^^^^

When adding a ``ref`` attribute on a **Component**, it will store a
top level reference to this component which can be retrieved later using the
:js:func:`$` helper function from the Component module.

Please note that the ``ref`` attribute is not handled on basic HTML tags.

.. code-block:: html

  <Component ref="someComponent" />

  // $("someComponent") //=> Component

``key``
^^^^^^^

When adding a ``key`` attribute on a children node, it will store a
reference to this node on the current rendering component.

.. code-block:: html

   <Parent>
     <Child key="child" />
   </Parent>

   // parent.child //=> Child

``collection``
^^^^^^^^^^^^^^

When adding a ``collection`` attribute on a children node, it will add
the instance to a collection property on the current rendering
component. If the collection does not exist yet, it is created first.

.. code-block:: html

   <Parent>
     <Child collection="children" />
     <Child collection="children" />
     <Child collection="children" />
   </Parent>

   // parent.children //=> [Child, Child, Child]

``prop``
^^^^^^^^

When adding a ``prop`` attribute on an HTML tag, it will bind the tag to the
given property of the parent component of this tag.

Whenever :js:func:`.setProp` will be used on the component to update the
property, the HTML tag content will be automatically updated.

Please note that the ``prop`` attribute is not handled on components.

.. code-block:: html

  <span prop="value" />

``htmlFor`` and ``className``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

``for`` and ``class`` are reserved JavaScript keywords. If you need to
use them in JSX, respectively use ``htmlFor`` and ``className`` instead.
They will be translated to the correct HTML attribute at render time.

.. code-block:: js

   <input className="Button" type="button" htmlFor="formId" />
   // Compiles to: <input class="Button" type="button" for="formId" />

Example
~~~~~~~

The following JSX example outlines what is possible to do within the
Component framework:

.. code-block:: html

   <!-- Checklist -->
   <div class="Checklist">
     <Header key="header" text="Checklist" ref="articleHeader"/>
     <List>
       {[1, 2, 3].map((i) =>
         <ListItem value={i} collection="items" />
       )}
     </List>
   </div>

   <!-- Header -->
   <h1 prop="value" />

   <!-- List -->
   <ul class="List">
     {this.children}
   </ul>

   <!-- ListItem -->
   <li class="ListItem">
     <span prop="value" />
   </li>

In this example:

- ``Checklist`` is a composite component using the ``Header``, ``List`` and ``ListItem`` components.
- Its ``Header`` component will be accessible inside the ``Checklist`` component using ``this.header``.
- It will also be accessible as a top-level component using ``$("articleHeader")``.
- All ``ListItem`` instances will be accessible in an array at ``this.items``
  within the ``Checklist`` component.
- The ``Header`` component is made of an ``h1`` tag which will hold the
  ``text`` property value. Calls to ``setProp("text", "new value")`` will
  automatically update this content.
- The ``List`` component is simply a wrapper around it's children.
- ``ListItem`` components mostly consist in a ``span`` tag bound to the ``value`` property.


BEM
---

The Component framework relies on the `BEM
methodology <http://blog.kaelig.fr/post/48196348743/fifty-shades-of-bem>`__
for HTML and CSS.

It provides helpers such as :js:func:`~pushState` or
:js:func:`~pullState` to ease manipulation of the BEM
state of a Component's root element.

The ``className`` of the root element is automatically inferred at
Component's ``build()`` time.

.. code-block:: js

   // Given a component with root element <div class="MyComponent">
   component.pushState("hidden")
   // HTML is now <div class="MyComponent MyComponent--hidden">

There are also helpers to manipulate the ``hidden`` BEM state:
:js:func:`~show` and :js:func:`~hide`.

For more helpers, please see the ``core/utils/dom`` module.

Animations
----------

There are helpers to facilitate animations and transition flow in the
UI, namely :js:func:`~addTransitionListener` and
:js:func:`~removeTransitionListener`.

One-way data-bindings
---------------------

When instantiating a Component (by JSX or JS), you can pass an object of
properties to the constructor. These properties will be accessible in your
component code through the ``this.props`` object and in ``prop`` bindings on
your HTML tags.

Using :js:func:`.setProp` and :js:func:`.setProps` will allow you to update the
property value and the bound nodes at once.

API
---

.. toctree::

   api-Component

