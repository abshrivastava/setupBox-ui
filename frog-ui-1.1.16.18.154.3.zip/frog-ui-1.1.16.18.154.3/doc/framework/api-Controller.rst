##############
Controller API
##############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. class:: Controller()


..  attribute:: controller.activeDelegate

   Child controller to delegate actions to, or null.

     :type: Controller

..  attribute:: controller.delagates

   List of delegate controller instances.

     :type: Array<Controller>
     :private:

..  attribute:: controller.displayName

   Name of the controller without "Controller"

     :type: String

