############
polyfill API
############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  Object.assign()

   Based on MDN's `Object.assign Polyfill https://mdn.io/assign#Polyfill`__ (Public Domain)

   The Object.assign() method is used to copy the values of all enumerable own properties from one or more source
   objects to a target object. It will return the target object.

    :param Object target: The target object.
    :returns Object: The target object gets returned.

   Cloning an object

   .. code-block:: js

      var obj = {a: 1}
      var copy = Object.assign({}, obj);
      console.log(copy); //=> { a: 1 }

   Merging objects

   .. code-block:: js

      var o1 = { a: 1 };
      var o2 = { b: 2 };
      var o3 = { c: 3 };

      var obj = Object.assign(o1, o2, o3);
      console.log(obj); //=> { a: 1, b: 2, c: 3 }
      console.log(o1);  //=> { a: 1, b: 2, c: 3 }, target object itself is changed.

   Copying symbol-typed properties

   .. code-block:: js

      var o1 = { a: 1 };
      var o2 = { [Symbol('foo')]: 2 };

      var obj = Object.assign({}, o1, o2);
      console.log(obj); // { a: 1, [Symbol("foo")]: 2 }

