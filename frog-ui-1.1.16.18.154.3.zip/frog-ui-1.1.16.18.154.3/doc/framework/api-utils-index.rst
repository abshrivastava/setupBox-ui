###############
utils/index API
###############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: utils.noop()

   A function that does nothing

.. function:: utils.constructorOf(obj)

   Returns the function used to construct an object

     :param Object obj:
     :returns Function: obj's constructor

   .. code-block:: js

      const animal = new Animal()
      constructorOf(animal) //=> Animal

.. function:: utils.isObject(obj)

   Tests if an object has the Object constructor

     :returns Boolean:

.. function:: utils.isArray(obj)

   Tests if an object has the Array constructor

     :returns Boolean:

.. function:: utils.isFunction(obj)

   Tests if an object has the Function constructor

     :returns Boolean:

.. function:: utils.isDefined(obj)

   Tests if a variable is defined

     :returns Boolean:

.. function:: utils.trace()

   This logging decorator provides additional information about a class method
   calls.

   Add it before any method that you want to trace in the console and you will
   get a detail stack trace and arguments inspection whenever the method is
   called.

   Keep in mind that this is a costly operation and that it will not be
   available in production because of this.

     :implements: |-ext-js-decorators|_

   .. code-block:: js

      class Foo() {
        @trace
        hello() { console.log("Hello") }
      }

.. function:: utils.mod(a, b)

   Returns the a mod b, fixing JavaScript's behaviour when working with negative
   numbers.

     :returns Number:

   .. code-block:: js

      -4 % 3 //=> -1
      mod(-4, 3) //=> 2

.. function:: utils.throttle(fn, rate)

   Caps a function's execution rate.

     :param Function fn: Target function
     :param Number rate: Maximal execution rate
     :returns Function: A new function capped to the maximal execution rate

.. function:: utils.debounce(fn, delay)

   Creates a new function that defers its execution until it has stopped being
   called for a specific delay.

     :param Function fn: Target function
     :param Number delay: Debounce delay
     :returns Function: The debounced function

.. function:: utils.createTicker()

   Creates a programmable ticker that can be stopped and started and which
   executes a given callback at a specified rate.

   See :js:func:`~utils.ticker.start` and :js:func:`~utils.ticker.stop`

     :param Number rate: Call rate of the ticker
     :returns Object: The ticker object with ``start`` and ``stop`` methods

.. function:: utils.ticker.start(fn)

   Starts executing a callback function using the ticker's rate.

     :param Function fn: The callback to execute

.. function:: utils.ticker.stop()

   Stops execution of the current callback.

.. function:: utils.wait(ms)

   Creates a Promise that automatically resolves after a given amount of time.

     :param number ms: Miliseconds to wait before resolving
     :returns Promise:

.. function:: utils.pick(source, ...props)

   Remove the given properties from an object and return a new object
   containing them.

     :param Object source: The object to get properties from
     :param ...string props: The properties to keep
     :returns Object: The filtered object

.. function:: utils.reverseObject(obj)

   Returns an array of [values, keys] using the keys and values from the given
   object.

     :param Object obj: The object to reverse
     :returns Array: A list of [value, key]

.. function:: utils.findKey(obj, val)

   Returns the key associated with a given value in an object.

     :param Object obj: The object to search
     :param Object value: The value used to find the key for
     :returns String: The key associated with the given value, or null

.. function:: utils.findObjInArrayByValue(array, val)

   Returns the objet associated with a given value in an array of object.

     :param Object array: The array to search
     :param Object value: The value used to find the key for
     :returns Object: The object associated with the given value, or null

