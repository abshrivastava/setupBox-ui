####################
utils/Scrollable API
####################

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. data:: Scrollable

   These mixins are used to implement scrollable lists with animated
   transitions.

   You will need to include the ControllerMixin in the controller and the
   ComponentMixin in the Component. See the documentation of these function for
   more information.

.. data:: Scrollable.DIRECTION

   These mixins are used to implement scrollable lists with animated
   transitions.

   You will need to include the ControllerMixin in the controller and the
   ComponentMixin in the Component. See the documentation of these function for
   more information.

.. function:: ControllerMixin(instance, options)

   This Controller mixin automatically adds the required methods to implement a
   scrollable list.

   The mandatory source option should be a List (see List and CircularList in
   utils).

   The provided methods are:

   - scroll(direction): Start scrolling in the given direction (forward or
     backward);
   - stopScrolling(): Stops scrolling and call the function specified with the
     onScrollStop option if given;
   - jumpTo(): Jumps to a specific item in the list (by index);
   - getSelectedItem(): Returns the selected item in the list.

   Other options:

   - fastScrollable: if true, scroll accelerates after a few iterations
   - scrollSpeed: delay between scrolls (in ms)
   - fastScrollSpeed: delay between scrolls when in fastScroll mode (in ms)
   - mode: bounded or cyclic

.. function:: ComponentMixin(instance, options)


