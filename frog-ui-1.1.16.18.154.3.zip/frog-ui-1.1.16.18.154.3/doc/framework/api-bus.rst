#######
bus API
#######

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  class:: Bus()


   Extends Emitter class

   `Singleton`

   .. code-block:: js

      import bus from "services/bus"

      bus.emit("home:stop:release") //=> Fire a simple event: "home:stop:release"
      bus.emit("message", {foo: "bar"}) //=> Fire an event "message" with data: {foo: "bar"}

   Register/ Unregister to events

   .. code-block:: js

      import bus from "services/bus"

      function sayHello(name) {
        console.log("Hello ", name")
        bus.off("login", sayHello)
      }
      bus.on("login", sayHello)

      bus.emit("login", "John") //=> The console prints: Hello John

   .. code-block:: js

      bus.openUniverse("tv") //=> fire event "tv:open" , current universe is now "tv"
      bus.universe //=> "tv"
      bus.closeCurrentUniverse() //=> fire event: "tv:close", current universe is null
      bus.universe //=> null

..  attribute:: universe

   Current existing universes:
    - `tv`
    - `vod`
    - `epg`
    - `settings`
    - `mediacenter`
    - `radio`
    - `pvr`
    - `home`
    - `ad`
    - `standby`
    - `popup`

    And one special during UI creation/loading:
    - `bigbang`

     :type: String
     :private:

..  function:: on(event, fn)

   Register an event handler fn.

     :param String event: Event to register
     :param Function fn: handler
     :returns Emitter:

..  function:: once(event, fn)

   Register a single-shot event handler fn, removed immediately after it is invoked the first time.

     :param String event: Event to register
     :param Function fn: handler

     :returns Emitter:

..  function:: off(event, fn)

   Pass event and fn to remove a listener.
   Pass event to remove all listeners on that event.
   Pass nothing to remove all listeners on all events.

     :param String event: Event to register
     :param Function fn: handler

     :returns Emitter:

..  function:: emit(event, ...)

   Emit an event with variable option args.

     :param String event: Event

     :returns Emitter:

..  function:: listeners(event)

   Return an array of callbacks, or an empty array.

     :param String event: Event
     :returns Array:

..  function:: hasListenerss(event)

   Check if this emitter has event handlers.

     :param String event: Event
     :returns Boolean:

..  function:: handleRcuEvent(key, type, kbd)

   Handle all RCU key events
   and return an event:

     :param ? key:
     :param String type: the type of Rcu event (press/release)
     :param ? kbd:
     :returns Emitter:

   .. code-block:: js

      bus.handleRcuEvent(7, "press", 7) //=> "rcu:bigbang:up:press"

..  attribute:: universe

   Returns the current universe

     :returns String: current universe

..  setter: universe

   Set the current universe

     :param String: universe

..  function:: openUniverse(universe)

   Open an universe, set it as current and emit a message `universe:open`

     :param String: universe
     :returns Emitter:

..  function:: closeCurrentUniverse()

   Close current universe, set it to null  and emit a message `universe:close`

     :returns Emitter:

