Utility functions
=================

This module exports a lot of utility functions that can be used in the UI code.

.. toctree::

    api-utils
    api-polyfill
    api-utils-string
    api-utils-date
    api-utils-dom
    api-utils-List
    api-utils-CircularList
    api-utils-Scrollable

