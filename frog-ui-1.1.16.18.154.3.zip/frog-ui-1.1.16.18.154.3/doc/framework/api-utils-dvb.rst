#############
utils/dvb API
#############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: utils.dvb.getCategory(nibbleLevel1)

   Return a category from given nibble 1 value

     :param int nibbleLevel1: Nibble to translate
     :returns String:

   .. code-block:: js

      getCategory(1) // => "Movie"

