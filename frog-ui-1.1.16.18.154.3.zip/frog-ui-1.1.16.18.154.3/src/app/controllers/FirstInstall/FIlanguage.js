//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import {ListObj} from "app/utils/widgets/lists"
import {pushState, pullState} from "utils/dom"
import {_, locale} from "utils/locale"
import bus from "services/bus"
import {setLocale, getLocale, updateDefaultTrack, updateAudiotracks, setFirstInstall} from "services/managers/config"
import {on} from "services/events"
import {setEpgLanguage} from "services/api/program"

const ZERO_INDEX = 0
const PAGE_SIZE = 2


export default class FIlanguageController extends Controller {

  constructor() {
    super()
    this.view = $("firstInstall_language")
    this.languageSelected = true
    this.currLanguage = "English"
    this.options = [{
      name: _("Finish"),
      action: "FirstInstall:close",
    }]
    this.list = 0
    this.enableMultiLang = true
  }

  open() {
    setFirstInstall()
    this.updateScreen()
    this.view.show()
    this.languageSelected = true
    this.view.menuList.onFocusLeft(this.list)
    return Promise.resolve()
  }

  updateScreen() {
    this.loadFIlanguages(ZERO_INDEX, PAGE_SIZE)
    this.view.loadItems(this.options)
  }

  @on("FIlanguage:close")
  close() {
    this.view.hide()
  }

  loadFIlanguages() {
    if (this.enableMultiLang) {
      this.newFIlanguageArr = [
        {label: "English", value: "eng"},
        {label: "Hindi", value: "hin"},
        {label: "Marathi", value: "mar"},
        /* {label: "Tamil", value: "tam"}, */
        {label: "Telugu", value: "tel"},
      ]
    } else {
      this.newFIlanguageArr = [{label: "English", value: "eng"},{label: "Hindi", value: "hin"}]
    }

    getLocale()
    .then((lang) => {
      if (lang === "en") lang = "eng"
      this.languageListObj = new ListObj(this.newFIlanguageArr,this.view.fIlanguageList)
      this.newFIlanguageArr.forEach((obj, i) => {
        if (obj.value === lang) {
          this.currLanguage = obj.label
          this.languageListObj.select(i)
          this.view.highlightDefault(i)
        }
      })
    })
  }

  setLanguage(idx) {
    const lang = this.newFIlanguageArr[idx]
    this.selectedLang = lang.value
    setLocale(lang.value).then(() => {
      locale.current = lang.value
      this.currLanguage = lang.label
      this.view.highlightDefault(idx)
      let obj = {}

      if (!this.enableMultiLang) {
        if (lang.value === "eng") {
          obj = {"audio_tracks": {"1": "hin", "2": "eng"}}
        } else if (lang.value === "hin") {
          obj = {"audio_tracks": {"2": "hin", "1": "eng"}}
        }
      } else {
        switch (lang.value) {
        case "eng":
          obj = {"audio_tracks":
          {
            "1": "tel",
            "2": "mar",
            "3": "tam",
            "4": "hin",
            "5": "eng",
          },
          }
          break
        case "hin":
          obj = {"audio_tracks":
          {
            "1": "tel",
            "2": "mar",
            "3": "tam",
            "4": "eng",
            "5": "hin",
          },
          }
          break
        case "tam":
          obj = {"audio_tracks":
          {
            "1": "tel",
            "2": "mar",
            "3": "hin",
            "4": "eng",
            "5": "tam",
          },
          }
          break
        case "mar":
          obj = {"audio_tracks":
          {
            "1": "tel",
            "2": "tam",
            "3": "hin",
            "4": "eng",
            "5": "mar",
          },
          }
          break
        case "tel":
          obj = {"audio_tracks":
          {
            "1": "mar",
            "2": "tam",
            "3": "hin",
            "4": "eng",
            "5": "tel",
          },
          }
          break
        default:
          break
        }
      }

      // ==================================================
      updateDefaultTrack(this.selectedLang)
      updateAudiotracks(obj)
      setEpgLanguage(this.selectedLang)
      this.updateScreen()
    })
  }

  onOk() {
    if (this.languageSelected) {
      this.setLanguage(this.view.fIlanguageList.focusedIdx)
    } else {
      const signal = this.options[0].action
      bus.emit(signal, this.currLanguage)
    }
  }

  onUp() {
    if (this.languageSelected) {
      this.languageListObj.up()
    }
  }

  onDown() {
    if (this.languageSelected) {
      this.languageListObj.down()
    }
  }

  onRight() {
    if (this.languageSelected) {
      this.languageSelected = false
      pushState(this.view.fIlanguageList.selector.FIlanguageSelector, "hidden")
      this.view.menuList.onFocusRight(this.list)
    }
  }

  onLeft() {
    if (!this.languageSelected) {
      this.languageSelected = true
      pullState(this.view.fIlanguageList.selector.FIlanguageSelector, "hidden")
      this.view.menuList.onFocusLeft(this.list)
    }
  }

}
