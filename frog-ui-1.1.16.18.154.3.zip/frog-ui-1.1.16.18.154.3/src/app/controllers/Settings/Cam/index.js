//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"

// import bus from "services/bus"
import {on} from "services/events"
import CamManager from "services/managers/CamManager"
import {$} from "widgets/Component"
import {ListObj} from "app/utils/widgets/lists"

export default class CamController extends Controller {
  constructor() {
    super()
    this.LoadingMessage = "Loading Please Wait ...."
    this.view = $("cam")
    this.MainMenu = true
    this.activeDelegate = null
  }
  open() {
    this.view.onForeground()
    this.view.show()
    this.displayLoading()
    return Promise.resolve()
  }

  displayLoading() {
    this.newChannelArr=[]
    const obj = {}
    obj.label = this.LoadingMessage
    obj.serviceId = "1"
    this.newChannelArr.push(obj)
    this.channelListObj = new ListObj(this.newChannelArr,this.view.CamList)
  }

  @on("Cam:MainMenu")
  mainMenu(data) {
    const indexToRemove = 0
    const needToRemove = this.getIndexOfActualArray(data.mmi_menu)
    const response = data.mmi_menu.splice(indexToRemove,needToRemove)
    console.log(response)
    const len = data.mmi_menu.length
    console.log("len", len)
    len <= 9 ? this.loadMenuItem(data.mmi_menu) : this.loadMenuItemWithPaging(data.mmi_menu)
  }

  loadMenuItem(array) {
    const CamMenu = []
    for (let i = 0; i < array.length; i++) {
      if (array[i].trim()) {
        CamMenu.push({
          label: array[i],
          id: i+1,
        })
      }
    }
    this.channelListObj = new ListObj(CamMenu,this.view.CamList)
  }

  loadMenuItemWithPaging(data) {
    const response = data.splice(0,9)
    console.log("response", response)
    const CamMenu = []
    for (let i = 0; i < response.length; i++) {
      if (response[i].trim()) {
        CamMenu.push({
          label: response[i],
          id: i+1,
        })
      }
    }
    this.channelListObj = new ListObj(CamMenu,this.view.CamList)
  }
  getIndexOfActualArray(menuArray) {
    for (let iCounter=0;iCounter < menuArray.length ; iCounter++) {
      if (menuArray[iCounter].includes("OK") || menuArray[iCounter].includes("ok") || menuArray[iCounter].includes("Ok")
       || menuArray[iCounter].includes("EXIT") || menuArray[iCounter].includes("Exit")) {
        return iCounter+1
      }
    }
  }

  moveUp() {
    this.channelListObj.up()
  }
  moveDown() {
    this.channelListObj.down()
  }
  onOk() {
    const selectedItem = this.channelListObj.items[this.channelListObj.selected]
    if (selectedItem.label !== this.LoadingMessage) {
      const params = {"entry":selectedItem.id}
      CamManager.getCamSubMenu(params)
      this.displayLoading()
    }
  }
  onBack() {
    this.view.hide()
    return Promise.resolve()
  }
  @on("Cam:close")
  close() {
    this.view.hide()
  }
}
