//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {$} from "widgets/Component"
import {createTicker} from "utils"
import AbstractSetting from "../AbstractSetting"

export default class LicenseController extends AbstractSetting {


  constructor() {
    super()
    this.clockUpdater = createTicker(1500)
    this.view = $("license")
    this.scrollIndex = 0
    this.scrollDiff = 100
    this.scrollWidth = null
    this.offsetHeight = null
  }

  open() {
    this.clockUpdater.start(() => this.updateClock())
    this.view.onLoad()
    this.view.scrollUp(0)
    this.scrollWidth = this.view.scrollWidth()
    this.offsetHeight = this.view.OffSetHeight()
  }

  updateMenuTitle() {
    this.view.updateTitleForFta()
  }

  moveDown() {
    if (this.offsetHeight > this.scrollIndex) {
      this.scrollIndex  = +(this.scrollIndex + this.scrollDiff)
      this.view.scrollDown(this.scrollIndex)
    } else {
      this.scrollIndex  = this.offsetHeight
      this.view.scrollDown(this.scrollIndex)
    }
  }

  moveUp() {
    if (this.scrollIndex || this.scrollIndex > this.scrollDiff) {
      this.scrollIndex  = +(this.scrollIndex - this.scrollDiff)
      this.view.scrollUp(this.scrollIndex)
    } else {
      this.scrollIndex = this.scrollIndex < 0 ? 0 :this.scrollIndex
      this.view.scrollUp(this.scrollIndex)
    }
  }


  updateClock() {
    this.view.updateClock(new Date())
  }
}
