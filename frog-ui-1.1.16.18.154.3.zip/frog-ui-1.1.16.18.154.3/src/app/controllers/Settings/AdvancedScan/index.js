//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on} from "services/events"

import Controller from "utils/Controller"
import {$} from "widgets/Component"

import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import standby from "services/managers/PowerManager"
import ScanManager from "services/managers/ScanManager"
import PVRManager from "services/managers/PVRManager"
import {updateIFtoIF} from "services/managers/config"
import {IFTOIF, Satellite, LNB} from "./OptionsList"


export default class AdvancedScanController extends Controller {
  static delegates = [
    IFTOIF,
    Satellite,
    LNB,
  ]

  constructor() {
    super()
    this.optionList = [{name: "Launch a scan"}]
    this.view = $("advancedScan")
    this.activeDelegate = null
    // this.Satellite.getSatList()
    this.if2IF = false
  }

  get ScanProgress() {
    return this.master.ScanProgress
  }

  open() {
    PlayerManager.stop()
    this.updateAdvanceTitle()
    return this._load()
      .then(() => {
        this.view.show()
      })
  }

  updateAdvanceTitle() {
    const ftaBlockStatus = FtaBlockManager.isNavigationRestricted()
    let title = null
    if (ftaBlockStatus) {
      title= "My DishTV"
    }
    this.view.updateFtaAdvanceTitle(title)
  }



  @on("AdvancedScan:close")
  close() {
    let p
    if (this.activeDelegate === this.ScanProgress) {
      p = this.ScanProgress.close()
    } else {
      p = Promise.resolve()
    }
    return p.then(() => {
      ScanManager.alwaysCommit =false
      this.activeDelegate = null
      return standby._checkStandbyPower().then(() => {
        return this.view.hide()
      })
    })
  }

  moveUp() {
    switch (this.activeDelegate) {
    case this.IFTOIF:
      return this.IFTOIF.up()
        .catch(() => {
          return this.activeDelegate = this.IFTOIF
        })
    case this.Satellite:
      return this.Satellite.up()
        .catch(() => {
          this.Satellite.blur()
          this.IFTOIF.focus()
          return this.activeDelegate = this.IFTOIF
        })
    case this.LNB:
      return this.LNB.up()
        .catch(() => {
          this.LNB.blur()
          this.Satellite.focus()
          return this.activeDelegate = this.Satellite
        })
    default:
      break
    }
  }

  moveDown() {
    switch (this.activeDelegate) {
    case this.IFTOIF:
      return this.IFTOIF.down()
      .catch(() => {
        this.IFTOIF.blur()
        this.Satellite.focus()
        this.LNB.blur()
        return this.activeDelegate = this.Satellite
      })
    case this.Satellite:
      return this.Satellite.down()
        .catch(() => {
          if (this.IFTOIF.state === "IFTOIF_ON") return
          this.Satellite.blur()
          this.LNB.focus()
          return this.activeDelegate = this.LNB
        })
    case this.LNB:
      return this.LNB.down()
        .catch(() => {
          return this.activeDelegate = this.LNB
        })
    default:
      break
    }
  }

  onLeft() {
    this.activeDelegate.left()
  }

  onRight() {
    this.activeDelegate && this.activeDelegate.right()
  }

  onInput(kbd, _) {
    this.activeDelegate.input(kbd, _)
  }

  onOk() {
    PlayerManager.stopCurrentChannel()
    if (PVRManager.ongoing.length > 0) {
      PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
    }
    const options = {}
    for (const delegate of this.delegates) {
      Object.assign(options, delegate.options)
    }
    this.optionList = [{name: "Stop & Save"}]
    this.view.loadItems(this.optionList)

    //* updating Antenna setting DVB uri and Diseqc according to  IF2IF status*//
    const cb = (resolve) => {
      if (!this.Satellite.parametersValid()) return Promise.reject()
      if (this.IFTOIF.state === "IFTOIF_OFF") {
        Promise.resolve(this.LNB.updateConfigutaion())
          .then((resp) => {
            if (resp) {
              this.updateConfigSettings()
                .then((rsp)=>{
                  this.view.onBackground()
                  this.activeDelegate = this.ScanProgress
                  resolve(rsp)
                })
            }  else {
              resolve (false)
            }
          })
      }
      if (this.IFTOIF.state === "IFTOIF_ON") {
        this.updateConfigSettings()
          .then((rsp)=>{
            this.view.onBackground()
            this.activeDelegate = this.ScanProgress
            resolve(rsp)
          })
      }
    }
    bus.emit("IF2IF:change", (this.IFTOIF.state).split("_")[1])
    //* checking whether IF2IF is on or not*//
    return updateIFtoIF(this.IFTOIF.state)
      .then(() => {
        return new Promise(cb)
      }).catch(() => {
        return new Promise(cb)
      })

  }

  //* Updating Diseqc and DVBUri*//
  updateConfigSettings() {
    return Promise.all([this.LNB.updateDiseqc(), this.Satellite._updateDVBUri()])
      .then(() => {
        return (true)
      })
      .catch(() => {
        return (false)
      })
  }

  onBack() {
    if (this.activeDelegate === this.ScanProgress && this.ScanProgress.running) {
      return Promise.reject("Scan is running")
    }
    if (PlayerManager._state === 10) {
      PlayerManager.playCurrentChannel(ChannelManager.current)
    }
    this.close()
    return Promise.resolve()
  }

  @on("IF2IF:change")
  onIftoIfChange(mode) {
    this.if2IF = (mode === "ON" ? true : false)
  }

  @on("scan:finished")
  _onScanFinished() {
    this.optionList = [{name: "Launch a scan"}]
    this.view.loadItems(this.optionList)
  }

  _load() {
    return new Promise((resolve) => {
      const promises = []
      for (const delegate of this.delegates) {
        promises.push(delegate.load())
      }
      return Promise.all(promises)
        .then(() => {
          this.activeDelegate = this.Satellite
          this.IFTOIF.blur()
          this.Satellite.focus()
          this.LNB.blur()
          console.log(this.optionList)
          this.view.loadItems(this.optionList)
        })
        .then(() => {
          resolve()
        })
    })
  }
}
