//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import ScanManager from "services/managers/ScanManager"
import {getDvbUris, getIFtoIF, getDiseqcType, setDiseqcType} from "services/managers/config"
import bus from "services/bus"
import {on} from "services/events"
import {_} from "utils/locale"

class OptionsListController extends Controller {
  constructor(view) {
    super()
    this.optionList = []
    this.view = $(view)
    this.selectedIdx = 0
  }

  get options() {
    return null
  }

  load() {
    return new Promise((resolve) => {
      const propObj = {IFTOIF: "IFTOIF", LNB: _("LNB settings"), Satellite: _("Satellite")}
      this.view.load(this.optionList, propObj[this.displayName])
      resolve()
    })
  }

  up() {
    if (this.selectedIdx === 0) {
      return Promise.reject("Can't go Up")
    } else {
      this.selectedIdx = this.selectedIdx - 1
      this.view.select(this.selectedIdx)
      return Promise.resolve()
    }
  }

  down() {
    if (this.selectedIdx === this.optionList.length - 1) {
      return Promise.reject("Can't go Down")
    } else {
      this.selectedIdx = this.selectedIdx + 1
      this.view.select(this.selectedIdx)
      return Promise.resolve()
    }
  }

  left() {
    return
  }

  right() {
    return
  }

  focus() {
    this.view.focus()
  }

  blur() {
    this.view.blur()
  }
}
export class IFTOIF extends OptionsListController {
  constructor() {
    super("if2if")
    this.selectedIdx = 0
    this.ifToifList = [
      {
        label: "OFF",
        value: false,
      },
      {
        label: "ON",
        value: true,
      },
    ]
    this.selectedIfToIf = 0
    this.state = "IFTOIF_OFF"
  }

  selectIFTOIF(idx) {
    if (idx < 0 && this.selectedIfToIf === 0) {
      this.selectedIfToIf = this.ifToifList.length - 1
    } else if (idx > 0 && this.selectedIfToIf === this.ifToifList.length - 1) {
      this.selectedIfToIf = 0
    } else {
      this.selectedIfToIf += idx
    }
    if (this.selectedIfToIf) {
      this.state = "IFTOIF_ON"
      bus.emit("LNB:IfToIf:changed", this.state)
    } else {
      this.state = "IFTOIF_OFF"
      bus.emit("Satellite:IfToIf:changed", this.state)
    }
    bus.emit("Satellite:IfToIf:changed", this.state)
    bus.emit("LNB:disable", (this.state === "IFTOIF_ON") ? true:false)
    this.optionList[0].value = this.ifToifList[this.selectedIfToIf].label
    super.load()
  }

  load() {
    return new Promise((resolve) => {
      getIFtoIF()
      .then((value) => {
        this.state = value
        bus.emit("LNB:disable", (this.state === "IFTOIF_ON") ? true:false)
        this.selectedIfToIf = 0
        if (this.state === "IFTOIF_ON") this.selectedIfToIf = 1
        const IftoIf = {
          name: "IFTOIF State",
          value: this.ifToifList[this.selectedIfToIf].label,
        }
        this.optionList = [IftoIf]
        super.load()
      })
      .then(() => {
        return resolve()
      })
    })
  }

  input(kbd, keynum) {
    const value = this.optionList[this.selectedIdx].value
    switch (this.selectedIdx) {
    case 1:
      this.optionList[this.selectedIdx].value = value.substring(0, value.length-3)+ keynum +"MHz"
      super.load()
      break
    default:
      break
    }
  }

  up() {
    return super.up()
  }

  down() {
    return super.down()
  }

  left() {
    switch (this.selectedIdx) {
    case 0:
      this.selectIFTOIF(-1)
      break
    default:
      break
    }
  }

  right() {
    switch (this.selectedIdx) {
    case 0:
      this.selectIFTOIF(1)
      break
    default:
      break
    }
  }
}

export class Satellite extends OptionsListController {
  constructor() {
    super("satellite")
    this.selectedIdx = 0
    this.maxCount = 5

    this.satList = []
    this.selectedSat = 0

    this.transponderList = []
    this.selectedTp = 0
    this.polarizationList = ["Vertical", "Horizontal"]
    this.fecList = ["Auto", "1/2", "2/3", "3/4", "5/6", "7/8"]
    this.transmitter_id = 1
  }

  get options() {
    const sat = this.satList[this.selectedSat]
    return {
      satellite: sat,
    }
  }

  getSatList() {
    return ScanManager.getSatelliteList()
      .then((response) => {
        this.satList = response
        this.satList.forEach((sat) => {
          sat.diseqcId = -1
        })
        const satName = {
          name: "Satellite Name:",
          value: this.satList[this.selectedSat].name,
        }
        this.optionList = [satName, null, null, null, null]
        super.load()
      })
  }

  getTpList(id) {
    return ScanManager.getTransponderList(id)
      .then((response) => {
        this.transponderList = response
      })
  }

  getSatelliteSettings(IfToIfChangeValue = "") {
    return new Promise((resolve) => {
      if (!IfToIfChangeValue) {
        return getDvbUris() // setDefaultDVBUri
          .then((uri) => {
            const uriSections = uri.toString().split("&")
            const currentFreq = parseInt(uriSections[0].split("=")[1]/1000)
            const currentFEC = uriSections[2].split("=")[1]
            const currentSR = parseInt(uriSections[3].split("=")[1]/1000)
            const currentPolarity = uriSections[5].split("=")[1]
            return resolve([currentFreq, currentFEC, currentSR, currentPolarity])
          })
      } else {
        const uriList = {
          IFTOIF_OFF: {frequency: "12688", code_rate:"Auto", symbol_rate: "27500", polarity:"V"},
          IFTOIF_ON: {frequency: "10730", code_rate:"Auto", symbol_rate:"27500", polarity:"V"},
        }
        // const uriSections = uriList.IfToIfChangeValue.frequency+"/"+uriList.IfToIfChangeValue.polarity
        // +"/"+uriList.IfToIfChangeValue.symbol_rate
        const currentFreq = uriList[IfToIfChangeValue].frequency
        const currentFEC = uriList[IfToIfChangeValue].code_rate
        const currentSR = uriList[IfToIfChangeValue].symbol_rate
        const currentPolarity = uriList[IfToIfChangeValue].polarity
        return resolve([currentFreq, currentFEC, currentSR, currentPolarity])
      }
    })
  }

  @on("Satellite:IfToIf:changed")
  load(IfToIfChange = "") {
    if (!IfToIfChange) {
      this.selectedIdx = 1
      this.view.select(this.selectedIdx)
    }
    return new Promise((resolve) => {
    /*
    const uriList = {
      IFTOIF_OFF: {frequency: "12688", code_rate:"Auto", symbol_rate: "27500", polarity:"Vertical"},
      IFTOIF_ON: {frequency: "10730", code_rate:"Auto", symbol_rate:"27500", polarity:"Vertical"},
    }
    */
      return this.getSatelliteSettings(IfToIfChange)
      .then(([currentFreq, currentFEC, currentSR, currentPolarity]) => {
        const satName = {
          name: _("Home Transponder:"),
          value: currentFreq+"/"+currentPolarity+"/"+currentSR, // this.satList[this.selectedSat].name,
        }
        const transponders = {
          name: _("Change Freq:"),
          value: currentFreq+"MHz",
        }
        const symbolRate = {
          name: _("Please enter Symbol rate:"),
          value: currentSR+"Kbps",
        }
        const fec = {
          name: _("Please select FEC:"),
          value: this.getFEC(currentFEC),
        }

        const polarization = {
          name: _("Please select Polarization:"),
          value: this.getPolarization(currentPolarity),
        }

        this.optionList = [satName, transponders, symbolRate, fec, polarization]
        return super.load()
      })
      .then(() => {
      //  bus.emit("sat:selected", this.options.satellite)
        resolve()
      })
    })
  }

  getFEC(value) {
    for (let i = 0; i< this.fecList.length; i++) {
      if (value === this.fecList[i]) {
        this.fecList.selected = i
        return this.fecList[i]
      }
    }
    this.fecList.selected = 0
    return this.fecList[0]
  }

  getPolarization(value) {
    for (let i = 0; i< this.polarizationList.length; i++) {
      if (value === this.polarizationList[i].substring(0, 1)) {
        this.polarizationList.selected = i
        return this.polarizationList[i]
      }
    }
    this.polarizationList.selected = 0
    return this.polarizationList[0]
  }


  left() {
    const value = this.optionList[this.selectedIdx].value
    switch (this.selectedIdx) {
    case 1:
      if (value.substring(0, value.length-3).length>1) {
        this.optionList[1].value = value.substring(0, value.length-4)+"MHz"
        super.load()
      } else if (value.substring(0, value.length-3).length===1) {
        this.optionList[1].value = ""
        super.load()
      }
      break
    case 2:
      if (value.substring(0, value.length-4).length>1) {
        this.optionList[2].value = value.substring(0, value.length-5)+"Kbps"
        super.load()
      } else if (value.substring(0, value.length-4).length===1) {
        this.optionList[2].value = ""
        super.load()
      }
      break
    case 3:
      if (this.fecList.selected === 0) {
        this.fecList.selected = this.fecList.length-1
      } else {
        this.fecList.selected = this.fecList.selected-1
      }
      this.optionList[3].value = this.fecList[this.fecList.selected]
      super.load()
      break
    case 4:
      if (this.polarizationList.selected === 0) {
        this.polarizationList.selected = this.polarizationList.length-1
      } else {
        this.polarizationList.selected = this.polarizationList.selected-1
      }
      this.optionList[4].value = this.polarizationList[this.polarizationList.selected]
      super.load()
      break

    default:
      break
    }
  }

  right() {
    switch (this.selectedIdx) {
    case 3:
      if (this.fecList.selected === this.fecList.length-1) {
        this.fecList.selected = 0
      } else {
        this.fecList.selected = this.fecList.selected+1
      }
      this.optionList[3].value = this.fecList[this.fecList.selected]
      super.load()
      break
    case 4:
      if (this.polarizationList.selected === this.polarizationList.length-1) {
        this.polarizationList.selected = 0
      } else {
        this.polarizationList.selected = this.polarizationList.selected+1
      }
      this.optionList[4].value = this.polarizationList[this.polarizationList.selected]
      super.load()
      break

    default:
      break
    }

  }

  input(kbd, keynum) {
  //  const keynum = Number(kbd.code.substring(5))
    const value = this.optionList[this.selectedIdx].value
    switch (this.selectedIdx) {
    case 1:
      if (value.substring(0, value.length-3).length<5) {
        this.optionList[1].value = value.substring(0, value.length-3)+ keynum +"MHz"
        super.load()
      }
      break
    case 2:
      if (value.substring(0, value.length-4).length<5) {
        this.optionList[2].value = value.substring(0, value.length-4)+ keynum +"Kbps"
        super.load()
      }
      break
    default:
      break
    }
  }

  up() {
    if (this.selectedIdx !== 1) {
      super.up()
      return Promise.resolve()
    } else {
      return Promise.reject()
    }
  }

  down() {
    if (this.selectedIdx === this.maxCount - 1) {
      return Promise.reject()
    } else {
      this.selectedIdx = this.selectedIdx + 1
      this.view.select(this.selectedIdx)
      return Promise.resolve()
    }
  }

  _updateDVBUri() {
    const data = {}
    let value
    value = this.optionList[1].value
    data["frequency"] = value.replace("MHz", "000")
    value = this.optionList[2].value
    data["symbol_rate"] = value.replace("Kbps", "000")
    data["code_rate"] = this.optionList[3].value
    data["polarity"] = this.optionList[4].value.substring(0, 1).toUpperCase()
    data["transmitter_id"] = this.transmitter_id
    return ScanManager.onUpdateDVBUri("Advanced", data)
  }

  parametersValid() {
    if (this.optionList[1].value.length === 0 || this.optionList[2].value.length === 0) {
      return false
    } else {
      return true
    }
  }

  @on("diseqc:selected")
  onDiseqcSelected(id) {
    this.transmitter_id = id
  }
}

export class LNB extends OptionsListController {
  constructor() {
    super("lnbSettings")
    this.currentTpSetId = -1

    this.selectedIdx = 0
    this.antennaInd = 1
    this.antennaOther = 2
    this.lnbPowerList = [
      {
        label: "ON",
        value: true,
      },
      {
        label: "OFF",
        value: false,
      },
    ]
    this.selectedLnbPower = 0

    this.selectedLnbType = 0

    this.diseqcList = [
      {
        label: "Auto",
        id: -1,
        assigned: false,
        value: [{
          antenna_transmitter_id: 1,
          antenna_satellite_switch_position: 0,
        },
        {
          antenna_transmitter_id: 2,
          antenna_satellite_switch_position: 1,
        }],
      },
    ]
    for (let i=1; i<5;i++) {
      this.diseqcList.push({
        label: `Port${i}`,
        id: i,
        assigned: false,
        value: [{
          antenna_transmitter_id: i,
          antenna_satellite_switch_position: i-1,
        }],
      })
    }
    this.selectedDiseqc = 0
  }

  getAntennaConfigIndex(diseqcVal) {
    let switchPos = 0
    switch (diseqcVal) {
    case "DISEQC_AUTO":
      switchPos = 0
      break
    case "DISEQC_PORT1":
      switchPos = 0
      break
    case "DISEQC_PORT2":
      switchPos = 1
      break
    case "DISEQC_PORT3":
      switchPos = 2
      break
    case "DISEQC_PORT4":
      switchPos = 3
      break
    default:
      switchPos = 0
    }

    for (let i = 0; i < ScanManager.antennaConfig.length; i++) {
      if (ScanManager.antennaConfig[i].antenna_satellite_switch_position === switchPos) {
        this.antennaInd = i
        if (diseqcVal === "DISEQC_AUTO" && ScanManager.antennaConfig[i].antenna_satellite_switch_position === 1) {
          this.antennaOther = i
        }
        break
      }
    }

  }

  updateConfigutaion() {
    const selectedDiseqc = ("DISEQC_"+this.diseqcList[this.selectedDiseqc].label).toUpperCase()
    this.getAntennaConfigIndex(selectedDiseqc)
    this._updateLnb()
    bus.emit("scan:diseqcUpdate", selectedDiseqc)
    return ScanManager.saveAntennaConfig()
  }


  updateDiseqc() {
    const selectedDiseqc = ("DISEQC_"+this.diseqcList[this.selectedDiseqc].label).toUpperCase()
    bus.emit("scan:diseqcUpdate", selectedDiseqc)
    return setDiseqcType(selectedDiseqc)
  }

  _setLnbFrequencyLow() {
    let value = this.optionList[2].value
    value = value.replace("MHz","000")
    value = parseInt(value, 10)
    return {
      antenna_satellite_freq_oscillator1: value,
    }
  }

  _setLnbFrequencyHigh() {
    let value = this.optionList[1].value
    value = value.replace("MHz","000")
    value = parseInt(value, 10)
    return {
      antenna_satellite_freq_oscillator2: value,
    }
  }

  _setLnbPower(value) {
    if (value) {
      return {
        antenna_satellite_lnb_control_mode: "lnb_control_13_v_18_v_22_k",
      }
    } else {
      return {
        antenna_satellite_lnb_control_mode: "lnb_control_disabled",
      }
    }
  }

  _updateDiseqc() {
    const selectedDiseqc = this.diseqcList[this.selectedDiseqc]
    const antenna_config = ScanManager.antennaConfig
    if (antenna_config.length > 1) {
      antenna_config.splice(1, 1)
    }
    if (this.selectedDiseqc === 0) {
      if (antenna_config.length === 1) {
        antenna_config.push(JSON.parse(JSON.stringify(antenna_config[0])))
      }
    }

    for (let i = 0; i < selectedDiseqc.value.length; i++) {
      antenna_config[i].antenna_transmitter_id = selectedDiseqc.value[i].antenna_transmitter_id
      antenna_config[i].antenna_satellite_switch_position = selectedDiseqc.value[i].antenna_satellite_switch_position
    }

  }

  _updateLnb() {
    const lnbPower = this.lnbPowerList[this.selectedLnbPower].value
    Object.assign(ScanManager.antennaConfig[this.antennaInd], this._setLnbFrequencyLow())
    Object.assign(ScanManager.antennaConfig[this.antennaInd], this._setLnbFrequencyHigh())
    Object.assign(ScanManager.antennaConfig[this.antennaInd], this._setLnbPower(lnbPower))
    if (this.selectedDiseqc === 0) {
      Object.assign(ScanManager.antennaConfig[this.antennaOther], this._setLnbFrequencyLow())
      Object.assign(ScanManager.antennaConfig[this.antennaOther], this._setLnbFrequencyHigh())
      Object.assign(ScanManager.antennaConfig[this.antennaOther], this._setLnbPower(lnbPower))
    }
  }

  getCurrentLnbPower() {
    switch (ScanManager.antennaConfig[this.antennaInd].antenna_satellite_lnb_control_mode) {
    case "lnb_control_disabled":
      this.selectedLnbPower = 1
      break
    default:
      this.selectedLnbPower = 0
      break
    }
  }

  getCurrentDiseqc(diseqcType) {
    diseqcType = diseqcType.toString()
    switch (diseqcType) {
    case "DISEQC_AUTO":
      this.selectedDiseqc = 0
      break
    default:
      this.selectedDiseqc = parseInt(diseqcType.slice(-1))
      break
    }
  }

  @on("LNB:disable")
  disable(isDisable = false) {
    this.view.disable(isDisable)
  }

  @on("LNB:IfToIf:changed")
  load() {
    return new Promise((resolve) => {
      Promise.all([ScanManager.getAntennaConfig(), getDiseqcType()])
      .then(([antenna_config, diseqcType]) => {
        this.getAntennaConfigIndex(diseqcType)
        console.log(antenna_config)
        this.getCurrentLnbPower()
        this.getCurrentDiseqc(diseqcType)
        const lnbPower = {
          name: _("LNB Power:"),
          value: this.lnbPowerList[this.selectedLnbPower].label,
        }

        const lnbMax = {
          name: _("LNB Hi Frequency:"),
          value: parseInt(ScanManager.antennaConfig[this.antennaInd].antenna_satellite_freq_oscillator2/1000)+"MHz",
        }

        const lnbMin = {
          name: _("LNB Low Frequency:"),
          value: parseInt(ScanManager.antennaConfig[this.antennaInd].antenna_satellite_freq_oscillator1/1000)+"MHz",
        }
        console.log(this.diseqcList, this.selectedDiseqc)
        const diseqc = {
          name: _("DiSEqC:"),
          value: this.diseqcList[this.selectedDiseqc].label,
        }
        bus.emit("diseqc:selected", this.diseqcList[this.selectedDiseqc].value[0].antenna_transmitter_id)
        this.optionList = [lnbPower, lnbMax, lnbMin, diseqc]
        return super.load()
      })
      .then(() => {
        resolve()
      })
    })
  }


  input(kbd, keynum) {
    const value = this.optionList[this.selectedIdx].value
    switch (this.selectedIdx) {
    case 1:
      if (value.substring(0, value.length-3).length<5) {
        this.optionList[1].value = value.substring(0, value.length-3)+ keynum +"MHz"
        super.load()
      }
      break
    case 2:
      if (value.substring(0, value.length-3).length<5) {
        this.optionList[2].value = value.substring(0, value.length-3)+ keynum +"MHz"
        super.load()
      }
      break
    default:
      break
    }
  }


  up() {
    return super.up()
  }

  down() {
    return super.down()
  }

  selectDiseqc(idx) {
    if (idx < 0 && this.selectedDiseqc === 0) {
      this.selectedDiseqc = this.diseqcList.length - 1
    } else if (idx > 0 && this.selectedDiseqc === this.diseqcList.length - 1) {
      this.selectedDiseqc = 0
    } else {
      this.selectedDiseqc += idx
    }

  /*  if (this.diseqcList[this.selectedDiseqc].assigned) {
      this.selectDiseqc(idx)
    }

    if (this.selectedDiseqc > 0) {
      this.diseqcList[this.selectedDiseqc].assigned = true
      this.diseqcList[this.selectedDiseqc].value.antenna_transmitter_id = this.currentTpSetId
    }
    */
    this.optionList[3].value = this.diseqcList[this.selectedDiseqc].label
    this.getAntennaConfigIndex(("DISEQC_"+this.optionList[3].value).toUpperCase())
    bus.emit("diseqc:selected", this.diseqcList[this.selectedDiseqc].value[0].antenna_transmitter_id)
    super.load()
  }

  selectLnbType(idx) {
    if (idx < 0 && this.selectedLnbType === 0) {
      this.selectedLnbType = this.lnbTypeList.length - 1
    } else if (idx > 0 && this.selectedLnbType === this.lnbTypeList.length - 1) {
      this.selectedLnbType = 0
    } else {
      this.selectedLnbType += idx
    }
  //  this._updateLnb()
    super.load()
  }

  selectLnbPower(idx) {
    if (idx < 0 && this.selectedLnbPower === 0) {
      this.selectedLnbPower = this.lnbPowerList.length - 1
    } else if (idx > 0 && this.selectedLnbPower === this.lnbPowerList.length - 1) {
      this.selectedLnbPower = 0
    } else {
      this.selectedLnbPower += idx
    }
//    this._updateLnb()
    this.optionList[0].value = this.lnbPowerList[this.selectedLnbPower].label
    super.load()
  }

  left() {
    const value = this.optionList[this.selectedIdx].value
    switch (this.selectedIdx) {
    case 0:
      this.selectLnbPower(-1)
      this.optionList[0].value = this.lnbPowerList[this.selectedLnbPower].label
      break
    case 1:
      // this.selectLnbType(-1)
      if (value.substring(0, value.length-3).length>1) {
        this.optionList[1].value = value.substring(0, value.length-4)+"MHz"
        super.load()
      } else if (value.substring(0, value.length-3).length===1) {
        this.optionList[1].value = ""
        super.load()
      }
      break
    case 2:
        // this.selectLnbType(-1)
      if (value.substring(0, value.length-3).length>1) {
        this.optionList[2].value = value.substring(0, value.length-4)+"MHz"
        super.load()
      } else if (value.substring(0, value.length-3).length===1) {
        this.optionList[2].value = ""
        super.load()
      }
      break
    case 3:
      this.selectDiseqc(-1)
      break
    default:
      break
    }
  }

  right() {
    switch (this.selectedIdx) {
    case 0:
      this.selectLnbPower(1)
      break
    case 3:
      this.selectDiseqc(1)
      break
    default:
      break
    }
  }

}

export default {
  IFTOIF,
  Satellite,
  LNB,
}
