//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {isDefined} from "utils"

import config from "utils/config"

export default class AbstractSetting extends Controller {
  constructor() {
    super()
    this.selectedIndex = 0
    this.editing = false
    this.keyToNum = {}

    for (const key in config.KEYMAP) {
      if (key.startsWith("KEY_")) {
        const keynum = Number(key.substring(4))
        this.keyToNum[config.KEYMAP[key]] = keynum.toString()
      }
    }
  }

  open() {
    this.view.show()
    this.load()
    return Promise.resolve()
  }

  close() {
    this.editing = false
    this.view.hide()
    return Promise.resolve()
  }

  onOk() {
    if (this.editing) {
      this.setOption()
    } else {
      this.select()
    }
  }

  onBack(kbd) {
    if (this.editing) {
      this.updateOption(kbd)
      return Promise.reject("AbstracSettings:onBack => currently editing, so close() won't be called")
    } else {
      this.close()
      return Promise.resolve()
    }
  }

  onInput(kbd) {
    if (this.editing) {
      this.updateOption(kbd)
    }
  }

  moveUp() {
    if (this.selectedIndex === 0 || this.editing) {
      return
    }
    this.selectedIndex--
    return this.optionList[this.selectedIndex]
  }

  moveDown() {
    if (this.selectedIndex === this.optionList.length - 1 || this.editing) {
      return
    }
    this.selectedIndex++
    return this.optionList[this.selectedIndex]
  }

  select() {
    const signal = this.optionList[this.selectedIndex].action
    const option = this.optionList[this.selectedIndex].option
    bus.emit(signal, option)
  }

  editOption() {
    this.editing = true
    const selectedMenu = this.optionList[this.selectedIndex]
    const selectedOption = selectedMenu.option
    const selectedValue = selectedMenu.value
    this.kbdInputs[selectedOption] = selectedValue.toString().split("")
  }

  updateOption(kbd) {
    const selectedMenu = this.optionList[this.selectedIndex]
    const selectedOption = selectedMenu.option
    const kbdInputs = this.kbdInputs[selectedOption]

    // handle kbdInputs
    if (kbd.which === config.KEYMAP.LEFT || kbd.which === config.KEYMAP.BACK) {
      kbdInputs.pop()
    } else if (kbd.which === config.KEYMAP.STOP) {
      return this.cancelOption()
    } else if (this.maxInputs && kbdInputs.length >= this.maxInputs) {
      Promise.resolve()
    } else {
      let kbdNum = this.keyToNum[kbd.which]
      if (isDefined(kbdNum)) {
        if (kbdInputs.length === 0 && kbdNum === "0") {
          kbdNum = "1"
        }
        kbdInputs.push(kbdNum)
      }
    }
    return kbdInputs
  }

  cancelOption() {
    this.editing = false
    const selectedMenu = this.optionList[this.selectedIndex]
    const selectedOption = selectedMenu.option
    const kbdInputs = selectedMenu.value.split("")
    this.kbdInputs[selectedOption] = kbdInputs
    return kbdInputs
  }

  setOption() {
    this.editing = false
    const selectedMenu = this.optionList[this.selectedIndex]
    const selectedOption = selectedMenu.option
    const kbdInputs = this.kbdInputs[selectedOption]
    selectedMenu.value = kbdInputs.join("")
  }
}
