//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {pushState, pullState} from "utils/dom"
import {createTicker} from "utils"
import {on} from "services/events"
import {$} from "widgets/Component"
import {_} from "utils/locale"

import {subscriptionStatus} from "services/api/transponders"
import {removeAllTune} from "services/api/scan"

import {
  PlayerManager,
  PVRManager,
  StorageManager,
  ChannelManager,
  CasManager,
  FtaBlockManager,
  InstantMessageManager,
  transponders,
} from "services/managers"

import {recordTPListConflict} from "app/utils/PopUpMsg"
import {ListObj} from "app/utils/widgets/lists"
import {myAccountTimestampToDate, formatDateOnly} from "utils/date"

import AbstractSetting from "../AbstractSetting"
import TransponderInfo from "./TransponderInfo"
import CasInfoSheet from "./CasInfoSheet"

const  TPInfo = {
  name: _("Transponder Information"),
  action: "STBInfoSheet: ok",
}

const connected = _("Connected")
const notConnected = _("Not Connected")

const StbInfoConst = Object.freeze({
  GbConvertor:(1024*1024*1024),
  REFRESH_INTERVAL: 15000, // milliseconds
  ZERO_INDEX: 0,
  FIRST_INDEX:1,
  THIRD_INDEX: 3,
  PAGE_SIZE:4,
})

export default class STBInfoSheetController extends AbstractSetting {

  static delegates = [
    TransponderInfo,
    CasInfoSheet,
  ]

  constructor() {
    super()
    this.optionList = [TPInfo]
    this.hdd = null
    this.BtnList = 0
    this.selectedBtnIndex = 0
    this.cashDelegate = false
    this.cashActive = CasManager.cashActive
    this.isSubPkgSelected =false
    this.pageNumber=1
    this.responseArr=[]
    this.clockUpdater = createTicker(StbInfoConst.REFRESH_INTERVAL)
    this.view = $("stbInfoSheet")
  }

  open(sub) {
    this.clockUpdater.start(() => this.updateClock())
    this.sub = sub
    sub.date = new Date()
    this.updateMenuTitle()
    if (!sub.hideStbInfo) this.view.onForeground()
    return super.open()
    .then(() => {
      this.getSubscriptions()
      .then(() => {
        this.load()
      })
    })
  }

  updateMenuTitle() {
    this.view.updateTitleForFta()
  }

  @on("STBInfoSheet:ok")
  onOk() {
    if (!this.isSubPkgSelected) {
      if (PVRManager.ongoing.length > 0) {
        this.showRecordTPInfoPopUp()
      } else {
        if (this.activeDelegate) return
        this.resetSubscriptionVariable()
        this.TransponderInfo.view.deleteTransList()
        this.activeDelegate = this.TransponderInfo
        bus.emit("setting:transponder:open")
      }
    }
  }

  showRecordTPInfoPopUp() {
    const buttons = [{
      label: "OK",
      action: () => {
        // stopping recording
        PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
        if (this.activeDelegate) return
        this.TransponderInfo.view.deleteTransList()
        this.activeDelegate = this.TransponderInfo
        bus.emit("setting:transponder:open")
      },
    },{
      label: "BACK",
      action: () => {
      // moving back to STBInfo Screen
      },
    },
    ]
    recordTPListConflict(buttons)
  }

  @on("blackuniverse:close:stbInfoSheet")
  onBack() {
    if (this.activeDelegate === null && this.cashDelegate === false) {
      InstantMessageManager.isCAmenuOpen = false
    }
    transponders.isTPListScreen = false
    if (this.activeDelegate === this.TransponderInfo
      || (FtaBlockManager.isNavigationRestricted() && FtaBlockManager.ftaPopupStatus.page)) {
      this.TransponderInfo.resetTransponder()
      this.TransponderInfo.stopTransStatus = true
      this.TransponderInfo.view.onBackground()
      this.loadSubscriptions(StbInfoConst.ZERO_INDEX, StbInfoConst.PAGE_SIZE)
      this.showHidearrow()
      this.onLeft()
      this.view.onForeground()
      this.activeDelegate = null
      if (PlayerManager._state !== 11) PlayerManager.playCurrentChannel(ChannelManager.current)
      removeAllTune()
      return Promise.reject()
    } else if ((this.cashDelegate === true) && (this.cashActive === true)) {

      // Back press on Cas Information page
      this.CasInfoSheet.view.onBackground()
      this.loadSubscriptions(StbInfoConst.ZERO_INDEX,StbInfoConst.PAGE_SIZE)
      this.onLeft()
      this.view.onForeground()
      this.cashDelegate = false
      if (ChannelManager.current) {
        CasManager.getPlayerSubscribeInfo(ChannelManager.current.lcn)
      }
      return Promise.reject()
    } else {
      this.resetVariable()
      this.resetSubscriptionVariable()
      this.view.onBackground()
      this.TransponderInfo.view.deleteTransList()
      if (PlayerManager._state !== 11) PlayerManager.playCurrentChannel(ChannelManager.current)
      return Promise.resolve()
    }
  }

  @on("STBInfoSheet:close")
  close() {
    if (this.activeDelegate === null && this.cashDelegate === false) {
      InstantMessageManager.isCAmenuOpen = false
    }

    if (this.activeDelegate === this.TransponderInfo) {
      this.activeDelegate = null
      removeAllTune()
    }

    this.TransponderInfo.view.deleteTransList()
    this.view.onBackground()
    this.TransponderInfo.resetTransponder()
    this.resetVariable()
    this.resetSubscriptionVariable()
    this.TransponderInfo.stopTransStatus = true
    this.TransponderInfo.view.onBackground()

    if ((this.cashDelegate === true)  && (this.cashActive === true)) {

      // Home Press on Cas Information page
      this.CasInfoSheet.view.onBackground()
      this.cashDelegate = false
      if (ChannelManager.current) {
        CasManager.getPlayerSubscribeInfo(ChannelManager.current.lcn)
      }
    }

    if (PlayerManager._state && PlayerManager._state !== 11) {
      if (ChannelManager.current) {
        PlayerManager.playCurrentChannel(ChannelManager.current)
      }
    }
    this.selectedBtnIndex = 0
  }
  @on("STBInfoSheet:unfold")
  onUnfold() {
    this.view.onBackground()
  }

  @on("STBInfoSheet:updatehd")
  updateStrogeDetails() {
    this.hdd ={}
    this.hdd.hddSize = (StorageManager.USB_size === null) ?
        notConnected:connected + ` ${(Math.round((StorageManager.USB_size/StbInfoConst.GbConvertor)*100))/100} GB`
    if (StorageManager.UsbStorageDetail) {
      this.hdd.freeSize =
        (StorageManager.UsbStorageDetail.free_size === 0 && StorageManager.UsbStorageDetail.used_size === 0)?
       "--":`${(Math.round((StorageManager.UsbStorageDetail.free_size/StbInfoConst.GbConvertor)*100))/100} GB`
    } else {
      this.hdd.freeSize = "--"
    }
    this.view.updateHddDetails(this.hdd)
  }

  load() {
    if (StorageManager.UsbStorageDetail) {
      this.sub.hddSize = connected + ` ${(Math.round((StorageManager.USB_size/StbInfoConst.GbConvertor)*100))/100} GB`
      this.sub.freeSize = `${(Math.round((StorageManager.UsbStorageDetail.free_size/
        StbInfoConst.GbConvertor)*100))/100} GB`
    } else {
      this.sub.hddSize = notConnected
      this.sub.freeSize = "--"
    }
    this.view.onLoad(this.sub)
    this.loadSubscriptions(StbInfoConst.ZERO_INDEX, StbInfoConst.PAGE_SIZE)
    this.view.loadSubscriptions()
    this.onLeft()
    // Select Default first button on every load
    this.selectedBtnIndex = 0
    this.view.onMoveUp()

    // If Cas feature enable then show both button cas information button and transpord information button
    if (this.cashActive) {
      this.view.CasBtnShow()
    }

    // If Cas feature disbale then hide cas information button
    if (!this.cashActive) {
      this.view.CasBtnHide()
    }
    // FTA active then show 2 color button Functionality and
    // hide cas information button and transpord information button
    const isFtaActive = FtaBlockManager.isNavigationRestricted()
    if (isFtaActive) {
      this.view.onBtnShow()
      this.view.updateTitleForFta()
    }
    // FTA diactive then hide 2 color button Functionality
    // show cas information button and transpord information button
    if (!isFtaActive) {
      this.view.onBtnClose()
    }
  }
  updateClock() {
    this.view.updateClock(new Date())
  }

  moveUp() {
    if (this.activeDelegate) {
      this.activeDelegate.moveUp()
    } else {
      if (this.isSubPkgSelected) {
        if (this.SubscriptionListObj.selected % StbInfoConst.PAGE_SIZE === StbInfoConst.ZERO_INDEX) {
          if (this.pageNumber !== StbInfoConst.FIRST_INDEX) {
            /** for first element of any page other than 1st page**/
            this.pageNumber--
            const pageupStartIndex = ((this.pageNumber - StbInfoConst.FIRST_INDEX) * StbInfoConst.THIRD_INDEX)
            + (this.pageNumber - StbInfoConst.FIRST_INDEX)
            const pageupLastIndex = ((this.pageNumber - StbInfoConst.FIRST_INDEX) * StbInfoConst.THIRD_INDEX) +
            StbInfoConst.PAGE_SIZE + (this.pageNumber - StbInfoConst.FIRST_INDEX)
            this.loadSubscriptions(pageupStartIndex, pageupLastIndex)
            this.SubscriptionListObj.selected = StbInfoConst.PAGE_SIZE
          }
        }
        this.SubscriptionListObj.up()
        this.l2Page = this.pageNumber
        this.showHidearrow()
      } else {
        this.selectedBtnIndex = 0
        this.view.onMoveUp()
      }
    }
  }

  moveDown() {
    if (this.activeDelegate) {
      this.activeDelegate.moveDown()
    } else {
      if (this.isSubPkgSelected) {
        let isPerfectLength = null
        isPerfectLength = (this.responseArr.length %StbInfoConst.PAGE_SIZE === 0) ? true : false
        if (isPerfectLength) {
          if (this.SubscriptionListObj.selected % StbInfoConst.THIRD_INDEX === 0 &&
            this.SubscriptionListObj.selected !== StbInfoConst.ZERO_INDEX) {
              /** for last element of any page except last page **/
            if (this.pageNumber !== (this.responseArr.length /StbInfoConst.PAGE_SIZE)) {
              const pagedownStartIndex = (this.pageNumber * StbInfoConst.THIRD_INDEX) + this.pageNumber
              const pagedownLastIndex = (this.pageNumber * StbInfoConst.THIRD_INDEX) +
              StbInfoConst.PAGE_SIZE + this.pageNumber
              this.pageNumber++
              this.loadSubscriptions(pagedownStartIndex, pagedownLastIndex)
            }
          } else {
            /** for up  movement on any other element on al pages except last **/
            this.SubscriptionListObj.down()
          }
          this.l2Page = this.pageNumber
          this.showHidearrow()
        }
        if (!isPerfectLength) {
          if (this.SubscriptionListObj.selected % StbInfoConst.THIRD_INDEX === 0 &&
            this.SubscriptionListObj.selected !== StbInfoConst.ZERO_INDEX) {
            /** for last element of any page except last page **/
            const pagedownStartIndex = (this.pageNumber * StbInfoConst.THIRD_INDEX) + this.pageNumber
            const pagedownLastIndex = (this.pageNumber * StbInfoConst.THIRD_INDEX) +
            StbInfoConst.PAGE_SIZE + this.pageNumber
            this.pageNumber++
            this.loadSubscriptions(pagedownStartIndex, pagedownLastIndex)
          } else {
            /** for up  movement on any other element on al pages except last **/
            this.SubscriptionListObj.down()
          }
          this.l2Page = this.pageNumber
          this.showHidearrow()
        }
      }
      if (this.cashActive && !this.isSubPkgSelected) {
        this.selectedBtnIndex = 1
        this.view.onMoveDown()
      }
    }
  }

  onLeft() {
    this.isSubPkgSelected = false
    if (this.SubscriptionArr.length >0)
      pushState(this.view.SubscriptionList.SubscriptionList.selector.SubscriptionSelector, "hidden")
    this.showHideSelectedButton(`show_${this.selectedBtnIndex}`)
    this.view.showRightArrow()
  }

  onRight() {
    if (this.SubscriptionArr.length >0) {
      this.isSubPkgSelected = true
      pullState(this.view.SubscriptionList.SubscriptionList.selector.SubscriptionSelector, "hidden")
      this.showHideSelectedButton(`hide_${this.selectedBtnIndex}`)
      this.view.showLeftArrow()
    }
  }

//* to hide and show the selected button when
// focus moves to the Package list from the ButtonList
//* .
  showHideSelectedButton(btnState) {
    switch (btnState) {
    case "show_0":
      pushState(this.view.tranponderNameBtn, "selected")
      break
    case "show_1":
      pushState(this.view.casNameBtn, "selected")
      break
    case "hide_0":
      pullState(this.view.tranponderNameBtn, "selected")
      break
    case "hide_1":
      pullState(this.view.casNameBtn, "selected")
      break
    default:
    }
  }

  showHidearrow() {
    if (this.responseArr.length > 0) {
      if ((this.SubscriptionListObj.selected === StbInfoConst.ZERO_INDEX) &&
      this.pageNumber === StbInfoConst.FIRST_INDEX) {
        this.view.SubscriptionList.hideBeforeArrow()
      } else if ((this.pageNumber === (Math.ceil(this.responseArr.length /(StbInfoConst.PAGE_SIZE))))&&
          (this.SubscriptionListObj.selected ===
            ((this.responseArr.length -(((this.pageNumber-1)*StbInfoConst.PAGE_SIZE)))-1))) {
        this.view.SubscriptionList.hideAfterArrow()
      } else {
        this.view.SubscriptionList.ShowAllArrow()
      }
    }
  }

  // Open cas information page
  @on("STBInfoSheet:CasStbinfoOpen")
  CasStbinfoOk() {
    if (!this.isSubPkgSelected) {
      if (this.activeDelegate) return
      this.view.onBackground()
      CasManager.getCaMenuInformation().then((data) => {
        const item = {
          title: _("CA Information"),
          context: "CAInfo",
          label: _("Return to STB InfoSheet"),
          data: data,
        }
        this.CasInfoSheet.open(item)
        bus.emit("UnsubscribedErrorMsg:close")
      }).catch((err) => {
        console.log(err)
        const data = {
          "CA_SYS_ID:": "NOT AVAILABLE",
          "Chip ID:": "NOT AVAILABLE",
          "Security client version:": "NOT AVAILABLE",
        }
        const item = {
          title: _("CA Information"),
          context: "CAInfo",
          label: _("Return to STB InfoSheet"),
          data: data,
        }
        this.CasInfoSheet.open(item)
        bus.emit("UnsubscribedErrorMsg:close")
      })
    }
  }

  // OK Functionality on Cas Information page
  @on("CasInfoSheet:ok")
  onCashOk() {
    this.CasInfoSheet.view.onBackground()
    this.view.onForeground()
    this.cashDelegate = false
    if (ChannelManager.current) {
      CasManager.getPlayerSubscribeInfo(ChannelManager.current.lcn)
    }
  }

/* get the list of subscription from api */
  getSubscriptions() {
    return subscriptionStatus()
    .then((rsp)=>{
      if (rsp) {
        this.view.showHorizontalArrow()
        this.responseArr = rsp.subsStatus
        let localArr = []
        const priority = 900000
        for (const item of this.responseArr) {
          const obj= {}
          obj.SubscriptionName = this.hexToStringConvertor(item[1])
          obj.priority = priority
          const name = this.splitCharNum(obj.SubscriptionName.trim())
          if (name.length === 2 && !isNaN(name[1]) && isNaN(name[0])) {
            switch (name[0].toUpperCase().trim()) {
            case "D": obj.priority = "1"+this.numbersPad(name[1], 5)
              break
            case "DISHTV": obj.priority = "2"+this.numbersPad(name[1], 4)+"0"
              break
            case "DISH TV": obj.priority = "2"+this.numbersPad(name[1], 4)+"1"
              break
            default:
            }
          }
          obj.CurrentBitSet =  item[2]
          obj.LastBitSet =  item[3]
          obj.CurrentValidStartDate = formatDateOnly(myAccountTimestampToDate(item[4], "s"))
          obj.CurrentValidEndDate =  ` ~   ${formatDateOnly(myAccountTimestampToDate(item[5], "s"))}`
          obj.LastValidStartDate =  formatDateOnly(myAccountTimestampToDate(item[6], "s"))
          obj.LastValidEndDate = ` ~    ${formatDateOnly(myAccountTimestampToDate(item[7], "s"))}`
          localArr.push(obj)
        }
        this.responseArr = localArr
        localArr = null
        this.responseArr.sort(function(a, b) {
          return a.priority - b.priority
        })
        this.LastPage = (Math.ceil(this.responseArr.length % StbInfoConst.PAGE_SIZE))
      }
    })
    .catch((err)=>{
      console.log("err",err)
    })
  }

/*
//loading list of Subscriptions page by page
//the PAGE_SIZE being 4 Subscription per page
*/
  loadSubscriptions(startIndex, lastIndex) {
    this.SubscriptionArr=[]
    if (this.responseArr.length >0) {
      this.focusId = 0
      if (this.l2ID) {
        this.focusId = this.l2ID
        this.l2ID = 0
      }

      this.SubscriptionArr = this.responseArr.slice(startIndex, lastIndex)
      this.SubscriptionListObj = new ListObj(this.SubscriptionArr,this.view.SubscriptionList.SubscriptionList)
    }
  }

  //* Separate Characters and NumbersPad upto 4 Characters *//
  numbersPad(n, width, z) {
    z = z || "0"
    n = n + ""
    return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n
  }

  //* Separate Chanracters and Numbers *//
  splitCharNum(str) {
    return str.split(/(\d+)/)
    .map((elem, i) => i % 2 ? Number(elem) : elem)
    .filter(elem => elem !== "")
  }

  //* Convert the HexDecimal text to String *//
  hexToStringConvertor(hex_string) {
    const hex = hex_string.toString()
    let ascii_string = ""
    for (let i = 0; i < hex.length; i += 2)
      ascii_string += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
    return ascii_string
  }

//* Reset all the variable used for Subscriptions *//
  resetSubscriptionVariable() {
    this.isSubPkgSelected =false
    this.focusId = 0
    this.pageNumber= 1
    this.LastPage = null
  }
  resetVariable() {
    this.SubscriptionArr=[]
    this.responseArr =[]
  }
}
