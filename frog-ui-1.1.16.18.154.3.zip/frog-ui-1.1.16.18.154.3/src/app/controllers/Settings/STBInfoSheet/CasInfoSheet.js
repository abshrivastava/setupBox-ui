//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {createTicker} from "utils"
import {on} from "services/events"
import {$} from "widgets/Component"
import AbstractSetting from "../AbstractSetting"

const REFRESH_INTERVAL = 15000 // milliseconds

export default class CasInfoSheetController extends AbstractSetting {

  constructor() {
    super()
    this.clockUpdater = createTicker(REFRESH_INTERVAL)
    this.view = $("CasInfoSheet")
    this.lastUniverse="settings"
  }
  open(sub) {
    this.view.onForeground()
    this.clockUpdater.start(() => this.updateClock())
    this.sub = sub
    sub.date = new Date()
    return super.open()
  }
  @on("CasInfoSheet:close")
  onBack() {
    this.clockUpdater.stop()
    this.view.onBackground()
    return Promise.resolve()
  }

  load() {
    this.view.onLoad(this.sub)
  }
  updateClock() {
    this.view.updateClock(new Date())
  }
}
