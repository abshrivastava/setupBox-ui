//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"

import {on} from "services/events"
import {TreeObj} from "app/utils/widgets/lists"
import {_} from "utils/locale"

export default class EpgDetailsController extends Controller {
  constructor() {
    super()
    this.selected = 0
    this.actions = []
    this.view = $("epgDetails")
    this.tree = new TreeObj(this.view.actionsTree)
  }

  open(item) {
    this.selected = 0
    this.actions = this._actionsFactory(item)
    this.tree.setItems(0, this.actions)

    return this.view.open(item)
  }

  @on("EpgDetails:close")
  close() {
    this.tree.reset()
    return this.view.close()
  }

  prev() {
    this.tree.up()
  }

  next() {
    this.tree.down()
  }

  trigger() {
    this.tree.trigger()
  }

  _actionsFactory(item) {
    const actions = []
    if (item.obj_class === "CHANNEL_AUDIO") {
      actions.push({
        label: "Listen",
        signal: "epg:watch",
      })
      return actions
    }

    if (item.isOngoing) {
      actions.push({
        label: "Watch",
        signal: "epg:watch",
      })
    } else {
      if (!item.isReminder) {
        const cTm = new Date()
        if (((item.startDate.getTime() - cTm.getTime())/60000) > 2) { // is not in grace period
          actions.push(
            {
              label: _("Set Reminder"),
              signal: "epg:set_reminder",
            })
        }
      } else {
        actions.push({
          label: _("Cancel Reminder"),
          signal: "epg:cancelReminder",
        })
      }
    }

    let manualRecOnGoing = false
    const manualRecords = this.master.getManualRecordsFromServiceId(item.serviceId, item.startDate)
    manualRecords.forEach((manualRec) => {
      if (manualRec.startDate > item.startDate && manualRec.startDate < item.endDate) {
        manualRecOnGoing = true
      }
    })

    if (!item.isReminder && (item.isScheduled || item.isRecording || manualRecOnGoing)) {
      actions.push({
        label: item.isScheduled ? "Cancel Record" : "Stop Record",
        signal: "epg:stop_record",
      })
    } else {
      actions.push({
        label: "Record",
        signal: "epg:record",
      })
    }

    return actions
  }
}
