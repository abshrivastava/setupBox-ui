//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"

import bus from "services/bus"

import {$} from "widgets/Component"

import {epgNoChannels} from "app/utils/PopUpMsg"
import {ListObj} from "app/utils/widgets/lists"
import ChannelManager from "services/managers/ChannelManager"

const ZERO_INDEX = 0
const FIRST_INDEX = 1
const FIFTH_INDEX = 4
const PAGE_SIZE = 5
const PAGE_SIZE_R = 5


export default class EpgFilterController extends Controller {

  constructor() {
    super()
    this.view = $("EpgFilter")
    this.filterpage=0
    this.pageNumberSub=0
    this.allFiltersIds=[]
    this.newFilterArr=[]
    this.pageNumber=1
    this.genreChannels=[]
    this.l1ID = 0
    this.l2Page = 0
    this.selectedFilterId = 999
    this.filtersArray = ChannelManager.getGenreFilterList()
    this.filtersSubArray = []
    this.selectedGenre = ""
  }

  open() {

    if (bus.universe !== "epg") {
      return
    }
    this.pageNumber=1
    this.pageNumberSub=1
    this.l2ID = 0
    this.loadFilters(ZERO_INDEX, PAGE_SIZE)
    this.view.show()
    this.view.showFirstLevelFilter()
    this.filterpage=0

    return Promise.resolve()
  }

  close() {
    return this.onBack(1)
  }

  onBack(closeAll) {
    if (closeAll === 1) {
      return this.view.hideAllFilters()
    }

    if (this.filterpage === 1) {
      this.view.showFirstLevelFilter()
      this.filterpage = 0
      this.pageNumberSub = 1
      if (this.l2Page === 2) {
        this.loadFilters(ZERO_INDEX+PAGE_SIZE, PAGE_SIZE*2)
      } else if (this.l2Page === 3) {
        this.loadFilters(ZERO_INDEX+PAGE_SIZE*2, PAGE_SIZE*3)
      } else if (this.l2Page === 1) {
        this.loadFilters(ZERO_INDEX, PAGE_SIZE)
      }
    } else {
      this.selectedGenre = ""
      return this.view.hideAllFilters()
    }
  }

  moveUp() {
    if (this.filterpage === 0) {
      if (this.filterListObj.selected % PAGE_SIZE === ZERO_INDEX
          && this.filterListObj.selected !== FIRST_INDEX) {
        if (this.pageNumber === FIRST_INDEX) {
          this.pageNumber =(Math.ceil(this.filtersArray.length /PAGE_SIZE))
          const pageupStartIndex = ((this.pageNumber - FIRST_INDEX) * FIFTH_INDEX) + (this.pageNumber - FIRST_INDEX)
          const pageupLastIndex = ((this.pageNumber - FIRST_INDEX) * FIFTH_INDEX) +
          PAGE_SIZE + (this.pageNumber - FIRST_INDEX)
          this.loadFilters(pageupStartIndex, pageupLastIndex)
          this.filterListObj.selected = (this.filtersArray.length %PAGE_SIZE)
        } else {
          this.pageNumber--
          const pageupStartIndex = ((this.pageNumber - FIRST_INDEX) * FIFTH_INDEX) + (this.pageNumber - FIRST_INDEX)
          const pageupLastIndex = ((this.pageNumber - FIRST_INDEX) * FIFTH_INDEX) +
          PAGE_SIZE + (this.pageNumber - FIRST_INDEX)
          this.loadFilters(pageupStartIndex, pageupLastIndex)
          this.filterListObj.selected = PAGE_SIZE
        }
      }
      this.l2Page = this.pageNumber
      this.filterListObj.up()

    } else if (this.filterpage === 1) {
      if (this.filterSubListObj.selected % PAGE_SIZE_R === ZERO_INDEX
        && this.filterSubListObj.selected !== FIRST_INDEX) {
        if (this.pageNumberSub === FIRST_INDEX) {
          this.pageNumberSub =(Math.ceil(this.filtersSubArray.length /PAGE_SIZE_R))
          const pageupStartIndex = ((this.pageNumberSub - FIRST_INDEX) * (FIFTH_INDEX))
          + (this.pageNumberSub - FIRST_INDEX)
          const pageupLastIndex = this.filtersSubArray.length
          if (this.filterSubListObj.items[0].id !== 999 && pageupStartIndex <= this.filtersSubArray.length) {
            this.loadSubFilters(pageupStartIndex, pageupLastIndex, 888)
            this.filterSubListObj.selected = this.filtersSubArray.length-((this.pageNumberSub-FIRST_INDEX)*PAGE_SIZE_R)
          } else {
            this.filterSubListObj.selected = (this.filtersSubArray.length)
          }
        } else {
          this.pageNumberSub--
          const pageupStartIndex = ((this.pageNumberSub - FIRST_INDEX) * (FIFTH_INDEX))
          + (this.pageNumberSub - FIRST_INDEX)
          const pageupLastIndex = ((this.pageNumberSub - FIRST_INDEX) * (FIFTH_INDEX)) +
          PAGE_SIZE_R + (this.pageNumberSub - FIRST_INDEX)
          if (this.filterSubListObj.items[0].id !== 999 && pageupLastIndex <= this.filtersSubArray.length) {
            this.loadSubFilters(pageupStartIndex, pageupLastIndex, 888)
            this.filterSubListObj.selected = PAGE_SIZE_R
          }
        }
      }
      this.filterSubListObj.up()
    }
  }

  moveDown() {
    if (this.filterpage === 0) {
      if (this.filterListObj && this.filterListObj.selected % FIFTH_INDEX === 0 &&
        this.filterListObj.selected !== ZERO_INDEX) {
        const pagedownStartIndex = (this.pageNumber * FIFTH_INDEX) + this.pageNumber
        const pagedownLastIndex = (this.pageNumber * FIFTH_INDEX) + PAGE_SIZE + this.pageNumber
        this.loadFilters(pagedownStartIndex, pagedownLastIndex)
        this.pageNumber++
      } else if ((this.pageNumber === (Math.ceil(this.filtersArray.length /(PAGE_SIZE))))&&
        this.filterListObj.selected === ZERO_INDEX) {
        const pagedownStartIndex = ZERO_INDEX
        const pagedownLastIndex = PAGE_SIZE
        this.loadFilters(pagedownStartIndex, pagedownLastIndex)
        this.pageNumber = FIRST_INDEX
      } else {
        this.filterListObj.down()
      }
      this.l2Page = this.pageNumber
    } else if (this.filterpage === 1) {
      if ((this.filtersSubArray.length-((this.pageNumberSub-1)*PAGE_SIZE_R) - 1) === this.filterSubListObj.selected &&
      (this.pageNumberSub === (Math.ceil(this.filtersSubArray.length /PAGE_SIZE_R)))) {
        if (this.filterListObj.items[this.filterListObj.selected].id === 888) {
          if (this.filterSubListObj.selected === 0
            && this.filterSubListObj.selected === this.filterSubListObj.items.length-1) {
            this.pageNumberSub = 1
            this.loadSubFilters(ZERO_INDEX, PAGE_SIZE_R, 888)
          }
        } else {
          if (this.filterSubListObj.selected === this.filterSubListObj.items.length-1) {
            this.filterSubListObj.select(0)
          }
        }
      } else if (this.filterSubListObj.selected % (FIFTH_INDEX) === 0 &&
        this.filterSubListObj.selected !== ZERO_INDEX &&
        (this.pageNumberSub !== (Math.ceil(this.filtersSubArray.length /PAGE_SIZE_R)))) {

        const pagedownStartIndex = (this.pageNumberSub * (FIFTH_INDEX)) + this.pageNumberSub
        let pagedownLastIndex = (this.pageNumberSub * (FIFTH_INDEX)) + PAGE_SIZE_R + this.pageNumberSub
        if (pagedownLastIndex > this.filtersSubArray.length) pagedownLastIndex = this.filtersSubArray.length

        if (this.filterSubListObj.items[0].id !== 999 && pagedownLastIndex<= this.filtersSubArray.length) {
          this.loadSubFilters(pagedownStartIndex, pagedownLastIndex, 888)
          this.pageNumberSub++
        }
      } else if ((this.pageNumberSub === (Math.ceil(this.filtersSubArray.length /PAGE_SIZE_R))) &&
        (this.filtersSubArray.length ===
        ((this.filterSubListObj.selected * this.pageNumberSub) +this.pageNumberSub)))   {
        const pagedownStartIndex = ZERO_INDEX
        const pagedownLastIndex = PAGE_SIZE_R
        if (this.filterSubListObj.items[0].id !== 999 && pagedownLastIndex<= this.filtersSubArray.length) {
          this.loadSubFilters(pagedownStartIndex, pagedownLastIndex, 888)
          this.pageNumberSub = FIRST_INDEX
        } else {
          this.loadSubFilters(ZERO_INDEX, PAGE_SIZE_R, 999)
        }
      } else {
        this.filterSubListObj.down()
      }
    }
  }

  trigger(defaultGrid) {
    const index = defaultGrid ? 0 : ((this.pageNumber - FIRST_INDEX) * PAGE_SIZE) +
    this.view.EpgFirstFilterList.focusedIdx
    let focusedGenre = this.filtersArray[index]
    this.l1ID = focusedGenre
    if (this.filterpage === 0) {
      if (focusedGenre.id === 1 || focusedGenre.id === 4 || focusedGenre.id === 6 || focusedGenre.id === 888) {
        this.l2ID = this.view.EpgFirstFilterList.focusedIdx
        this.selectedFilterId = focusedGenre.id
        this.view.showSecondLevelFilter(focusedGenre)
        this.filterpage=1
        this.selectedGenre = focusedGenre.title
        this.loadSubFilters(ZERO_INDEX, PAGE_SIZE_R,focusedGenre.id)
      } else {
        ChannelManager.getChannelsByGenre([focusedGenre.id])
        .then(() =>  {

          if (ChannelManager.channelsForGenre.length === 0) {
            epgNoChannels()
            return
          }
          this.selectedFilterId = 999
          this.filterpage=0
          defaultGrid || this.view.hide()
          this.selectedGenre = focusedGenre.title
          bus.emit("epg:opengrid")
          bus.emit("channels:genreUpdated")
        })
      }
    } else if (this.filterpage === 1) {
      focusedGenre = this.filtersSubArray[((this.pageNumberSub - FIRST_INDEX) * PAGE_SIZE_R) +
      this.view.EpgSecondFilterList.focusedIdx]
      const arr = []
      if (this.selectedFilterId!==999 && this.selectedFilterId!==888) {
        arr.push(this.selectedFilterId)
      }
      if (focusedGenre.id!==999) {
        arr.push(focusedGenre.id)
      }
      ChannelManager.getChannelsByGenre(arr)
      .then(() =>  {
        if (ChannelManager.channelsForGenre.length === 0) {
          epgNoChannels()
          return
        }
        this.filterpage=0
        this.view.hide()
        if (this.selectedGenre === "Regional") {
          this.selectedGenre = focusedGenre.title
        }

        bus.emit("epg:opengrid")
        bus.emit("channels:genreUpdated")
      })
    }
    return
  }



  defaultTrigger() {
    const focusedGenre = this.filtersArray[0]
    this.l1ID = focusedGenre
    this.filterpage=0
    if (ChannelManager.channels.length === 0 && bus.universe === "epg") {
      epgNoChannels()
      return Promise.resolve(true)
    }
    this.selectedFilterId = 999
    this.filterpage=0
    this.selectedGenre = focusedGenre.title
    return Promise.resolve()
  }


  loadFilters(startIndex, lastIndex) {
    let focusId = 0
    if (this.l2ID) {
      focusId = this.l2ID
      this.l2ID = 0
    }

    this.newFilterArr=[]
    const FiltersList = this.filtersArray.slice(startIndex, lastIndex)
    for (let iCounter = 0; iCounter < FiltersList.length; iCounter++) {
      const obj = {}
      obj.label = FiltersList[iCounter].title
      obj.id = FiltersList[iCounter].id
      this.newFilterArr.push(obj)
    }
    this.filterListObj = new ListObj(this.newFilterArr,this.view.EpgFirstFilterList)
    this.filterListObj.select(Number(focusId))
  }

  loadSubFilters(sI, lI, filterId) {
    this.subfilterArray=[]
    this.filtersSubArray = ChannelManager.getGenreSubFilterList(filterId)
    const fl = this.filtersSubArray.slice(sI, lI) // this.filtersArray.slice(sI, lI)
    for (let iCounter = 0; iCounter < fl.length; iCounter++) {
      const obj = {}
      obj.label = fl[iCounter].title
      obj.id = fl[iCounter].id
      this.subfilterArray.push(obj)
    }
    this.filterSubListObj = new ListObj(this.subfilterArray,this.view.EpgSecondFilterList)
    this.filterSubListObj.select(0)
    this.filterpage = 1

  }

}
