//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Controller from "utils/Controller"
import {on} from "services/events"
import {$} from "widgets/Component"

export default class NotificationController extends Controller {
  constructor() {
    super()
    this.tvView = $("tvNotification")
    this.radioView = $("radioNotification")
    this.notificationToDisplay = false
  }

  @on("player:nosignal")
  _showNosignalMsg() {
    this.notificationToDisplay = true
    this.tvView.showNoTvMessage()
    this.radioView.showNoTvMessage()
  }

  @on("player:signal")
  _hideNosignalMsg() {
    this.notificationToDisplay = false
    this.tvView.hideNoTvMessage()
    this.radioView.hideNoTvMessage()
  }

  @on("player:scrambled")
  _showScrambledMsg() {
    this.notificationToDisplay = true
    this.tvView.showScrambledMessage()
    this.radioView.showScrambledMessage()
  }

  @on("player:descrambled")
  _hideScrambledMsg() {
    this.notificationToDisplay = false
    this.tvView.hideScrambledMessage()
    this.radioView.hideScrambledMessage()
  }

  @on("bus:universe")
  onBusUniverse(universe) {
    switch (universe) {
    case "tv":
    case "home":
    case "radio":
      this.toggleDisplay(true)
      break
    default:
      this.toggleDisplay(false)
      break
    }
  }

  toggleDisplay(toDisplay) {
    if (toDisplay && this.notificationToDisplay) {
      this.tvView.show()
      // this.radioView.show()
    } else {
      this.tvView.close()
      // this.radioView.close()
    }
  }
}
