//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {putReset} from "services/api/reset"
import {locale} from "utils/locale"
import {
  ScanManager,
  PlayerManager,
  ChannelManager,
  TimezoneManager,
  FtaBlockManager,
  PowerManager,
  VersionManagers,
  PVRManager} from "services/managers"

import SoftwareUpdateManager from "services/managers/SoftwareUpdateManager"
import CasManager from "services/managers/CasManager"
import InstantMessageManager from "services/managers/InstantMessageManager"
import {PUT} from "services/http"
import {getAvio} from "services/api/config"
import {setUIReady, updateAvio, getTimeFormat,
  updateDefaultTrack,fetchPersistancAudioLang,
  getLocale, getIFtoIF, updateIFtoIF, getDiseqcType, setup as configSetup,
  getFirstInstall} from "services/managers/config"

const ONBOOT = Object.freeze({
  INSTALLATION:"installation",
  SCAN: "launchEasyScan",
  HOME:"home",
  FTA_ACTIVE:3,
  FTA_BLOCK:"block",
  LANDING_CHANNEL : 99,
  ADSCATALOG :208,
})

export default class SplashController extends Controller {

  constructor() {
    super()
    this.play = false
    this.active = false
  }

  updateDefaultChannelInfo() {
    return PowerManager.getDynamicDefaultLC()
      .then((defaultChannel) => {
        return PlayerManager.getInitialId().then((initialId) => {
          const channel = ChannelManager.getChannelFromServiceId(initialId)
          if (channel === null) {
            this.play = true
          }
          defaultChannel = (channel && channel.lcn)  ? channel.lcn :  defaultChannel
          if (defaultChannel > 0) {
            return defaultChannel
          } else {
            return ONBOOT.LANDING_CHANNEL
          }
        })
      })
    .then((currentChannel) => {
      return ChannelManager.getChannelZapInformation(currentChannel)
    })
    .then((response) => {
      const channel = response.resource.real || response.resource.fallback
      ChannelManager.setCurrent(channel)
      return channel
    })
  }

  startLoading() {
    return new Promise((resolve) => {
      setUIReady().then(() => {
        SoftwareUpdateManager.fetchSoftwareVersion()
        resolve(true)
      })
      .catch(() => {
        SoftwareUpdateManager.fetchSoftwareVersion()
        resolve(true)
      })
    })
  }

  startup() {
    return new Promise((resolve) => {
      this.startLoading().then(() => {
        return this.initialize()
      })
      .then(()=>{
        return Promise.all([getFirstInstall(), ScanManager.checkSvlVersionChange(),
          VersionManagers.getDvbUri(ONBOOT.ADSCATALOG)])
      })
      .then(([fiVal, status, isDvbUri])=> {
        if (fiVal) {
          const item = {format : "1280x720@50p"}
          PUT("/player/config/output/avio_output_hdmi0/", item)
          ScanManager.isFirstInstall = true
          resolve(ONBOOT.INSTALLATION)
        } else if (status === ONBOOT.SCAN || isDvbUri === false) {
          resolve(ONBOOT.SCAN)
        } else {
          FtaBlockManager.callFromBoot = true
          FtaBlockManager.setFTAflag(true)
          return FtaBlockManager.isFtaBlockMode()
          .then((response)=> {
            if (response === ONBOOT.FTA_ACTIVE) this.active = true
            return this.updateDefaultChannelInfo()
          })
          .then((channel) => {
            if (channel && this.active && this.play) {
              PlayerManager.play(channel)
            }

            if (this.active) {
              resolve(ONBOOT.HOME)
            } else {
              resolve(ONBOOT.FTA_BLOCK)
            }

          })
        }
      })
      .catch((error) => {
        resolve(error)
      })
    })
  }

  /** function:: initialize()
   * On Boot initialize the component.....
   *
   *   :function  configSetup :: Creates the settings entry in config if missing
   *   :function  getDiseqcType : Get Diseqc settings
   *   :function  getLocale :: Get CUrrent Locale and apply traduction
   *   :function  getDiseqcType : Get Diseqc settings
   *
   *   :function  getIFtoIF :: Get IF2IF settings
   *   :function  PlayerManager.setFullScreen() : Restore Placement of VideoPlayer when starting UI (fullscreen)
   *   :function  PlayerManager.setDownMix() :: Hardcode to Downmix the Player sound
   *   :function  PVRManager.onBoot() : Depending of the PVR Ready status, Fetch the records and schedules
   */

  @on("FirstInstall:complete")
  initialize() {
    return putReset().then(() => {
      return configSetup()
    })
    .then(() => {
      return getLocale()
    })
    .then((lang) => {
      locale.current = lang
      updateDefaultTrack(lang)
    })
    .then(() => {
      return getTimeFormat()
    })
    .then((timeFormat) => {
      TimezoneManager.displayH24 = timeFormat
      bus.emit("hours:update")
    })
    .then(() => CasManager.setVSCnumber())
    .then(PlayerManager.setFullScreen())
    .then(PlayerManager.setDownMix())
    .then(PlayerManager.setTimeshiftDuration())
    .then(() => PlayerManager.onBoot())
    .then(() => {
      return ChannelManager.update(false, false)
    })
  }

  @on("boot:medium-priority")
  onBootMedium() {
    PowerManager._checkPowerCurrenState()
    .then(() => {
      bus.emit("channels:updated")
    })
    .then(() => PVRManager.onBoot())
    .then(() => {
      return fetchPersistancAudioLang()
    })
    .then((response) => {
      if (response !== null) {
        PlayerManager.setPersistanceAudio(response)
      }
    })
    .then(() => {
      return getDiseqcType()
    })
    .then((value) => {
      bus.emit("scan:diseqcUpdate", value)
      this.diseqc = value
    })
    .then(() => {
      return getIFtoIF()
    })
    .then((value) => {
      value || (updateIFtoIF("IFTOIF_OFF"))
      value && bus.emit("IF2IF:change", value.split("_")[1])
      bus.emit("transponder:getlist",{diseqc:this.diseqc, IF2IF:value})
      bus.emit("download:getIFtoIF",{diseqc:this.diseqc, IF2IF:value})
    })
    .then(() => {
      return updateAvio()
    })
    .then(() => {
      return getAvio()
    })
    .then((avioResponse) => {
      if (avioResponse.hdmi_connection_plugged !== true) {
        bus.emit("application:output", true)
      }
      Promise.resolve()
    })
    .then(() => InstantMessageManager.processingMessage = false)
    .then(() => {
      bus.emit("setting:tvtype")
      bus.emit("setting:stb-serialNo")
    })
  }
}
