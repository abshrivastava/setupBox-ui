//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import List from "utils/List"
import Scrollable from "utils/Scrollable"
import {$} from "widgets/Component"

import PVRManager from "services/managers/PVRManager"
import PvrEmpty from "services/models/pvr/PvrEmpty"
import Manual from "services/models/pvr/Manual"

export default class RecordListController extends Controller {
  constructor() {
    super()
    this.recordList = new List([])
    Scrollable.ControllerMixin(this, {
      mode: "bounded",
      source: this.recordList,
    })
    this.view = $("recordList")
    this.listview = this.view.itemList
  }

  open(id) {
    bus.emit("clock:open", "pvr")
    this.refresh(id)
    return this.view.open()
  }

  @on("pvr:refresh")
  refresh(id) {
    // Removing Reminder from future Array
    // this.RemoveReminder()
    const list = [].concat(
      PVRManager.futures.sort((a, b) => b.startDate-a.startDate),
      PVRManager.ongoing.sort((a, b) => b.startDate-a.startDate),
      new Manual(),
      PVRManager.finished.sort((a, b) => b.startDate-a.startDate)
    )
    const indexes =[]
    for (let i =0 ; i < list.length ; i++) {
      if (list[i]._title && !isNaN(list[i]._title)) {
        indexes.push(i)
      }
    }
    let x = 0
    if (indexes.length > 0) {
      for (const index of indexes) {
        list.splice(index-x, 1)
        x++
      }
    }

    let firstRec = list.indexOf(PVRManager.finished[0])
    if (!PVRManager.finished.length) {
      list.push(new PvrEmpty())
      firstRec = list.length - 1
    }
    this.recordList.update(list)
    this.view.update(this.recordList)
    this.jumpToId(id || list[firstRec].id)
  }
  RemoveReminder() {
    for (let i =0 ; i < PVRManager.futures.length ; i++) {
      if (PVRManager.futures[i]._title && !isNaN(PVRManager.futures[i]._title)) {
        PVRManager.futures.splice(i,1)
      }
    }
  }
  @on("RecordList:close")
  close() {
    return this.view.close()
  }

  jumpToId(id) {
    let selection = 0
    if (id) {
      for (selection = 0; selection < this.recordList.length; selection++) {
        if (this.recordList.get(selection).id === id) {
          break
        }
      }
      selection = selection % this.recordList.length
    }

    this.jumpTo(selection)
  }

  hasDetails() {
    const item = this.getSelectedItem()
    if (item.constructor.name === "Record" ||
        item.constructor.name === "Schedule") {
      return Promise.resolve(item)
    } else {
      return Promise.reject(item)
    }
  }

  isRemovable() {
    const item = this.getSelectedItem()
    if (item.constructor.name === "Record" ||
        item.constructor.name === "Schedule") {
      return Promise.resolve(item)
    } else {
      return Promise.reject("item is not removable because it's not a Record or Schedule object")
    }
  }

  failure() {
    this.view.selection.failure()
  }

  showSpinner() {
    this.view.showSpinner()
  }

  hideSpinner() {
    this.view.hideSpinner()
  }
}
