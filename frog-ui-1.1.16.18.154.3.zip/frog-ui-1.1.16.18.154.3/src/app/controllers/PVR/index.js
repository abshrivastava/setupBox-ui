//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as PVRApi from "services/api/pvr"
import Controller from "utils/Controller"
import bus from "services/bus"
import {on, rcu} from "services/events"
import {DIRECTION as SCROLL_DIRECTION} from "utils/Scrollable"
import PowerManager from "services/managers/PowerManager"
import PlayerManager from "services/managers/PlayerManager"
import PVRManager from "services/managers/PVRManager"
import ChannelManager from "services/managers/ChannelManager"
import LedManager from "services/managers/LedManager"
import {mute,unmute} from "services/managers/volume"
import * as popUpMsg from "app/utils/PopUpMsg"
import CamManager from "services/managers/CamManager"
import * as PVRReminder from "services/api/reminder"
import Playback from "../Playback"
import PvrDetails from "./PvrDetails"
import RecordList from "./RecordList"
import ManualRecord from "./ManualRecord"


export default class PVRController extends Controller {
  static delegates = [
    Playback,
    PvrDetails,
    RecordList,
    ManualRecord,
  ]

  constructor() {
    super()
    this.activeDelegate = null
    this.recordingRunning = false
  }

  /* ********* Open/Close functions ********* */
  @on("pvr:open")
  open() {
    this.closing = false
    mute()
    if (this.closing) {
      this.closing = false
      return Promise.reject("PVR: closing, so, reject opening")
    }
    this.activeDelegate = this.RecordList
    this.RecordList.open()
    clearTimeout(this.Playback.infoView.foldDelayed)
  }

  @on("pvr:close")
  close() {
    this.closing = true
    /** Resume Player....
     * Before Playing Current Channel, When PlayBack is Going on..
     */
    if (this.activeDelegate === this.Playback) PlayerManager.resume()
    this.activeDelegate = null
    for (const delegate of this.delegates) {
      bus.emit(`${delegate.displayName}:close`)
    }
    PlayerManager.playCurrentChannel(ChannelManager.current, "channel")
    bus.emit("volume:unmute")
  }

  @on("pvr:stopped")
  onStopped(id) {
    if (this.activeDelegate === this.Playback) {
      this.RecordList.open(id)
      this.activeDelegate = this.RecordList
      if (!this.recordingRunning) {
        popUpMsg.RecordingEnded()
      }
      this.recordingRunning=false
      bus.emit("tv:hideOperatorLogo")
    }

    // #85586 : If PVRDetails is displayed, then close it and return to the record list
    if (this.activeDelegate === this.PvrDetails) {
      this.PvrDetails.close()
      this.RecordList.open(id)
      this.activeDelegate = this.RecordList
    }
  }
  /* ************************************************************************ */

  /* ********* P+/P- & Arrow Keys ********* */
  @rcu("pvr:up:press")
  onUp() {
    switch (this.activeDelegate) {
    case this.RecordList:
      this.RecordList.scroll(SCROLL_DIRECTION.BACKWARD)
      break
    case this.PvrDetails:
      this.PvrDetails.prev()
      break
    case this.ManualRecord:
      this.ManualRecord.up()
      break
    default:
      break
    }
  }

  @rcu("pvr:down:press")
  onDown() {
    switch (this.activeDelegate) {
    case this.RecordList:
      this.RecordList.scroll(SCROLL_DIRECTION.FORWARD)
      break
    case this.PvrDetails:
      this.PvrDetails.next()
      break
    case this.ManualRecord:
      this.ManualRecord.down()
      break
    default:
      console.error("No activeDelegate in PVR universe?")
      break
    }
  }

  @rcu("pvr:up:release")
  @rcu("pvr:down:release")
  onReleaseUpDown() {
    if (this.activeDelegate === this.RecordList) {
      this.RecordList.stopScrolling()
    }
  }

  @rcu("pvr:right:press")
  onRight() {
    if (this.activeDelegate === this.PvrDetails) {
      this.PvrDetails.right()
    } else if (this.activeDelegate === this.ManualRecord) {
      this.ManualRecord.right()
    }
  }

  @rcu("pvr:left:press")
  onLeft() {
    if (this.activeDelegate === this.PvrDetails) {
      this.PvrDetails.left()
    } else if (this.activeDelegate === this.ManualRecord) {
      this.ManualRecord.left()
    }
  }
  /* ************************************************************************ */

  /* ********* Trickmodes ********* */
  @rcu("pvr:play:press")
  onPlay() {
    switch (this.activeDelegate) {
    case this.RecordList:
      const item = this.RecordList.getSelectedItem()
      if (item.userContent) {
        this._play()
      }
      break
    case this.Playback:
      this.Playback.resume()
      break
    default:
      break
    }
  }

  @rcu("pvr:stop:press")
  onStop() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.stop()
      break
    default:
      break
    }
  }

  @rcu("pvr:pause:press")
  onPause() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.pause()
      break
    default:
      break
    }
  }

  @rcu("pvr:fast_rewind:press")
  onFastRewind() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.fastRewind()
      break
    default:
      break
    }
  }

  @rcu("pvr:fast_forward:press")
  onFastForward() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.fastForward()
      break
    default:
      break
    }
  }
  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back, Rec, Info, Ad) ********* */
  @rcu("pvr:ok:press")
  onOk() {
    switch (this.activeDelegate) {
    case this.RecordList:
    case this.Playback:
      this._openDetails()
        .catch((item) => {
          if (item.constructor.name === "Manual") {
            // If CAM is inserted then we have to block all the conax features
            if (CamManager.insertStatus) {
              popUpMsg.ConaxDisabled()
              return
            }
            this.activeDelegate = null
            this.RecordList.showSpinner()
            this.ManualRecord.open().then(() => {
              this.RecordList.hideSpinner()
              this.activeDelegate = this.ManualRecord
            })
          }
        })
      break
    case this.PvrDetails:
      this.PvrDetails.trigger()
      break
    case this.ManualRecord:
      this.ManualRecord.record()
      break
    default:
      console.error("No activeDelegate in PVR universe?")
      break
    }
  }

  @rcu("pvr:back:press")
  onBack() {
    switch (this.activeDelegate) {
    case this.PvrDetails:
      this.activeDelegate = (this.PvrDetails.fromPlayback) ? this.Playback : this.RecordList
      this.PvrDetails.close()
      break
    case this.Playback:
      clearTimeout(this.Playback.infoView.foldDelayed)
      this.recordingRunning = true
      this.onUsbRemoved()
      break
    case this.ManualRecord:
      this.ManualRecord.close()
      this.activeDelegate = this.RecordList
      break
    // case this.RecordList:
    default:
      this.close()
      bus.openUniverse("home")
      break
    }
  }

  @rcu("pvr:ad:press")
  onAd() {
    if (this.activeDelegate === this.RecordList) {
      bus.emit("adbanner:inflate")
    }
  }

  @rcu("pvr:info:press")
  onInfo() {
    if (this.activeDelegate === this.Playback) {
      bus.emit("clock:open", "pvr")
      this.Playback.infoView.open()
      this.Playback.infoView.delayedFold()
    }
  }

  /* ************************************************************************ */

  /* ************************************************************************ */
  @on("pvr:resumeCurrent")
  onResumeCurrent() {
    this.PvrDetails.close()
    const item = this.RecordList.getSelectedItem()
    this._play(item.lastPosition)
  }

  @on("pvr:playCurrent")
  onPlayCurrent() {
    this.PvrDetails.close()
    this._play()
  }


  @on("pvr:usbRemoved")
  onUsbRemoved() {
    if (this.activeDelegate === this.Playback) {
      bus.emit("tv:setActiveDelegate", null)
      this.Playback.close().then(() => {
        this._playbackCloseCallBack()
      }).catch(() => {
        this._playbackCloseCallBack()
      })
    }
  }

  _playbackCloseCallBack() {
    PlayerManager.resume().then(() => {
      PlayerManager.stop()
    }).catch(() => {
      PlayerManager.stop()
    })
    this.Playback.flush()
    if (this.Playback.timeshiftPlayback) {
      bus.off("player:speed:normal")
      bus.off("player:state:stopped")
    }
    this.RecordList.open()
    this.activeDelegate = this.RecordList
  }

  _getMetaDataById(schedule) {
    return new Promise((resolve) => {
      if (schedule.isAlert) {
        PVRReminder.getAlert(schedule.id).then((resp)=>{
          resolve(resp)
        })
      } else {
        PVRApi.getSchedulesWithProperties(schedule.id).then((resp)=>{
          resolve(resp)
        })
      }
    })
  }

  @on("pvr:conflict:tuner")
  _onPVRTunerConflict(schedule) {

    if (ChannelManager.current.serviceId === schedule.serviceId ||
      ChannelManager.current.serviceId === schedule.service_Id) {
      LedManager.SetRecordOpen()
      return
    }
    this._getMetaDataById(schedule).then((resp)=> {
      this.chnl = {"title" : "", "lcn": "", "progTitle": ""}
      if (resp.metadata) {
        this.chnl.title = resp.metadata.channel_name
        this.chnl.lcn = resp.metadata.channel_number
      } else if (resp.channel_name) {
        this.chnl.progTitle = resp.title
        this.chnl.title = resp.channel_name
        this.chnl.lcn = resp.channel_number
      } else if (resp.task && resp.task.userContent && resp.task.userContent.channelNo) {
        const userContents = resp.task.userContent.channelNo
        this.chnl.title = userContents.title
        this.chnl.lcn = userContents.lcn
        this.chnl.progTitle = userContents.lcn
      } else if (resp.user_content) {
        this.chnl.progTitle = resp.title
        const userContents = JSON.parse(resp.user_content)
        this.chnl.title = userContents.channelTitle
        if (userContents.channelNo) this.chnl.lcn = userContents.channelNo.lcn
      } else {
        console.log("something wrong in resp=",resp)
      }
      const buttons = [
        {
          label: "OK",
          action: () => {
            if (PVRManager.ongoing.length > 0) {
              const currentPVR = PVRManager.ongoing[0]
              PVRManager.remove(currentPVR)
            }
            if (schedule.serviceId || schedule.service_Id)
              ChannelManager.current = ChannelManager.getChannelFromServiceId(schedule.serviceId || schedule.service_Id)
            else if (schedule.isAlert && this.chnl.lcn)
              ChannelManager.current = ChannelManager.getChannelFromLcn(this.chnl.lcn)
            if (this.activeDelegate !== this.Playback) {
              PlayerManager.play(ChannelManager.current)
            } else if (this.activeDelegate === this.Playback) {
              bus.emit("tv:setActiveDelegate", null)
              this.Playback.close().then(() => {
                bus.closeCurrentUniverse()
                bus.emit("home:close")
                bus.openUniverse("tv")
              }).catch(() => {
                console.log("pvr Home Press Catch")
              })
            }
          },
        },
        {
          label: "Cancel",
          action: () => {},
        },
      ]
      const closeCallback = () => {}
      popUpMsg.tunerConflict(this.chnl.title, this.chnl.progTitle, buttons, closeCallback)
    })
  }

  @rcu("pvr:home:press")
  onPvrHomePress() {
    if (this.activeDelegate === this.Playback) {
      // this.onUsbRemoved()
      bus.emit("tv:setActiveDelegate", null)
      this.Playback.close().then(() => {
        console.log("pvr Home Press")
      }).catch(() => {
        console.log("pvr Home Press Catch")
      })
    }
  }

  _play(pos) {
    const item = this.RecordList.getSelectedItem()
    return PowerManager.tuneToHomeTp().then(() => {
      return PlayerManager.play(item, "pvr", {
        play_at_pos: pos,
        play_at_pos_type: 1,
      })
      .then(unmute())
      .then(() => {
        this.activeDelegate = this.Playback
        this.Playback.open(item)
      }).catch(() => {
        this.activeDelegate = this.RecordList
        this.RecordList.failure()
        popUpMsg.playbackError()
      })
      .then(
        setTimeout(() => {
          this.RecordList.close()
          this.Playback.infoView.delayedFold()
        }, 500)
      )
    })
  }

  onPlayBackFeature(pos) {
    const item = this.RecordList.getSelectedItem()
    return PlayerManager.play(item, "pvr", {
      play_at_pos: pos,
      play_at_pos_type: 1,
    })
      .then(() => {

        this.RecordList.close()
          .then(() => {

            this.activeDelegate = this.Playback
            this.Playback.open(item)
          })
      })
      .catch(() => {
        this.activeDelegate = this.RecordList
        this.RecordList.failure()
      })
  }

  @on("pvr:deleteCurrent")
  onDeleteCurrent() {
    this.RecordList.isRemovable()
      .then((item) => PVRManager.remove(item))
  }

  @on("pvr:deleted")
  _onPVRDeleted() {
    if (this.activeDelegate === this.PvrDetails) {
      this.RecordList.refresh()
      this.activeDelegate = this.RecordList
      this.PvrDetails.close()
    }
  }

  @on("pvr:created")
  _onPVRCreated() {
    if (this.activeDelegate === this.ManualRecord) {
      this.RecordList.refresh()
      this.activeDelegate = this.RecordList
      this.ManualRecord.close()
    }
  }

  _openDetails() {
    return this.RecordList.hasDetails()
      .then((item) => {
        const serviceId=item.userContent === undefined ? item.serviceId : item.userContent.serviceId
        const channel=ChannelManager.getChannelFromServiceId(serviceId)
        if (channel !== null) {
          const genre =  ChannelManager.getGenreInfo(channel.genre)
          item.genre=genre
        }

        const playingback = (this.activeDelegate === this.Playback)
        this.activeDelegate = this.PvrDetails
        this.PvrDetails.open(item, playingback)
      })
  }
}
