//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {on} from "services/events"
import {$} from "widgets/Component"

export default class VoucherPopUpController extends Controller {
  constructor(props) {
    super(props)
    this.view = $("voucherPopUp")
  }

  get title() {
    return this._title
  }

  set title(value) {
    this._title = value
    this.view.updateTitle(value || "")
  }

  get message() {
    return this._message
  }

  set message(value) {
    this._message = value
    this.view.updateMessage(value || "")
  }

  get buttons() {
    return this._buttons
  }

  set buttons(value) {
    this._buttons = value
    this.view.setButtons(value)
  }

  get backButton() {
    return this.buttons[0]
  }

  get okButton() {
    return this.buttons[1]
  }

  get currentLevel() {
    return this.levels[this.currentLevelIdx]
  }

  get selectedIdx() {
    return this.currentLevel.selectedIdx
  }

  set selectedIdx(value) {
    this.currentLevel.selectedIdx = value
    this.updateSelectedIndex()
  }

  get itemCount() {
    return this.currentLevel.itemCount
  }

  set itemCount(value) {
    this.currentLevel.itemCount = value
  }

  /* ************************************************************************ */

  /* ********* Open/Close functions ********* */
  open(title, message, buttons, digitCount) {
    this.voucherCode = {}
    this.title = title
    this.message = message
    this.buttons = buttons
    this.init(digitCount)
    this.view.onOpen(digitCount)
  }

  init(digitCount) {
    this.levels = [{
      label: "voucher",
      itemCount: digitCount,
      selectedIdx : 0,
    }, {
      label: "buttons",
      itemCount: this.buttons.length,
      selectedIdx: 1,
    }]
    this.currentLevelIdx = 0
  }

  @on("VoucherPopUp:close")
  close() {
    return this.view.onClose()
  }

  /* ************************************************************************ */

  /* ********* Key binding functions ********* */
  onUp() {
    if (this.currentLevelIdx > 0) {
      this.currentLevelIdx--
      this.updateSelectedIndex()
    }
  }

  onDown() {
    if (this.currentLevelIdx < this.levels.length - 1) {
      this.currentLevelIdx++
      this.updateSelectedIndex()
    }
  }

  onLeft() {
    if (this.selectedIdx > 0) {
      this.selectedIdx--
    }
  }

  onRight() {
    if (this.selectedIdx < this.itemCount - 1) {
      this.selectedIdx++
    }
  }

  updateSelectedIndex() {
    switch (this.currentLevelIdx) {
    case 0:
      this.view.selectDigit(this.currentLevel.selectedIdx)
      break
    case 1:
      this.view.selectButton(this.currentLevel.selectedIdx)
      break
    }
  }

  onDigitPress(key) {
    if (this.currentLevelIdx === 0) {
      this.updateCurrentDigit(key)
      if (this.selectedIdx === (this.itemCount - 1)) {
        this.onDown()
      } else {
        this.onRight()
      }
    }
  }

  updateCurrentDigit(key) {
    this.voucherCode[this.selectedIdx] = key
    this.view.setDigit(key, this.selectedIdx)
  }

  backToFirstDigit() {
    this.onUp()
    this.selectedIdx = 0
  }

  getVoucherCode() {
    let voucherCode = ""
    for (const key in this.voucherCode) {
      voucherCode += this.voucherCode[key]
    }
    return voucherCode
  }

  /* ************************************************************************ */

  /* ********* Ok/Back/Validation buttons functions ********* */
  onBack() {
    if (this.backButton.action) {
      this.backButton.action()
    }
  }

  onOk() {
    if (this.currentLevelIdx === 1) {
      this.buttons[this.selectedIdx].action()
    }
  }

  showVoucherError(message, backToFirstDigit) {
    this.view.showVoucherError(message)
    if (backToFirstDigit) {
      this.backToFirstDigit()
    }
  }
}
