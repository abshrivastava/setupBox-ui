//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {_} from "utils/locale"
import {on, rcu, rcuLong} from "services/events"
import {noop, findObjInArrayByValue, avoidRedundantOnThreshold} from "utils"
import {DIRECTION as SCROLL_DIRECTION} from "utils/Scrollable"
import {$} from "widgets/Component"
import UsbManger from "services/managers/StorageManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import * as epgService from "services/managers/epg"
import PVRManager from "services/managers/PVRManager"
import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import ModManager from "services/managers/ModManager"
import CasManager from "services/managers/CasManager"
import ScanManager from "services/managers/ScanManager"
import ComboButton from "services/managers/ComboButton"
import NumZap from "app/controllers/Application/NumZap"
import {getDefaultChannel} from "services/managers/config"
import CamManager from "services/managers/CamManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import LedManager from "services/managers/LedManager"
import transponders from "services/managers/transponders"
import * as PVRReminder from "services/api/reminder"
import ChannelList from "./ChannelList"
import InfoBanner from "./InfoBanner"
import Timeshift from "./Timeshift"
import ProgramDetails from "./ProgramDetails"


class ProgramList {
  constructor() {
    this.flush()
    this.timer = null
  }

  [Symbol.iterator]() {
    return this.programs[Symbol.iterator]()
  }

  indexOf(obj) {
    return this.programs.indexOf(obj)
  }

  flush() {
    this.channel = null
    this._streamed = null
    this.programs = []
  }

  push(program, channel) {
    this.channel = channel
    if (this.programs.length === 0 || program.id !== this.live.id) {
      if (this.channel && this.channel.serviceId !== program.serviceId) {
        this.flush()
      } else {
        this.programs.push(program)
      }
    }
  }

  get live() {
    return this.programs[this.programs.length - 1] || null
  }

  get streamed() {
    return this._streamed
  }

  set streamed(data) {
    this._streamed = data
  }

  setCurrentlyStreamed() {
    return PlayerManager.getAbsoluteTimestampPosition()
      .then((playerPosition) => {
        const position = new Date((playerPosition.position * 1000) - 5)
        for (const program of this.programs) {
          if (program.startDate < position && program.endDate > position) {
            this.streamed = program
            return this.streamed
          }
        }
      })
      .catch(() => {
        return this.live
      })
  }
}


export default class TelevisionController extends Controller {
  static delegates = [
    ChannelList,
    InfoBanner,
    NumZap,
    Timeshift,
    ProgramDetails,
  ]

  constructor() {
    super()
    this.timeshifting = false
    this.programList = new ProgramList()
    this._initNumZap()
    this._playCustThrottle = avoidRedundantOnThreshold(function() {
      this._play()
    }, 1000)
    this.operatorLogo = $("operatorLogo")
    this.usbFormat = $("usbFormat")
    this.recordTimeshifting = false
    this.showCRIcon = false
  }

  get currentProgram() {
    if (this.timeshifting && !this.recordTimeshifting) {
      return this.programList.streamed
    } else {
      return this.programList.live
    }
  }

  getNextProgram(channel) {
    if (this.timeshifting && channel === ChannelManager.current) {
      const programIdx = this.programList.indexOf(this.programList.streamed) + 1
      const program = this.programList.programs[programIdx]
      if (program) {
        return Promise.resolve(program)
      } else {
        return epgService.getNextProgram(channel)
      }
    } else {
      return epgService.getNextProgram(channel)
    }
  }

  get recording() {
    return PVRManager.ongoing.length > 0
  }

  /* ********* Open/Close functions ********* */
  @on("tv:open")
  open() {
    if (ScanManager.serviceFound === 0 && ChannelManager.channels.length === 0) {
      const closeCallback = () => {
        getDefaultChannel()
        .then((lcn) => {
          ChannelManager.getChannelFromLcn(lcn)
           .then((response) => {
             const lcnChannel = response.resource.real || response.resource.fallback
             if (lcnChannel) {
               PlayerManager.play(lcnChannel)
             } else {
               // bus.emit("player:nosignal")
             }
           }).catch(() => {})
        })
      }

      const buttons = [
        {
          label: "OK",
          action: () => {
            bus.emit("scan:quickscan")
          },
        },
        {
          label: "BACK",
          action: () => {
            closeCallback()
          },
        },
      ]

      popUpMsg.reInstallServices(buttons, CasManager.vscNumber, closeCallback)
    } else {
      if (!PlayerManager.callbyStandy) {
        this._showBanner()
        this.operatorLogo.unfold()
      }
    }
  }

  @on("tv:showOperatorLogo")
  showOperatorLogo() {
    this.operatorLogo.unfold()
  }

  @on("tv:hideOperatorLogo")
  hideOperatorLogo() {
    this.operatorLogo.fold()
  }

  @on("tv:close")
  close() {
    this.pPlusRelease(false)
    this.pMinusRelease(false)
    this.activeDelegate = null

    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    if (this.timeshifting) promises.push(this.Timeshift.backToLive())
    promises.push(this.operatorLogo.fold())
    this.timeshifting = false
    return Promise.all(promises)
  }

  @on("tv:operateFormat")
  showFormat() {
    this.usbFormat.unfold()
  }

  @on("tv:storageRemoveOnTimeshift")
  storageRemoveOnTimeshift() {
    if (this.timeshifting) {
      popUpMsg.storageRemoved()
      // bus.emit("tv:operateFormatHide")
    } else {
      popUpMsg.storageRemoved()
      bus.emit("tv:operateFormatHide")
    }
    // this.operatorLogo.focus()
  }

  @on("tv:ZapOnTimeshift")
  ZapOnTimeshift() {
    if (this.timeshifting) {
      this.Timeshift.playerControlView.fold()
      this.timeshifting = false
      PlayerManager.stop()
      .then(() => {
        PlayerManager.play(ChannelManager.current)
      })
    }
  }

  @on("tv:timeshiftNoSignal")
  timeshiftNoSignal() {
    this.timeshifting = false
    this.Timeshift.backToLive()
  }

  @on("tv:operateFormatHide")
  hideFormat() {
    this.usbFormat.fold()
  }

  UsbUnhideFormat() {
    this.operatorLogo.unfold()
  }

  UsbHideFormat() {
    this.operatorLogo.fold()
  }


  _openChannelList() {
    this.activeDelegate = this.ChannelList
    this.ChannelList.open()
  }

  @rcu("tv:info:press")
  _onInfoBannerPress(_, __) {
    if (!PlayerManager.callbyStandy && !ComboButton.comboBtnPress) {
      // bus.emit("comboBtn:infoPress")
    }
  }

  @on("tv:fav:press")
  _onKeyFav() {
    if (this.activeDelegate === this.ProgramDetails) {
      console.debug("[FAVORITES] Unable to switch when ProgramDetails is displayed")
      return
    }
    const channelName = ChannelManager.current.title
    const toggleList = (showMsg = false) => {
      ChannelManager.toggleFavoriteListAsChannelList().then(() => {
        if (showMsg) {
          if (ChannelManager.useFav) {
            popUpMsg.favChannelList()
          } else {
            popUpMsg.defaultChannelList()
          }
        }
        bus.emit("channels:updated")
      })
    }
    if (!ChannelManager.useFav && this.recording
      && (ChannelManager.favoriteChannels.indexOf(ChannelManager.current) === -1)) {
      const cb = () => {
        if (PVRManager.ongoing) {
          return PVRManager.cancel(PVRManager.ongoing[0].programId)
          .then(() => {
            PVRManager.ongoing = []
            toggleList()
          })
        }
      }
      const buttons = [
        {
          label: _("Ok "),
          action: cb,
        },
        {
          label: _("Cancel"),
          action: () => {
            this.activeDelegate = null
          },
        },
      ]
      popUpMsg.FavListConflictRecording(channelName, buttons, cb)
    } else {
      toggleList(true)
    }

  }

  @on("tv:backToLive")
  @rcu("tv:info:release")
  _openInfoBanner(_, __, forceRec=false) {
    if (ComboButton.longPressTimmer)clearTimeout(ComboButton.longPressTimmer)
    if (!PlayerManager.callbyStandy) {
      if (!ComboButton.comboBtnPress) {
        // bus.emit("comboBtn:infoRelease")
        if (this.activeDelegate === this.ProgramDetails || this.activeDelegate === this.ChannelList) {
          return
        }
        this._showBanner(forceRec)
        if (this.activeDelegate === this.ChannelList) {
          this.activeDelegate = this.ChannelList
          if (this.ChannelList.nextOpened) {
            this.ChannelList.hideNextProgram()
          }
        }
      } else {
        ComboButton.longPressTimmer = null
        ComboButton.comboBtnPress = false
      }
    }
  }

  _showBanner(forceRec=false, channel) {
    if (bus.universe !== "tv" || this.ChannelList.channelList.items.length === 0) {
      return
    }
    if (this.timeshifting && PlayerManager.speed === 1) {
      if (UsbManger.showBannerIcon !== null && UsbManger.showBannerIcon !== false) {
        this.InfoBanner.showUsbBanner(UsbManger.showBannerIcon)
      }
      return this.Timeshift.show(this.recording || forceRec)
    } else {
    //  this.timeshifting = false
      this.ChannelList.selectChannel(channel)
      .then(() => {
        if (this.activeDelegate !== this.ChannelList && ChannelManager.displayMode !== "channelList") {
          this.activeDelegate = this.InfoBanner
          this.InfoBanner.show(this.recording || forceRec)
        }
      })
    }
  }

  @on("tv:infoBannerTimeout")
  _closeInfoBanner(closeOnTimeshift) {
    if (this.timeshifting && !closeOnTimeshift) {
      return
    }
    if (this.activeDelegate === this.InfoBanner) {
      this.activeDelegate = null
    }
    return this.InfoBanner.hide()
  }

  @on("tv:ChannelListClose")
  _closeChannelList(closeFull = true) {
    if (this.activeDelegate === this.ChannelList) {
      this.activeDelegate = null
    }

    if (this.Timeshift.mode !== "pause") {
      this.Timeshift.hide()
    }

    this.ChannelList.hideNextProgram()
    if (this.Timeshift.mode === "pause") closeFull = false
    this.ChannelList.close(closeFull)
    return this.ChannelList.selectChannel()
  }

  /* ************************************************************************ */

  /* ********* P+/P- & Arrow Keys ********* */
  @rcuLong("tv:program_plus:press")
  nextChannelLong() {
    this._longPplus = setInterval(() => this.nextChannel(), 200)
    if (!this.recording) {
      PlayerManager.stop()
    }
  }

  @rcu("tv:program_plus:release")
  pPlusRelease(tune = true) {
    if (this._longPplus) {
      clearInterval(this._longPplus)
      this._longPplus = undefined
    }
    if (tune) {
      this._playCustThrottle()
    }
  }

  @on("tv:nextChannel")
  @rcu("tv:program_plus:press")
  nextChannel() {
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
    }
    if (this.timeshifting) {
      this.Timeshift.quit()
      this.timeshifting = false
    }
    if (!this.recording && ChannelManager.channels.length !== 0) {
      if (this.activeDelegate === this.ChannelList || this.ChannelList.isOpened) {
        this.ChannelList.close()
        this.activeDelegate = null
      }
      this.InfoBanner.show()
    }
    this.ChannelList.clearProgram()
    this.ChannelList.selectPrev()
  }


  @rcuLong("tv:program_minus:press")
  previousChannelLong() {
    if (!this.recording) {
      PlayerManager.stop()
    }
    this._longPminus = setInterval(() => this.previousChannel(), 200)
  }

  @rcu("tv:program_minus:release")
  pMinusRelease(tune = true) {
    if (this._longPminus) {
      clearInterval(this._longPminus)
      this._longPminus = undefined
    }
    if (tune) {
      this._playCustThrottle()
    }
  }

  @on("tv:previousChannel")
  @rcu("tv:program_minus:press")
  previousChannel() {
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
    }
    if (this.timeshifting) {
      this.Timeshift.quit()
      this.timeshifting = false
    }
    if (!this.recording && ChannelManager.channels.length !== 0) {
      if (this.activeDelegate === this.ChannelList || this.ChannelList.isOpened) {
        this.ChannelList.close()
        this.activeDelegate = null
      }
      this.InfoBanner.show()
    }
    this.ChannelList.clearProgram()
    this.ChannelList.selectNext()
  }

  @rcu("tv:up:press")
  @rcuLong("tv:up:press")
  @rcu("UnsubscribedErrorMsg:up:press")
  onUp() {

    if (this.activeDelegate === this.ChannelList) {
      if (this.ChannelList.nextOpened) {
        this.ChannelList.hideNextProgram()
      }
      this.ChannelList.scroll(SCROLL_DIRECTION.BACKWARD)
      this.ChannelList.clearProgram()
      this.ChannelList.view.openFull()
      this.ChannelList.view.hideDolbyInfo()
      bus.emit("adbanner:open", "tv",true)
    } else if (this.activeDelegate === this.ProgramDetails) {
      this.ProgramDetails.prev()
    } else {
      this._openChannelList()
      bus.emit("adbanner:open", "tv",true)
    }
  }
  @on("tv:down:press")
  @rcu("tv:down:press")
  @rcuLong("tv:down:press")
  @rcu("UnsubscribedErrorMsg:down:press")
  onDown() {

    if (this.activeDelegate === this.ChannelList) {
      if (this.ChannelList.nextOpened) {
        this.ChannelList.hideNextProgram()
      }

      this.ChannelList.scroll(SCROLL_DIRECTION.FORWARD)
      this.ChannelList.clearProgram()
      this.ChannelList.view.openFull()
      this.ChannelList.view.hideDolbyInfo()
      bus.emit("adbanner:open", "tv",true)
    } else if (this.activeDelegate === this.ProgramDetails) {
      this.ProgramDetails.next()
    } else {
      this._openChannelList()
      bus.emit("adbanner:open", "tv",true)
    }
  }

  @rcu("tv:up:release")
  @rcu("tv:down:release")
  @rcu("popup:up:release")
  @rcu("popup:down:release")
  @rcu("UnsubscribedErrorMsg:up:release")
  @rcu("UnsubscribedErrorMsg:down:release")
  onReleaseUpDown() {
    if (this.activeDelegate === this.ProgramDetails) {
      this.ChannelList.stopScrolling()
    }
    if (this.activeDelegate === this.ChannelList) {
      this.ChannelList.stopScrolling()

      if (this.recording && PlayerManager.speed !== 0) {
        this.InfoBanner.show(this.recording)
      }
      if (this.timeshifting) {
        this.Timeshift.playerControlView.unfold()
      }
    }
  }

  @rcu("tv:right:press")
  onRight() {

    if (this.activeDelegate === this.ChannelList) {
      this.showNextProgram()
    } else if (this.activeDelegate === this.ProgramDetails) {
      PlayerManager.setAudioconfig = true
      this.ProgramDetails.right()
    }
  }

  @rcu("tv:left:press")
  onLeft() {
    if (this.activeDelegate === this.ChannelList) {
      this.ChannelList.hideNextProgram().then(() => {
        if (this.recording && PlayerManager.speed !== 0) {
          this.InfoBanner.show(this.recording)
        }
        if (this.timeshifting) {
          this.Timeshift.playerControlView.unfold()
        }
      })
    } else if (this.activeDelegate === this.ProgramDetails) {
      this.ProgramDetails.left()
    }
  }

  /* ************************************************************************ */

  /* ********* Trickmodes ********* */
  @rcu("tv:play:press")
  onPlay() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    if (ModManager.isCurrentChannelMod()) return  // Checking If Channel is MOD then recording is not allowed
    if (PVRManager.disableOnUnsubscribed) return  // Disable timeshift when errorplate is in display
    if (this.activeDelegate === this.ProgramDetails) {
      return
    }
    if (this.timeshifting) {
      if (this.closeCList) {
        this.Timeshift.resumeFromPause(this.closeCList)
        this.closeCList = null
      } else this.Timeshift.resumeFromPause()
    }
  }

  @on("tv:stop_record")
  @rcu("tv:stop:press")
  onStop() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    const channel = this.ChannelList.getSelectedItem()
    if (ModManager.isCurrentChannelMod(channel)) return  // Checking If Channel is MOD then recording is not allowed
    // if (PVRManager.disableOnUnsubscribed) return // Disable timeshift when errorplate is in display
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
      if (this.ChannelList.nextOpened) {
        return this.getNextProgram(channel)
          .then((program) => {
            PVRManager.cancel(program.id)
            bus.emit("epg:hide_recording_banner")
          })
      } else {
        return epgService.getCurrentProgram(channel)
          .then(program => PVRManager.cancel(program.id))
          .catch(() => {
            const pvr = PVRManager.ongoing[0]
            if (pvr && pvr.serviceId === ChannelManager.current.serviceId) {
              return PVRManager.remove(pvr)
            }
          })
      }
    } else if (this.activeDelegate === this.ChannelList &&
        this.ChannelList.nextOpened) {
      // Cancel schedule
      return this.getNextProgram(channel)
        .then((program) => {
          PVRManager.cancel(program.id)
          bus.emit("epg:hide_recording_banner")
        })
    }

    if (this.timeshifting) {
      this.timeshifting = false
      this.Timeshift.backToLive()
        .then(() => this._showBanner())
    } else if (this.recording) {
      return epgService.getCurrentProgram(channel)
        .then(program => PVRManager.cancel(program.id))
        .catch(() => {
          const pvr = PVRManager.ongoing[0]
          if (pvr && pvr.serviceId === ChannelManager.current.serviceId) {
            return PVRManager.remove(pvr)
          }
        })
        .then(() => {
          // this.InfoBanner.playerControlView.disableImmediately()
          this._showBanner(false)
        })
    }
  }

  @on("pvr:started")
  _displayOrHideRedPicto() {
    clearTimeout(this.timer)
    this.timer = setTimeout(()=> this.ChannelList._updateCurrentProgram(), 500)
  }

  @on("pvr:deleted")
  _onScheduleFinished(schedule) {
    setTimeout(()=>this.InfoBanner.playerControlView.disableImmediately(), 500)
    this._onScheduleDeleted(schedule)
  }

  @on("pvr:created")
  _onScheduleDeleted(schedule) {
    this._displayOrHideRedPicto()
    const channel = this.ChannelList.getSelectedItem()
    if (this.activeDelegate === this.ChannelList &&
        this.ChannelList.nextOpened) {
      return this.getNextProgram(channel)
        .then(program => {
          if (schedule.programId === program.id)
            this.ChannelList.showNextProgram()
        })
    }
  }

  @rcu("tv:pause:press")
  onPause() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    if (ModManager.isCurrentChannelMod()) return  // Checking If Channel is MOD then recording is not allowed
    if (PVRManager.disableOnUnsubscribed) return // Disable timeshift when errorplate is in display
    if (this.activeDelegate === this.ProgramDetails) {
      return
    }
    if (!PVRManager.pvrReady) {
      return this._displayPVRnotReadyPopUp()
    }
    if (this.ChannelList.nextOpened) {
      this.ChannelList.hideNextProgram()
    }
    if (this.activeDelegate === this.ChannelList) this.closeCList = true
    this.timeshifting = true
    this.Timeshift.pause()
  }

  @rcu("tv:fast_rewind:press")
  onRewind() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    if (ModManager.isCurrentChannelMod()) return  // Checking If Channel is MOD then recording is not allowed
    if (PVRManager.disableOnUnsubscribed) return // Disable timeshift when errorplate is in display
    if (this.activeDelegate === this.ProgramDetails) {
      return
    }
    if (!PVRManager.pvrReady) {
      return this._displayPVRnotReadyPopUp()
    }
    this.timeshifting = true
    this.Timeshift.fastRewind()
  }

  @rcu("tv:fast_forward:press")
  onForward() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    if (ModManager.isCurrentChannelMod()) return  // Checking If Channel is MOD then recording is not allowed
    if (PVRManager.disableOnUnsubscribed) return // Disable timeshift when errorplate is in display
    if (this.activeDelegate === this.ProgramDetails) {
      return
    }
    if (!PVRManager.pvrReady) {
      return this._displayPVRnotReadyPopUp()
    }
    PlayerManager.getDeltaFromLive()
      .then((originalDelta) => {
        if (this.timeshifting && originalDelta) {
          this.Timeshift.fastForward()
        }
      })


  }
  @on("tv:language:press")
  OnLangPress() {

    if (this.activeDelegate !== this.ChannelList) {
      this.openLanguagePopup()

    } else if (this.activeDelegate === this.ChannelList) {
      this._closeChannelList()
      this.openLanguagePopup()

    }
  }

  @on("tv:setActiveDelegate")
  setActiveDelegate(delegate) {
    this.activeDelegate = delegate
  }

  openLanguagePopup() {
    const channel = ChannelManager.current
    epgService.getCurrentProgram(channel)
      .then(program => {
        this.showCRIcon = true
        const currentChannel=ChannelManager.current
        if (program !==null && currentChannel.serviceId === program._attributes.service_id) {
          program.currentOngoing=false
        } else {
          program.currentOngoing=true
        }
        program.channelTitle = channel.title
        CasManager.fetchCriStatus().then((criValue) => {
          program.accStats = criValue
          this.ProgramDetails.open(program,this.recording,channel,this.showCRIcon)
          this.activeDelegate = this.ProgramDetails
          this.onDown()
          this.ProgramDetails.right()
        })
      })
  }

  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back, Rec, Info, Ad) ********* */
  @rcu("tv:ok:press")
  onOk() {

    // By pass the Ok button if it triger before channel tune...
    if (this.NumZap.byPassOkButton) return
    const seletedItem = this.ChannelList.getSelectedItem()
    if (seletedItem !== undefined && seletedItem !== null) {
      PlayerManager.setChannelId(this.ChannelList.getSelectedItem())
    }
    if (this.activeDelegate === this.ChannelList) {

      if (this.NumZap.kbdInput.length > 0) {
        this._closeChannelList()
        this.ChannelList.playSelectedChannel()
        return
      }
      const channel = this.ChannelList.getSelectedItem()
      this.showCRIcon = ChannelManager.current.serviceId === channel.serviceId ? true : false
      if (this.activeDelegate.nextOpened) {
        this.getNextProgram(channel)
         .then(NextProgram => {
           NextProgram.currentOngoing=false
           NextProgram.showReminder=true
           NextProgram.channelTitle = channel.title
           if (this.showCRIcon) {
             CasManager.fetchCriStatus().then((criValue) => {
               NextProgram.accStats = criValue
               this.ProgramDetails.open(NextProgram,this.recording,channel,this.showCRIcon)
               this.activeDelegate = this.ProgramDetails
             })
           } else {
             this.ProgramDetails.open(NextProgram,this.recording,channel,this.showCRIcon)
             this.activeDelegate = this.ProgramDetails
           }
         })
      } else {
        epgService.getCurrentProgram(channel)
         .then(program => {
           const currentChannel=ChannelManager.current
           if (currentChannel!==null && program !==null
             && currentChannel.serviceId === program._attributes.service_id) {
             program.currentOngoing=false
           } else {
             program.currentOngoing=true
           }
           program.channelTitle = channel.title
           if (this.showCRIcon) {
             CasManager.fetchCriStatus().then((criValue) => {
               program.accStats = criValue
               this.ProgramDetails.open(program,this.recording,channel,this.showCRIcon)
               this.activeDelegate = this.ProgramDetails
             })
           } else {
             this.ProgramDetails.open(program,this.recording,channel,this.showCRIcon)
             this.activeDelegate = this.ProgramDetails
           }
         })
      }

    } else if (this.activeDelegate === this.ProgramDetails) {
      this.ProgramDetails.popUpTrigger().then((response) => {
        if (!response) return
        this.ProgramDetails.right()
      }).catch(() => {
        this.ProgramDetails.trigger()
      })
    } else if (this.activeDelegate === null) {
      const channel = ChannelManager.current


      epgService.getCurrentProgram(channel)
      .then(program => {
        this.showCRIcon = true
        const currentChannel=ChannelManager.current
        if (program !==null && currentChannel.serviceId === program._attributes.service_id) {
          program.currentOngoing=false
        } else {
          program.currentOngoing=true
        }
        program.channelTitle = channel.title
        if (this.showCRIcon) {
          CasManager.fetchCriStatus().then((criValue) => {
            program.accStats = criValue
            this.ProgramDetails.open(program,this.recording,channel,this.showCRIcon)
            this.activeDelegate = this.ProgramDetails
          })
        } else {
          this.ProgramDetails.open(program,this.recording,channel,this.showCRIcon)
          this.activeDelegate = this.ProgramDetails
        }
      })
    }
  }


  @on("tv:watch")
  _onWatch() {
    PlayerManager.callbyStandy = false
    if (PVRManager.ongoing.length > 0) {
      this.showRecordConflictPopUp(this.ChannelList.getSelectedItem())
    } else {
      this.operatorLogo.unfold()
      PlayerManager.play(this.ChannelList.getSelectedItem())
    }
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
    }
    this._closeChannelList(false)
  }
  @on("tv:cancelReminder")
  onCancelReminder() {
    const channel = this.ChannelList.getSelectedItem()
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      const self = this
      this.ProgramDetails.close()
      if (this.ChannelList.nextOpened) {
        this.getNextProgram(channel)
          .then((program) => {
            PVRManager.cancel(program.id)
            setTimeout(function() {

              self.ChannelList.showNextProgram()
            },1000)
          })
      }
    } else {
      const self = this
      if (this.ChannelList.nextOpened) {
        this.getNextProgram(channel)
          .then(() => {
            setTimeout(function() {
              self.ChannelList.showNextProgram()
            },1000)
          })
      }
    }
  }
  @on("tv:reminder")
  onReminder() {
    const channel = this.ChannelList.getSelectedItem()
    if (ModManager.isCurrentChannelMod(channel)) return  // Checking If Channel is MOD then recording is not allowed
    if (this.activeDelegate === this.ProgramDetails) {

      if (this.ChannelList.nextOpened) {
        this.getNextProgram(channel)
          .then((program) => {
            const currentChannel =  this.ChannelList.getSelectedItem()
            const {list} = PVRManager._getScheduleIdx(program.id, "program")
            if (list) {
              const closeCallback = () => {
                console.log("I am closeCallback")
              }
              const buttons = [
                {
                  label: _("Ok"),
                  action: () => {
                  },
                },
              ]
              return popUpMsg.recordVSReminderConflictSameTime(buttons,closeCallback)

            }
            const params={
              "name":program.programId.toString(),
              "duration":(program.cdsEndDate-program.cdsStartDate).toString(),
              "event":program.programId.toString(),
              "class": "content_program_id",
              "preview_time" : "60",
              "channel_name": currentChannel.title,
              "channel_number":currentChannel.lcn.toString(),
              "start_hour":program.startDate.toLocaleTimeString(navigator.language,
              {hour: "2-digit", minute:"2-digit"}),
              "title": program.title.trim(),
              "service_id":program.serviceId.toString(),
            }
            PVRManager.lastReminderServiceId = params.service_id
            PVRReminder.createReminder(params)
            this.activeDelegate = this._getCurrectDelegateForChannelList()
            this.ProgramDetails.close()
            const self = this
            setTimeout(function() {

              self.ChannelList.showNextProgram()
            },50)
          })
      }
    }
  }

  getManualRecordsFromServiceId(serviceId, startDate, endDate) {
    const manualRecordsArray = []
    const schedules = PVRManager.getSchedulesFromServiceId(serviceId, startDate, endDate)
    schedules.forEach(({schedule}) => {
      if (this.isManualRecordToDisplay(schedule, startDate, endDate)) {
        manualRecordsArray.push(schedule)
      }
    })
    return manualRecordsArray
  }

  isManualRecordToDisplay(manualRec, startDate) {
    return (this.isManualRecToDisplayOnTV(manualRec, startDate) && !manualRec.programId)
  }

  isManualRecToDisplayOnTV(manualRec, startDate) {
    if (manualRec.startDate <= new Date()) {
      return manualRec && ((startDate >= manualRec.startDate && startDate < manualRec.endDate) ||
      (manualRec.startDate > startDate))
    }
  }

  showRecordConflictPopUp(selectedChannel = null) {
    const buttons = [
      {
        label: _("Ok"),
        action: () => {
          // Request for cancel current Recording...
          PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
            this.operatorLogo.unfold()
            if (selectedChannel) PlayerManager.play(selectedChannel)
          })
        },
      },
      {
        label: "Back",
        action: () => {
        },
      },
    ]
    popUpMsg.zapConflict(buttons)
  }

  @rcu("tv:back:press")
  onBack() {
    if (!this.activeDelegate) {
      this.tunePreviousChannel()
      return
    }
    switch (this.activeDelegate) {
    case this.ChannelList:
      this._closeChannelList()
      break
    case this.InfoBanner:
      this._closeInfoBanner()
      break
    case this.ProgramDetails:
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
      break
    default:
      break
    }
  }

  _getCurrectDelegateForChannelList() {
    switch (ChannelManager.displayMode) {
    case "infoBanner":
      console.warn("infoBanner")
      return this.InfoBanner
    case "channelList":
      console.warn("channelList")
      return this.ChannelList
    default:
      return null
    }
  }

  @on("tv:tunePrevious")
  tunePreviousChannel() {
    const prevTunedChannel = PlayerManager.prevChannelTuned
    if (prevTunedChannel) {
      ChannelManager.getChannelFromLcn(prevTunedChannel)
         .then((response) => {
           const lcnChannel = response.resource.real || response.resource.fallback
           if (lcnChannel) {
             this._play(lcnChannel)
           }
         })
    }
  }

  @on("tv:record")
  @rcu("tv:rec:press")
  onRec() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    const channel = this.ChannelList.getSelectedItem()
    if (ModManager.isCurrentChannelMod(channel)) return  // Checking If Channel is MOD then recording is not allowed
    if (this.activeDelegate === this.ProgramDetails) {
      if (this.ChannelList.nextOpened) {
        this.getNextProgram(channel)
            .then((program)=>{
              if (program.isReminder) {
                const closeCallback = () => {
                  console.log("I am closeCallback")
                }
                const buttons = [
                  {
                    label: _("Ok"),
                    action: () => {
                    },
                  },
                ]
                return popUpMsg.recordVSReminderConflictSameTime(buttons,closeCallback)
              }
              this._tryRecord(program)
            })
      } else {
        epgService.getCurrentProgram(channel)
        .then(program => this._tryRecord(program))
        .then(() => this._showBanner(true))
      }
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
    } else if (this.activeDelegate === this.ChannelList) {
      if (this.ChannelList.nextOpened) {
        this.getNextProgram(channel)
          .then(program => this._tryRecord(program))
      } else {
        // this._closeChannelList() //acc to TK behaviour, channel list should not disappear
        epgService.getCurrentProgram(channel)
        .then(program => {
          if (program.serviceId === ChannelManager.current.serviceId && this.recording) {
            bus.emit("tv:stop_record")
            return
          }
          this._tryRecord(program)
          .then(() => this._showBanner(true))
        })
      }
    } else {
      this.recordTimeshifting = true
      if (this.recording && this.currentProgram.serviceId === ChannelManager.current.serviceId) {
        bus.emit("tv:stop_record")
        return
      }
      epgService.getCurrentProgram(channel)
      .then(program => this._tryRecord(program))
      .then(() => {
        this._showBanner(true)
        this.recordTimeshifting = false
      })
    }
  }

  _tryRecord(program) {
    if (!program) {
      return Promise.reject("No program to record")
    }
    const channelObj = this.ChannelList.getSelectedItem()
    return PVRManager.recordProgram(program.programId,
                                    Object.assign({channelTitle: channelObj.title,
                                      channelNo: ChannelManager.getChannelFromServiceId(channelObj.serviceId),
                                      isOngoing:program.isOngoing},program.getAttributes()),bus.universe)
  }

  @rcu("tv:ad:press")
  onAd() {
    if (this.activeDelegate === this.ChannelList) {
      bus.emit("adbanner:inflate")
    }
  }
  /* ************************************************************************ */

  /* ********* Numeric/Numzap ********* */
  _initNumZap() {
    this.NumZap.setTriggerFunction((lcn) => {
      return ChannelManager.getChannelFromLcn(lcn)
    })
  }

  @on("tv:numeric:press")
  @rcu("tv:numeric:press")
  onNumeric(key, kbd) {
    if (this.activeDelegate === this.ProgramDetails) {
      this.activeDelegate = this._getCurrectDelegateForChannelList()
      this.ProgramDetails.close()
    }

    let triggerNew
    let triggerEach

    switch (this.activeDelegate) {
    case this.ChannelList:
      triggerNew = true
      triggerEach = false
      break
    case this.InfoBanner:
      triggerNew = true
      triggerEach = true
      break
    default:
      triggerNew = false
      triggerEach = true
      break
    }

    this.NumZap.open(kbd, triggerNew, triggerEach)
  }

  @on("tv:numzap_each")
  onNumZapEach(channel) {
    const seletedItem = this.ChannelList.getSelectedItem()
    if (seletedItem !== undefined && seletedItem !== null) {
      PlayerManager.setChannelId(this.ChannelList.getSelectedItem())
    }
    this.ChannelList.selectChannel(channel)

    if (this.ChannelList.nextOpened) {
      this.ChannelList.hideNextProgram()
    }
  }

  @on("tv:numzap_real")
  onNumZapReal(channel) {
    const seletedItem = this.ChannelList.getSelectedItem()
    if (seletedItem !== undefined && seletedItem !== null) {
      PlayerManager.setChannelId(this.ChannelList.getSelectedItem())
    }

    this.ChannelList.selectChannel(channel)
      .then(() => {
        if (this.timeshifting) {
          this.Timeshift.quit()
          this.timeshifting = false
        }
        this.ChannelList.playSelectedChannel()
      })
  }

  @on("tv:zap")
  @on("tv:numzap_already")
  onNumZapAlready(channel) {
    PlayerManager.callbyStandy = false
    const seletedItem = this.ChannelList.getSelectedItem()
    if (seletedItem !== undefined && seletedItem !== null) {
      PlayerManager.setChannelId(this.ChannelList.getSelectedItem())
    }
    this.programList.flush()
    let forceRec = false
    if (channel.recording) {
      channel.recording = null
      forceRec = true
    }
    this._showBanner(forceRec, channel)
  }

  @on("channels:updated")
  onUpdate() {
    // this.ChannelList.loadChannels()
    if (ChannelManager.current) {
      const channel = findObjInArrayByValue(ChannelManager.channels, Number(ChannelManager.current.lcn))
      if (!channel) {
        ChannelManager.setCurrent(ChannelManager.channels[0])
      }
    }
  }

  @on("tv:numzap_fallback")
  onNumZapFallback(channel) {
    this.activeDelegate = this.ChannelList
    this.ChannelList.open(channel)
    if (CasManager.cashActive === true) {
      if (CasManager.unsubscribedPopupOpen === true) {
        if (FtaBlockManager.ftaPopupStatus.popcode && FtaBlockManager.ftaPopupStatus.popcode !== -1) {
          bus.emit("UnsubscribedErrorMsg:close")
        }
      }
    }
  }
  /* ************************************************************************ */

  updateProgramInfos() {
    this.programList.setCurrentlyStreamed()
  }

  showNextProgram() {
    this.ChannelList.showNextProgram().then((hasProgram) => {
      if (hasProgram) {
        if (this.recording) {
          this.InfoBanner.hide()
        }
        if (this.timeshifting) {
          this.Timeshift.playerControlView.fold()
        }
      }
    })
  }

  @on("player:program:update")
  _onProgramUpdate(program) {
    if (program === null) {
      epgService.getCurrentProgram(ChannelManager.current)
        .then(program => {
          this.programList.push(program, ChannelManager.current)
        })
    } else {
      this.programList.push(program, ChannelManager.current)
    }
  }

  @on("player:program:parental")
  _onParental() {
    if (this.timeshifting) {
      this.updateProgramInfos()
    }
  }

  @on("tv:conflict:tuner")
  _onTunerConflict(schedule, universe) {
    let serviceID = null
    if (schedule.serviceId || schedule.service_Id)
      serviceID = schedule.serviceId || schedule.service_Id
    if (ChannelManager.current.serviceId === serviceID) {
      if (!(universe === "settings" && transponders.isTPListScreen === true)) {
        LedManager.SetRecordOpen()
        return
      }
    }
    const channel = ChannelManager.getChannelFromServiceId(serviceID)
    if (ChannelManager.useFav && ChannelManager.favoriteChannels.indexOf(channel) === -1) {
      const cb = () => {
        ChannelManager.toggleFavoriteListAsChannelList(channel)
        .then(() => {
          bus.emit("channels:updated")
          if (this.recording) {
            const currentPVR = PVRManager.ongoing[0]
            PVRManager.remove(currentPVR)
          }
          LedManager.SetRecordOpen()
        })

      }
      const channelName = schedule.channelTitle
      const buttons = [
        {
          label: _("Ok "),
          action: cb,
        },
        {
          label: _("Cancel"),
          action: () => {
            PVRManager.remove(schedule)
          },
        },
      ]
      if (this.activeDelegate === this.ProgramDetails) {
        this.ProgramDetails.close()
      }
      popUpMsg.switchOnDefaultChannelList(channelName, buttons, cb)
      return
    }
    const channelName = schedule.channelTitle
    const buttons = [
      {
        label: "OK",
        action: () => {
          if (this.recording) {
            const currentPVR = PVRManager.ongoing[0]
            PVRManager.remove(currentPVR)
          }
          ChannelManager.current = channel
          if (universe === "settings" && transponders.isTPListScreen === true) {
            bus.emit("settings:subClose")
          }
          PlayerManager.play(ChannelManager.current)
          LedManager.SetRecordOpen()
        },
      },
      {
        label: "Cancel",
        action: () => {
          PVRManager.remove(schedule)
        },
      },
    ]
    const closeCallback = () => {
      if (this.recording) {
        const currentPVR = PVRManager.ongoing[0]
        PVRManager.remove(currentPVR)
      }
      ChannelManager.current = channel
      if (universe === "settings" && transponders.isTPListScreen === true) {
        bus.emit("settings:subClose")
      }
      PlayerManager.play(ChannelManager.current)
      LedManager.SetRecordOpen()
    }

    if (this.activeDelegate === this.ProgramDetails) {
      this.ProgramDetails.close()
    }

    popUpMsg.tunerConflict(schedule._title,channelName, buttons, closeCallback)
  }

  @on("pvr:ready")
  setPvrReady(value) {
    if (value) {
      if (PlayerManager.state && PlayerManager.state !== "STOPPED") {
        return
      }
    } else {
      if (this.timeshifting) {
        this.Timeshift.quit()
        this.timeshifting = false
        PlayerManager.stop()
      .then(() => {
        PlayerManager.play(ChannelManager.current)
      })
      }
    }
  }

  _displayPVRnotReadyPopUp() {
    popUpMsg.pvrNotReady()
  }

  _getPreviousChannel() {
    const items = ChannelManager.channels
    const previousChannelIdx = items.indexOf(ChannelManager.current) - 1
    return (previousChannelIdx < 0) ? items[items.length - 1] : items[previousChannelIdx]
  }

  _getNextChannel() {
    const items = ChannelManager.channels
    const nextChannelIdx = items.indexOf(ChannelManager.current) + 1
    return (nextChannelIdx === items.length) ? items[0] : items[nextChannelIdx]
  }

  _playNextChannel() {
    return this._play(this._getNextChannel())
  }

  _playPreviousChannel() {
    return this._play(this._getPreviousChannel())
  }

  _play(channel) {
    if (!channel) {
      channel = this.ChannelList.getSelectedItem()
    }
    if (PVRManager.ongoing.length > 0) {
      /*  if :: InfoBanner is Opened On P+/P- on Recording
          InfoBanner is Removed...
       */
      if (this.activeDelegate === this.InfoBanner) {
        this.InfoBanner.hide()
      }

      /*  if :: ChannelList is Opened On P+/P- on Recording
          ChannelList is Removed...
       */
      if (this.activeDelegate === this.ChannelList) {
        this.ChannelList.close()
        this.activeDelegate = null
      }
      /*
        Show tunerConflict conflict Message (803 - Recording Alert)
      */
      return ChannelManager.showZapConflictPopUp(channel)
    }
    if (ChannelManager.current !== channel && this.timeshifting) {
      this.Timeshift.playerControlView.fold()
      this.timeshifting = false
    }
    return PlayerManager.play(channel)
      .then(() => {
        this.updateProgramInfos()
      })
      .catch(() => {
        // Zap has been cancelled, do nothing
        noop()
      })
  }
}
