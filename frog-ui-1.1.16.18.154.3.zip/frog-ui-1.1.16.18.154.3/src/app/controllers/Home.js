//
// Copyright (C) 2006-2017 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import bus from "services/bus"
import {PlayerManager, ChannelManager, PVRManager, AppsManager} from "services/managers"
import {on, rcu, rcuLong} from "services/events"
import {ListObj} from "app/utils/widgets/lists"
import Home from "app/models/Home"

export default class HomeController extends Controller {
  constructor() {
    super()
    this.model = new Home()
    this.items = this.model.items
    this.view = $("homeMenu")
    this.homeList = new ListObj(this.items, this.view.homeList)
    this._selectedIndex = 0
  }

  get selectedIndex() {
    return this._selectedIndex
  }

  set selectedIndex(value) {
    this._selectedIndex = value
    this.onSelectedItemChange()
  }

  @on("home:open")
  open() {
    if (PlayerManager._state && PlayerManager._state === 10) {
      PlayerManager.playCurrentChannel(ChannelManager.current)
    }
    bus.emit("clock:open", "home")
    return this.view.show()
      // .then(() => {
      //   if (PlayerManager._state && PlayerManager._state === 10) {
      //     PlayerManager.playCurrentChannel(ChannelManager.current)
      //   }
      //   bus.emit("clock:open", "home")
      // })
  }

  @on("home:close")
  close() {
    bus.emit("clock:close")
    return this.view.hide()
  }

  @on("home:reset")
  reset() {
    this.selectedIndex = 0
  }

  @rcu("home:numeric:press")
  onInput(key, kbd) {
    if (key !== 0) {
      this.onHome()
      bus.emit("tv:numeric:press", key, kbd)
    }
  }

  /* ********* P+/P- & Arrow Keys ********* */

  @rcu("home:program_plus:press")
  nextChannel() {
    this.onHome()
    bus.emit("tv:nextChannel")
  }

  @rcu("home:program_minus:press")
  previousChannel() {
    this.onHome()
    bus.emit("tv:previousChannel")
  }

  @rcu("home:ok:press")
  onOk() {
    const item = this.items[this.selectedIndex]
    if (item.args === "appstore" &&
      (PVRManager.ongoing.length > 0 || PVRManager.recordingInTransitionInfo.inTransition)) {
      return AppsManager.showAppStoreConflictPopUp(item)
    }
    this.close()
    bus.emit(item.signal, item)
  }

  @on("goto")
  onGoTo(item) {
    this.openUniverse(item.args)
  }

  @rcu("home:ad:press")
  onAd() {
    bus.emit("adbanner:inflate")
  }

  @rcu("home:back:press")
  onHome() {
    this.openUniverse("tv")
  }

  @on("vod:goto")
  gotoVod(item) {
    this.openUniverse(item.args)
  }

  openUniverse(universe) {
    bus.closeCurrentUniverse()
    bus.openUniverse(universe)
  }

  @rcu("home:left:release")
  prevLongRelease() {
    this.rcuPrevLong = false
  }


  @rcuLong("home:left:press")
  prevLong() {
    this.rcuPrevLong = true
    this._prevLong()
  }

  _prevLong() {
    if (!this.rcuPrevLong || this._selectedIndex <= 0) {
      return
    }
    this._selectedIndex--
    // this.onSelectedItemChange().then(() => {
    //   this._prevLong()
    // })
    this.onSelectedItemChange()
    this._prevLong()
  }

  @rcu("home:left:press")
  prev() {
    if (this.selectedIndex > 0) {
      this.selectedIndex--
    }
  }

  @rcu("home:right:release")
  prevNextRelease() {
    this.rcuNextLong = false
  }

  @rcuLong("home:right:press")
  nextLong() {
    this.rcuNextLong = true
    this._nextLong()
  }


  _nextLong() {
    if (!this.rcuNextLong || this._selectedIndex >= this.items.length - 1) {
      return
    }
    this._selectedIndex++
    // this.onSelectedItemChange().then(() => {
    //   this._nextLong()
    // })
    this.onSelectedItemChange()
    this._nextLong()
  }

  @rcu("home:right:press")
  next() {
    if (this.selectedIndex < this.items.length-1) {
      this.selectedIndex++
    }
  }

  @on("home:activeMenuItem")
  activeMenuItem(itemtTitle) {
    for (let i=0; i<this.items.length-1; i++) {
      if (this.items[i].args === itemtTitle) {
        this.selectedIndex = i
        break
      }
    }
  }

  @on("locale:update")
  updateLanguage() {
    this.model = new Home()
    this.homeList = new ListObj(this.items, this.view.homeList)
    this.onSelectedItemChange()
  }

  onSelectedItemChange() {
    return this.view.select(this.selectedIndex)
  }
}
