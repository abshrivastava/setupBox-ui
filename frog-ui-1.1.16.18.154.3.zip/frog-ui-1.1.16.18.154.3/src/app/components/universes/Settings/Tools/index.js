//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {_} from "utils/locale"
import TimezoneManager from "services/managers/TimezoneManager"

import "./index.css"
import License from "./text"

export default class LicenseInfo extends Component {
  constructor(props) {
    super(props)
    this.homeTP = null
  }
  render() {
    return (
      <div className="LicenseInfo LicenseInfo--hidden  LicenseInfo--BtnHide">
        <div className="LicenseInfo-heading-wrapper">
          <div className="LicenseInfo-date-Wrapper">
            <span className="LicenseInfo-date" prop="date"/>
            <span className="LicenseInfo-time" prop="time"/>
          </div>
          </div>
          <div className="LicenseInfo-inner">
            <div className="LicenseInfo-main">
              <div className="LicenseInfo-context">
                <div class="LicenseInfo-header" prop="LicenseInfo-header"/>
              </div>
              <div id="scrollBar" className="LicenseInfo-details" key="scrollBar">
                <div class="content" key="header_detail"/>
                <div>
                  <div class="content-header" key="heading_1"/>
                  <div class="content-details" key="detail_1"/>
                </div>
                <div>
                  <div class="content-header" key="heading_2"/>
                  <div class="content-details" key="detail_2"/>
                </div>
                <div>
                  <div class="content-header" key="heading_3"/>
                  <div class="content-details" key="detail_3"/>
                </div>
                <div>
                  <div class="content-header" key="heading_4"/>
                  <div class="content-details" key="detail_4"/>
                </div>
                <div>
                  <div class="content-header" key="heading_5"/>
                  <div class="content-details" key="detail_5"/>
                </div>

              </div>
           </div>
           <div className="LicenseInfo-footer">
            <div  className="LicenseInfo-exitLabel" prop= "ExitLabel"/>
            <div class="LicenseInfo-backLabel" prop= "backLabel"/>
           </div>
        </div>
      </div>
    )
  }

  loadStaticData() {
    this.getStbRelatedDetails()
    this.show()
  }

  onLoad() {
    this.updateClock(new Date())
    this.setProp("LicenseInfo-header", "Copyright & License Info")
    this.header_detail.innerHTML = `${License.heading}`
    this.heading_1.innerHTML = `${License.heading_1}`
    this.detail_1.innerHTML = `${License.detail_1}`
    this.heading_2.innerHTML = `${License.heading_2}`
    this.detail_2.innerHTML = `${License.detail_2}`
    this.heading_3.innerHTML = `${License.heading_3}`
    this.detail_3.innerHTML = `${License.detail_3}`
    this.heading_4.innerHTML = `${License.heading_4}`
    this.detail_4.innerHTML = `${License.detail_4}`
    this.heading_5.innerHTML = `${License.heading_5}`
    this.detail_5.innerHTML = `${License.detail_5}`
    this.onForeground()
    this.updateTpTitleForFta()
  }


  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
    this.pullState("hidden")
  }

  updateClock(d) {
    const time = TimezoneManager.getFormatTime(d)
    const d1 =  (d.toString()).slice(0,16)
    const itemDate = d1.split(" ")
    const date = _(itemDate[0]) +(",") +(" ")+(_(itemDate[2]))+(" ")
    +(_(itemDate[1]))+(" ")+(_(itemDate[3]))+(" ")

    this.setProp("time", time)
    this.setProp("date", date)
  }

  updateTpTitleForFta() {
    this.setProp("ExitLabel", _("Press Back for Tools"))
    this.setProp("backLabel", _("Press Menu to Exit"))
  }

  scrollWidth() {
    return this.scrollBar.scrollWidth
  }

  OffSetHeight() {
    return this.scrollBar.scrollHeight
  }

  scrollUp(number) {
    this.scrollBar.scrollTop = number
  }

  scrollDown(number) {
    this.scrollBar.scrollTop = number
  }

}
