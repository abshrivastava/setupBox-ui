//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import "./index.css"

class TransponderSelector extends Component {
  render() {
    return (< div className = "TransponderSelector" key = "TransponderSelector">
      <div className = "TransponderSelector-bg" / >
        <div className = "TransponderSelector-arrow" key = "arrow" / >
        </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class TPTransponderItem extends Component {
  render() {
    return (
      <div className = "TPTransponderItem"
      prop = "label" / >
    )
  }
}

export class TPTransponderHList extends HybridListComponent {
  constructor() {

    super(TransponderSelector, TPTransponderItem)
    this.ITEM_HEIGHT = 45

  }

  render() {
    return (<div className = "TPTransponderHList" />)
  }
  showSelector() {
  }

}

export default class TPmain extends Component {
  render() {
    return (
      <div className="TPTranspondersMenu">
        <div className="TPTranspondersMenu-inner">
          <div className = "TPTranspondersMenu-container" >
            <div className = "FilterContent">
              <TPTransponderHList key="TPTransponderList"/>
            </div>
          </div>
        </div>
      </div>
    )
  }


  showFirstLevelTransponder() {
    this.TPTransponderList.pullState("hidden")
  }

  hideAllTransponders() {
    this.TPTransponderList.pushState("hidden")
    this.TPTransponderList.hide()
  }

  show() {
    this.pullState("onBackground")
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    this.pushState("hidden")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  openList() {

  }

}
