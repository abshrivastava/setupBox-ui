//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import bus from "services/bus"
import {_} from "utils/locale"
import TimezoneManager from "services/managers/TimezoneManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import CasManager from "services/managers/CasManager"
import Transponders from "services/managers/transponders"

import "./index.css"

class Item extends Component {
  constructor(props) {
    super(props)
    this.index = 0
  }

  render() {
    return (
      <div className="TransponderInfo-data">
      <span className="Trans-Icon"/>
        <div class="Trans-data">
          <span className="TransponderInfo-label" prop="label" />&nbsp;
          <span className="TransponderInfo-value" prop="value" />&nbsp;
          <span className="TransponderInfo-signal" prop="signal"/>&nbsp;
        </div>
      </div>
    )
  }
}

export default class TransponderInfo extends Component {
  constructor(props) {
    super(props)
    this.subItems = []
    this.transList = []
    this.index = 0
    this.homeTPProp = null
    this.homeTP = null
  }
  render() {
    return (
      <div className="TransponderInfo TransponderInfo--hidden  TransponderInfo--BtnHide">
        <div className="TransponderInfo-heading-wrapper">
        <div className="TransponderInfo-title" prop="menuTitle"/>
          <div className="TransponderInfo-heading" prop="heading"/>
          <div className="TransponderInfo-date-Wrapper">
            <span className="TransponderInfo-date" prop="date"/>
            <span className="TransponderInfo-time" prop="time"/>
          </div>
          </div>
          <div className="TransponderInfo-inner">
            <div className="TransponderInfo-main">
              <div className="TransponderInfo-context">
              <span class="SettingsSub-label" key="vc_label" prop="vc_label" />
              <span class="SettingsSub-value" key="context" prop="VC"/><br />
              <span class="SettingsSub-label" key="stb_label" prop="stb_label" />
              <span class="SettingsSub-value" key ="context1" prop ="STB"/>
              </div>
              <div className="TransponderInfo-details">
                <div className="TransponderInfo-item">
                  <div className="TransponderInfo-items" key ="SubItems" />
                </div>
              </div>
           </div>
           <div className="TransponderInfo-footer">
           <span className="TransponderInfo-exitLabel" prop= "ExitLabel"/>
           <span className="TransponderInfo-backLabel" prop= "backLabel"/>
           </div>
           <div className="Button-section">
             <span className="TPInfoBlue-button" prop="Exit" />
             <span className="TPInfoYellow-button" prop="STBlist" />
           </div>
        </div>
      </div>
    )
  }

  loadStaticData() {
    this.getStbRelatedDetails()
    this.show()
  }

  getStbRelatedDetails() {
    const vcno =  CasManager.vscNumber ||"NOT AVAILABLE"
    const STBInfoSheet = _("STB Info Sheet")
    const TPInfo = _("TP Info")
    this.setProp("VC", vcno)
    this.setProp("vc_label", _("VC No") + ": ")
    this.setProp("STB", Transponders.stbSerialNo)
    this.setProp("stb_label", _("STB No")+ ": ")
    this.setProp("heading",STBInfoSheet + " - " +TPInfo)
    this.setProp("STBlist", _("STB InfoSheet"))
    this.setProp("Exit", _("Exit"))
  }

  onLoad() {
    this.updateClock(new Date())
    this.getStbRelatedDetails()
    for (const item of this.subItems) {
      item.destroy()
    }
    this.subItems = []
    let data = []
    if (this.transList.length !==0) {
      data = this.transList
      for (let i = 0; i < data.length; i++) {
        const splited = data[i].properties.split(" ")
        const temp = splited[1].substring(0,splited[1].length -3)  + "/"
        + splited[2] + "/" + splited[3].substring(0,splited[1].length -3)  + " "
        let tp =null
        if (this.pageNumber > 1) {
          tp = (i+(30*(this.pageNumber-1))).toString()
        } else {
          tp = ((i+1) < 10) ? "0" + (i+1).toString() : (i+1).toString()
        }
        const subItem = new Item({label: "TP"+tp+":", value: temp})
        subItem.index = i
        this.SubItems.appendChild(subItem.build())
        this.subItems[i] = subItem
      }
      this.onForeground()
      bus.emit("TransponderInfo:TranponderStat", (data))
    }
  }

/* to update the signal Strength an Quality of each Transponder*/
  updateTransponderStatus(TransSignal, transflag,indexForUpdate) {

    if (transflag) {
      this.subItems[indexForUpdate].dom.childNodes[0].className= "transGreen"
    } else {
      this.subItems[indexForUpdate].dom.childNodes[0].className= "Trans-Icon"
    }
    this.subItems[indexForUpdate].dom.childNodes[1].childNodes[4].firstChild.data = TransSignal
  }

/* to update the current Tuned Transponder*/
  updateCurrentTransponder(currentTrans) {
    this.subItems[currentTrans].dom.lastChild.className = "current-Trans"
  }

/* to update the home tp at the top of the TranspondersList*/
  updatehomeTp(homeTrans) {
    this.homeTPProp =homeTrans

  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  updateTransList(item, pageNumber= 1) {
    this.transList = item
    this.pageNumber =pageNumber
  }

  deleteTransList() {
    this.transList = []
  }
  onBtnShow() {
    this.pullState("BtnHide")
  }

  onBtnClose() {
    this.pushState("BtnHide")
  }
  updateClock(d) {
    const time = TimezoneManager.getFormatTime(d)
    const d1 =  (d.toString()).slice(0,16)
    const itemDate = d1.split(" ")
    const date = _(itemDate[0]) +(",") +(" ")+(_(itemDate[2]))+(" ")
    +(_(itemDate[1]))+(" ")+(_(itemDate[3]))+(" ")

    this.setProp("time", time)
    this.setProp("date", date)
  }

  updateTpTitleForFta() {
    this.setProp("menuTitle", _("My DishTV"))
    if (!FtaBlockManager.isNavigationRestricted()) {
      this.setProp("ExitLabel", _("Press Menu to Exit"))
      this.setProp("backLabel", _("Press Back for STB InfoSheet"))
    } else {
      this.setProp("ExitLabel", "")
      this.setProp("backLabel", _(""))
    }
  }

}
