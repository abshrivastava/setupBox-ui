//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {_} from "utils/locale"
import TimezoneManager from "services/managers/TimezoneManager"
import ActionsList from "../ActionList"

import "./index.css"

class Item extends Component {
  render() {
    return (
      <div className="CasInfoSheet-data">
        <span className="CasInfoSheet-label" prop="label" />&nbsp;
        <span className="CasInfoSheet-value" prop="value" />
      </div>
    )
  }
}

export default class CasInfoSheet extends Component {
  constructor(props) {
    super(props)
    this.subItems = []
  }
  render() {
    return (
      <div className="CasInfoSheet CasInfoSheet--hidden">
          <div className="CasInfoSheet-inner"  key="STBparent">
          <div className="CasInfoSheet-heading-wrapper">
            <div className="CasInfoSheet-heading" prop="heading"/>
            <div className="CasInfoSheet-date-Wrapper">
              <span className="CasInfoSheet-date" prop="date"/>
              <span className="CasInfoSheet-time" prop="time"/>
            </div>
            </div>
            <div className="CasInfoSheet-main">
              <div className="CasInfoSheet-context" prop="title"/>
              <div className="CasInfoSheet-details">
                <div className="CasInfoSheet-item">
                  <div className="CasInfoSheet-items" key ="SubItems" />
                </div>
              </div>
              <div className="CasInfoSheet-button" prop="STBInfo" />
           </div>
           <ActionsList key="optionList"/>
        </div>
      </div>
    )
  }

  onLoad(sub) {
    this.setProp("title", sub.title)
    this.setProp("STBInfo", sub.label)
    this.setProp("heading",_("CA Info Sheet"))
    this.updateClock(sub.date)
    this.setProp("TPlist", _("TP list screen"))
    this.setProp("Exit", _("Exit"))

    for (const item of this.subItems) {
      item.destroy()
    }
    this.subItems = []

    let data = {}
    if (!sub.filter) {
      data = sub.data
    } else {
      for (const key of sub.filter) {
        data[key] = sub.data[key] || ""
      }
    }
    let i = 0
    for (const [label, value] of Object.entries(data)) {
      const subItem = new Item({label: _(label), value: value})
      this.SubItems.appendChild(subItem.build())
      this.subItems[i] = subItem
      i++
    }
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  updateClock(d) {
    const time = TimezoneManager.getFormatTime(d)
    const d1 =  ((d).toString()).slice(0,16)
    const itemDate = d1.split(" ")
    const date = _(itemDate[0]) +(",") +(" ")+(_(itemDate[2]))+(" ")
    +(_(itemDate[1]))+(" ")+(_(itemDate[3]))+(" ")
    this.setProp("time", time)
    this.setProp("date", date)
  }

}
