//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"

import {default as heartDark} from "assets/pictos/heart-dark.png"
import {default as heartBlue} from "assets/pictos/heart-blue.png"

import "./ChannelItem.css"

export default class ChannelItem extends Component {
  constructor(item) {
    super()
    this.update(item)
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }

  update(item) {
    if (!item) {
      return
    }
    this.setProp("lcn", item.lcn)
    this.setProp("name", item.title)
    if (item.favorite) {
      this.setProp("defaultSrc", heartBlue)
    } else {
      this.setProp("defaultSrc", heartDark)
    }
  }

  enableFavorite() {
    this.favorite.src = heartBlue
  }

  disableFavorite() {
    this.favorite.src = heartDark
  }

  render() {
    let img = ""
    if (this.props.defaultSrc) {
      img = (
        <img className="favorite" src={this.props.defaultSrc} key="favorite"/>
        )
    }
    return (
      <div className="ChannelItem">
        {img}
        <span className="lcn" prop="lcn" />
        <span className="name" prop="name" />
      </div>
    )
  }
}
