//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"

import arrowLeft from "assets/arrows/left.png"
import arrowRight from "assets/arrows/right.png"
import {_} from "utils/locale"
import "./index.css"

class Item extends Component {
  render() {
    return (
      <div className="AdvancedScanItem">
        <span className="AdvancedScanItem-name" prop="name" />
        <div className="AdvancedScanItem-value">
          <img src={arrowLeft} className="arrow-left"/>
          <span prop="value" />
          <img src={arrowRight} className="arrow-right"/>
        </div>
      </div>
    )
  }

  update(item) {
    this.setProps(item)
  }

  select() {
    this.pushState("selected")
  }

  unSelect() {
    this.pullState("selected")
  }
}

class OptionListComponent extends Component {
  constructor(props) {
    super(props)
    this.optionListLength = 3
    this.selectedIdx = 0
  }

  render() {
    return (
      <div className="AdvancedScanOptionList">
        <span className="AdvancedScanOptionList-title" prop="title"/>
        <div key="inner">
          {Array.from({length: this.optionListLength}, () =>
          <Item collection="children" />)}
      </div>
    </div>
    )
  }

  load(itemList, title) {
    let i = 0
    itemList.forEach((item) => {
      this.children[i].update(item)
      i++
    })
    if (title) {
      this.setProp("title", title)
    }
  }

  select(idx) {
    this.children[this.selectedIdx].unSelect()
    this.selectedIdx = idx
    this.children[this.selectedIdx].select()
  }

  focus() {
    this.select(this.selectedIdx)
  }

  blur() {
    this.children[this.selectedIdx].unSelect()
  }

  disable(isDisable = false) {
    if (isDisable) this.pushState("disable")
    else this.pullState("disable")
  }
}

export class IFTOIF extends OptionListComponent {
  constructor() {
    super({title: "IFTOIF"})
    this.optionListLength = 1
  }
}

export class Satellite extends OptionListComponent {
  constructor() {
    super({title: _("Satellite")})
    this.optionListLength = 5
  }
}
export class LNB extends OptionListComponent {
  constructor() {
    super({title: _("LNB settings")})
    this.optionListLength = 4
  }
}

export default {
  IFTOIF,
  Satellite,
  LNB,
}
