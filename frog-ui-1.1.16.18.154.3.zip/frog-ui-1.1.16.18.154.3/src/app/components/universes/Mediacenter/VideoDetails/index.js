//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import ActionsTree from "app/components/widgets/ItemDetails/actions"

export default class MediaDetails extends Component {
  constructor() {
    super({
      title: "Untitled",
    })
  }

  render() {
    return (
      <div className="ItemDetails ItemDetails--hidden">
        <div className="ItemDetails-summary">
          <div className="ItemDetails-title" prop="title" />
        </div>
        <ActionsTree key="actionsTree" />
      </div>
    )
  }

  open(item) {
    this.setProps({
      title: item.title,
    })

    this.actionsTree.show()
    return this.show()
  }

  close() {
    return this.hide()
  }
}
