//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import defaultLogoUrl from "assets/pictos/unknown.png"
import imageLogoUrl from "assets/pictos/photo.png"
import videoLogoUrl from "assets/pictos/video.png"
import audioLogoUrl from "assets/pictos/music.png"
import folderLogoUrl from "assets/pictos/folder.png"
import volumeLogoUrl from "assets/pictos/usb.png"

import Volume from "services/models/mediacenter/Volume"
import Folder from "services/models/mediacenter/Folder"
import AudioFile from "services/models/mediacenter/AudioFile"
import VideoFile from "services/models/mediacenter/VideoFile"
import ImageFile from "services/models/mediacenter/ImageFile"
import UnknownFile from "services/models/mediacenter/UnknownFile"

export default class MediaItem extends Component {
  constructor() {
    super({
      title: "Untitled",
    })

    this.props.logo = defaultLogoUrl
  }

  render() {
    return (
      <div className="MediaItem MediaItem--hidden">
        <div className="MediaItem-summary">
          <img
            key="logoImg"
            className="MediaItem-logo"
            src={this.props.logo} />
          <div className="MediaItem-title" prop="title" />
        </div>
      </div>
    )
  }

  update(item) {
    this.item = item
    if (this.item) {
      this.updateView()
    } else {
      this.hide()
    }
  }

  updateView() {
    this.updateTitle()
    this.updateLogo()
    this.show()
  }

  updateTitle() {
    this.setProp("title", this.item.title)
  }

  updateLogo() {
    switch (this.item.constructor) {
    case Volume:
      this.logoImg.src = volumeLogoUrl
      break
    case Folder:
      this.logoImg.src = folderLogoUrl
      break
    case VideoFile:
      this.logoImg.src = videoLogoUrl
      break
    case AudioFile:
      this.logoImg.src = audioLogoUrl
      break
    case ImageFile:
      this.logoImg.src = imageLogoUrl
      break
    case UnknownFile:
    default:
      this.logoImg.src = defaultLogoUrl
      break
    }
  }
}
