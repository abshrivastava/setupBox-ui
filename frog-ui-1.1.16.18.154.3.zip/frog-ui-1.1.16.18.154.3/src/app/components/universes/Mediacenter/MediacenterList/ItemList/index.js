//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import Scrollable from "utils/Scrollable"
import {disableTransitions, restoreTransitions} from "utils/dom"

import MediacenterListItem from "./MediacenterListItem"
import "./index.css"

const LIST_SIZE = 9
const HALF_LIST_SIZE = ~~(LIST_SIZE / 2)
const WINDOW_SIZE = 5
const ITEM_HEIGHT = 94
const SELECTED_ITEM_HEIGHT = 106

export default class MediacenterListItemList extends Component {
  constructor(props) {
    super(props)
    Scrollable.ComponentMixin(this, {
      controller: "Mediacenter",
      collection: "children",
      size: LIST_SIZE,
      mode: "bounded",
    })
  }

  render() {
    return (
      <div className="MediacenterListItemList">
        <div className="MediacenterListItemList-inner" key="inner">
          {Array.from({length: LIST_SIZE}, () =>
            <MediacenterListItem collection="children" />)}
        </div>
      </div>
    )
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  applyScroll() {
    for (let i = 0, l = this.children.length; i < l; ++i) {
      const child = this.children[i]
      let y = ~~(i * ITEM_HEIGHT - (LIST_SIZE - WINDOW_SIZE) / 2 * ITEM_HEIGHT)

      if (i === HALF_LIST_SIZE) {
        y += ~~((SELECTED_ITEM_HEIGHT - ITEM_HEIGHT) / 2)
      }
      if (i > HALF_LIST_SIZE) {
        y += SELECTED_ITEM_HEIGHT - ITEM_HEIGHT
      }

      if (i === 0 || i === this.children.length - 1) {
        disableTransitions(child.dom)
      } else {
        restoreTransitions(child.dom)
      }

      child.dom.style.webkitTransform = `translate3d(0, ${y}px, 0)`
    }
  }
}
