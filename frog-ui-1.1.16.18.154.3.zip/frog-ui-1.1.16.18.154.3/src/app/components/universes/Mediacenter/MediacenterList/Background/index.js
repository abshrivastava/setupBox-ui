//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {default as backgroundUrl} from "assets/backgrounds/list-full.png"
import "./index.css"

export default class Background extends Component {

  render() {
    return (
      <img
        className="MediacenterListBackground"
        src={backgroundUrl}
        key="image" />
    )
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }
}
