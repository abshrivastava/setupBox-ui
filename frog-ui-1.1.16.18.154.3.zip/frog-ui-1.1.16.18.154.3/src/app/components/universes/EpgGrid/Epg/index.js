//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {default as blueIcon} from "assets/pictos/vod-bubble.png"

import ItemList from "./ItemList"
import ProgramInfos from "./ProgramInfos"
import TimeLine from "./TimeLine"
import ProgramGrid from "./ProgramGrid"
import "./index.css"

export default class Epg extends Component {

  render() {
    return (
      <div className="EpgGrid EpgGrid--hidden">
        <ProgramInfos key="programInfos" />
        <TimeLine key="timeLine" />
        <ItemList key="itemList" />
        <ProgramGrid key="programGrid" />
        <div className="GenreInfo" prop="genremain" />
          <img className="genre-icon" src={blueIcon} />
          <span className="genre-regional" prop="genreregional" />
          &nbsp;<span className="genre-title" prop="genrename" />
      </div>
    )
  }

  open() {
    return new Promise((resolve) => {
      this.itemList.open()
      this.programGrid.open()
      this.programInfos.open()
      this.timeLine.open()

      this.pullState("hidden")
      resolve()
    })
  }

  close() {
    return new Promise((resolve) => {
      this.programGrid.close()
      this.itemList.close()
      this.programInfos.close()
      this.timeLine.close()

      this.pushState("hidden")
      resolve()
    })
  }

  openTimeline() {
    return new Promise((resolve) => {
      this.timeLine.open()
      this.pullState("hidden")
      resolve()
    })
  }

  update(item) {
    this.programInfos.update(item)
  }

  setChannels(channels, currentChannelIndex) {
    this.itemList.setChannels(channels, currentChannelIndex)
  }

  selectChannel(idx) {
    this.itemList.selectChannel(idx)
  }

  move(direction, idx) {
    this.itemList.move(direction, idx)
  }

  loadPrograms(programs, manualRecords, timeLine) {
    this.programGrid.load(programs, manualRecords, timeLine)
  }

  programChanged(rowIndex, idx) {
    this.programGrid.selectProgram(rowIndex, idx)
  }

  flush() {
    this.programGrid.flush()
  }

  loadTimeline(data) {
    this.timeLine.loadTimeline(data)
  }

  setClock(clock) {
    this.programInfos.setClock(clock)
  }

  setGenre(genre) {
    if (genre.selectedFilterId === 888) {
      this.setProp("genreregional", "Regional")
      this.setProp("genrename", genre.selectedSubGenre)
    } else {
      this.setProp("genreregional", "")
      this.setProp("genrename", genre.selectedGenre)
    }
  }

  clearChannels() {
    this.itemList.flush()
  }

  closeTimeline() {
    this.timeLine.close()
  }

  markAsRecording(x, y, program) {
    this.programGrid.markAsRecording(x, y, program)
  }

  markAsScheduled(x, y, program) {
    this.programGrid.markAsScheduled(x, y, program)
  }

  unmarkScheduled(x, y, program) {
    this.programGrid.unmarkScheduled(x, y, program)
  }

  unmarkManualRecord(y, startDate) {
    this.programGrid.unmarkManualRecord(y, startDate)
  }
}
