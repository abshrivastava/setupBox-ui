//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {default as separatorUrl} from "assets/separators/vertical-right-96.png"
import "./index.css"

const LIST_SIZE = 5

class Item extends Component {
  constructor(props) {
    const defaultProps = {
      title: "Unknown",
      lcn: "0",
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="EpgChannelListItem EpgChannelListItemList-item">
        <div className="EpgChannelListItem-lcn" prop="lcn" />
        <div className="EpgChannelListItem-title" prop="title" />
        <img className="EpgChannelListItem-separator" src={separatorUrl} />
      </div>
    )
  }

  update(item) {
    this.setProp("title", item.title)
    this.setProp("lcn", item.lcn)
  }
}

export default class ItemList extends Component {
  constructor(props) {
    super(props)
    this.channels = null
  }

  render() {
    return (
      <div className="EpgChannelList EpgChannelList--hidden">
        <div className="EpgChannelItemList-inner" key="inner">
          {Array.from({length: LIST_SIZE}, () =>
            <Item collection="children" />)}
        </div>
      </div>
    )
  }

  open() {
    return this.pullState("hidden")
  }

  close() {
    return this.pushState("hidden")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  setChannels(channels, currentChannelIndex) {
    this.channels = channels
    this.selectChannel(currentChannelIndex)
  }

  selectChannel(index) {
    if (index === this.currentIndex) {
      // return
    }

    const computedIndex = index - (index % LIST_SIZE)
    const start = computedIndex
    const end = computedIndex + LIST_SIZE
    const channelsToShow = this.channels.items.slice(start, end)
    if (channelsToShow.length < LIST_SIZE) {
      while (channelsToShow.length < LIST_SIZE) {
        channelsToShow.push({title: "", lcn: ""})
      }
    }
    this.currentIndex = index
    let i = 0
    for (const item of channelsToShow) {
      this.children[i].pullState("selected")
      this.children[i].update(item)
      i++
    }

    this.applyScroll()
  }

  applyScroll() {
    this.children[this.currentIndex % LIST_SIZE].pushState("selected")
  }

  move(direction, newIndex) {
    if (direction === "UP") {
      this.moveUp(newIndex)
    }
    if (direction === "DOWN") {
      this.moveDown(newIndex)
    }
  }

  moveUp(newIndex) {
    this.children[this.currentIndex % LIST_SIZE].pullState("selected")
    this.currentIndex = newIndex
    this.applyScroll()
  }

  moveDown(newIndex) {
    this.children[this.currentIndex % LIST_SIZE].pullState("selected")
    this.currentIndex = newIndex
    this.applyScroll()
  }

  flush() {
    for (const item of this.children) {
      item.pullState("selected")
      item.update({})
    }
  }
}
