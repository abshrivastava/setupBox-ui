//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import TimezoneManager from "services/managers/TimezoneManager"
import {default as timeLineBackground} from "assets/backgrounds/epg-timeline.png"
import "./index.css"

const TIMELINE_ITEMS_NUMBERS = 5

class TimeItem extends Component {
  constructor(props) {
    const defaultProps = {
      value: "",
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="TimeItem TimeItem-item">
        <div className="TimeItem-value" prop="value" />
        <div className="TimeItem-indicator"/>
      </div>
    )
  }

  update(index, item) {
    if ((index % 2) === 1) {
      this.setProp("value", item.split(":")[1])
      this.pushState("half")
    } else {
      this.setProp("value", TimezoneManager.getEpgFormatTime(item))
    }
  }
}

export default class TimeLine extends Component {

  render() {
    return (
      <div className="TimeLine TimeLine--hidden">
        <img src={timeLineBackground}/>
        {Array.from({length: TIMELINE_ITEMS_NUMBERS}, () =>
        <TimeItem collection="children" />)}
      </div>
    )
  }

  loadTimeline(datas) {
    let i = 0
    datas.list.forEach((timeItem) => {
      this.children[i].update(i, timeItem)
      i++
    })
  }

  close() {
    return this.hide()
  }

  open() {
    return this.show()
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }
}
