//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import {_} from "utils/locale"
import "./index.css"

class FilterSelector extends Component {
  render() {
    return (< div className = "FilterSelector" key = "FilterSelector">
      <div className = "FilterSelector-bg" / >
        <div className = "FilterSelector-arrow" key = "arrow" / >
        </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class EpgFilterItem extends Component {
  render() {
    return (
      <div className = "EpgFilterItem"
      prop = "label" / >
    )
  }
}

export class EpgFilterList extends HybridListComponent {
  constructor() {
    super(FilterSelector, EpgFilterItem)
    this.ITEM_HEIGHT = 45
  }

  render() {
    return (<div className = "EpgFilterList" />)
  }
  showSelector() {
  }
}

export class EpgFilterListr extends HybridListComponent {
  constructor() {
    super(FilterSelector, EpgFilterItem)
    this.ITEM_HEIGHT = 45
  }

  render() {
    return (<div className = "EpgFilterListr" />)
  }
  showSelector() {
  }
}


export default class FiltersMenu extends Component {
  constructor() {
    const props = {filterHeading: "",filterSubHeading:"",filterFooter:""}
    super(props)
  }

  render() {
    return (
      <div className="FiltersMenu FiltersMenu--hidden">
        <div className="FiltersMenu-inner">
          <div className = "FiltersMenu-container" >
          <div className="Filter-icon " />
            <div className = "FilterContent">
              <div className = "FiltersMenu-heading" prop="filterHeading" />
              <div className = "FiltersMenu-subHeading" prop="filterSubHeading" />

              <EpgFilterList key="EpgFirstFilterList"/>
              <EpgFilterListr key="EpgSecondFilterList"/>
              <div className = "FiltersMenu-footer" prop="filterFooter" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  showSecondLevelFilter(filter) {
    this.setProp("filterSubHeading", _(filter.title))
    if (filter.title === "Regional") {
      this.setProp("filterHeading", _("Please choose a language"))
    }
    this.EpgFirstFilterList.pushState("hidden")
    this.EpgSecondFilterList.pullState("hidden")
  }

  showFirstLevelFilter() {
    // alert("Closing 2, Showing 1")

    this.setProp("filterHeading", _("Please choose a Filter"))
    this.setProp("filterSubHeading", "")
    this.setProp("filterFooter", _("Press OK to confirm"))
    this.EpgFirstFilterList.pullState("hidden")
    this.EpgSecondFilterList.pushState("hidden")
  }

  hideAllFilters() {
    // alert("Closing both")
    this.EpgFirstFilterList.pushState("hidden")
    this.EpgSecondFilterList.pushState("hidden")
    return this.hide()
  }

  show() {
    this.pullState("onBackground")
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    return this.pushState("hidden")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  openList() {

  }
}
