//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {isDefined} from "utils"
import "./index.css"

class ActionItem extends Component {
  render() {
    return (
      <div className="EpgsSubItem">
        <span className="EpgsSubItem-name" prop="name" />
        <kbd className="EpgsSubItem-value" key="inputs" prop="value" />
        <em className="" key="nextInput">_</em>
      </div>
    )
  }

  update(item) {
    this.setProp("name", item.name)
    if (isDefined(item.value)) {
      this.setProp("value", item.value)
    } else {
      this.pushState("action")
    }
  }

  setCurrent() {
    this.pushState("current")
  }

  unsetCurrent() {
    this.pullState("current")
  }

  activate() {
    this.pushState("active")
  }

  desactivate() {
    this.pullState("active")
  }

  showSpinner() {
    setTimeout(() => {
      this.pushState("hamsterWheel")
    })
  }

  hideSpinner() {
    setTimeout(() => {
      this.pullState("hamsterWheel")
    })
  }
}

export default class ActionsList extends Component {

  constructor(props) {
    super(props)
    this.maxInputs = 0
    this.actions = []
  }

  render() {
    return (
      <div className="EpgsSubList">
        <div className="actionList-inner" key="actionList" />
      </div>
    )
  }

  _flush() {
    this.actions = []
    this.focusedIdx = 0
    this.maxInputs = 0
    while (this.actionList.firstChild) {
      this.actionList.removeChild(this.actionList.firstChild)
    }
  }

  setActions(actions, maxInputs) {
    this._flush()

    this.maxInputs = maxInputs
    for (const action of actions) {
      const item = new ActionItem(action)
      this.actionList.appendChild(item.build())
      this.actions.push(item)
    }
    this.select(0)
  }

  setActive(idx) {
    this.actions[idx].activate()
  }

  select(idx) {
    this.actions[this.focusedIdx].pullState("selected")
    this.focusedIdx = idx
    this.actions[idx].pushState("selected")
  }

  onEdit() {
    for (const action of this.actions) {
      action.pushState("blur")
    }
    this.actions[this.focusedIdx].pullState("blur")
    this.actions[this.focusedIdx].pullState("selected")
    this.actions[this.focusedIdx].pushState("edit")
  }

  onError(index) {
    this.actions[index].pushState("error")
  }

  onCancel(inputs) {
    const selectedItem = this.actions[this.focusedIdx]
    selectedItem.inputs.textContent = inputs.join("")
    this.onSet()
  }

  onSet() {
    for (const action of this.actions) {
      action.pullState("blur")
    }
    this.actions[this.focusedIdx].pullState("error")
    this.actions[this.focusedIdx].pullState("edit")
    this.actions[this.focusedIdx].pushState("selected")
  }

  checkMaxInputs(item, inputs) {
    item.nextInput.className = (inputs.length > (this.maxInputs - 1)) ? "max" : ""
  }

  onUpdate(inputs) {
    const selectedItem = this.actions[this.focusedIdx]
    return new Promise((resolve) => {
      this.actions[this.focusedIdx].pullState("error")
      this.checkMaxInputs(selectedItem, inputs)
      selectedItem.inputs.textContent = inputs.join("")
      resolve()
    })
  }

  focus() {
    this.focusedIdx = 0
    this.actions[this.focusedIdx].pushState("selected")
  }

  blur() {
    this.actions[this.focusedIdx].pullState("selected")
  }

  setCurrent() {
    this.actions[this.focusedIdx].setCurrent()
  }

  updateCurrent() {
    for (const action of this.actions) {
      action.unsetCurrent()
    }
    this.actions[this.focusedIdx].setCurrent()
  }

  activate() {
    this.actions[this.focusedIdx].activate()
  }

  desactivate() {
    this.actions[this.focusedIdx].desactivate()
  }

  showSpinner() {
    this.actions[this.focusedIdx].showSpinner()
  }

  hideSpinner() {
    this.actions[this.focusedIdx].hideSpinner()
  }
}
