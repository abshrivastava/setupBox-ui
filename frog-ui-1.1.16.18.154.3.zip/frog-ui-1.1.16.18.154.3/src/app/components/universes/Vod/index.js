//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pullState, pushState, waitReflow} from "utils/dom"
import OptionMenu from "app/components/widgets/OptionMenu"
import ratingLogoUrl from "assets/pictos/rate.png"
import {formatDuration} from "utils/date"
import VoucherPopUp from "./voucherPopUp"
import VodLoading from "./loading"
import "./index.css"

const MAX_RATE = 5

class VodRating extends Component {
  render() {
    return (
      <div className="ratingWrapper">
        {Array.from({length: MAX_RATE}, () =>
          <img src={ratingLogoUrl} />)}
      </div>
    )
  }

  update(ratingLength) {
    this.dom.className = "ratingWrapper VodRating-" + ratingLength
  }
}

class VodDetail extends Component {
  render() {
    return (
      <div className="VodDetail">
        <div className="VodDetail-inner">
          <div className="VodDetail-header">
            <div prop="title" className="VodDetail-title"/>
            <div className="VodDetail-subHeader">
              <span prop="duration" className="VodDetail-duration"/>
              <VodRating key="vodRating" />
              <span key="priceContainer" className="VodDetail-price">
                <span key="price" prop="price" className="price"/>
                <span key="rented" prop="rented" className="rented"/>
              </span>
              <span key="vodDetailPack" className="VodDetail-pack">
                <span key="packprice" prop="packprice" className="packprice"/>
                <span key="rentedpack" prop="subscribedPack" className="subscribedPack" />
                <span prop="packname" />
              </span>
            </div>
          </div>
          <div className="VodDetail-actors">
            <span prop="actors" className="VodDetail-actors"/>
          </div>
          <div className="VodDetail-description">
            <span prop="description" />
          </div>
        </div>
      </div>
    )
  }

  update(item) {
    this.item = item
    this.setProp("title", item.title)
    this.setProp("duration", formatDuration(item.duration))
    this.setProp("rating", item.rating)
    this.setProp("description", item.description)
    this.setProp("actors", "ACTORS: " + item.getFormattedActors())

    this.updatePriceInfos()
    this.updatePackInfos()
    this.updateRating()
  }

  updatePriceInfos() {
    (this.item.isRented()) ? this.displayRented(this.item) : this.displayPrice(this.item)
    pullState(this.priceContainer, "hidden")
  }

  displayPrice() {
    this.setProp("price", this.item.price)
    pullState(this.price, "hidden")
    pushState(this.rented, "hidden")
  }

  displayRented() {
    this.setProp("rented", "Rented")
    pushState(this.price, "hidden")
    pullState(this.rented, "hidden")
  }

  updatePackInfos() {
    if (this.item.pack) {
      this.updatePricePackageInfo(this.item)
      this.setProp("packname", this.item.pack.name)
      pullState(this.vodDetailPack, "hidden")
    } else {
      pushState(this.vodDetailPack, "hidden")
    }
  }

  updatePricePackageInfo() {
    (this.item.pack.isBuy) ? this.displayPackSubscribed(this.item) : this.displayPackPrice(this.item)
  }

  displayPackSubscribed() {
    this.setProp("subscribedPack", "Subscribed")
    pushState(this.packprice, "hidden")
    pushState(this.priceContainer, "hidden")
    pullState(this.rentedpack, "hidden")
  }

  displayPackPrice() {
    this.setProp("packprice", this.item.pack.price)
    pullState(this.packprice, "hidden")
    pullState(this.priceContainer, "hidden")
    pushState(this.rentedpack, "hidden")
  }

  updateRating() {
    this.vodRating.update(this.item.rating)
  }
}

export default class VodMenu extends Component {
  render() {
    return (
      <div className="vodWrapper">
        <VodLoading ref="vodLoding"/>
        <div className="VodMenu VodMenu--hidden" key="vodMenu">
          <div className="VodMenu-background">
            <div className="VodMenu-background0" />
            <div className="VodMenu-background1" />
            <div className="VodMenu-background2" />
          </div>
          <div className="VodMenu-inner" key="inner">
            <VodDetail key="vodDetail"/>
            <OptionMenu ctrl="Vod" baseName="Vod2" key="Vod2"
              itemWidth="256" itemHeight="263" level="2"/>
            <OptionMenu ctrl="Vod" baseName="Vod1" key="Vod1"
              itemWidth="256" itemHeight="263" level="1" />
            <OptionMenu ctrl="Vod" baseName="Vod0" key="Vod0"
              itemWidth="256" itemHeight="66" level="0" />
          </div>
          <VoucherPopUp ref="voucherPopUp"/>
        </div>
      </div>
    )
  }

  update(item) {
    this.vodDetail.update(item)
  }

  showItemDetail() {
    this.Vod2.show()
  }

  hideItemDetail() {
    this.Vod2.hide()
  }

  onStyle(style) {
    const context = "Vod"
    const dom = this[`${context}${style.level}`].dom
    dom.setAttribute("style", `${style.attribute}: ${style.value}`)
  }

  show() {
    pullState(this.vodMenu, "onBackground")
    pullState(this.vodMenu, "hidden")
    waitReflow(this.dom)
    this.unfold()
  }

  hide() {
    this.fold()
    waitReflow(this.dom)
    pushState(this.vodMenu, "onBackground")
    pushState(this.vodMenu, "hidden")
  }

  onBackground() {
    pushState(this.vodMenu, "onBackground")
  }

  onForeground() {
    pullState(this.vodMenu, "onBackground")
  }

  fold() {
    pullState(this.vodMenu, "unfold")
  }

  unfold() {
    pushState(this.vodMenu, "unfold")
  }
}
