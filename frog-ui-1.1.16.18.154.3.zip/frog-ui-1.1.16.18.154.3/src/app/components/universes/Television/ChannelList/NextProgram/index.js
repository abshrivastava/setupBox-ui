//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import TimezoneManager from "services/managers/TimezoneManager"
import {pushState, pullState} from "utils/dom"
import "./index.css"
import * as images from "./images/"

const DEFAULT_PROPS = {
  title: "No information",
  category: "",
  startTime: "00:00",
  endTime: "00:00",
}

export default class NextProgram extends Component {
  constructor(props) {
    super(Object.assign({}, DEFAULT_PROPS, props))
  }

  render() {
    return (
      <div className="NextProgram">
        <div className="NextProgram-inner">
          <img className="NextProgram-scheduleIndicator" src={images.schedule} key="scheduleIndicator" />
          <img className="NextProgram-scheduleIndicator" src={images.reminder} key="reminderIndicator" />
          <div className="NextProgram-epgTitle" prop="title" />
          <div className="NextProgram-epgGenre" prop="category" />
          <div className="NextProgram-timeInfo" key="timeInfo">
            <div className="NextProgram-epgStart" prop="startTime" />
            <span>-</span>
            <div className="NextProgram-epgEnd" prop="endTime" />
          </div>
        </div>
      </div>
    )
  }

  update(program) {

    this.hideScheduleIndicator()
    this.hideReminderIndicator()
    if (!program) {
      this.setProps(DEFAULT_PROPS)
      return
    }

    this.setProp("title", program.title)
    this.setProp("category", program.category)
    this.setProp("startTime", TimezoneManager.getFormatTime(program.startDate))
    this.setProp("endTime", TimezoneManager.getFormatTime(program.endDate))

    if (program.isScheduled && !program.isReminder) {
      this.showScheduleIndicator()
    }
    if (program.isReminder) {
      this.showReminderIndicator()
    }
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  showScheduleIndicator() {

    pushState(this.scheduleIndicator, "visible", false)
  }

  hideScheduleIndicator() {
    pullState(this.scheduleIndicator, "visible", false)
  }

  showReminderIndicator() {
    pushState(this.reminderIndicator, "visible", false)
  }

  hideReminderIndicator() {
    pullState(this.reminderIndicator, "visible", false)
  }
}
