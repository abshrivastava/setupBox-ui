//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pick} from "utils"
import bus from "services/bus"
import ChannelManager from "services/managers/ChannelManager"
import Background from "./Background"
import Selection from "./Selection"
import UsbDisplay from "./UsbDisplay"
import ItemList from "./ItemList"
import CurrentProgram from "./CurrentProgram"
import NextProgram from "./NextProgram"

import "./index.css"

export default class ChannelList extends Component {
  constructor(props) {
    const {variant} = pick(props, "variant")
    super(props)
    this.variant = variant
  }

  render() {
    return (
      <div className={`ChannelList ChannelList--${this.variant}`}>
        <Background key="background" />
        <ItemList key="itemList" hasLogos={this.variant === "withLogos"}
                                 hasDefaultLogo={this.variant === "withDefaultLogo"}/>
        <CurrentProgram key="currentProgram" />
        <Selection key="selection" />
         <UsbDisplay key="UsbDisplay" />
        <NextProgram key="nextProgram" />
      </div>
    )
  }

  openFull() {
    bus.emit("adBanner:channelListOpen", true)
    ChannelManager.displayMode = "channelList"
    this.itemList.setMinimal(false)
    this.background.setMinimal(false)
    const promises = [
      this.selection.unfold(),
      this.UsbDisplay.fold(),
      this.itemList.unfold(),
      this.background.unfold().then(() => this.currentProgram.unfold()),
    ]

    return Promise.all(promises)
  }

  closeFull() {
    bus.emit("adBanner:channelListOpen", false)
    ChannelManager.displayMode = null
    return Promise.all([
      this.currentProgram.fold(),
      this.UsbDisplay.fold(),
      this.itemList.fold(),
      this.selection.fold(),
      this.background.fold(),
    ])
  }

  closeOnlyChannelList() {
    bus.emit("adBanner:channelListOpen", false)
    this.itemList.setMinimal(true)
    this.background.setMinimal(true)
    ChannelManager.displayMode = "infoBanner"
    this.itemList.unfold()
  }

  showNextProgram(program) {
    ChannelManager.displayMode = "channelList"
    // this.background.showNextProgram()
    this.selection.showNextProgram()
    this.currentProgram.fade()
    this.nextProgram.update(program)
    this.nextProgram.unfold()
  }

  hideNextProgram() {
    ChannelManager.displayMode = "channelList"
    // this.background.hideNextProgram()
    this.selection.hideNextProgram()
    this.nextProgram.fold()
    this.currentProgram.focus()
  }

  openInfoBanner() {
    if (ChannelManager.displayMode === "channelList") {
      return
    }
    ChannelManager.displayMode = "infoBanner"
    if (this.delayedDisable) {
      clearTimeout(this.delayedDisable)
    }
    this.itemList.setMinimal(true)
    this.background.setMinimal(true)
    return Promise.all([
      this.selection.unfold(),
      this.itemList.unfold(),
      this.background.unfold().then(() =>this.currentProgram.unfold()),
    ])
  }

  showDolbyLogo() {
    this.currentProgram.updateDolbyInfo()
  }

  closeInfoBanner() {
    if (ChannelManager.displayMode !== "infoBanner") {
      return
    }
    ChannelManager.displayMode = null
    bus.emit("clock:close")
    return Promise.all([
      this.currentProgram.fold(),
      this.UsbDisplay.fold(),
      this.itemList.fold().then(()=>{
        this.itemList.setMinimal(false)
        this.background.setMinimal(false)
      }),
      this.selection.fold(),
      this.background.fold(),
    ])
  }

  openUSBlist() {
    // alert("asda1")
    return  this.UsbDisplay.unfold()
  }

  closeUSBlist() {
  // alert("asda")
    return this.UsbDisplay.fold()
  }


  closeInfoBannerWithDelay() {
    if (ChannelManager.displayMode !== "infoBanner") {
      return
    }
    this.delayedDisable = setTimeout(() => this.closeInfoBanner(), 3000)
  }

  enableFastScroll() {
    this.pushState("fastScroll")
  }

  disableFastScroll() {
    this.pullState("fastScroll")
  }

  update(data) {
    return this.itemList.setScrollableSource(data)
  }

  updateProgram(program,genre) {
    this.currentProgram.update(program,genre)
  }

  clearCurrentProgram() {
    this.currentProgram.update({
      title: "...",
      id: -1,
    }, "")
    this.currentProgram.hideDolbyInfo()
  }

  updateDolbyInfo(data) {
    this.currentProgram.updateDolbyInfo(data)
  }

  hideDolbyInfo() {
    this.currentProgram.hideDolbyInfo()
  }
  updateUsb(title) {
    this.UsbDisplay.updateTitle(title)
  }


  updateNextProgram(program) {
    this.nextProgram.update(program)
  }

  startScrolling() {
    this.currentProgram.onScrollStart()
  }

  stopScrolling() {
    this.currentProgram.onScrollStop()
  }

  showTSIndicator() {
    this.currentProgram.showTSIndicator()
  }

  hideTSIndicator() {
    this.currentProgram.hideTSIndicator()
  }

  showRecordIndicator() {
    this.currentProgram.showRecordIndicator()
  }

  hideRecordIndicator() {
    this.currentProgram.hideRecordIndicator()
  }
}
