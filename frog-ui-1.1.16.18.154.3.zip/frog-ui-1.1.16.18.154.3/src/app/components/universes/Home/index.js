//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {MenuListComponent} from "app/utils/widgets/lists"
import "./index.css"

class HomeSelector extends Component {
  render() {
    return (
      <div className="HomeSelector"/>
    )
  }

  select(translationValue) {
    const translation = `(${translationValue}px, 0, 0)`
    return this.dom.style.webkitTransform = "translate3d" + translation
    // const p = new Promise((resolve) => {
    //   const animationListener = () => {
    //     this.dom.removeEventListener("webkitTransitionEnd", animationListener)
    //     resolve()
    //   }
    //   this.dom.addEventListener("webkitTransitionEnd", animationListener)
    // })
    // return p
  }
}

class HomeItem extends Component {
  render() {
    return (
      <div className="HomeItem">
        <div key="icon" className={`HomeItem-icon--${this.props.icon} HomeItem-icon`}/>
        <div key="label" className="HomeItem-label" prop="label"/>
      </div>
    )
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }
}

class HomeList extends MenuListComponent {
  constructor() {
    super(HomeSelector, HomeItem)
    this.ORIENTATION = "horizontal"
    this.ITEM_HEIGHT = 184
    this.ITEM_WIDTH = 213
    this.WINDOW_SIZE = 6
    this.EXTRA_VISIBLE_ITEMS = 0
  }

  render() {
    return (
      <div className="HomeList" />
    )
  }
}

export default class HomeMenu extends Component {
  constructor(props) {
    super(props)
    this.ITEM_WIDTH = 213
    this.timer = null
  }

  render() {
    return (
      <div className="HomeMenu">
        <div className="HomeMenu-background" key="background"/>
        <HomeList key="homeList"/>
      </div>
    )
  }

  select(idx) {
    return this.homeList.select(idx)
  }

  show() {
    return this.unfold()
  }

  hide() {
    return this.fold()
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }
}
