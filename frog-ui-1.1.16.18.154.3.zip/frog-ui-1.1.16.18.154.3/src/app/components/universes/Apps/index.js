//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"

import AppHeader from "./AppHeader"
import AppCategories from "./AppCategories/AppCategories"
import AppItems from "./AppItems/AppItems"
import AppDetail from "./AppDetail"
import AppPreview from "./AppPreview"
import AppActions from "./AppActions/AppActions"

import "./index.css"

export default class AppsUniverse extends Component {
  render() {
    return (
      <div className="Apps-universe Apps-universe--hidden" >
        <AppHeader key="header"/>
        <div className="infos">
          <AppDetail key="detail" />
          <AppPreview key="preview" />
          <AppActions key="actions" />
        </div>
        <AppItems key="items" />
        <AppCategories key="categories"/>
      </div>
    )
  }

  show() {
    this.pullState("hidden")
  }

  hide() {
    this.pushState("hidden")
  }
}
