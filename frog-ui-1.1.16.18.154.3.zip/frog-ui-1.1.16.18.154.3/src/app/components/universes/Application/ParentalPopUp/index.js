//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"
import {_} from "utils/locale"
import {pushState, pullState} from "utils/dom"
import {default as PopUp, PopUpButton} from "app/components/universes/Application/PopUp"

export default class ParentalPopUp extends PopUp {
  constructor(props) {
    const defaultProps = {
      title: _("Parental Control Settings"),
      subtitle: _("Enter pin code"),
      message: _("Press OK to confirm"),
      countdown: "",
      error_msg: _("Wrong pin code !"),

    }
    super(Object.assign({}, defaultProps, props))
    this.focusedIdx = 1
    this.countDown = null
    this.refreshCountDownTicker = null
    this.enteredPin = ""
    this.errorStrings= {
      error_msg: "Wrong pin code !",
      mismatch: _("PINs do not match."),
    }
    this.updatePopUpDetails()
  }

  updatePopUpDetails() {
    this.popupDetails = {
      IF2IF: {
        title: _("IF2IF MODE"),
        subtitle: _("Please enter PIN to select IF2IF mode, this will launch scan and "+
                    "it will delete your recording and favourite list."),
        message: _("Press OK to confirm"),
        countdown: "",
      },
      EnterPin: {
        title: _("Parental Control Settings"),
        subtitle: _("Enter pin code"),
        message: _("Press OK to confirm"),
        countdown: "",
      },
      ChangePin: {
        title: _("Change Pin Code"),
        subtitle: _("Enter current pin code"),
        message: _("Press OK to confirm"),
        countdown: "",
      },
      NewPin: {
        title: _("Change Pin Code"),
        subtitle: _("Enter new pin code"),
        message: _("Press OK to confirm"),
        countdown: "",
      },
      ConfirmPin: {
        title: _("Change Pin Code"),
        subtitle: _("Confirm new pin code"),
        message: _("Press OK to confirm"),
        countdown: "",
      },
      Success: {
        title: _("Change Pin Code"),
        subtitle: _("Your pin code has been successfully updated !"),
        message: _("Press OK to exit"),
        countdown: "",
      },
      BlockChannel: {
        title: _("This Channel Is Blocked"),
        subtitle: _("Enter pin code"),
        message: _("Press OK to confirm"),
        countdown: "",
      },
    }
  }

  render() {
    return (
      <div class="ParentalPopUp ParentalPopUp--hidden">
        <div className="ParentalPopUp_icon1" key = "ParentalPopUp_icon1" />
        <div className="ParentalPopUp-wrapper">
        <div id="step1">
      <p className="ParentalPopUp-title" prop="title" key = "title" />
       <p className="ParentalPopUp-subtitle" prop="subtitle" key = "subtitle" />
       <div className="ParentalPopUp-Pincodebox" key = "pincodeFld" />
       <div className="ParentalPopUp-underline" key = "pincod_underline" />
       <div className="ParentalPopUp-buttonsec" prop="message" key = "message"  />
       </div>

          <div className="ParentalPopUp-buttons-wrapper" key="buttonWrapper">
            {Array.from({length: 2}, () =>
            <PopUpButton collection="button"/>)}
          </div>
          <span className="ParentalPopUp-countdown hidden" prop="countdown" />
        </div>
      </div>
    )
  }
  updateText(value) {
    if (this.pincodeFld.textContent.length < 7) {
      this.enteredPin += value
      this.pincodeFld.textContent += "*" + " "
      // this.setProp("pincodeFld","*" + " ")
    }
  }
  deleteText() {
    if (this.pincodeFld.textContent.length >= 2) {
      this.enteredPin = this.enteredPin.substring(0, this.enteredPin.length-1)
      this.pincodeFld.textContent = this.pincodeFld.textContent.substring(0, this.pincodeFld.textContent.length-2)
  //    this.setProp("pincodeFld",this.pincodeFld.textContent.substring(0, this.pincodeFld.textContent.length-2))
    }
  }
  updatePopup(code) {
    this.updatePopUpDetails()
    this.setProp("title",this.popupDetails[code].title)
    this.setProp("subtitle",this.popupDetails[code].subtitle)
    this.setProp("message",this.popupDetails[code].message)

    this.pincodeFld.textContent = ""
    this.enteredPin = ""

  }

  updateRecordingPopup() {
    this.setProp("title","The Recording is Locked .")
    this.setProp("subtitle","")
    this.setProp("message","Please Enter PIN .")

    this.pincodeFld.textContent = ""
    //  this.setProp("pincodeFld","")
    this.enteredPin = ""
  }

  showError(errorType) {
    // this.message.textContent = this.errorStrings[errorType]
    this.setProp("message",_(this.errorStrings[errorType]))
    pushState(this.ParentalPopUp_icon1, "errorIcon")
    pushState(this.message, "error_msg")
    this.pincodeFld.textContent = ""
    // this.setProp("pincodeFld","")
    this.enteredPin = ""

  }
  hideError() {
    pullState(this.message, "error_msg")
    pullState(this.ParentalPopUp_icon1, "errorIcon")
    this.setProp("message","")
  }

  showSuccess() {
    pushState(this.ParentalPopUp_icon1, "infoIcon")
    pushState(this.subtitle, "success_msg")
    this.pincodeFld.textContent = ""
    // this.setProp("pincodeFld","")
    this.enteredPin = ""
    pushState(this.pincod_underline, "hidden")
  //  this.pincod_underline.className += " hideElement"
    pushState(this.message, "success_msg")
  }

  hideSuccess() {
    pullState(this.subtitle, "success_msg")
    pullState(this.ParentalPopUp_icon1, "infoIcon")
  //  this.pincod_underline.className = this.pincod_underline.className.replace(" hideElement", "")
    pullState(this.pincod_underline, "hidden")
    pullState(this.message, "success_msg")
  }


  onOpen() {
    this.enteredPin = ""
    this.pincodeFld.textContent = ""
    // this.setProp("pincodeFld","")
    this.pincod_underline.textContent = "_ _ _ _"
    // this.setProp("pincod_underline","_ _ _ _")
    return this.show()
  }

  noButtons() {
    pullState(this.buttonWrapper, "hidden")
  }


}
