//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Component from "widgets/Component"
import "./index.css"
import {createTicker} from "utils"
import {pushState, pullState} from "utils/dom"

export class UnsubscribedErrorMsgButton extends Component {
  render() {
    return (
      <div className="UnsubscribedErrorMsg-button" prop="label" />
    )
  }

  update(value) {
    this.setProp("label", value)
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }
}

export default class UnsubscribedErrorMsg extends Component {
  constructor(props) {
    const defaultProps = {
      title: "",
      message: "",
      message2: "",
      countdown: "",
    }
    super(Object.assign({}, defaultProps, props))

    this._flush()
  }

  render() {
    return (
      <div class="UnsubscribedErrorMsg UnsubscribedErrorMsg--hidden UnsubscribedErrorMsg--BtnHide"
      key="UnsubscribedErrorMsgLevel">
        <div className="UnsubscribedErrorMsg-icon " />
        <div className="UnsubscribedErrorMsg-wrapper">
          <span className="UnsubscribedErrorMsg-title" prop="title" />
          <div className="UnsubscribedErrorMsg-message" key="message" prop="message"/>
          <div className="UnsubscribedErrorMsg-message2 UnsubscribedErrorMsg-message2" key="message2" prop="message2" />
          <div className="UnsubscribedErrorMsg-message3 UnsubscribedErrorMsg-message3" key="message3" prop="message3" />
          <div className="UnsubscribedErrorMsg-message4 UnsubscribedErrorMsg-message4" key="message4" prop="message4" />
          <div className="UnsubscribedErrorMsg-buttons-wrapper" key="buttonWrapper" />
          <span className="UnsubscribedErrorMsg-countdown hidden" prop="countdown" />
          <div className="Button-section">
            <span className="InfoBlue-button" prop="STBlist" />
            <span className="InfoYellow-button" prop="TPlist" />
          </div>
        </div>
      </div>
    )
  }

  onOpen() {
    return this.show()
  }

  onClose() {
    // this.message2 && pushState(this.message2, "hidden")
    // this.message3 && pushState(this.message3, "hidden")
    // this.message4 && pushState(this.message4, "hidden")
    this.resetMessage()
    this._clearCountDown()
    return this.hide()
  }

  updateTitle(title) {
    this.setProp("STBlist", "STB InfoSheet")
    this.setProp("TPlist", "TP list screen")
    this.setProp("title", title)
  }

  updateMessage(message) {
    this.setProp("message", message)
  }

  alignMessage() {
    pushState(this.message, "alertMessage")
  }

  resetMessage() {
    pullState(this.message, "alertMessage")
  }

  updateMessage2(message) {
    pullState(this.message2, "hidden")
    this.setProp("message2", message)
  }

  updateMessage3(message) {
    pullState(this.message3, "hidden")
    this.setProp("message3", message)
  }
  updateMessage4(message) {
    pullState(this.message4, "hidden")
    this.setProp("message4", message)
  }

  startCountDown(value) {
    const countDown = value
    this.setProp("countdown", countDown  + " sec")
  }

  setCountDown(value) {
    if (!this.refreshCountDownTicker) {
      this.refreshCountDownTicker = createTicker(1000)
      this.refreshCountDownTicker.start(this._updateCountDown.bind(this), true)
    }
    this.countDown = value
    this.setProp("countdown", value  + " sec")
  }

  _updateCountDown() {
    this.setCountDown(this.countDown - 1)
  }

  _clearCountDown() {
    if (this.refreshCountDownTicker) {
      this.refreshCountDownTicker.stop()
      this.setProp("countdown", "")
    }
    this.refreshCountDownTicker = null
  }

  setButtons(buttons) {
    this._flush()
    if (buttons.length > 0) {
      for (const button of buttons) {
        const item = new UnsubscribedErrorMsgButton(button)
        this.buttonWrapper.appendChild(item.build())
        this.buttons.push(item)
      }
      pushState(this.buttonWrapper, "hidden")
      this.selectButton(Math.min(this.buttons.length - 1, 1))
    }
  }

  selectButton(index) {
    this.buttons[this.focusedIdx].blur()
    this.focusedIdx = index
    this.buttons[index].focus()
  }

  displayTop() {
    pushState(this.UnsubscribedErrorMsgLevel, "displayTop")
  }

  onBtnShow() {
    this.pullState("BtnHide")
  }

  onBtnClose() {
    this.pushState("BtnHide")
  }

  onBackgroundShow() {
    this.pushState("BackgoundShow")
  }

  onBackgroundClose() {
    this.pullState("BackgoundShow")
  }

  _flush() {
    this.focusedIdx = 0
    this.countDown = null
    this.buttons = []
    this.refreshCountDownTicker = null
    if (this.buttonWrapper) {
      while (this.buttonWrapper.firstChild) {
        this.buttonWrapper.removeChild(this.buttonWrapper.firstChild)
      }
      pullState(this.buttonWrapper, "hidden")
    }
  }
}
