//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {testImage} from "utils/image"

import "./index.css"

export default class AdBanner extends Component {
  render() {
    return (
      <div className="Ad">
        <img className="Ad-image"
          src=""
          key="adImage" />
      </div>
    )
  }

  fold() {
    return this.pullState("unfold")
  }

  unfold(url, action) {
    this.pushState("unfold")
    return this.setBanner(url, action)
    //  .then(() => this.pushState("unfold"))
  }

  setBelow(url, action) {
    return this.setBanner(url, action)
      .then(() => {
        this.pushState("below")
        this.show()
      })
  }

  unsetBelow() {
    return this.pullState("below")
  }

  setBanner(url, action="none") {
    if (!url) return Promise.resolve()
    this.adImage.style.display = (action === "none") ? "block" : "none"
    return new Promise((resolve) => {
      if (url) testImage(this.adImage, url)
      resolve()
    })
  }
}
