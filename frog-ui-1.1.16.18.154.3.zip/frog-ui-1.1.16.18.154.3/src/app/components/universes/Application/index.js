//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"
import config from "utils/config"

import Clock from "./Clock"
import AdBanner from "./AdBanner"
import OperatorLogo from "./OperatorLogo"
import Usb from "./Usb"
import VolumeBar from "./VolumeBar"
import PopUp from "./PopUp"
import ParentalPopUp from "./ParentalPopUp"
import UnsubscribedErrorMsg from "./UnsubscribedErrorMsg"
import DevToolBar from "./DevToolBar"
import NumZap from "./NumZap"
import PlaybackInfo from "./PlaybackInfo"

export default class ApplicationUniverse extends Component {
  render() {
    return (
      <div className="Application-universe">
        <Clock ref="clock"/>
        <AdBanner ref="adBanner"/>
        <OperatorLogo ref="operatorLogo"/>
        <Usb ref="usbFormat"/>
        <VolumeBar ref="volumeBar"/>
        <PopUp ref="popUp"/>
        <ParentalPopUp ref="ParentalpopUp"/>
        <UnsubscribedErrorMsg ref="UnsubscribedErrorMsg"/>
        <NumZap ref="numZap"/>
        <PlaybackInfo ref="playbackInfo"/>
        {config.DEBUG && <DevToolBar ref="devToolBar"/>}
      </div>
    )
  }
}
