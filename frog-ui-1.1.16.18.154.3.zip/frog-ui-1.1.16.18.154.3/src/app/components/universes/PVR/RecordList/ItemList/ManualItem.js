//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"

import pictoUrl from "assets/pictos/manual.png"

export default class ManualItem extends Component {
  constructor() {
    super({comment: ""})
  }

  render() {
    return (
      <div className="ManualItem ManualItem--hidden">
        <img className="ManualItem-picto" src={pictoUrl} />
        <div className="ManualItem-comment" prop="comment" />
      </div>
    )
  }

  update(item) {
    this.show()
    this.setProps({
      comment: item.comment,
    })
  }
}
