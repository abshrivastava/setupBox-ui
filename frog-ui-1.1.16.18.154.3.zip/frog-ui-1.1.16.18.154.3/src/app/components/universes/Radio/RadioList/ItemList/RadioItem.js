//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pick} from "utils"
import {testImage} from "utils/image"
import defaultLogoUrl from "assets/fallbacks/radio-logo.png"

export default class RadioItem extends Component {
  static defaultProps = {
    lcn: 0,
    title: "Unknown",
    logo: defaultLogoUrl,
  }

  constructor(props) {
    const {hasLogo} = pick(props, "hasLogo")
    super(props)
    this.hasLogo = hasLogo
  }

  render() {
    if (this.hasLogo) {
      return (
        <div className="RadioListItem RadioListItemList-item">
          <div className="RadioListItem-lcn" prop="lcn" />
          <img
            key="logoImg"
            className="RadioListItem-logo"
            src={this.props.logo} />
          <div className="RadioListItem-title line-clamp" prop="title" />
        </div>
      )
    } else {
      return (
        <div className="RadioListItem RadioListItemList-item">
          <div className="RadioListItem-lcn" prop="lcn" />
          <div className="RadioListItem-title line-clamp" prop="title" />
        </div>
      )
    }
  }

  update(channel) {
    if (!channel) {
      this.setProps({lcn: "", title: "", logo: ""})
      return
    }
    this.setProps(channel)
    if (this.logoImg) {
      testImage(this.logoImg, channel.logo, defaultLogoUrl)
    }
  }
}
