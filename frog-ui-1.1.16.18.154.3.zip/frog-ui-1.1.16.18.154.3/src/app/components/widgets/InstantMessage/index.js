//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Component from "widgets/Component"
import TimeoutsManager from "services/managers/TimeoutsManager"
import {on} from "services/events"
import bus from "services/bus"
import "./index.css"

const INSTANT_MESSAGE_H_MESSAGE = "INSTANT MESSAGE"

export default class InstantMessage extends Component {
  constructor(props) {
    const defaultProps = {
      messageHead: "INSTANT MESSAGE",
      messageSub: "",
    }
    super(Object.assign({}, defaultProps, props))
    this.instantMessageShown = null
  }

  render() {
    return (
      <div className="InstantMessage InstantMessage--hidden">
        <div className="InstantMessage-icon "/>
        <table className="Message-wrapper">
          <tr>
            <th className="Message-head" prop="messageHead" />
          </tr>
          <tr>
            <th className="Message-sub" prop="messageSub" />
          </tr>
        </table>
      </div>
    )
  }

  showInstantMessage(message, duration) {
    this.setProp("messageHead", INSTANT_MESSAGE_H_MESSAGE)
    this.setProp("messageSub", message)
    this.show()
    TimeoutsManager.setTimer(duration*100000, function() {
      bus.emit("instantmessage:close")
    })
  }

  @on("instantmessage:close")
  hideInstantMessage() {
    this.hide()
  }

  close() {
    this.instantMessageShown = null
    this.hide()
  }
}
