//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import "./index.css"

class ItemBackground extends Component {
  render() {
    return (
      <div className="OptionMenu-background" />
    )
  }
}

class Item extends Component {
  constructor(props) {
    const defaultProps = {
      label: "",
      title: "",
      icon: "",
      context: "",
      signal: "",
      filter: [],
      data: null,
      focus: null,
      default: false,
      foreground: false,
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="OptionMenu-item">
        <div key="title" className="OptionMenu-item-title">
          <span prop="title" />
        </div>
        <div
          key="icon"
          className="OptionMenu-item-icon" />
        <div key="label" className="OptionMenu-item-label">
          <span prop="label" />
        </div>
      </div>
    )
  }

  update(item, handleIcons) {
    this.setProp("label", item.label || item.name)
    this.setProp("title", item.title)
    this.setDefault(item)
    this.setIcon(item, handleIcons)
  }

  setDefault(item) {
    if (item.default) {
      domUtils.pushState(this.label, "default")
    } else {
      domUtils.pullState(this.label, "default")
    }
  }

  setIcon(item, handleIcons) {
    const icon = handleIcons && item.icon ? item.icon : false
    this.icon.className = "OptionMenu-item-icon"
    if (icon) {
      domUtils.pullState(this.label, "no-icon")
      if (icon.startsWith("http://") || icon.startsWith("https://")) {
        this.icon.setAttribute("style", `background-image: url("${icon}")`)
      } else {
        domUtils.pushState(this.icon, icon)
      }
    } else {
      domUtils.pushState(this.label, "no-icon")
    }
  }
}

export default class OptionMenu extends Component {
  constructor(props) {
    super(props)
    this.ctrl = this.props.ctrl
    this._level = this.props.level
    this.itemWidth = this.props.itemWidth
    this.itemHeight = this.props.itemHeight
    this.baseName = this.props.baseName

    // herein props
    this.defaultItem = {label: ""}
    this.items = []
    this.optionItems = []
    this.maxItems = 0
    this.selectedIndex = 0
    this.lastIndex = 0
    this.hybrids = {"max": 0, "pos": 0}
    this.selectedTimer = null
    this.backgroundItems = []
    this.icons = []
    this.isRoot = false
    this.isBranch = false
    this.isLeaf = false
  }

  render() {
    return (
      <div className={`${this.baseName}Menu OptionMenu-widget`}>
        <div className="OptionMenu OptionMenu--unfocused" key="inner">
          <div key="backgrounds" className="OptionMenu-backgrounds" />
          <div key="selector" className="OptionMenu-selector">
            <span key="arrow" className="OptionMenu-selector-arrow" />
          </div>
          <div key="OptionMenu" className="OptionMenu-items" />
        </div>
      </div>
    )
  }

  set level(value) {
    this._level = value
  }

  get level() {
    return parseInt(this._level, 10)
  }

  onStyle() {
    return new Promise((resolve) => {
      const style = {
        level: this.level,
        attribute: "width",
        value: `${this.maxItems * this.itemWidth}px`,
      }
      resolve(style)
    })
  }

  onInit(model) {
    Object.assign(this, model)
    if (this.level === 0) {
      this.onRoot()
    } else if (this.level > 1) {
      this.hide()
    }
  }

  clear() {
    this.isRoot = false
    this.isBranch = false
    this.isLeaf = false
    this.items = []
    this.optionItems = []
    this.backgroundItems = []
    while (this.OptionMenu.firstChild) {
      this.OptionMenu.removeChild(this.OptionMenu.firstChild)
    }
    while (this.backgrounds.firstChild) {
      this.backgrounds.removeChild(this.backgrounds.firstChild)
    }
    domUtils.pushState(this.inner, "previous")
    domUtils.pushState(this.inner, "unfocused")
  }

  onLoad(items, resetSelector = true) {
    this.items = items
    this.selectedIndex = 0
    let i = 0

    // build and|or update items
    for (const item of this.items) {
      this.addItem(item, i)
      i++
    }

    // remaining items from previous load
    this.updateItems(i)

    // if !inNextLevel (id: loading current level items) no reset of selector
    if (resetSelector) {
      this.handleSelection(true)
    }
  }

  addItem(item, index) {
    item.baseName = this.baseName
    item.icon = item.assetIcon || false
    item.default = item.default && this.isLeaf || false

    if (!this.optionItems[index]) {
      this.buildItem(index)
    }

    this.optionItems[index].update(item, this.handleIcons)
    if (index > 0) {
      this.optionItems[index].pullState("selected")
    }
    if (this.withBg) {
      this.backgroundItems[index].pullState("selected")
    }

    this.maxItems = this.items.length
    this.lastIndex = this.items.length - 1
  }

  buildItem(itemIndex) {
    const item = new Item({baseName: this.baseName})
    item.build()
    this.OptionMenu.appendChild(item.dom)
    this.optionItems[itemIndex] = item
    this.addBackgroundToItem(item, itemIndex)
  }

  addBackgroundToItem(item, itemIndex) {
    if (this.withBg) {
      const backgroundItem = new ItemBackground(item)
      this.backgrounds.appendChild(backgroundItem.build())
      this.backgroundItems[itemIndex] = backgroundItem
    }
  }

  updateItems(startIndex) {
    while (startIndex < this.optionItems.length) {
      this.optionItems[startIndex].update(this.defaultItem, this.handleIcons)
      this.optionItems[startIndex].pullState("selected")
      if (this.withBg) {
        this.backgroundItems[startIndex].pullState("selected")
      }
      startIndex++
    }
  }

  onFocus(init = false) {
    domUtils.pullState(this.inner, "previous")
    domUtils.pullState(this.inner, "unfocused")
    if (!init) {
      this.handleSelection()
    }
  }

  onBlur(asPrevious = false) {
    (asPrevious) ?  domUtils.pushState(this.inner, "previous") : domUtils.pushState(this.inner, "unfocused")
  }

  onSelect(prevIndex, nextIndex, timeout) {
    if (this.optionItems[prevIndex] && prevIndex >= 0) {
      this.optionItems[prevIndex].pullState("selected")
    }

    setTimeout(() => {
      if (this.selectedIndex === nextIndex) {
        if (this.optionItems[nextIndex] && nextIndex <= this.lastIndex) {
          this.optionItems[nextIndex].pushState("selected")
        }
      }
    }, timeout)

    this.selectedIndex = nextIndex
    this.handleSelection()
  }

  handleSelection(reset = false) {
    // nothing to do in case of item detail
    if (this.level < 2) {
      const x = -this.itemWidth * this.selectedIndex
      const y = (!reset || this.scroll) ? 0 : -this.itemHeight
      this.OptionMenu.style.webkitTransform = `translate3d(${x}px, ${y}px, 0)`
    }
  }

  show() {
    domUtils.pullState(this.dom, "hidden")
  }

  hide() {
    domUtils.pushState(this.dom, "hidden")
  }

  onUnfold() {
    domUtils.pullState(this.dom, "folded")
  }

  onFold() {
    domUtils.pushState(this.dom, "folded")
  }

  onBranch() {
    domUtils.pullState(this.inner, "leaf")
  }

  onLeaf() {
    domUtils.pushState(this.inner, "leaf")
  }

  onRoot() {
    this.isRoot = true
    domUtils.pushState(this.inner, "root")
  }
}
