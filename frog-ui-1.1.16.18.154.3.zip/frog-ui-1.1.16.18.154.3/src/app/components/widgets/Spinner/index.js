//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {FixedLimitedListComponent} from "app/utils/widgets/lists"
import "./index.css"

class SpinnerSelector extends Component {
  render() {
    return (
      <div className="SpinnerSelector">
        <div className="SpinnerSelector-bg"/>
      </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {}
  showArrow() {}
}

export class SpinnerItem extends Component {
  constructor(props) {
    const defaultProps = {
      title: "Unknown",
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="SpinnerItem">
        <div className="SpinnerItem-title" prop="title" />
      </div>
    )
  }

  update(item) {
    this.setProp("title", item.title)
  }
}

export default class SpinnerList extends FixedLimitedListComponent {
  constructor(item) {
    super(SpinnerSelector, item || SpinnerItem)
  }

  render() {
    return (
      <div className="SpinnerList-items" />
    )
  }

  enable() {
    this.actions[this.focusedIdx].pushState("selected")
  }

  disable() {
    this.actions[this.focusedIdx].pullState("selected")
  }

  select(idx) {
    return new Promise((resolve) => {
      this.actions[this.focusedIdx].pullState("selected")
      super.select(idx)
      this.actions[this.focusedIdx].pushState("selected")
      resolve(idx)
    })
  }
}
