//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import defaults from "../../../config.json"
import KEYMAPS from "./keys"

try {
  // const localDefaults = require("../../../config.local.json")
  Object.assign(defaults) // , localDefaults
} catch (e) {
  // Ignored
}

config.setDefaults(defaults)

config.defineFlag("KEYS", "keymap")
config.defineFlag("STB_IP", "stbIp")
config.defineFlag("APP_IP", "appIp")
config.defineFlag("DEBUG", "debug")
config.defineFlag("BROADCAST", "broadcast")
config.defineFlag("FREQ_START", "freqStart")
config.defineFlag("FREQ_END", "freqEnd")
config.defineFlag("LOG_IP", "logIp")
config.defineFlag("CHANNEL_LIST_STYLE", "channelListStyle")
config.defineFlag("LOGO_BASE", "logoBase")
config.defineFlag("APPS_BASE", "appsBase")
config.defineFlag("APPS_PLAY_STORE", "playStore")
config.defineFlag("APPS_MODE", "appsMode")
config.defineFlag("HOME_ORIENTATION", "homeOrientation")
config.defineFlag("HOME_ITEMS", "homeItems", ",")
config.defineFlag("AD_MODE", "adMode")
config.defineFlag("AD_BASE", "adBase")
config.defineFlag("TRANSPONDER_SET_ID", "transponderSetId")
config.defineFlag("DVB_NAME", "dvbName")
config.defineFlag("SCAN_TYPE", "scanType")

const map = KEYMAPS[config.KEYS]
config.KEYMAP = map
config.IS_REMOTE = (config.STB_IP !== "ui.local")

export {config as appConfig}
