//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.


import * as playerConfigApi from "services/api/player_config"

const VOL_LEVELS = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70,
  75, 80, 85, 90, 95, 100]

export function increaseVolume() {
  return unmute()
    .then(() => playerConfigApi.getVolume())
    .then((response) => {
      const newLevel = VOL_LEVELS.find(level => level > response.volume)
      if (newLevel === undefined) {
        return Promise.resolve(100)
      }
      return playerConfigApi.setVolume(newLevel).then(() => newLevel)
    })
}

export function decreaseVolume() {
  return unmute()
    .then(() => playerConfigApi.getVolume())
    .then((response) => {
      const newLevel = VOL_LEVELS.slice().reverse()
        .find(level => level < response.volume)
      if (newLevel === undefined) {
        return Promise.resolve(0)
      }
      return playerConfigApi.setVolume(newLevel).then(() => newLevel)
    })
}

export function setVolume(vol) {
  return playerConfigApi.setVolume(vol)
}

export function mute() {
  return playerConfigApi.setMute(true)
}

export function unmute() {
  return playerConfigApi.setMute(false)
}

export function getMute() {
  return playerConfigApi.getMute()
}

export function getVolume() {
  return playerConfigApi.getVolume()
}

export default {
  increaseVolume,
  decreaseVolume,
  mute,
  unmute,
  getMute,
  getVolume,
  setVolume,
}
