//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on, sse, enableEvents} from "services/events"

import * as storageApi from "services/api/storage"

import {setDeviceId} from "services/managers/config"
import {
  PVRManager,
  LedManager,
  FtaBlockManager,
  CamManager,
  CasManager,
  ChannelManager,
  PlayerManager,
  PowerManager,
} from "services/managers"

import * as popUpMsg from "app/utils/PopUpMsg"
import {setTimeShiftDuration,getPartitionIdVal,
  getPartitionFreeSize,putRecordMedium} from "services/api/config"

class StorageManager {
  constructor() {
    this.addedtime=null
    this.removetime=null
    this.checkStorageFormatStatus=99
    this.USB_size=null
    this.USB_type=null
    this.USB_freeSize=false
    this.USB_key=null
    this.UsbStorageInforamtion = {}
    this.showBannerIcon = null
    this.storageled=1
    this.UsbStorageDetail=null
    this.usbEvent = null
    this.formatflag = false
    this.isUSBFormatting = false

    enableEvents(this)
  }

  getUsbDetails() {
    return storageApi.list()
  }
  putUsbUnmount(listId) {
    return storageApi.putUsbUnmount(listId)
  }

  putUsbFormat(listId) {
    return storageApi.putUsbFormat(listId)
  }

  getPartitionID(listId) {
    return storageApi.partitionDetails(listId)
    .then((response) => {
      const partitionId = response.partition_list
      return storageApi.partitionDetailType(partitionId)
      .then((response) => {
        return response.file_system_type
      })
    })
  }


  findAttachedUsb(list) {
    const ids = list
    const isUsb = []
    return Promise.all(ids.map((id) => {
      return storageApi.details(id)
    }))
      .then((response) => {
        const usbLength = response.length
        if (usbLength > 0) {
          Array.from(response).forEach((key,value) => {
            if (key.type ===  "usb.key" || key.type === "usb.disk") {
              key.Usbstoragelist = ids[value]
              isUsb.push(key)
            }
          })
          if (isUsb.length > 0) {
            return isUsb
          } else {
            return false
          }
        } else {
          return false
        }
      })
  }

  storageID(list) {
    const ids = list
    return Promise.race(ids.map((id) => {
      return storageApi.details(id).then((response) => {
        if (response.type ===  "usb.key" || response.type === "usb.disk") {
          this.idval = id
          return this.idval
        }
      })
    }))
  }


  checkDataStorage(isFrogBoot= false) {
    // Need To Remove this lined when PVR Turn ON
    return new Promise((resolve,reject)=>{
      this.getUsbDetails()
      .then((usbList) => {
        this.findAttachedUsb(usbList.storage_list).then((response) => {
          const usbStorageId = response[0].Usbstoragelist
          this.USB_key = usbStorageId
          const isFtaBlock = FtaBlockManager.isNavigationRestricted()
          // if NO USB Detected.....
          if (response === false && !isFtaBlock) {
            popUpMsg.ErrorUsb()
            reject("No usb is Detected")
          }
          if (response !== false) {
            if (!isFtaBlock && !isFrogBoot) LedManager.SetUsbOpen()
            this.USB_size = response[0].size
            this.USB_type = response[0].type
            this.getUsbStorageDetails()
            if (isFtaBlock) {
              reject("FTA Block Mode On, Hence No USB Device will be Detected")
              return
            }
            if (response[0].size < 943718400) {
              popUpMsg.unsupportedUsb()
              reject("the external device size is too low")
            }  else {
              this.getPartitionID(usbStorageId).then((response) => {
                if (response === "ext4") {
                  LedManager.SetUsbClose()
                  storageApi.details(usbStorageId).then((response) => {
                    this._storageUsbInformation(usbStorageId,response)
                    this.showBannerIcon = this._showUsbAttachedInfoBannerName()
                    this._setTimeshiftDuration(this.USB_size)
                    PVRManager.pvrReady = true // Need turn ON pvrReady true when we want to enable PVR functionality
                    resolve("the usb is already formatted")
                  })
                  .catch(() => {
                    reject("Unable to find the exteranal device details.. ")
                  })
                } else {
                  this._askUsbFormat(usbStorageId, null)
                  resolve("Usb is not Format")
                }
              }).catch(()=> reject("unable to do partition"))
            }
          }
        }).catch(() => reject("Unable to find external device type=usb"))
      }).catch(() => reject("No extenal device"))
    })
  }

@on("storage:updateUSBStatus")
  getUsbStorageDetails() {
    if (this.USB_key) {
      if (this.USB_size > 943718400) {
        return getPartitionIdVal(this.USB_key).then((data) => {
          return getPartitionFreeSize(data.partition_list[0]).then((data) => {
            return this.UsbStorageDetail= data
          })
        })
      }
    }
  }

  _askUsbFormat(usbList, data) {
    const disableBack = true
    const buttons = [
      {
        label: "YES",
        action: () => {
          this.isUSBFormatting = true
          bus.emit("tv:operateFormat")
          popUpMsg.formattingInProcess()
          this.putUsbUnmount(usbList).then(()=>{
            this.putUsbFormat(usbList).then(() => {
              this.checkStorageFormatStatus = 0
            })
          }).catch(() => {
            this.putUsbUnmount(usbList).then(()=>{
              this.putUsbFormat(usbList).then(() => {
                this.checkStorageFormatStatus = 0
              })
            })
          })
          if (!data) {
            storageApi.details(usbList).then((response) => {
              this._storageUsbInformation(usbList,response)
            })
          } else {
            this._storageUsbInformation(usbList,data)
          }

        },
      },
      {
        label: "NO",
        action: () => {
          this.storageled=1
          this.isUSBFormatting = false
          LedManager.SetUsbClose()
        },
      },
    ]
    popUpMsg.formatUsb(buttons, disableBack)
    this.storageled=0
  }

  @on("storage:hardformat")
  _askUsbHardFormat() {
    const usbList = this.USB_key
    if (this.isUSBFormatting === true) return
    if (!this.USB_key) {
      popUpMsg.ErrorUsb()
      return false
    }
    if (PVRManager.ongoing.length > 0) {
      const buttons = [
        {
          label: "OK",
          action: () => {
            return false
          },
        },
      ]
      popUpMsg.RecordingConflict(buttons)
      return false
    } else {
      const disableBack = true
      const buttons = [
        {
          label: "YES",
          action: () => {
            this.isUSBFormatting = true
            LedManager.SetUsbOpen()
            bus.emit("tv:operateFormat")
            PlayerManager.stop()
            .then(() => {
              PVRManager.pvrReady = false
              popUpMsg.formattingInProcess()
              this.putUsbUnmount(usbList).then(()=>{
                this.putUsbFormat(usbList).then(() => {
                  this.checkStorageFormatStatus = 0
                })
              })
              .then(() => {
                storageApi.details(usbList).then((response) => {
                  this._storageUsbInformation(usbList,response)
                })
              }).catch(() => {
                PVRManager.pvrReady = false
                popUpMsg.formattingInProcess()
                this.putUsbUnmount(usbList).then(()=>{
                  this.putUsbFormat(usbList).then(() => {
                    this.checkStorageFormatStatus = 0
                  })
                })
                .then(() => {
                  storageApi.details(usbList).then((response) => {
                    this._storageUsbInformation(usbList,response)
                  })
                })
              })
            })
          },
        },
        {
          label: "NO",
          action: () => {
            this.storageled=1
            LedManager.SetUsbClose()
          },
        },
      ]
      popUpMsg.hardFormatUsb(buttons, disableBack)
      this.storageled=0
    }
  }

  _askForPvrReady(name) {
    // Need To Remove this lined when PVR Turn ON
    const buttons = [
      {
        label: "YES",
        default: true,
        action: () => {
          PVRManager.pvrReady = true // Need turn ON pvrReady true when we want to enable PVR functionality
          setDeviceId(name, true).catch(() => {
            PVRManager.pvrReady = false
          })
        },
      },
      {
        label: "NO",
        action: () => {
          PVRManager.pvrReady = false
          setDeviceId(name, false).catch(() => {
            PVRManager.pvrReady = false
          })
        },
      },
    ]
    popUpMsg.confirmPvrReady(buttons)
  }

  _checkUsbIsAttachedBefore(key) {
    if (this.UsbStorageInforamtion !== null &&  this.UsbStorageInforamtion !== undefined) {
      if (key === this.UsbStorageInforamtion.key) {
        this.UsbStorageInforamtion.isAttachedBefore = true
        return true
      } else {
        return false
      }

    } else {
      return false
    }
  }

  _storageUsbInformation(key,data) {
    this.UsbStorageInforamtion.key = key
    this.UsbStorageInforamtion.data = data
    this.UsbStorageInforamtion.isPluged = true
    this.UsbStorageInforamtion.Isforamt = false
    this.UsbStorageInforamtion.isAttachedBefore = false
    this.UsbStorageInforamtion.InforBannerDisplay = false
  }

  _showUsbAttachedInfoBanner() {
    if (this.UsbStorageInforamtion.Isforamt === true  &&
    this.UsbStorageInforamtion.InforBannerDisplay === true &&
    this.UsbStorageInforamtion.isPluged === true) {
      const usbInsertName = this.UsbStorageInforamtion.data.name
      return usbInsertName
    } else {
      return false
    }
  }
  _showUsbAttachedInfoBannerName() {
    const usbInsertName = this.UsbStorageInforamtion.data.name
    return usbInsertName
  }

  _setTimeshiftDuration(size) {

    // Duration = (10% of size) / ((8192/8) * 1024)
    const duration = (10/100 * size) / ((8192/8) * 1024)
    const sizeDuration = (10/100 * size)
    const option = {"timeshift_duration": parseInt(duration)}
    //  const sizeOption = {"timeshift_duration": parseInt(sizeDuration)}
    const freeOption = {"medium": "NONE"}
    const freeTime = {"timeshift_duration": parseInt(0)}

    if (duration) {
      setTimeShiftDuration(option).then(() => {
      }).catch(()=>{})
    }
    if (sizeDuration) {
      setTimeShiftDuration(option).then(() => {
        return getPartitionIdVal(this.USB_key).then((data) => {
          return getPartitionFreeSize(data.partition_list[0]).then((data) => {
            if (data.free_size < sizeDuration) {
              this.USB_freeSize=false
              putRecordMedium(freeOption)
              setTimeShiftDuration(freeTime)
              popUpMsg.storageFreeSpace()
            }

          })
        })

      }).catch(()=>{})
    }
  }

  _callPartitionAdded(event) {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    const storageId = event.content.storage_name
    this.USB_key = storageId
    return storageApi.details(storageId)
      .then((data) => {
        const size = data.size
        const type = data.type
        this.USB_size = data.size
        this.USB_type = data.type
        if (isFtaBlock) return
        if (type === "usb.key" || type === "usb.disk") {
          if (size < 943718400) {
            popUpMsg.unsupportedUsb()
          }  else {
            bus.emit("STBInfoSheet:updatehd")
            this.getPartitionID(storageId).then((response) => {

              if (response === "ext4") {
                LedManager.SetUsbClose()
                if (FtaBlockManager.isFtaComplete === true)
                  popUpMsg.UsbEstablished()
                storageApi.details(event.content.storage_name).then((response) => {
                  this._storageUsbInformation(event.content.storage_name,response)
                  this.showBannerIcon = this._showUsbAttachedInfoBannerName()
                })
                .catch((response) => {
                  this._storageUsbInformation(event.content.storage_name,response)
                  this.showBannerIcon = this._showUsbAttachedInfoBannerName()
                  PVRManager.pvrReady = false
                })
              } else {
                if (FtaBlockManager.isFtaComplete === true)
                  this._askUsbFormat(event.content.storage_name, null)
              }
            })
          }
        }
      })
  }

  @sse("storage", {subtype: "storage_added"})
  _onStorageAdded(event) {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }

    // Ignore Storeage Event On Booting...
    if (PowerManager.bootTimeRunning) return

    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    this.usbEvent = event
    this.formatflag = true
    if (isFtaBlock) return
    LedManager.SetUsbOpen()
  }

  @sse("storage", {subtype: "partition_added"})
  _onStoragePartitionAdded() {
    // Ignore Storeage Event On Booting...
    if (PowerManager.bootTimeRunning) return

    if (this.formatflag) {
      this.formatflag = false
      this._callPartitionAdded(this.usbEvent)
    }
  }

  @sse("storage", {subtype: "storage_removed"})
  _onStorageRemoved() {
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }

    // Ignore Storeage Event On Booting...
    if (PowerManager.bootTimeRunning) return

    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    this.UsbStorageDetail = null
    if (!isFtaBlock) {
      this.storageled = 1
      LedManager.LedUsbDisconnect()
      // A storage has been removed
      if (bus.universe === "mediacenter") {
        bus.closeCurrentUniverse()
        bus.openUniverse("home")
      }
      if (this.USB_type === "usb.key" || this.USB_type === "usb.disk") {
        if (this.USB_size < 943718400) {
          popUpMsg.smallStorageRemoved()
        } else {
          bus.emit("tv:storageRemoveOnTimeshift")
        }
      }
      if (CasManager.isFingerprintActive) {
        CasManager.closeFingerprint()
      }
      PVRManager.pvrReady = false
      bus.emit("pvr:usbRemoved")
      this.UsbStorageInforamtion.isPluged = false
      this.showBannerIcon = null
    }
    this.USB_type = null
    this.USB_size = null
    bus.emit("STBInfoSheet:updatehd")
  }

  @sse("storage", {subtype: "storage_format_status"})
  onStorageFormatStatus() {
  }

  @sse("storage", {subtype: "data_partition_activation"})
  onStoragePartitioActivation(data) {

    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      return
    }

    // Ignore Storeage Event On Booting...
    if (PowerManager.bootTimeRunning) return

    if (data.content.status === true) {
      PVRManager.pvrReady = true
      bus.emit("popup:hideStorageEstablishPopup")
      getPartitionFreeSize(data.content.partition_name).then((d) => {
        this._setTimeshiftDuration(d.size)
      })
      .then(() => {
        PVRManager.onUSBformat()
        PlayerManager.stop()
        .then(() => {
          PlayerManager.play(ChannelManager.current)
        })
        .then(() => {
          if (this.isUSBFormatting === true) {
            this.isUSBFormatting = false
            popUpMsg.UsbFormatted()
          }
          LedManager.SetUsbClose()
          bus.emit("tv:operateFormatHide")
        })
      })
    }

  }

  @sse("storage", {subtype: "partition_mount_status"})
  onStoragePartitionMountStatus(data) {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    if (this.USB_key) {
      if (this.USB_size > 943718400) {
        this.getUsbStorageDetails().then(()=>{
          bus.emit("STBInfoSheet:updatehd")
        })
      }
    }
    if (isFtaBlock && PowerManager.bootTimeRunning) return
    if (this.checkStorageFormatStatus === 0) {
      if (data.content.status === 0) {
        this.checkStorageFormatStatus = 99
        this.storageled=1
        this.UsbStorageInforamtion.Isforamt = true
        this.UsbStorageInforamtion.InforBannerDisplay = true
        this.showBannerIcon = this._showUsbAttachedInfoBanner()
      } else {
        popUpMsg.UsbFormatError()
        this.setYesDetails()
      }
    }
  }

}

export default new StorageManager()
