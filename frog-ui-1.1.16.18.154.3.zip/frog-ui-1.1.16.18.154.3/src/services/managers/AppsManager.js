//
// Copyright (C) 2006-2017 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import config from "utils/config"
import {GET} from "services/http"
import CategoryModel from "services/models/apps/Category"
import {_} from "utils/locale"
import * as popUpMsg from "app/utils/PopUpMsg"
import PVRManager from "services/managers/PVRManager"

const DEFAULT_PREVIEW_IMG = "app/assets/backgrounds/dev.png"
const DEFAULT_THUMBNAIL_IMG = "app/assets/backgrounds/dev.png"

class AppsManager {
  constructor() {
    this.categories = []
    this.path = `http://${config.STB_IP}${config.APPS_BASE}`
  }

  getCategories() {
    return this.categories
  }

  getCategory(index) {
    return this.categories[index]
  }

  getPreview(item) {
    if (item.preview) {
      return `${this.path}${item.preview}`
    }
    return DEFAULT_PREVIEW_IMG
  }

  getThumbnail(item) {
    if (item.thumbnail) {
      return `${this.path}${item.thumbnail}`
    }
    return DEFAULT_THUMBNAIL_IMG
  }

  loadAppsCatalog() {
    return new Promise((resolve, reject) => {
      GET(`${this.path}catalog.json`, {
        headers: {
          "Accept": "application/json",
        },
      }).then((json) => {
        return this.fillManager(json, resolve)
      }).catch(() => {
        bus.emit("appstore:stopLoadingApps")
        return reject("No catalog")
      })
    })
  }

  fillManager(json, resolve) {
    this.categories = json.categories.map(category => new CategoryModel(category))
    // Sort the categories array by position
    this.categories.sort((a, b) => a.position - b.position)
    return resolve()
  }

  /**
   * Show PopUp before entering into Active Services if recording is Ongoing
   * @name showAppStoreConflictPopUp
   * @param {Object} item Object describe 'Active Service' item in Home Menu
   */

  showAppStoreConflictPopUp() {
    const currentUniverse = bus.universe
    const closeCallback = () => {
      /* Do Nothing */
    }
    const buttons = [
      {
        label: _("Ok"),
        action: () => {
          // Cancel current Ongoing Recording
          if (PVRManager.ongoing.length > 0) {
            PVRManager.cancel(PVRManager.ongoing[0].programId,(PVRManager.ongoing[0]))
          } else {
            PVRManager.remove(PVRManager.recordingInTransitionInfo.schedule)
          }
          bus.emit(`${currentUniverse}:close`)
          bus.emit("colorBtnPress:open:appstore")
        },
      },
      {
        label: _("Back"),
        action: closeCallback,
      },
    ]
    popUpMsg.RecordingConflictAppStore(buttons, closeCallback)
  }
}

export default new AppsManager()
