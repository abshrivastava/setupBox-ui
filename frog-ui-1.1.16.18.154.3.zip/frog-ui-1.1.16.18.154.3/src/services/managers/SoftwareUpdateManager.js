//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

// import {GET} from "../http"

import bus from "services/bus"
import {on, sse, enableEvents} from "services/events"
import {getSoftwareVersion, softwareUpdate} from "services/api/scan"
import standby from "services/managers/PowerManager"
import {setState} from "services/api/power"
import * as popUpMsg from "app/utils/PopUpMsg"
import PVRManager from "services/managers/PVRManager"
import ScanManager from "services/managers/ScanManager"
import {getSoftwareVersionSsuParams, setSoftwareVersionSsuParams, setSoftwareVersion} from "services/managers/config"

class SoftwareUpdateManager {
  constructor() {
    this.ssuParam = {}
    this.currentSTBVersion = null
    enableEvents(this)
  }

  /** function:: fetchSoftwareVersion()
   * On Boot get the ssuParam from CFG...
   *
   *   :function  getSoftwareVersionSsuParams :: set  ssuParam on CFg
   *   :function  setSoftwareUpdate :param option :: get the current Stp Sw version and Pass to MW
   */

  fetchSoftwareVersion() {
    getSoftwareVersionSsuParams()
    .then((response) => {
      const value = response.toString()
      this.ssuParam = value.split(",").map((item) => {
        return parseInt(item, 10)
      })
    }).catch(()=>{
      this.setSoftwareUpdate()
    })
    .then(()=>{
      this.setSoftwareUpdate()
    })
  }

  /** function:: setSoftwareUpdate()
   * Get the Current Software Version...And Make Put Request to MW
   *
   *   :function  getSoftwareVersion :: Return Current Software Version...
   *   :function  setSoftwareVersion :param option :: Make Put Request of Sw Version to MW
   */

  setSoftwareUpdate() {
    getSoftwareVersion().then((response) => {
      const option = {"software_version": response.version}
      this.currentSTBVersion = response.version
      setSoftwareVersion(option)
    })
  }

  /** function:: checkSoftwareVersion(event)
   * Check for the Current Sw version When Ever Get Sw Update Descriptor
   *
   *   :set ::  the boolean Value and set the boot_flag when ever Sw Update is Request...
   *   :param :: Return 0 if the Current Sw update Descriptor version and Current Stv Version are Same..
   *   :param :: Return 1 if the Current Sw update Descriptor version and Current Stv Version are Difference...
   */

  checkSoftwareVersion(event) {
    const currentSwVersion = parseInt(event.content.ssu_parameters[event.content.ssu_parameters.length-2])
    const bootFlag = (currentSwVersion > parseInt(this.currentSTBVersion))?1:0
    return bootFlag
  }

  /** function:: forceUpdateSw()
   * Make Request for Force Update
   *
   *   :Param ::  If there is no Current Descriptor set, get the ssu_parameters form cfg file..
   *   :Return Make Request for Reboot...
   */

  forceUpdateSw() {
    return new Promise((resolve,reject) => {
      if (this.ssuParam.length > 0) {
        const option = {"ssu_parameters":this.ssuParam,"forced":2,"power_status":0}
        softwareUpdate(option).then((response) => {
          resolve("Please reboot : ",response)
        }).catch((error) => {
          reject("Force softwareUpdate Error : ",error)
        })
      } else {
        reject("Error : No ssuParam..")
      }
    })
  }

  /** function:: onSoftwareRebootRequest
   * Show the PopUp Message..When ever Sw Descriptor is Immediate
   *
   *   :function  setState :: On ok make Request for Reboot
   */

  @on("software:rebootRequest")
  onSoftwareRebootRequest() {
    const closeCallback = () => {
      setState({"state":"reboot"})
    }
    const buttons = [
      {
        label: "OK",
        action: () => {
          if (PVRManager.ongoing.length) {
            PVRManager.cancel(PVRManager.ongoing[0].programId)
            .then(()=> {
              setState({"state":"reboot"})
            })
            .catch(() => {
              setState({"state":"reboot"})
            })
          } else {
            setState({"state":"reboot"})
          }
        },
      },
    ]
    ScanManager.running = false
    popUpMsg.confirmSoftwareUpdate(buttons, closeCallback)
  }

  /** function:: software:awake
   * Trigger Sw Update, When ever PowerManager is in Awake..
   *
   *   :param  isBootLoad :: Set the boot_flag according to Sw Udate Version
   *   :function  softwareUpdate :: Set the BootLoader with New Descriptor
   *   : Response :: show the Sw Update PopUp Message..if the Descriptor is Immediate...
   */

  @on("software:awake")
  onSoftwareAwake(event) {
    const isBootLoad = this.checkSoftwareVersion(event)
    const option = {"ssu_parameters":event.content.ssu_parameters,"forced":isBootLoad,"power_status":0}
    softwareUpdate(option)
    .then(() => {
      if (event.content.boot_flag !== 0 && isBootLoad) {
        bus.emit("software:rebootRequest")
      }
    })
  }

  /** function:: software:standby
   * Trigger Sw Update, When ever PowerManager is in standby..
   *
   *   :param  isBootLoad :: Set the boot_flag according to Sw Udate Version
   *   :function  softwareUpdate :: Set the BootLoader with New Descriptor
   *   :function  softwareUpdate :: Set the BootLoader with New Descriptor
   *   : Response :: Set the Timmer for Reboot...
   */

  @on("software:standby")
  onSoftwareStandby(event) {
    const isBootLoad = this.checkSoftwareVersion(event)
    const option = {"ssu_parameters":event.content.ssu_parameters,"forced":isBootLoad,"power_status":1}
    softwareUpdate(option).then(() => {
      event.content.boot_flag === 0 ? standby.isNonImmediate = true : standby.isImmediate = true
      if (isBootLoad) {
        standby._setRebootTimer()
      } else {
        standby.isImmediate = false
        if (standby.rebootTimer) {
          clearTimeout(standby.rebootTimer)
        }
      }
    })
  }

  /** function:: software_update
   * Make Trigger for Sw Udate Base on Awake/Standby...
   *
   *   :param  this.ssuParam :: Set ssuParram locale for Reference...
   *   :function  setSoftwareVersionSsuParams : param  this.ssuParam :: Set the ssuParam on Cfg...
   *   :: Make Request for software_update Base on Awake/Standby
   */
  @sse("scan", {subtype: "software_update"})
  onSoftwareUpdate(event) {
    if (event.content.ssu_parameters) {
      this.ssuParam = event.content.ssu_parameters
      this.checkSoftwareVersion(event) ? standby.swTakeAdvantage = true : standby.swTakeAdvantage = false
      setSoftwareVersionSsuParams(this.ssuParam)
      /** powerManagement:: state
       *   :awake:
       */
      if (!standby.isStandbyState) {
        this.onSoftwareAwake(event)
      }
      /** powerManagement:: state
       *   :standby:
       */
      if (standby.isStandbyState) {
        this.onSoftwareStandby(event)
      }

    }
  }


}
export default new SoftwareUpdateManager()
