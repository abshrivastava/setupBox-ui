//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as OutputApi from "services/api/output"
import {sse, enableEvents} from "services/events"
import {setResolution} from "services/managers/config"
import Singleton from "utils/Singleton"
import bus from "services/bus"

const DEVICE_TYPE = {
  "hdmi": "avio_output_hdmi0",
  "analog": "avio_output_videoanalog0",
  "avio_output_videoanalog0": "hdmi",
  "avio_output_hdmi0": "analog",
}

const ASPECT_RATIO_ENUM = {
  "16/9": "avio_aspect_ratio_16_9",
  "4/3": "avio_aspect_ratio_4_3",
  "avio_aspect_ratio_16_9": "16/9",
  "avio_aspect_ratio_4_3": "4/3",
}

export default class OutputManager extends Singleton {
  constructor() {
    super()
    this.device = null
    this._resolution = null
    this.hdmiPreferedResolution = null
    this.aspectRatio = null
    this.resolutionList = []
    this.minResolution = "720x480"
    this.maxResolution = "1920x1080"
    enableEvents(this)
  }

  setDevice(device) {
    this.device = device
  }

  set resolution(resolution) {
    this._resolution = resolution
    return setResolution(resolution)
  }

  get resolution() {
    return this._resolution
  }

  setResolution(device, resolution) {
    const wantedResolution = this._computeBestResolutionToApply(resolution)
    return OutputApi.setResolution(DEVICE_TYPE[device], wantedResolution)
      .then(() => {
        this.resolution = wantedResolution
      })
  }

  setAspectRatio(device, aspectRatio) {
    return OutputApi.setAspectRatio(DEVICE_TYPE[device], ASPECT_RATIO_ENUM[aspectRatio])
      .then(() => {
        this.aspectRatio = aspectRatio
      })
  }

  getAspectRatio() {
    return this.aspectRatio
  }

  fetchData(device) {
    return OutputApi.getData(DEVICE_TYPE[device])
      .then((data) => {
        if (device === "hdmi") {
          this.resolutionList = data.hdmi_supported_formats.filter(this._filterResolution.bind(this))
          this.hdmiPreferedResolution = data.hdmi_prefered_format
        } else {
          this.resolutionList = []
          this.hdmiPreferedResolution = null
        }
        this.tmpResolution = data.format
        this.aspectRatio = ASPECT_RATIO_ENUM[data.aspect_ratio]
      })
  }

  @sse("avio", {subtype: "hdmi_connection_plugged", content: {plugged: () => true}})
  _onHDMIEvent(data) {
    if (data.content.plugged) {
      bus.emit("application:output", false)
      this.setDevice("hdmi")
    } else {
      bus.emit("application:output", true)
      this.setDevice("analog")
    }
    return this.fetchData(this.device)
      .then(() => {
        this.setResolution(this.tmpResolution)
      })
  }

  _computeBestResolutionToApply(resolution) {
    let wantedResolution
    if (this.resolutionList.length === 0) {
      wantedResolution = "1280x720@50p"
    } else if (!this.resolutionList.find(res => res === resolution)) {
      wantedResolution = this.resolutionList.find(res => res === "1280x720@50p" || res === "1280x720@60p")
    } else if (this.resolutionList.find(res => res === resolution)) {
      wantedResolution = resolution
    }

    return wantedResolution
  }

  _filterResolution(data) {
    const [minW, minH] = this.minResolution.split("x")
    const [maxW, maxH] = this.maxResolution.split("x")
    const [resolution] = data.split("@")
    const [w, h] = resolution.split("x")

    if ((parseInt(w, 10) < parseInt(minW, 10) || parseInt(h, 10) < parseInt(minH, 10))
      || (parseInt(w, 10) > parseInt(maxW, 10) || parseInt(h, 10) > parseInt(maxH, 10))) {
      return false
    } else {
      return true
    }
  }
}
