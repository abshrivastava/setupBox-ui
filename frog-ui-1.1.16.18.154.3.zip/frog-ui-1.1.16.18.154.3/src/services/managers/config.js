//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as configApi from "services/api/config"

export function getSections() {
  return configApi.getSections()
    .then((response) => {
      return response.map(section => section.href.split("/")[2])
    })
}

export function getSection(sectionName) {
  return configApi.getSection(sectionName)
    .then((response) => {
      return response.map(section => section.href.split("/")[3])
    })
}

export function getEntry(section, entry) {
  return configApi.getEntry(section, entry)
    .then(response => response[entry].value[0])
}

export function getEntries(section, entry) {
  return configApi.getEntry(section, entry)
    .then(response => response[entry].value)
}

export function setEntry(section, entry, value) {
  const body = {value: [String(value)]}
  return configApi.updateEntry(section, entry, body)
}

export function setLastTunedLcn(lcn) {
  return setEntry("settings", "last_lcn", lcn)
}

export function getLastTunedLcn() {
  return getEntry("settings", "last_lcn")
    .then((value) => {
      const lcn = parseInt(value, 10)
      return isNaN(lcn) ? 0 : lcn
    })
    .catch(() => 0)
}

export function setFirstInstall(value = false) {
  return setEntry("settings", "first_install", value)
}

export function getFirstInstall() {
  return getEntry("settings", "first_install")
    .then((value) => {
      return value === "true" ? true : false
    })
    .catch(() => true)
}

export function getLandingChannel() {
  return getEntry("landing_channel", "channel_num")
    .then((value) => {
      const lcn = parseInt(value, 10)
      return  isNaN(lcn) ? 0 : lcn
    })
    .catch(() => 0)
}

export function getDefaultChannel() {
  return getEntry("settings", "default_channel")
    .then((value) => {
      const lcn = parseInt(value, 10)
      return  isNaN(lcn) ? 0 : lcn
    })
    .catch(() => 0)
}

export function getDefaultCounter() {
  return getEntry("default_lc", "default_counter")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return null
    })
}

export function getDefaultMaxLandingChannels() {
  return getEntry("default_lc", "max_number_of_channels")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return 0
    })
}

export function deleteSection(section) {
  return configApi.deleteSection(section)
}

export function createSection(section) {
  return configApi.createSections(section)
}

export function getMaxForceSlide() {
  return getEntry("settings", "max_force_slide")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return "emptyMaxSlide"
    })
}

export function getCurrentForceSlideRow() {
  return getEntry("settings", "current_force_slide_row")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return 0
    })
}

export function getFcSlider(index,value) {
  return getEntry(`force_slide_${index}`, value)
    .then((value) => {
      return  value
    })
    .catch(() => {
      return 0
    })
}

export function setDefaultLc(option,value) {
  return setEntry("default_lc", option, value)
}

export function getDefaultLcn(value) {
  return getEntry("default_lc", value)
    .then((value) => {
      return  value
    })
    .catch(() => {
      return null
    })
}

export function setDefaultCounter(value) {
  return setEntry("default_lc", "default_counter", value)
}

export function getGraceLcn() {
  return getEntry("grace_lc", "grace_default_channel")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return null
    })
}

export function getGraceoffset() {
  return getEntry("grace_lc", "grace_default_offset")
    .then((value) => {
      return  value
    })
    .catch(() => {
      return null
    })
}

export function setGraceInfo(option,value) {
  return setEntry("grace_lc", option, value)
}


export function setDeviceId(deviceId, pvrReady) {
  if (deviceId) {
    return setEntry("storage", atob(deviceId), pvrReady)
  } else {
    return Promise.reject()
  }
}

export function getDeviceId(deviceId) {
  if (deviceId) {
    return getEntry("storage", atob(deviceId))
      .then((value) => {
        return value === "true"
      })
      .catch(() => {
        return Promise.reject()
      })
  } else {
    return Promise.reject()
  }
}

export function setLocale(locale) {
  return setEntry("settings", "locale", locale)
}

export function getLocale() {
  return getEntry("settings", "locale")
    .then((value) => {
      const locale = value
      return typeof locale === "string" ? locale : "eng"
    })
    .catch(() => "eng")
}

export function getAppStoreURL() {
  return getEntry("appstore", "url")
}

export function getStartFreq() {
  return getEntry("scan", "startFreq")
}

export function getEndFreq() {
  return getEntry("scan", "endFreq")
}


export function getDvbUris() {
  return new Promise((resolve) => {
    return getEntries("scan", "easy_scan")
      .then((x) => {
        resolve(x)
      })
      .catch(() => resolve([]))
  })
}

export function setDvbUris(value) {
  return setEntry("scan", "easy_scan", value)
}


export function updateIFtoIF(value) {
  return setEntry("scan", "IFtoIF", value)
}

export function getIFtoIF() {
  return getEntry("scan", "IFtoIF")
        .then((value) => {
          const ifToIf = value
          return typeof ifToIf === "string" ? ifToIf : ifToIf.toString()
        })
        .catch(() => 0)
}

export function getHomeTP() {
  return new Promise((resolve) => {
    return getEntries("scan", "last_home_TP")
    .then((value) => {
      const HomeTPData = value
      resolve(HomeTPData.toString())
    })
    .catch(() => {
      resolve("")
    })
  })
}

export function setRefTPScan(name, value) {
  return setEntry(name, "RefTPScan", value)
}

export function getRefTPScan(name) {
  return new Promise((resolve) => {
    return getEntries(name, "RefTPScan")
      .then((RefTPScan) => {
        resolve(RefTPScan[0] === "true")
      })
      .catch(() => resolve(false))
  })
}

export function setNIT(name, value) {
  return setEntry(name, "NIT", value)
}

export function getNIT(name) {
  return new Promise((resolve) => {
    return getEntries(name, "NIT")
      .then((NIT) => {
        resolve(NIT[0] === "true")
      })
      .catch(() => resolve(false))
  })
}

export function setChannelsType(name, value) {
  return setEntry(name, "channels_type", value)
}

export function getChannelsType(name) {
  return new Promise((resolve) => {
    return getEntries(name, "channels_type")
      .then((scrambled) => {
        resolve(parseInt(scrambled[0], 10))
      })
      .catch(() => resolve(3))
  })
}

export function getUseFavorite() {
  return new Promise((resolve) => {
    return getEntry("settings", "favorite")
      .then((value) => {
        resolve(value === "true")
      })
      .catch(() => resolve(false))
  })
}

export function setUseFavorite(value) {
  return setEntry("settings", "favorite", value)
}

export function setDiseqcType(value) {
  return setEntry("scan", "diseqc", value)
}

export function getDiseqcType() {
  return new Promise((resolve) => {
    return getEntries("scan", "diseqc")
    .then((value) => {
      const diseqc = value
      resolve(diseqc.toString())
    })
    .catch(() => {
      resolve("")
    })
  })
}

export function setScrambled(value) {
  return setEntry("scan", "scrambled", value)
}

export function getScrambled() {
  return new Promise((resolve) => {
    return getEntries("scan", "scrambled")
      .then((scrambled) => {
        resolve(scrambled)
      })
      .catch(() => resolve(true))
  })
}

export function setFreeToAir(value) {
  return setEntry("scan", "freeToAir", value)
}

export function getFreeToAir() {
  return new Promise((resolve) => {
    return getEntries("scan", "freeToAir")
      .then((freeToAir) => {
        resolve(freeToAir)
      })
      .catch(() => resolve(true))
  })
}

export function setSoftwareVersionSsuParams(value) {
  return setEntry("scan", "sw_params", value)
}

export function getSoftwareVersionSsuParams() {
  return new Promise((resolve) => {
    return getEntries("scan", "sw_params")
      .then((x) => {
        resolve(x)
      })
      .catch(() => resolve(0))
  })
}

export function setSoftwareVersion(value) {
  return configApi.setSoftwareVersion(value)
}

export function setSvlVersionConf(value) {
  return setEntry("scan", "svl_version", value)
}

export function getSvlVersionConf() {
  return new Promise((resolve) => {
    return getEntries("scan", "svl_version")
      .then((x) => {
        resolve(x)
      })
      .catch(() => resolve(0))
  })
}


export function getTimeFormat() {
  return new Promise((resolve) => {
    return getEntry("settings", "h24")
      .then((value) => {
        resolve(value)
      })
      .catch(() => resolve(false))
  })
}

export function setTimeFormat(value) {
  return setEntry("settings", "h24", value)
}

export function getForceSlideRcuBlockTime() {
  return getEntry("force_slide", "rcu_block_time")
    .then((value) => {
      const rcuBlockTime = value
      return rcuBlockTime > 0 ? rcuBlockTime : 0
    })
    .catch(() =>  {
      return 0
    })
}

export function getForceSlidePlayTime() {
  return getEntry("force_slide", "delay_time")
    .then((value) => {
      const playTime = parseInt(value)
      return playTime > 0 ? playTime : 0
    })
    .catch(() =>  {
      return 0
    })
}

export function getHomeTpWydvbUrl() {
  return getEntry("scan", "easy_scan")
    .then((value) => {
      const wydvbUrl = value
      return wydvbUrl ? wydvbUrl : false
    })
    .catch(() =>  {
      return false
    })
}

export function getServiceID() {
  return getEntry("force_slide", "service_id")
    .then((value) => {
      const serviceID = value
      return serviceID !== null ? serviceID : null
    })
    .catch(() =>  {
      return null
    })
}

export function updateTimeZone(value) {
  const body = {timezone: value}
  return configApi.updateTimeZone(body)
}

export function updateAudiotracks(value) {
  return configApi.updateAudiotracks(value)
}


export function updateBlockedChannelList(blcnList) {
  return setEntry("settings", "blocked_ch_list", blcnList)
}

export function getBlockedChannelList() {
  return getEntry("settings", "blocked_ch_list")
    .then((value) => {
      const blockedList = value
      return typeof blockedList === "string" ? blockedList : blockedList.toString()
    })
    .catch(() => 0)
}

export function updatePinCode(pin) {
  return setEntry("settings", "blocked_ch_pin", pin)
}

export function getPinCode() {
  return getEntry("settings", "blocked_ch_pin")
        .then((value) => {
          const blockedPin = value
          return typeof blockedPin === "string" ? blockedPin : blockedPin.toString()
        })
        .catch(() => "0000")
}

export function updateAvio() {
  const type = {"audio_mode": "avio_audio_mode_bypass"}
  configApi.updateAvio(type)

}

export function updateEntryInSection(section, entry, value) {
  return setEntry(section, entry, value)
}

export function getEntryFromSection(section, entry) {
  return getEntry(section, entry)
  .then((value) => {
    return value
  })
  .catch(() => {
    return null
  })
}

export function getAudioTrackStatus(value) {
  return getEntry("audio_lang", value)
    .then((value) => {
      return  value
    })
    .catch(() => {
      return null
    })
}

export function updateDefaultTrack(track) {
  return setEntry("settings", "default_audio_track", track)
}

export function getDefaultTrack() {
  return getEntry("settings", "default_audio_track")
    .then((value) => {
      return value
    })
}

export function fetchPersistancAudioLang() {
  return configApi.getPersistanceAudioLang().then((response) => {
    return response
  }).catch(()=> {
    return null
  })
}

export function getResolution() {
  return new Promise((resolve) => {
    return getEntry("settings", "resolution")
      .then((value) => {
        resolve(value)
      })
      .catch(() => resolve(null))
  })
}

export function setResolution(value) {
  return setEntry("settings", "resolution", value)
}

export function getCamStatus() {
  return new Promise((resolve) => {
    return getEntry("cam_module", "camStatus")
      .then((value) => {
        resolve(value)
      })
      .catch(() => resolve(null))
  })
}

export function setCamStatus(value) {
  return setEntry("cam_module", "camStatus", value)
}

export function setup() {
  const sectionsName = [
    "settings",
    "scan",
    "storage",
    "force_slide",
    "my_account",
    "audio_lang",
    "cam_module",
    "default_lc",
    "grace_lc",
    "checker",
  ]

  return getSections().then((sections) => {
    const sectionsToFetch = sectionsName.filter((section) => {
      return sections.indexOf(section) === -1
    })

    const createPromises = []
    sectionsToFetch.forEach((sectionName) => {
      const section = {}
      section[sectionName] = {}
      createPromises.push(configApi.createSections(section))
    })
    return Promise.all(createPromises)
  }).then(() => {
  })
}

export function setDefaultAvio(item) {
  return configApi.updateAvio(item)
}

export function setDefaultAudio(track) {
  return configApi.updateDolby(track)
}

export function setDefaultTvType(armValue) {
  return configApi.updateDefaultTvType(armValue)
}

export function setUIReady() {
  return setEntry("settings", "started", "true")
}

export function setDefaultCVBS(format) {
  return configApi.updateCVBS(format)
}

export function deleteEntry(section, entry) {
  return configApi.deleteEntry(section, entry)
}

export function setApplicationScale(value) {
  return setEntry("settings", "scale", value)
}

export function getApplicationScale() {
  return getEntry("settings", "scale")
    .then((value) => {
      const scale = parseInt(value, 10)
      return isNaN(scale) ? 0 : scale
    })
    .catch(() => 0)
}

export function setAdsVersion(value) {
  return setEntry("checker", "ads_version", value)
}

export function setAppsVersion(value) {
  return setEntry("checker", "apps_version", value)
}

export function getAdsVersion() {
  return getEntry("checker", "ads_version")
    .then((value) => {
      const adsVersion = value
      return adsVersion ? adsVersion : false
    })
    .catch(() =>  {
      return false
    })
}

export function getAppsVersion() {
  return getEntry("checker", "apps_version")
    .then((value) => {
      const appsVersion = value
      return appsVersion ? appsVersion : false
    })
    .catch(() =>  {
      return false
    })
}

export default {
  getSections,
  getEntry,
  getEntries,
  setEntry,
  setLastTunedLcn,
  getLastTunedLcn,
  setFirstInstall,
  getFirstInstall,
  setDeviceId,
  getDeviceId,
  setLocale,
  getLocale,
  getAppStoreURL,
  getStartFreq,
  getEndFreq,
  getDvbUris,
  setDvbUris,
  updateIFtoIF,
  getIFtoIF,
  setScrambled,
  getScrambled,
  setFreeToAir,
  getFreeToAir,
  setChannelsType,
  getChannelsType,
  setDiseqcType,
  getDiseqcType,
  getTimeFormat,
  setTimeFormat,
  getUseFavorite,
  setUseFavorite,
  setup,
  updateDefaultTrack,
  getDefaultTrack,
  getAudioTrackStatus,
  fetchPersistancAudioLang,
  setSvlVersionConf,
  getSvlVersionConf,
  setSoftwareVersionSsuParams,
  getSoftwareVersionSsuParams,
  setSoftwareVersion,
  setDefaultAvio,
  setDefaultAudio,
  setDefaultTvType,
  setDefaultCVBS,
  deleteEntry,
  getHomeTpWydvbUrl,
  getApplicationScale,
  setApplicationScale,
  setResolution,
  getResolution,
  setUIReady,
  getDefaultCounter,
  setDefaultCounter,
  getGraceoffset,
  getGraceLcn,
  getDefaultLcn,
  setGraceInfo,
  setDefaultLc,
  deleteSection,
  createSection,
  getMaxForceSlide,
  getCurrentForceSlideRow,
  getFcSlider,
  getDefaultMaxLandingChannels,
  setAdsVersion,
  setAppsVersion,
  getAdsVersion,
  getAppsVersion,
}
