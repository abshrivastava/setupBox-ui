//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on,enableEvents} from "services/events"
import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import PVRManager from "services/managers/PVRManager"
import * as ChannelApi from "services/api/channels"
import * as popUpMsg from "app/utils/PopUpMsg"
import {getCurrentProgram} from "services/managers/epg"

const MOD_DEFAULT_QUERY = {
  order: ["lcn"],
  metadata: [
    "id", "play_info", "service_id", "title", "lcn", "obj_class",
    "scrambled", "genre",
  ],
  criteria: "obj_class==CHANNEL_TV",
}

const MOD_CHANNEL_IDS = [31,32,33,34,35]

class ModManager {
  constructor() {
    enableEvents(this)
    this._currentModChannel = null
    this._modChannel = []
    this.modServiceId = "4308107848"
  }

  get currentMod() {
    return this._currentModChannel
  }

  set currentMod(lcn) {
    this._currentModChannel = lcn
  }

  @on("mod:open")
  open() {
    let channel = ChannelManager.getChannelFromServiceId(this.modServiceId)
    if (channel === null) channel = ChannelManager.current.lcn
    this.load([channel])
  }

  getModChannels() {
    const temp = []
    let current = Promise.resolve()
    return Promise.all(MOD_CHANNEL_IDS.map((id) =>  {
      current = current.then(() =>  {
        MOD_DEFAULT_QUERY.criteria = `obj_class==CHANNEL_TV AND genre = ${id}`
        return ChannelApi.getChannels(MOD_DEFAULT_QUERY)
      }).then((result) =>  {
        const data = result.channels
        const dataLength = result.channels.length
        if (dataLength > 0) {
          data.forEach((value) => {
            temp.push(value)
          })
        }
        return data
      })
      return current
    })).then(function() {
      return temp
    }).catch(() => {
      return temp
    })
  }

  load(modChannels) {
    if (modChannels) {
      const modChannel = []
      modChannels.forEach((value) => {
        if (value.lcn) {
          modChannel.push(value.lcn)
        }
      })
      if (modChannel.length) {
        modChannel.sort((a, b) =>  {
          return a - b
        })
        this._modChannel = modChannel
        this._currentModChannel = modChannel[0]
      }
      // Check if recording ongoing on current channel
      if (PVRManager.ongoing.length > 0) {
        return ChannelManager.showZapConflictPopUp(this._currentModChannel)
      }
      this.viewMod(this._currentModChannel)
    } else {
      this.viewMod(null)
    }
  }

  _closeLegacyUniverse() {
    let i = 0
    do {
      i += 1
      const busUniverse = bus.universe
      if (busUniverse === "popup" || busUniverse === "parentalpopup") {
        bus.emit(`${busUniverse}:close`)
      } else {
        if (ChannelManager.displayMode === "infoBanner") {
          // nothing to do...
        } else if (ChannelManager.displayMode === "channelList") {
          bus.emit("tv:ChannelListClose", false)
        } else {
          bus.closeCurrentUniverse()
          bus.emit("home:close")
          bus.openUniverse("tv")
        }
        bus.emit("home:activeMenuItem", "vod")
        break
      }
    } while (i < 3)
  }

  viewMod(lcn) {
    if (lcn) {
      ChannelManager.getChannelZapInformation(lcn)
      .then((response) => {
        const channel = response.resource.real || response.resource.fallback
        if (channel) {
          getCurrentProgram(channel)
          this.modClose(channel)
        } else {
          this.modClose(false)
        }
      })
    } else {
      this.modClose(false)
    }
  }

  modClose(channel) {
    const lcn = channel.lcn || false
    if (lcn) {
      PlayerManager.play(channel, "channel")
      this._closeLegacyUniverse()
    } else {
      PlayerManager.play(ChannelManager.current)
      bus.openUniverse("tv")
    }
  }

  isCurrentChannelMod(channel = ChannelManager.current) {
    let genre
    if (channel) {
      genre = channel.genre ? channel.genre.split(",") : undefined
    }
    if (channel) {
      if (genre && genre.length) {
        for (let i=0; i<genre.length; i++) {
          genre[i] = parseInt(genre[i], 10)
          if ((genre[i] >= 31) && (genre[i] <= 35)) {
            popUpMsg.RecordBlockOnMOD()
            return 1
          }
        }
      }
    }
    return 0
  }
}

export default new ModManager()
