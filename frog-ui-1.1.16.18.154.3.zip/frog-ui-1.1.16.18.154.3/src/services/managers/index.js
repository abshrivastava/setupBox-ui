//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import ManagerOutput from "services/managers/OutputManager"

export {default  as AdsManager} from "./AdsManager"
export {default  as AppsManager} from "./AppsManager"
export {default  as BrowserManager} from "./BrowserManager"
export {default  as ChannelManager} from "./ChannelManager"
export {default  as config} from "./config"
export {default  as epg} from "./epg"
export {default  as MediaCenterManager} from "./MediaCenterManager"
export {default  as NetworkManager} from "./NetworkManager"
export {default  as PowerManager} from "./PowerManager"
export {default  as CasManager} from "./CasManager"
export {default  as CamManager} from "./CamManager"
export {default  as PlayerManager} from "./PlayerManager"
export {default  as PVRManager} from "./PVRManager"
export {default  as ScanManager} from "./ScanManager"
export {default  as StorageManager} from "./StorageManager"
export {default  as FtaBlockManager} from "./FtaBlockManager"
export {default  as VodManager} from "./VodManager"
export {default  as volume} from "./volume"
export {default  as TimezoneManager} from "./TimezoneManager"
export {default  as DownloaderManager} from "./DownloaderManager"
export {default  as VersionManagers} from "./VersionManagers"
export {default  as SoftwareUpdateManager} from "./SoftwareUpdateManager"
export {default  as transponders} from "./transponders"
export {default  as ComboButton} from "./ComboButton"
export {default  as LedManager} from "./LedManager"
export {default  as RechargeReminder} from "./RechargeReminderManager"
export {default  as ModManager} from "./ModManager"
export {default  as InstantMessageManager} from "./InstantMessageManager"

export const OutputManager = new ManagerOutput()
