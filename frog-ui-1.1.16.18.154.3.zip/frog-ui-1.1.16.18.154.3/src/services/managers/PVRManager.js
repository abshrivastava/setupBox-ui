//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as PVRApi from "services/api/pvr"
// import TimezoneManager from "services/managers/TimezoneManager"
import {findObjInArrayByValue} from "utils"
import {_} from "utils/locale"

import Schedule from "services/models/pvr/Schedule"
import Task from "services/models/pvr/Task"
import Record from "services/models/pvr/Record"

import {sse, enableEvents} from "services/events"
import bus from "services/bus"

import ChannelManager from "services/managers/ChannelManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import LedManager from "services/managers/LedManager"
import ScanManager from "services/managers/ScanManager"
import PlayerManager from "services/managers/PlayerManager"
import PowerManager from "services/managers/PowerManager"
import {addMinutes} from "utils/date"
import * as RechargeReminderApi from "services/api/recharge_reminder"
import * as PVRReminder from "services/api/reminder"
import ProgramReminder from "services/managers/ProgramReminder"
import {getLastTunedLcn, setLastTunedLcn} from "services/managers/config"

const START_MARGIN = 2 * 60 // 2 minutes
const DURATION_MARGIN = 2 * 60 // 2 minutes


/** class:: PVRManager()
 *
 */
class PVRManager {
  constructor() {
    /** attribute:: futures
     * Store Futures Recordings (Schedules w/ IDLE task)
     *
     *   :type: Array
     */
    this.futures = []

    /** attribute:: ongoing
     * Store Ongoing Recordings (Schedules w/ ACTIVE task)
     *
     *   :type: Array
     */
    this.ongoing = []

    /** attribute:: finished
     * Store finished Recordings
     *
     *   :type: Array
     */
    this.finished = []  // Records
    this._pvrReady = false
    this.pvrValue = false
    this.lastRecordingIdentify = {
      x: null,
      y: null,
      isOngoing: false,
    }
    this.recordingInTransitionInfo = {
      inTransition : false,
      schedule : null,
    }
    this.disableOnUnsubscribed = false
    this.lastReminderServiceId = null
    enableEvents(this)
  }

  get pvrReady() {
    return this._pvrReady
  }

  set pvrReady(value) {
    if ((value !== this.pvrReady)) {
      this._pvrReady = value
      this.onBoot()
    }
    bus.emit("pvr:ready", value)
  }


  @sse("scheduled", {subtype: "LastChange", content: {record_schedule_created: () => true}})
  _onScheduledCreated(data) {
    if (data.content.record_schedule_created.title === "RechargeReminder") return
    // adds a UISchedule to the "futures" list
    const schedule = new Schedule(data.content.record_schedule_created)
    this.recordingInTransitionInfo.schedule = null
    schedule.isAlert = false
    if (data.content.record_schedule_created.current_errors.includes("154")) {
      if (this.lastReminderServiceId) schedule.service_Id = this.lastReminderServiceId
      schedule.isAlert = true
    }
    this.futures.push(schedule)
    this.recordingInTransitionInfo.schedule = schedule
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_task_modified: {task_state_phase: "ACTIVE"}}})
  _onTaskActive(data) {
    // find the parent UISchedule in futures
    // move the UISchedule to the "ongoing" list
    const contentTask = data.content.record_task_modified
    const {schedule, list, idx} = this._getScheduleIdx(contentTask.id, "task")

    if (schedule) {
      if (this.recordingInTransitionInfo.schedule && this.recordingInTransitionInfo.schedule.id) {
        if (this.recordingInTransitionInfo.schedule.id === schedule.id) {
          this.recordingInTransitionInfo.inTransition = false
        }
      }
      schedule.task.phase = contentTask.task_state_phase
      if (!isNaN(schedule._title)) return
      if (!this.pvrReady || ScanManager.isFirstInstall) {
        PVRApi.deleteTask(contentTask.id)
        if (!this.pvrReady)
          popUpMsg.scheduleFailed(schedule)
        return false
      }

      if (contentTask.task_state_pending_errors === "204" || contentTask.task_state_current_errors === "204") {
        return this._onDiskSpaceRecordConflict(schedule)
      }

      ChannelManager.current = ChannelManager.getChannelFromServiceId(schedule.serviceId || schedule.service_Id)
      getLastTunedLcn().then((lastTuneChannel) => {
        if (lastTuneChannel !== ChannelManager.current.lcn) {
          if (!PowerManager.isStandbyState) {
            PlayerManager.play(ChannelManager.current)
          }
          setLastTunedLcn(ChannelManager.current.lcn)
        }
      })

      if (list === "futures") {
        this.futures.splice(idx, 1)
        this.lastReminderServiceId = null
        schedule.x = this.lastRecordingIdentify.x
        schedule.y = this.lastRecordingIdentify.y
        schedule.isOngoing = this.lastRecordingIdentify.isOngoing
        this.ongoing.push(schedule)
        bus.emit("pvr:started", schedule)
      }
      if (contentTask.task_state_recording === "1"
          && (contentTask.task_state === "ACTIVE.RECORDING.FROMSTART.OK"
          || contentTask.task_state === "ACTIVE.RECORDING.RESTART.OK")) {
        LedManager.SetRecordOpen()
      }
    }
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_task_modified: {task_state_phase: "DONE"}}})
  _onTaskDone(data) {
    // delete the DONE task
    PVRApi.deleteTask(data.content.record_task_modified.id)
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_task_created: {task_state_pending_errors: () => true}}})
  _onTaskConflict(data) {
    // linking schedule with task...
    if (data.content.record_task_created.title === "RechargeReminder") return
    const task = new Task(data.content.record_task_created)
    const {schedule} = this._getScheduleIdx(task.scheduleId, "schedule")
    schedule.task = task
    schedule.isAlert = false

    const taskStatePendingErrors = data.content.record_task_created.task_state_pending_errors

    if (taskStatePendingErrors.includes("154")) {
      schedule.isAlert = true
    }
    if (taskStatePendingErrors.includes("401")) {
      if (schedule.isAlert) {
        PVRReminder.getAlert(schedule.id).then((resp) => {
          schedule.metadata = resp
          this.conflictHandler(schedule)
        })
      } else {
        this.conflictHandler(schedule)
      }
    }
    if (taskStatePendingErrors === "204") {
      this._onDiskSpaceScheduleConflict(data)
    }
    if (!schedule.isAlert) {
      bus.emit("pvr:created", schedule)
    }
  }

  @sse("scheduled", {subtype: "LastChange", content: {x__record_task_warm_up: () => true}})
  _onRecordError(data) {
    const task = data.content.x__record_task_warm_up
    const {schedule} = this._getScheduleIdx(task.id, "task")
    // Ignore "x__record_task_warm_up" Notification if RechargeReminder is Scheduled
    // And if Schedule Value  is Null...
    if (schedule === null) return

    if (task.task_state_pending_errors === "204") {
      if (this._pvrReady) {
        this._onDiskSpaceRecordConflict(schedule)
      } else {
        popUpMsg.scheduleFailed(schedule)
        this.remove(schedule)
      }
    } else {
      bus.emit("conflict:tuner", schedule)
    }
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_task_deleted: () => true}})
  _onTaskDeleted(data) {
    // Ignore "record_task_deleted" Notification if RechargeReminder is Scheduled
    const contentTask = data.content.record_task_deleted
    if (contentTask.title === "RechargeReminder") return

    // find the parent UISchedule
    // get the matching record and add it to 'finished'
    const {schedule} = this._getScheduleIdx(contentTask.id, "task")

    if (schedule) {
      this.afterTaskDeleted(schedule)
      schedule.task = null
    }
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_schedule_modified: {state: "COMPLETED"}}})
  _onScheduleComplete(data) {

    // remove the UISchedule from 'futures' and 'on-going'
    // delete its task
    // delete the schedule
    const {schedule, list, idx} = this._getScheduleIdx(
      data.content.record_schedule_modified.id, "schedule")
    if (!schedule) return
    this[list].splice(idx, 1)
    this.afterTaskDeleted(schedule)

    PVRApi.deleteSchedule(schedule.id)
    this.pvrValue = false

    // to update the Harddisk storage evrytime after recording is completed
    bus.emit("storage:updateUSBStatus")
    bus.emit("STBInfoSheet:updatehd")

    // In standby: a svl version changes is received while recording
    // On completing the record Easy scan is launched
    if (PowerManager.isStandbyState && !PowerManager.isEasyScanRunning && PowerManager.startEasyScan) {
      PowerManager._startEasyScan(PowerManager.startEasyScan, PowerManager.isEasyScanRunning)
    }
  }

  @sse("scheduled", {subtype: "LastChange", content: {record_schedule_deleted: () => true}})
  _onScheduleDeleted(data) {
    // Ignore "record_schedule_deleted" Notification if RechargeReminder is Scheduled
    if (data.content.record_schedule_deleted.title === "RechargeReminder") return

    const {list, idx} = this._getScheduleIdx(
      data.content.record_schedule_deleted.id, "schedule")
    if (list) {
      this[list].splice(idx, 1)
    }
    this.ongoing.length === 0 && LedManager.SetRecordStop()
    if (!isNaN(data.content.record_schedule_deleted.title)) return
    bus.emit("pvr:deleted", new Schedule(data.content.record_schedule_deleted))
  }

  conflictHandler(schedule) {
    this._conflictHandler = {}
    this._conflictHandler.popUpText = _("conflicting with")
    this._conflictHandler.schedule = schedule
    this._conflictHandler.conflictTaskStr = ""
    this._conflictHandler._getChannelInfo = (resp) => {
      const channel = {"title" : "", "lcn": ""}
      if (resp.metadata) {
        channel.title = resp.metadata.channel_name
        channel.lcn = resp.metadata.channel_number
      } else if (resp.channel_name) {
        channel.title = resp.channel_name
        channel.lcn = resp.channel_number
      } else if (resp.task && resp.task.userContent && resp.task.userContent.channelNo) {
        const userContents = resp.task.userContent.channelNo
        channel.title = userContents.title
        channel.lcn = userContents.lcn
      } else if (resp.user_content) {
        const userContents = JSON.parse(resp.user_content)
        channel.title = userContents.channelTitle
        if (userContents.channelNo) channel.lcn = userContents.channelNo.lcn
      } else {
        console.log("something wrong in resp =",resp)
      }
      if (this._conflictHandler.conflictTaskStr === "") {
        this._conflictHandler.conflictTaskStr += "" + channel.title + "("+ channel.lcn +") "
        + this._conflictHandler.popUpText + " "
      } else {
        this._conflictHandler.conflictTaskStr += "" + channel.title + "("+ channel.lcn +"), "
      }
      return channel
    }

    this._conflictHandler._removeIcons = (scdulObj) => {
      let obj = this.futures.find((res) => {
        return res.id === scdulObj.record_schedule_id
      })
      if (!obj) {
        obj = this.ongoing.find((res) => {
          return res.id === scdulObj.record_schedule_id
        })
      }
      const scdulObjDetail = ProgramReminder.iconDetail[obj.programId]
      if (bus.universe !== "tv") {
        if (scdulObjDetail) {
          bus.emit("epg:remove_recording_banner",scdulObjDetail)
        }
      }
    }

    this._conflictHandler._okCallback = (scheduleObjArr) => {
      scheduleObjArr.forEach((scheduleObj) => {
        if (scheduleObj.isAlert) {
          PVRReminder.deleteAlert(scheduleObj.record_schedule_id)
        } else {
          PVRApi.deleteSchedule(scheduleObj.record_schedule_id)
          .then((rsp)=>{
            // if record_schedule_id is ongoing then disableRecordTask then delete it
            if (rsp && rsp.error && rsp.error === 705) {
              PVRApi.disableRecordTask(scheduleObj.record_schedule_id)
              .then(()=>{
                PVRApi.deleteSchedule(scheduleObj.record_schedule_id)
              })
              .catch((error)=>{
                console.log("error =",error)
              })
            }
          })
          .catch((error)=>{
            console.log("error =",error)
          })
        }
        this._conflictHandler._removeIcons(scheduleObj)
      })
    }

    this._conflictHandler._closeCallback = () => {
      if (this._conflictHandler.schedule.isAlert) {
        PVRReminder.deleteAlert(this._conflictHandler.schedule.id)
      } else {
        PVRApi.deleteSchedule(this._conflictHandler.schedule.id)
      }
      bus.emit("pvr:conflict")
      bus.emit("epg:hide_recording_banner")
    }

    this._conflictHandler._popUpMaker = (_scheduleArr) => {
      const buttons = [
        {
          label: _("Ok"),
          action: () => {
            this._conflictHandler._okCallback(_scheduleArr)
          },
        },{
          label: _("BACK"),
          action: () => {
            this._conflictHandler._closeCallback()
          },
        },
      ]
      const str = this._conflictHandler.conflictTaskStr
      this._conflictHandler.conflictTaskStr =(str.substr(str.length - 2) === ", ") ? str.substr(0, str.length - 2) : str
      const param = {
        conflictTaskStr: this._conflictHandler.conflictTaskStr,
        buttons: buttons,
        closeCallback: this._conflictHandler._closeCallback,
      }
      popUpMsg.currentConflictWithScheduled(param)
    }

    this._conflictHandler._getScheduleIdsObj = (taskIdsArr) => {
      let serchQry = "id=="
      taskIdsArr.forEach((ts) => {
        if (serchQry === "id==") serchQry += ts
        else serchQry += " OR id==" + ts
      })
      return new Promise((resolve) => {
        PVRApi.getTasks(serchQry)
        .then((taskArr) => {
          const scheduleIdsArr = []
          taskArr.tasks.forEach((tsk) => {
            const obj = {"record_schedule_id": "", "isAlert": false, "taskObj": ""}
            obj.record_schedule_id = tsk["record_schedule_id"]
            obj.taskObj = tsk
            const taskStatePendingErrors = tsk["task_state_pending_errors"]
            if (taskStatePendingErrors.includes("154")) {
              obj.isAlert = true
            }
            scheduleIdsArr.push(obj)
          })
          return resolve(scheduleIdsArr)
        })
      })
    }

    this._conflictHandler._getConflictData = () => {
      return new Promise((resolve) => {
        this.getConflict(schedule.task.id).then((data) => {
          if (data.tasks && data.tasks.length) {
            this._conflictHandler._getScheduleIdsObj(data.tasks).then((_scheduleArr) => {
              resolve(_scheduleArr)
            })
          }
        })
      })
    }

    this._conflictHandler._getMetaData = (dataArray) => {
      const promises = []
      return new Promise((resolve) => {

        dataArray.forEach((scheduleObj) => {
          if (scheduleObj.isAlert) {
            promises.push(PVRReminder.getAlert(scheduleObj.record_schedule_id))
          } else {
            promises.push(PVRApi.getSchedulesWithProperties(scheduleObj.record_schedule_id))
          }
        })

        Promise.all(promises).then((resp) => {
          console.debug("RES =========",resp)
          resolve(resp)
        })

      })
    }

    this._conflictHandler._conflictTaskStringMaker = (respArr) => {
      return new Promise((resolve) => {
        respArr.forEach((resp) => {
          this._conflictHandler._getChannelInfo(resp)
        })
        resolve(true)
      })
    }

    this._conflictHandler._init = () => {
      this._conflictHandler._getChannelInfo(this._conflictHandler.schedule)
      this._conflictHandler._getConflictData().then((_scheduleArray)=>{
        this._conflictHandler._getMetaData(_scheduleArray).then((resp)=>{
          this._conflictHandler._conflictTaskStringMaker(resp)
          .then(()=>{
            this._conflictHandler._popUpMaker(_scheduleArray)
          })
        })
      })
    }

    this._conflictHandler._init()
  }

  _onDiskSpaceScheduleConflict(data) {
    // retrieve data of winner schedule
    const {schedule} = this._getScheduleIdx(data.content.record_task_created.id, "task")
    if (schedule) {
      PVRApi.deleteTask(schedule.task.id)
      bus.emit("pvr:conflict")
    // finally, display a pop up for informing user the schedule can't be done.
      popUpMsg.DiskSpaceConflict()
    }
  }

  /**function:: record(programId, userContent)
   * Record a specific program
   *
   *   :param Int programId: programId of the Program to record
   *   :param Object userContent: Extra data you want to save
   *   :returns Promise:
   */
  recordProgram(programId, userContent, currentUniverse) {
    // check if there is no inforamtion, Recording can not possible...
    if (!userContent.programId) {
      if (currentUniverse === "epg") {
        popUpMsg.recordingFailed(userContent)
        return Promise.reject(`Recording can not be done as there is no inforamtion ${userContent.channelTitle}`)
      }
      // 89614 : 45 mins of Recording can be done from TV/HOME universe in case there is no program info available
      return this.recordProgramNoInfo(userContent, currentUniverse)
    }

    const {list} = this._getScheduleIdx(programId, "program")
    if (list) {
      return Promise.reject("Program is already scheduled")
    }

    // if Usb is not Ready or Plugged Return Back.
    if (!this.pvrReady) {
      popUpMsg.pvrNotReady()
      return Promise.reject("No USB key plugged")
    }

    // check if Recording conflick...
    const isRecordingFlick = this._isRecordingflick(userContent.serviceId, ChannelManager.current.serviceId,
      userContent.isOngoing)

    if (isRecordingFlick) {
      // if Recording  is conflick...show the Popup for user Selection...
      this._askForFlickRecording(programId, userContent, currentUniverse)
      return Promise.reject("this is return")
    } else {
      // there is no Reconding conflick...make Request for current Recoding...
      const isfrom = false
      return this._requestToRecord(programId, userContent, isfrom)
    }
  }

  recordProgramNoInfo(userContent, currentUniverse) {
    // Create a "manual" schedule in case of no information
    const startDate = (userContent.startDate.getTime() / 1000)
    const duration = 45  // hard coding this value right now as 45 min, can be configured later TODO
    userContent.endDate = addMinutes(userContent.startDate, duration)
    userContent.title = userContent.channelTitle
    userContent.isOngoing = startDate <= Date.now() / 1000
    const recordingParams = {
      "title": userContent.channelTitle,
      "class":"OBJECT.RECORDSCHEDULE.DIRECT.CDSNONEPG",
      "service_id": userContent.serviceId,
      "channel_id_type": "URI",
      "start": startDate,
      "duration": duration * 60,
      "repetition": null,
      "start_margin": 0,
      "duration_margin": 0,
      "desired_tasks" : "0",
      "user_content": JSON.stringify(userContent),
    }

    // if Usb is not Ready or Plugged Return Back.
    if (!this.pvrReady) {
      popUpMsg.pvrNotReady()
      return Promise.reject("No USB key plugged")
    }

    const isRecordingFlick = this._isRecordingflick(userContent.serviceId, ChannelManager.current.serviceId,
      userContent.isOngoing)

    if (isRecordingFlick) {
      // if Recording  is conflick...show the Popup for user Selection...
      this._askForFlickRecording(null, userContent, currentUniverse, recordingParams)
      return Promise.reject("this is return")
    } else {
      if (startDate <= Date.now() / 1000) {
        recordingParams.active_period = startDate
      }
      this.markRecordingInitiation(userContent)
      return this._record(recordingParams).then(()=>{
        bus.emit("epg:show_recording_banner")
      })
    }
  }

  recordManual(userContent, channel, recurrence) {
    // Create a "manual" schedule
    const startDate = (userContent.startDate.getTime() / 1000)
    const endDate = (userContent.endDate.getTime() / 1000)
    const recordingParams = {
      "title": userContent.title,
      "class":"OBJECT.RECORDSCHEDULE.DIRECT.CDSNONEPG",
      "service_id": channel.serviceId,
      "channel_id": channel.playInfo,
      "channel_id_type": "URI",
      "start": startDate,
      "duration": endDate - startDate,
      "repetition": recurrence,
      "start_margin": 0,
      "duration_margin": 0,
      "desired_tasks" : "0",
      "user_content": JSON.stringify(userContent),
    }

    if (startDate <= Date.now() / 1000) {
      recordingParams.active_period = startDate
    }
    return this._record(recordingParams)
  }

  _record(recordingParams) {
    this.pvrValue = true
    return PVRApi.createSchedule(recordingParams)
  }

  _askForFlickRecording(programId, userContent, currentUniverse, recordingParams) {
    const buttons = [
      {
        label: _("Ok"),
        action: () => {
          // Request for cancel current Recording...
          const isfrom = true
          const recOngoingProgram = Object.assign({}, this.ongoing)
          if (this.ongoing.length > 0) {
            this.cancel(this.ongoing[0].programId).then(() => {
              // set the current Channel...which is Request for Recording and make tune to live..
              ChannelManager.current = ChannelManager.getChannelFromServiceId(userContent.serviceId)
              ChannelManager.current.recording = true
              PlayerManager.play(ChannelManager.current)
              // Make Request for New Recording Once Previous Recoding is Cancel...
              .then(() => {
                if (recordingParams) {
                  if (recordingParams["start"] <= Date.now() / 1000) {
                    recordingParams.active_period = recordingParams["start"]
                  }
                  return this._record(recordingParams).then(() => {
                    bus.emit("epg:show_recording_banner")
                  })
                } else {
                  this._requestToRecord(programId, userContent,isfrom).then(() => {
                    if (currentUniverse !== "tv") {
                      bus.emit("epg:hide_unmarkRecodingBanner",recOngoingProgram)
                    }
                  })
                }
              })
              .catch(() => {
                PlayerManager.play(ChannelManager.current)
              })
            })
          } else {
            // Make Request for New Recording...
            ChannelManager.current = ChannelManager.getChannelFromServiceId(userContent.serviceId)
            ChannelManager.current.recording = true
            PlayerManager.play(ChannelManager.current)
            if (recordingParams) {
              if (recordingParams["start"] <= Date.now() / 1000) {
                recordingParams.active_period = recordingParams["start"]
              }
              return this._record(recordingParams).then(() => {
                bus.emit("epg:show_recording_banner")
              })
            } else {
              this._requestToRecord(programId, userContent, isfrom)
            }
          }
        },
      },
      {
        label: "Back",
        action: () => {
          // silent is Golden...
        },
      },
    ]
    if (this.ongoing.length > 0) {
      popUpMsg._askForFlickRecording(buttons)
    } else {
      popUpMsg._askForConflictRecording(buttons)
    }

  }

  _requestToRecord(programId,userContent,isfrom) {
    const recordingParams = {
      "title": userContent.title || "Unknown Title",
      "class": "OBJECT.RECORDSCHEDULE.QUERY.CONTENTID",
      "matching_id_type": "SI_PROGRAMID",
      "matching_id": programId,
      "start_margin": START_MARGIN,
      "duration_margin": DURATION_MARGIN,
      "user_content": JSON.stringify(userContent),
    }
    const startDate = (userContent.startDate.getTime() / 1000) || -1
    let isActive = false
    if (startDate >= 0 && startDate <= Date.now() / 1000) {
      recordingParams.active_period = startDate
      isActive = true
    }
    this.markRecordingInitiation(userContent)
    return this._record(recordingParams).then(() => {
      if (isfrom) {
        bus.emit("epg:show_recording_banner")
      }
      return Promise.resolve(isActive)
    })
  }

  _isRecordingflick(pServiceId,cServiceId,isOngoing) {
    if (cServiceId === pServiceId) {
      return false
    } else if (isOngoing === false && cServiceId !== pServiceId) {
      return false
    } else {
      return true
    }
  }

  /**function:: cancel(programId)
   * Cancel a specific Record based on its programId (delete task matching program)
   *
   *   :param Int programId: programId of the Program to cancel record
   *   :returns Promise:
   */
  cancel(programId, pvr) {
    this.pvrValue = false
    if (pvr) {
      return PVRApi.deleteTask(pvr.task.id)
    }
    if (programId) {
      const {schedule, list} = this._getScheduleIdx(programId, "program")
      if (!list) {
        return Promise.reject("This program has not been scheduled")
      }
      return PVRApi.deleteTask(schedule.task.id)
    } else {
      // In case ProgramId and PVR both parameters are null then handle this case.
      // [happens with manual recording USE case often]
      const lpvr = this.ongoing[0]
      if (lpvr && lpvr.serviceId === ChannelManager.current.serviceId)
        return this.remove(lpvr)
    }
  }

  /**function:: remove(pvr)
   * Remove a Record (and/or delete schedule and its tasks fails for non-recorded/non-scheduled programs)
   *
   *   :param Record pvr: instance of PVR to remove
   *   :param Schedule pvr: instance of PVR to remove
   *   :returns Promise:
   */
  remove(pvr) {
    if (pvr.constructor.name === "Record") {
      return PVRApi.deleteRecord(pvr.id)
        .then(() => {
          this.finished.splice(this.finished.indexOf(pvr), 1)
          bus.emit("pvr:deleted")
          // to update the HD info on STBInfosheet
          bus.emit("storage:updateUSBStatus")
          bus.emit("STBInfoSheet:updatehd")
        })
    } else if (pvr.constructor.name === "Schedule") {
      if (pvr.task.phase === "ACTIVE") {
        if (pvr.task.programId) {
          return this.cancel(pvr.task.programId)
        } else {
          return this.cancel(null, pvr)
        }
      } else {
        return PVRApi.deleteSchedule(pvr.id)
      }
    } else {
      console.error("What are you trying to remove?")
    }
  }

  /**function:: update(pvr, metadata)
   * Update data of a finished Recordings
   *
   *   :param Record pvr: instance of PVR to update
   *   :param Object metadata: data to put on Record object
   *   :returns Promise:
   */
  update(pvr, metadata) {
    if (pvr.constructor.name === "Record") {
      pvr.updateAttributes(metadata)
      return PVRApi.updateRecord(pvr.id, metadata)
    }
    return Promise.reject("Can't update this item")
  }

  isProgramReminder(title) {
    if (isNaN(title)) {
      return true
    } else {
      return false
    }
  }

  getConflict(id) {
    return new Promise((resolve) => {
      RechargeReminderApi.getTaskConflict(id)
      .then((data) => {
        resolve(data)
      })
      .catch((error) => {
        resolve(error)
      })
    })
  }

  _onDiskSpaceRecordConflict(schedule) {
    PVRApi.deleteTask(schedule.task.id)
    bus.emit("pvr:conflict")

    // finally, display a pop up for informing user the schedule can't be done.
    popUpMsg.DiskSpaceConflict()
  }

  afterTaskDeleted(schedule) {
    if (schedule.task) {
      PVRApi.getRecords({criteria: `srs_record_task_id==${schedule.task.id}`})
        .then(({records}) => {
          if (records.length) {
            for (const rec of records) {
              if (rec.status === "DONE" && records.length > 1) {
                PVRApi.deleteRecord(rec.id)
              } else {
                const existingRecord = findObjInArrayByValue(this.finished, rec.id)
                if (existingRecord === null) {
                  this.finished.push(new Record(rec))
                  bus.emit("pvr:refresh")
                }
              }
            }
          }
        })
    }
  }

  /**function:: onBoot()
   * Return List of schedules and records
   *
   *   :returns Promise:
   */
  onBoot() {
    // Fetch futures, ongoing & finished schedules/records
    this._fetchSchedules().then(() => this._fetchRecords().then(() => {
      bus.emit("pvr:refresh")
    }))
  }

  onUSBformat() {
    // Fetch futures, ongoing & finished schedules/records
    this._fetchRecords().then(() => {
      bus.emit("pvr:refresh")
    })
  }

  /**function:: _fetchSchedules()
   * get schedules then get Task, drop COMPLETED (delete schedule & task)
   *  OPERATIONNAL
   *    -> move UISchedule in future or ongoing
   *
   *   :returns Promise:
   */
  _fetchSchedules() {
    this.futures = []
    this.ongoing = []
    return PVRApi.getSchedules()
      .then((data) => {
        const schedules = []
        const tasksPromises = []

        for (const scheduleData of data.scheduled_records) {
          const schedule = new Schedule(scheduleData)
          const promise = PVRApi.getTasks(`record_schedule_id==${schedule.id}`)

          tasksPromises.push(promise)

          promise
            .then((data) => {
              const task = new Task(data.tasks[0])
              schedule.task = task
              schedules.push(schedule)
            })
        }

        return Promise.all(tasksPromises)
          .then(() => {
            // Check Completed etc.
            for (const schedule of schedules) {
              if (schedule.state === "COMPLETED") {
                PVRApi.deleteSchedule(schedule.id)
              } else {
                if (schedule.task.phase === "IDLE") {
                  this.futures.push(schedule)
                } else if (schedule.task.phase === "ACTIVE") {
                  if (this._pvrReady && isNaN(schedule._title)) {
                    this.ongoing.push(schedule)
                  }
                }
              }
            }

            return Promise.resolve()
          })
      })
  }

  /**function:: _fetchRecords()
   * get records
   *  drop ACTIVE
   *  DONE
   *    -> move UIRecord to finished
   *
   *   :returns Promise:
   */
  _fetchRecords() {
    return PVRApi.getRecords({criteria: "status!=ACTIVE"})
      .then(({records}) => {
        this.finished = []
        for (const recordData of records) {
          this.finished.push(new Record(recordData))
          if (recordData.status === "DONE_ERROR") {
            const taskId = recordData.srs_record_task_id
            PVRApi.deleteTask(taskId)
          }
        }
      })
  }

  _getScheduleIdx(id, type) {
    let res = this._searchScheduleIn(id, type, "futures")
    if (!res.list) {
      res = this._searchScheduleIn(id, type, "ongoing")
    }
    return res
  }

  _searchScheduleIn(id, type, list) {
    for (let i=0; i < this[list].length; i++) {
      const schedule = this[list][i]
      let matchingId = -1
      switch (type) {
      case "schedule":
        matchingId = schedule.id
        break
      case "task":
        if (schedule.task && schedule.task.id) {
          matchingId = schedule.task.id
        }
        break
      case "program":
        matchingId = schedule.programId
        break
      case "service":
        if (schedule.task && isNaN(schedule._title) && schedule.task.serviceId) {
          matchingId = schedule.task.serviceId
        } else {
          matchingId = null
        }
        break
      default:
        console.warn("What did you expect?")
        break
      }
      if (matchingId !== null && matchingId === id) {
        return {
          schedule: schedule,
          list: list,
          idx: i,
        }
      }
    }
    return {schedule: null, list: null, idx: null}
  }

  getSchedulesFromServiceId(serviceId) {
    const onGoingchedules = this.getSchedulesFromServiceIdInList(serviceId, "ongoing")
    const futuresSchedules = this.getSchedulesFromServiceIdInList(serviceId, "futures")
    return onGoingchedules.concat(futuresSchedules)
  }

  getSchedulesFromServiceIdInList(serviceId, list) {
    const schedules = []
    for (let i=0; i < this[list].length; i++) {
      const schedule = this[list][i]
      if (isNaN(schedule._attributes.title) && schedule.task && schedule.task.serviceId === serviceId) {
        schedules.push({
          schedule: schedule,
          list: list,
          idx: i,
        })
      }
    }
    return schedules
  }

  /**function:: isScheduled(programId)
   * Check if Program is scheduled
   *
   *   :param Int programId: programId of the Program
   *   :returns Boolean:
   */
  isScheduled(programId, serviceId, startDate) {
    if (programId === null) {
      const {schedule, list} = this._getScheduleIdx(serviceId, "service")
      return list === "futures" && schedule.endDate > startDate
    } else {
      const {list} = this._getScheduleIdx(programId, "program")
      return list === "futures"
    }
  }

  /**function:: isRecording(programId)
   * Check if Program is recording
   *
   *   :param Int programId: programId of the Program
   *   :returns Boolean:
   */
  isRecording(programId, serviceId, startDate) {
    if (programId === null) {
      const {schedule, list} = this._getScheduleIdx(serviceId, "service")
      return list === "ongoing" && schedule.endDate > startDate
    } else {
      const {list} = this._getScheduleIdx(programId, "program")
      return list === "ongoing"
    }
  }

  /**function:: isRecording(programId)
   * Check if Program is recording
   *
   *   :param Int programId: programId of the Program
   *   :returns Boolean:
   */
  isReminder(programId) {
    if (programId === null) {
      return false
    } else {
      const obj = this._getScheduleIdx(programId, "program")
      return  obj.schedule === null ? false : !isNaN(obj.schedule._title)
    }
  }

  /**function:: ifRecoding is ongoing set the row column for Cancel (row,column)
   * Check if Recoding is ongoing
   *
   *   :param Int row: set the Program row
   *   :param Int column: set the Program column
   *   :set the row and cloumn of onging recoding
   */

  setIndexForRecIcon(x,y) {
    if (this.ongoing.length > 0 && !this.ongoing.x && !this.ongoing.y) {
      this.ongoing.x = x
      this.ongoing.y = y
    }
  }

  /**
   * isOngoing flag is true, mark recording as in transition flag to handle conflict smoothly
   * @name markRecordingInitiation
   * @param {*Object} userContent Object which knows that if instant recording going on with isOngoing key
   */

  markRecordingInitiation(userContent) {
    if (userContent.isOngoing) {
      this.recordingInTransitionInfo.inTransition = true
    }
  }

}

export default new PVRManager()
