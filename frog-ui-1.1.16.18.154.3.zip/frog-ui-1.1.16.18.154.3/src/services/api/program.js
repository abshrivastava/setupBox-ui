//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, POST,PUT, DELETE, createQueryString} from "../http"

export function getProgram(id, options) {
  const parameters = {}
  if (options.metadata) {
    parameters.metadata = options.metadata.join(",")
  }
  const queryString = createQueryString(parameters)
  return GET(`/program/${id}/${queryString}`)
}

export function updateProgram(id) {
  let source
  return POST("/programs/", {
    criteria: `program_id==${id}`,
    metadata: ["service_id","title","start_date","end_date",
      "content_nibble_level_1","content_nibble_level_2",
      "description","short_description","program_id"],
  })
  .then(({href}) => {
    source = href
    return GET(source)
  })
  .then((data) => {
    DELETE(source)
    return Promise.resolve(data)
  })
}

export function setEpgLanguage(lang) {
  const option = {
    "language": lang,
  }

  if (!lang) {
    throw "Missing mandatory Lang"
  }

  return PUT("/cds_epg/language/",option)
}

export default {
  getProgram,
  updateProgram,
  setEpgLanguage,
}
