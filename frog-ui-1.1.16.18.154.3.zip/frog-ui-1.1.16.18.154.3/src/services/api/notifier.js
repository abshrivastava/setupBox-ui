//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {POST, PUT, DELETE} from "../http"

export function create() {
  return POST("/broadcast/notifier/")
    .then(({href}) => {
      return Promise.resolve(href)
    })
}

export function destroy(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return DELETE(href)
}

export function addAssetFilter(href, params) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}asset_filters/`, params)
    .then((data) => {
      return Promise.resolve(data)
    })
}

export function resetAssetFilter(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return DELETE(`${href}asset_filters`)
}

export function startAssetFilter(href, params) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}start`, params)
}

export function stopAssetFilter(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}stop`)
}

export default {
  create,
  destroy,
  addAssetFilter,
  resetAssetFilter,
  startAssetFilter,
  stopAssetFilter,
}
