//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"

const POLARIZATION_TYPE = {
  "H": "Horizontal",
  "V": "Vertical",
  "Horizontal": "H",
  "Vertical": "V",
}

@Model.defineAttributes({
  id: {
    from: "href",
    convert: x => parseInt(x.split("/")[5], 10),
  },
  satId: {
    from: "href",
    convert: x => parseInt(x.split("/")[3], 10),
  },
  userName: {
    from: "name",
  },
  name: {
    from: "properties",
    convert: (x) => x.split(" ")[1],
  },
  _tpInfos: {
    from: "properties",
    convert: x => x.replace(/ +/g, " ").split(/\s/),
  },
})
export default class SatTransponder extends Model {

  constructor(data) {
    super(data)
    this._transponder = this._tpInfos[1] / 1000
    this._polarization = POLARIZATION_TYPE[this._tpInfos[2]]
    this._symbolRate = `${this._tpInfos[3]}`
    this._fec = `${this._tpInfos[4]}`
  }

  get properties() {
    let properties = "S "
    properties += this.transponder * 1000 + " "
    properties += this.polarizationLetter + " "
    properties += this.symbolRate + " "
    properties += this.fec
    return properties
  }

  get transponder() {
    return this._transponder
  }

  set transponder(value) {
    this._transponder = value
  }

  get polarization() {
    return this._polarization
  }

  set polarization(value) {
    this._polarization = value
  }

  get polarizationLetter() {
    return POLARIZATION_TYPE[this._polarization]
  }

  get symbolRate() {
    return this._symbolRate
  }

  set symbolRate(value) {
    this._symbolRate = value
  }

  get fec() {
    return this._fec
  }

  set fec(value) {
    this._fec = value
  }

  get wydvbUri() {
    return `wydvb://dvbs/?frequency=${parseFloat(this.transponder, 10) * 1000}&modulation=Auto&code_rate=${this.fec}` +
      `&symbol_rate=${this.symbolRate}&polarity=${this.polarizationLetter}`
  }
}


