//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"

import {createSections} from "services/api/config"

import {
  setNIT,
  setRefTPScan,
  setChannelsType,
  getNIT,
  getRefTPScan,
  getChannelsType,
  getLNBType,
  setLNBType,
  getLNBFreqs,
  setLNBFreqs,
} from "services/managers/config"


export const MIN_FREQ = 1
export const MAX_FREQ = 999999999

const LNB_UNIVERSAL = {
  antenna_satellite_lnb_control_mode: "lnb_control_13_v_18_v_22_k",
  antenna_satellite_lnb_type: "lnb_type_2_bands",
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_auto",
  antenna_satellite_switch_freq: 11725000,
}

const LNB_MULTIPOINT = {
  antenna_satellite_lnb_control_mode: "lnb_control_force_18_v",
  antenna_satellite_lnb_type: "lnb_type_merged_bands",
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_off",
  antenna_satellite_switch_freq: 11725000,
}

const LNB_MONOPOINT = {
  antenna_satellite_lnb_control_mode: "lnb_control_13_v_18_v_22_k",
  antenna_satellite_lnb_type: "lnb_type_1_band",
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_off",
  antenna_satellite_switch_freq: 11725000,
}

const LNB_INVERTED_MULTIPOINT = {
  antenna_satellite_lnb_control_mode: "lnb_control_force_13_v",
  antenna_satellite_lnb_type: "lnb_type_merged_bands",
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_off",
  antenna_satellite_switch_freq: 11725000,
}

const LNB_INVERTED_MONOPOINT = {
  antenna_satellite_lnb_control_mode: "lnb_control_13_v_18_v_22_k_inverted_polarity",
  antenna_satellite_lnb_type: "lnb_type_1_band",
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_off",
  antenna_satellite_switch_freq: 11725000,
}

export const DEFAULT_ANTENNA_CONFIG = {
  antenna_satellite_lnb_control_mode: "lnb_control_13_v_18_v_22_k",
  antenna_transmitter_id: -1,
  antenna_satellite_switch_freq: 11725000,
  antenna_satellite_lnb_type: "lnb_type_2_bands",
  antenna_satellite_switch_position: -1,
  antenna_satellite_tone_22_khz_mode: "tone_22_khz_auto",
  antenna_satellite_freq_oscillator1: 9750000,
  antenna_satellite_freq_oscillator2: 10600000,
  antenna_type: "antenna_type_satellite",
}

const LNB_TYPE = {
  LNB_UNIVERSAL: LNB_UNIVERSAL,
  LNB_MULTIPOINT: LNB_MULTIPOINT,
  LNB_MONOPOINT: LNB_MONOPOINT,
  LNB_INVERTED_MONOPOINT: LNB_INVERTED_MONOPOINT,
  LNB_INVERTED_MULTIPOINT: LNB_INVERTED_MULTIPOINT,
}

@Model.defineAttributes({
  id: {
    from: "href",
    convert: x => parseInt(x.split("/")[3], 10),
  },
  href: {
    from: "href",
  },
  name: {
    from: "name",
  },
})

export default class Sat extends Model {

  constructor(data) {
    super(data)
    this.transponderList = []
    this._tpRefId = 0
    this.antennaSettings = {
      LNBPower: true,
      LNBType: LNB_UNIVERSAL,
      LNBTypeName : "LNB_UNIVERSAL",
      DiSEqCPosition: -1,
    }
    this._freqs = {}
    this.userSettings = {
    }

    if (this.id < 8000) {
      const options = {}
      options[this.name] = {}
      createSections(options).then(() => {
        getNIT(this.name).then((v) => {
          this.NIT = v
        })
        getChannelsType(this.name).then((v) => {
          this.ChannelsType = v
        })
        getRefTPScan(this.name).then((v) => {
          this.RefTPScan = v
        })
        for (const type in LNB_TYPE) {
          getLNBFreqs(this.name, type).then((v) => {
            this.setLNBFreq(type, v)
          })
        }
      })
    }
  }

  setLNBFreq(lnbType, freq) {
    if (!LNB_TYPE[lnbType]) {
      throw new Error(`Unknown LNB type : ${lnbType}`)
    }
    if (!("low" in freq && "high" in freq)) {
      throw new Error("freq must be an object with 'high' and 'low' values")
    }
    if (freq.low < MIN_FREQ || freq.low > MAX_FREQ) {
      throw new Error(`Low Frequency must be between ${MIN_FREQ} and ${MAX_FREQ}`)
    }
    if (freq.high < MIN_FREQ || freq.high > MAX_FREQ) {
      throw new Error(`High Frequency must be between ${MIN_FREQ} and ${MAX_FREQ}`)
    }
    this._freqs[lnbType] = freq
    setLNBFreqs(this.name, lnbType, freq.low, freq.high)
  }

  set TpRefId(value) {
    if (value < 0 && value > this.transponderList.length - 1) {
      throw new Error("Id not in transponderList range")
    }
    this._tpRefId = value
  }

  get TpRefWydvbURI() {
    return this.TpRef.wydvbUri + "&transmitter_id=" + this.id
  }

  get FreqToString() {
    return this.getFreqToString(this.LNBTypeName)
  }

  getFreqToString(lnbType) {
    if (!LNB_TYPE[lnbType]) {
      throw new Error(`Unknown LNB type : ${lnbType}`)
    }
    const freq = this._freqs[lnbType]
    if (lnbType === "LNB_MONOPOINT" || lnbType === "LNB_INVERTED_MONOPOINT") {
      return (freq.low / 1000).toString()
    }
    return freq.low / 1000 + " / " + freq.high / 1000
  }

  get TpRef() {
    return this.transponderList[this._tpRefId]
  }

  get TpRefId() {
    return this._tpRefId
  }

  get FreeToAir() {
    return !!(this.ChannelsType&2)
  }

  get Scrambled() {
    return !!(this.ChannelsType&1)
  }

  get LNBPower() {
    return this.antennaSettings.LNBPower
  }

  set LNBPower(value) {
    if (value !== true && value !== false) {
      throw new Error("Wrong argument, must be a boolean.")
    }
    this.antennaSettings.LNBPower = value
  }

  get LNBType() {
    return this.antennaSettings.LNBType
  }

  set LNBType(type) {
    if (!LNB_TYPE[type]) {
      throw new Error(`Unknown LNB type : ${type}`)
    }
    this.antennaSettings.LNBType = LNB_TYPE[type]
    this.antennaSettings.LNBTypeName = type
    setLNBType(this.name, type)
  }

  get LNBTypeName() {
    return this.antennaSettings.LNBTypeName
  }

  get DiSEqCPosition() {
    return this.antennaSettings.DiSEqCPosition
  }

  set DiSEqCPosition(value) {
    if (!Number.isInteger(value)) {
      throw new Error("Wrong argument, must be an integer.")
    }
    this.antennaSettings.DiSEqCPosition = value
  }

  get NIT() {
    return this.userSettings.NIT
  }

  set NIT(value) {
    if (value !== true && value !== false) {
      throw new Error("Wrong argument, must be a boolean.")
    }
    this.userSettings.NIT = value
    setNIT(this.name, value)
  }

  get ChannelsType() {
    return this.userSettings.channelsType
  }

  set ChannelsType(value) {
    if (value !== 1 && value !== 2 && value !== 3) {
      throw new Error("Wrong argument, must be a integer.")
    }
    this.userSettings.channelsType = value
    setChannelsType(this.name, value)
  }

  get RefTPScan() {
    return this.userSettings.RefTPScan
  }

  set RefTPScan(value) {
    if (value !== true && value !== false) {
      throw new Error("Wrong argument, must be a boolean.")
    }
    this.userSettings.RefTPScan = value
    setRefTPScan(this.name, value)
  }

  get rawAntennaSettings() {
    const lnbControlMode = (this.LNBPower) ? this.LNBType.antenna_satellite_lnb_control_mode : "lnb_control_extern"
    return {
      antenna_satellite_lnb_control_mode: lnbControlMode,
      antenna_transmitter_id: this.id,
      antenna_satellite_switch_freq: this.LNBType.antenna_satellite_switch_freq,
      antenna_satellite_lnb_type: this.LNBType.antenna_satellite_lnb_type,
      antenna_satellite_switch_position: this.DiSEqCPosition,
      antenna_satellite_tone_22_khz_mode: this.LNBType.antenna_satellite_tone_22_khz_mode,
      antenna_satellite_freq_oscillator1: this._freqs[this.LNBTypeName].low,
      antenna_satellite_freq_oscillator2: this._freqs[this.LNBTypeName].high,
      antenna_type: "antenna_type_satellite",
    }
  }

  updateAntennaSettings(data) {
    this.DiSEqCPosition = data.antenna_satellite_switch_position
    this.LNBPower = data.antenna_satellite_lnb_control_mode !== "lnb_control_extern"
    this._updateLNBType({
      antenna_satellite_lnb_control_mode: data.antenna_satellite_lnb_control_mode,
      antenna_satellite_lnb_type: data.antenna_satellite_lnb_type,
      antenna_satellite_tone_22_khz_mode: data.antenna_satellite_tone_22_khz_mode,
    }).then(() => {
      this._freqs[this.LNBTypeName] = {
        "low": data.antenna_satellite_freq_oscillator1,
        "high": data.antenna_satellite_freq_oscillator2,
      }
    })
  }

  _updateLNBType(data) {
    // Special Monopoint case
    if (data.antenna_satellite_lnb_type === "lnb_type_1_band") {
      if (data.antenna_satellite_lnb_control_mode === "lnb_control_extern") {
        return getLNBType(this.name).then((value) => {
          this.LNBType = value
          this.antennaSettings.LNBTypeName = value
        })
      } else if (data.antenna_satellite_lnb_control_mode === "lnb_control_13_v_18_v_22_k") {
        this.antennaSettings.LNBTypeName = "LNB_MONOPOINT"
        this.LNBType = "LNB_MONOPOINT"
        return Promise.resolve()
      } else {
        this.antennaSettings.LNBTypeName = "LNB_INVERTED_MONOPOINT"
        this.LNBType = "LNB_INVERTED_MONOPOINT"
        return Promise.resolve()
      }
    } else {
      // Others cases
      for (const k in LNB_TYPE) {
        if (
          LNB_TYPE[k].antenna_satellite_tone_22_khz_mode === data.antenna_satellite_tone_22_khz_mode &&
            LNB_TYPE[k].antenna_satellite_lnb_control_mode === data.antenna_satellite_lnb_control_mode
        ) {
          this.LNBType = k
          this.antennaSettings.LNBTypeName = k
          return Promise.resolve()
        }
      }

      // Default case
      this.antennaSettings.LNBTypeName = "LNB_UNIVERSAL"
      this.LNBType = "LNB_UNIVERSAL"
      return
    }
  }
}
