//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import {isoToName} from "utils/string"

@Model.defineAttributes({
  _lang: {
    from: "SubtitleLang",
    convert: (x) => {
      if (x !== "OFF") {
        return isoToName(x)
      }
      return x
    },
  },
  cleanEffects: {
    from: "SubtitleLangType",
    convert: x => x === "1",
  },
  hearingImpaired: {
    from: "SubtitleLangType",
    convert: x => x === "2",
  },
  visuallyImpaired: {
    from: "SubtitleLangType",
    convert: x => x === "3",
  },
  subtitleCodec: {
    from: "SubtitleCodec",
  },
})
export default class Subtitle extends Model {
  get lang() {
    const lang = [this._lang]
    if (this.hearingImpaired) {
      lang.push(" ( hearing impaired )")
    }
    if (this.visuallyImpaired) {
      lang.push(" ( visual impaired )")
    }
    if (this.cleanEffects) {
      lang.push(" ( clean effects )")
    }
    if (this.subtitleCodec === "teletext") {
      lang.push(" ( teletext )")
    }
    return `${lang.join("")}`
  }
}
