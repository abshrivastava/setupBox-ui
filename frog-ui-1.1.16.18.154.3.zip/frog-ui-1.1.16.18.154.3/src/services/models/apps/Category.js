//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import AppModel from "services/models/apps/App"

@Model.defineAttributes({
  title:{
    from: "label",
  },
  position:{
    from: "position",
  },
  description:{
    from: "description",
  },
  thumbnail:{
    from: "thumbnail",
  },
  preview:{
    from: "screenshot",
  },
  applications:{
    from: "applications",
    convert: x => x.map(app => new AppModel(app)).sort((a, b) => a.position - b.position),
  },
})

export default class CategoryModel extends Model {
  getApplications() {
    return this.applications
  }
}
