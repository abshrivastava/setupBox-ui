//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import {isoToName} from "utils/string"

@Model.defineAttributes({
  _lang: {
    from: "AudioLang",
    convert: x => isoToName(x),
  },
  cleanEffects: {
    from: "AudioLangType",
    convert: x => x === "1",
  },
  hearingImpaired: {
    from: "AudioLangType",
    convert: x => x === "2",
  },
  visuallyImpaired: {
    from: "AudioLangType",
    convert: x => x === "3",
  },
  audioCodec: {
    from: "AudioCodec",
  },
})
export default class AudioTrack extends Model {
  get lang() {
    const lang = [this._lang]
    if (this.audioCodec === "ac3") {
      lang.push(" ( 5.1 )")
    }
    if (this.audioCodec === "eac3") {
      lang.push(" ( 7.1 )")
    }
    if (this.cleanEffects) {
      lang.push(" ( no effect )")
    }
    if (this.visuallyImpaired) {
      lang.push(" ( visual impaired )")
    }
    return `${lang.join("")}`
  }
}
