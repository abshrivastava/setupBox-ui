//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import {matchFilters} from "utils"

const DEFAULT_OPTIONS = {
  headers: {
    "Accept": "application/json",
    "If-Modified-Since": "Thu, 01 Jan 1970 00:00:00 GMT",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json; charset=utf-8",
  },
}

function urlFor(path) {
  return (/^[a-z]+:/.test(path)) ? path : "http://" + config.STB_IP + path
}

/**class:: http.sse()
 *
 *   :returns Object:
 *
 * .. code-block:: js
 *
 *    import sse from "services/http"
 *
 *    function callback(data) {
 *      console.log(data)
 *    }
 *
 *    sse.connect()
 *    sse.addEventListener("player", callback, "playback"}
 *    sse.removeEventListener("player", callback)
 */
export const sse = {
  listeners: new Map(),

  connect() {
    const url = urlFor("/events/")

    this.eventSource = new EventSource(url)
  },

  addEventListener(eventName, fn, filters) {
    if (!this.eventSource) {
      this.connect()
    }

    const callback = (event) => {
      const data = JSON.parse(event.data)
      data.type = event.type

      if (!filters || matchFilters(filters, data)) {
        fn(data)
      }
    }

    if (!this.listeners.has(eventName)) {
      this.listeners.set(eventName, [{fn, callback}])
    } else {
      this.listeners.get(eventName).push({fn, callback})
    }

    this.eventSource.addEventListener(eventName, callback, true)
  },

  removeEventListener(eventName, fn) {
    if (!(this.listeners.has(eventName))) {
      return
    }
    const listeners = this.listeners.get(eventName)
    const index = listeners.findIndex((e) => e.fn === fn)

    if (index !== -1) {
      const callback = listeners[index].callback
      this.eventSource.removeEventListener(eventName, callback, true)
      listeners.splice(index, 1)
    }
  },

  on() {
    return this.addEventListener.apply(this, arguments)
  },

  off() {
    return this.removeEventListener.apply(this, arguments)
  },
}

function httpCall(method, path, options) {
  return new Promise((resolve, reject) => {
    options = {...DEFAULT_OPTIONS, ...options}
    const xhr = new XMLHttpRequest()
    const url = urlFor(path)
    // Force JSON for wyrest request because wyrest respond text/html
    // Content-Type but it is application/json in fact...
    const forceJson = path.indexOf("/") === 0

    const headers = options.headers
    options.body = serializeBody(options.body, headers["Content-Type"])

    xhr.open(method, url, true)

    if (options.blob) {
      xhr.responseType = "blob"
    }

    for (const header in headers) {
      xhr.setRequestHeader(header, headers[header])
    }

    xhr.onload = function() {
      const responseHeaders = {}
      if (options.responseHeaders) {
        for (const header in options.responseHeaders) {
          responseHeaders[options.responseHeaders[header]] =
            xhr.getResponseHeader(options.responseHeaders[header])
        }
      }

      if (xhr.status !== 200) {
        return reject(xhr.status)
      }

      if (options.blob) {
        resolve(xhr.response)
      } else if (xhr.responseText.length) {
        const contentType = (forceJson) ? "application/json; charset=utf-8" :
          xhr.getResponseHeader("Content-Type")
        const response = decodeResponse(xhr.responseText, contentType)
        response.headers = responseHeaders
        resolve(response)
      } else {
        resolve()
      }
    }

    xhr.onerror = function(e) {
      reject(e)
    }

    xhr.send(options.body)
  })
}

function serializeBody(body, contentType) {
  if (!body) {
    return null
  }

  // Only keep the first part of the content-type
  contentType = contentType.split(";")[0]

  switch (contentType) {
  case "application/json":
    return JSON.stringify(body)
  case "application/x-www-form-urlencoded":
    return formUrlencoded(body)
  }

  return body
}

function decodeResponse(data, contentType) {
  // Only keep the first part of the content-type
  contentType = contentType.split(";")[0]

  switch (contentType) {
  case "application/json":
    return JSON.parse(data)
  }

  return {data: data}
}

/**function:: http.formUrlencoded(body)
 *
 *   :returns Object:
 *
 * .. code-block:: js
 *
 *    formUrlencoded() //=>
 */
export function formUrlencoded(body) {
  return Object.keys(body)
    .map(key => {
      const encodedKey = encodeURIComponent(key).replace(/%20/g, "+")
      const encodedValue = encodeURIComponent(body[key]).replace(/%20/g, "+")

      return `${encodedKey}=${encodedValue}`
    })
    .join("&")
}

/**function:: http.createQueryString(parameters)
 *
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    createQueryString() //=>
 */
export function createQueryString(parameters) {
  return `?${formUrlencoded(parameters)}`
}

/**function:: http.GET(path, options)
 * GET
 *
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    GET("http://127.0.0.1/player/")
 */
export function GET(path, options = {}) {
  return httpCall("GET", path, options)
}

/**function:: http.PUT(path, body, options)
 * PUT
 *
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    PUT("http://127.0.0.1/player/", null, null)
 */
export function PUT(path, body, options = {}) {
  options.body = body

  return httpCall("PUT", path, options)
}

/**function:: http.POST(path, body, options)
 * POST
 *
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    POST("http://127.0.0.1/player/", null, null)
 */
export function POST(path, body, options = {}) {
  options.body = body

  return httpCall("POST", path, options)
}

/**function:: http.DELETE(path, options)
 * DELETE
 *
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    DELETE("http://127.0.0.1/player/")
 */
export function DELETE(path, options = {}) {
  return httpCall("DELETE", path, options)
}
