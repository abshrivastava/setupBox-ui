//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {enableEvents} from "services/events"
import {_} from "utils/locale"
import {
  isFunction,
  isObject,
  isArray,
  pick,
} from "utils"

import {pushState, pullState, addTransitionListener, removeTransitionListener} from "utils/dom"


const JS_TO_HTML_ATTRIBUTES = {
  className: "class",
  htmlFor: "for",
}

/** Top level component references. To make a component top level, give it a
 * `ref` property with the name you want.
 *
 * You can then use the :js:func:`$` helper function to retrieve the component
 * in the controllers.
 */
const REFS = {}

/** class:: Component([props, children])
 * See :js:attr:`.props` for details about properties.
 *
 *  :param Object<string, any> props: Properties.
 *  :param Array<> children: Children.
 */
export default class Component {
  /** data:: static defaultProps
   * Default properties of a component. To redefine in children classes.
   *
   *   :type: Object<string, any>
   */
  static defaultProps = {}

  constructor(props = {}, children = []) {
    /** attribute:: dom
     * Root DOM Element of the Component.
     *
     *   :type: ?Element
     */
    this.dom = null

    /** attribute:: className
     * Shortcut to the className of the root DOM Element.
     *
     *   :type: ?string
     */
    this.className = null

    /** attribute:: props
     * Component properties.
     *
     *   :type: Object<string, any>
     */
    this.props = Object.assign({}, this.constructor.defaultProps || {}, props)

    /** attribute:: children
     * Children nodes or components.
     *
     *   :type: Array<>
     */
    this.children = children.map((c) => renderTree(c, this))

    /** attribute:: _propRefs
     * References to nodes that are bound to some properties.
     *
     *   :type: Object<string, Array<Node>>
     *   :private:
     */
    this._propRefs = {}

    if (this.constructor.ref) {
      storeTopLevelRef(this.constructor.ref, this)
    }

    enableEvents(this)
  }

  /** function:: render()
   * Renders the DOM Element of the Component.
   *
   * Derived components must implement this method and ensure it returns a DOM
   * Element.
   *
   *   :throws Error: Must be overriden by the subclass
   *   :returns Element: The root element of the component
   */
  render() {
    throw new Error("Abstract method `render` called")
  }

  /** function:: build()
   * Renders the component.
   *
   * It will also automatically infer the base components `className` by using
   * the first class found in the root node's `classList`.
   *
   *   :returns Element: The root node created by #render()
   */
  build() {
    this.dom = renderTree(this.render(), this)

    const className = this.dom.classList[0]
    if (className) {
      this.className = className
    }

    return this.dom
  }

  /** function:: destroy()
   * Destroys the DOM for this component and detach from parent.
   *
   * It will NOT recursively destroy children components.
   */
  destroy() {
    this.dom.parentNode.removeChild(this.dom)
  }

  /** function:: setProps(props = {})
   * Changes the value of a set of properties and update all the nodes that
   * are bound to them.
   *
   * See :js:func:`.setProp`.
   *
   *   :param Object<string, any> props: Map of name/value for the new
   *     properties
   */
  setProps(props = {}) {
    for (const propName in props) {
      const propValue = props[propName]
      this.props[propName] = propValue

      const refs = this._propRefs[propName]

      if (refs && refs.length) {
        for (const ref of refs) {
          const limit = ref.firstChild.limit
          if (limit && Number.isInteger(limit.start) && Number.isInteger(limit.end)) {
            ref.textContent = _(propValue).substring(limit.start, limit.end) || " "
          } else {
            ref.textContent = _(propValue) || " "
          }
          if (ref.firstChild) {
            ref.firstChild.msgId = propValue
            ref.firstChild.limit = limit
          }
        }
      }
    }
  }

  /** function:: setProp(propName, propValue)
   * Changes the value of a property and update all the nodes that are bound to
   * it.
   *
   *   :param String propName: Name of the property to change
   *   :param <*> propValue: New value for the property
   */
  setProp(propName, propValue) {
    this.setProps({[propName]: propValue})
  }

  /** function:: show()
   * Removes the `hidden` BEM state on this component
   */
  show() {
    return this.pullState("hidden")
  }

  /** function:: hide()
   * Adds the `hidden` BEM state on this component
   */
  hide() {
    return this.pushState("hidden")
  }

  /** function:: pushState(state[, onTransitionEnd])
   * Adds a BEM state on this component, optionally passing a callback to be
   * executed on transition end.
   *
   * Be cautious that if you give a transition callback and do not define a CSS
   * transition for this state,
   *
   *   :param String state: Name of the state to add
   *   :param ?Function willTransition:
   *     Flag to set when state changes causes a transition
   */
  pushState(state, willTransition = false) {
    return pushState(this.dom, state, willTransition, this.className)
  }

  /** function:: pullState(state[, onTransitionEnd])
   * Removes a BEM state on this component, optionally passing a callback to be
   * executed on transition end.
   *
   * Be cautious that if you give a transition callback and do not define a CSS
   * transition for this state,
   *
   *   :param String state: Name of the state to remove
   *   :param ?Function willTransition:
   *     Flag to set when state changes causes a transition
   */
  pullState(state, willTransition = false) {
    return pullState(this.dom, state, willTransition, this.className)
  }

  /** function:: addTransitionListener(callback)
   * Adds a transition listener on the root DOM node of the component.
   *
   *   :param Function callback: Transition callback
   */
  addTransitionListener(callback) {
    addTransitionListener(this.dom, callback)
  }

  /** function:: removeTransitionListener(callback)
   * Removes a transition listener from the root DOM node of the component.
   *
   *   :param Function callback: Transition callback
   */
  removeTransitionListener(callback) {
    removeTransitionListener(this.dom, callback)
  }

  /** function:: _addPropRef(propName, node)
   * Bind a node to be automatically updated whenever a given property changes.
   *
   *   :param String propName: Name of the bound property
   *   :param Node node: The node to register
   *   :protected:
   */
  _addPropRef(propName, node) {
    let textContent = null
    let firstChar = null
    let lastChar = null

    const regexp = /\[(.*?)\]/
    const limitMatch = regexp.exec(propName)

    if (limitMatch) {
      propName = propName.split(limitMatch[0])[0]
      const limit = limitMatch[1].split(":")
      firstChar = parseInt(limit[0], 10)
      lastChar = parseInt(limit[1], 10)
    }

    if (!this._propRefs[propName]) {
      this._propRefs[propName] = []
    }
    this._propRefs[propName].push(node)

    textContent = _(this.props[propName])
    if ((firstChar || firstChar === 0) && lastChar) {
      textContent = textContent.substring(firstChar, lastChar)
    }
    node.textContent = textContent || " "
    if (node.firstChild) {
      node.firstChild.msgId = this.props[propName]
      node.firstChild.limit = {
        start: firstChar,
        end: lastChar,
      }
    }
  }

  static makeTree(type, props, ...children) {
    const specials = pick(props || {}, "key", "ref", "prop", "collection")

    const tree = {
      type,
      ...specials,
      props,
      children,
    }

    return tree
  }
}

/** function:: $(ref)
 * Returns a top level component by its reference.
 *
 *   :param String ref: Reference name
 */
export function $(ref) {
  return REFS[ref]
}

/* internal functions */

function renderTree(tree, parent) {
  if (isArray(tree)) {
    return tree.map((branch) => renderTree(branch, parent))
  } else if (isObject(tree)) {
    if (isFunction(tree.type)) {
      return renderComponent(tree, parent)
    } else {
      return renderHTML(tree, parent)
    }
  } else {
    return document.createTextNode(tree)
  }
}

function renderComponent(tree, parent) {
  const component = new tree.type(tree.props, tree.children)

  storeTopLevelRef(tree.ref, component)
  storeAsParentChild(parent, tree.key, component)
  storeInParentCollection(parent, tree.collection, component)

  return component.build()
}

function renderHTML(tree, parent) {
  const node = document.createElement(tree.type)

  function processChildren(children) {
    for (const child of children) {
      if (child === null || child === false) {
        continue // Skip falsy children
      } else if (isArray(child)) {
        processChildren(child)
      } else if (isObject(child)) {
        node.appendChild(renderTree(child, parent))
      } else if (child instanceof Node) {
        node.appendChild(child)
      } else {
        node.appendChild(document.createTextNode(String(child)))
      }
    }
  }

  for (const attrName in tree.props) {
    const realAttrName = JS_TO_HTML_ATTRIBUTES[attrName] || attrName
    const attrValue = tree.props[attrName]

    node.setAttribute(realAttrName, attrValue)
  }

  processChildren(tree.children)

  storeTopLevelRef(tree.ref, node)
  storeAsParentChild(parent, tree.key, node)
  storeInParentCollection(parent, tree.collection, node)

  if (tree.prop) {
    parent._addPropRef(tree.prop, node)
  }

  return node
}

function storeTopLevelRef(ref, component) {
  if (!ref) {
    return
  }

  if (REFS.hasOwnProperty(ref)) {
    throw new Error(`Component ${ref} already exists`)
  }
  REFS[ref] = component
}

function storeAsParentChild(parent, key, child) {
  if (!key) {
    return
  }

  if (parent[key]) {
    const parentName = parent.constructor.name
    console.warn(`${parentName} already has a child with key ${key}`)
  }
  parent[key] = child
}


function storeInParentCollection(parent, collection, child) {
  if (!collection) {
    return
  }

  if (!parent[collection]) {
    parent[collection] = []
  }
  parent[collection].push(child)
}
