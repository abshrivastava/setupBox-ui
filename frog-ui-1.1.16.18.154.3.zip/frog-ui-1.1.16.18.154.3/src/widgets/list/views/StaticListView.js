//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import ListView from "./ListView"


export default class StaticListView extends ListView {
  constructor(options) {
    super(options)
    this.rangeItem = []
    this.selectedNode = null
  }

  redraw(range, idx) {
    this.rangeItem = []
    while (this.itemsList.dom.firstChild) {
      this.itemsList.dom.removeChild(this.itemsList.dom.firstChild)
    }
    const fragments = document.createDocumentFragment()
    range.forEach((item, i) => {
      const value = item !== null ? item : ""
      const node = new this.itemView(value)
      this.rangeItem.push(node)
      fragments.appendChild(node.build())
      if (idx === i) {
        this.selectedNode = node
        this.selectedNode.pushState("selected")
      }
    })
    this.itemsList.dom.appendChild(fragments)
  }

  _removeFirstChildren(n) {
    for (let i=0; i < n; i++) {
      if (this.dom.firstChild) {
        this.rangeItem.shift()
        this.itemsList.dom.removeChild(this.itemsList.dom.firstChild)
      }
    }
  }

  _removeLastChildren(n) {
    for (let i=0; i < n; i++) {
      if (this.dom.lastChild) {
        this.rangeItem.pop()
        this.itemsList.dom.removeChild(this.itemsList.dom.lastChild)
      }
    }
  }

  _appendChildren(range) {
    range.forEach((item) => {
      const value = item !== null ? item : ""
      const node = new this.itemView(value)
      this.rangeItem.push(node)
      this.itemsList.dom.appendChild(node.build())
    })
  }

  _prependChildren(range) {
    range.forEach((item) => {
      const value = item !== null ? item : ""
      const node = new this.itemView(value)
      this.rangeItem.unshift(node)
      this.itemsList.dom.insertBefore(node.build(),
        this.itemsList.dom.firstChild)
    })
  }

  partialRedraw(range, idx, moveIdx) {
    if (moveIdx > 0) {
      this._removeFirstChildren(moveIdx)
      this._appendChildren(range.splice(range.length-moveIdx, moveIdx))
      this.selectedNode.pullState("selected")
      this.selectedNode = this.rangeItem[idx]
      this.selectedNode.pushState("selected")
    } else {
      this._removeLastChildren(-moveIdx)
      this._prependChildren(range.splice(0,-moveIdx))
      this.selectedNode.pullState("selected")
      this.selectedNode = this.rangeItem[idx]
      this.selectedNode.pushState("selected")
    }
  }

  update(range, idx, moveIdx) {
    if (Math.abs(moveIdx) > range.length || !moveIdx) {
      this.redraw(range, idx)
    } else {
      this.partialRedraw(range, idx, moveIdx)
    }
  }
}
