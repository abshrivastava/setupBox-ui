//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import List from "utils/List"
import {mod} from "./"

/** class:: CircularList(items)
 *
 *  :param Array<> items: Items.
 */
export default class CircularList extends List {

  getIdx(index) {
    return mod(index, this.count)
  }

  get(index) {
    // if (this.count === 0) {
    //   throw new Error("empty list")
    // }
    return this.items[mod(index, this.count)]
  }

  set(index, value) {
    // if (this.count === 0) {
    //   throw new Error("empty list")
    // }
    this.items[mod(index, this.count)] = value
  }

  /** function:: getRange(start, length)
   * Return Items in the specified range
   *
   *   :param Int start: Index
   *   :param Int length: Number of items to return
   *   :returns Array:
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c", "d", "e", "f"])
   *    list.getRange(5, 2) //=> ["f", "a"]
   */
  getRange(start, length) {
    const range = []

    const add = length < 0 ? range.unshift : range.push
    const s = length < 0 ? start + length + 1 : start
    const e = length < 0 ? start + 1 : start + length
    const list = this

    for (let i = s; i < e; i++) {
      add.apply(range, [list.get(i)])
    }

    return range
  }
}
