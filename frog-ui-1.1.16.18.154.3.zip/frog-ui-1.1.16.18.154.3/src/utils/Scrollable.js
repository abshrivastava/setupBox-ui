//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as string from "./string"
import {mod, reverseObject, createTicker} from "./"

/**data:: Scrollable
 * These mixins are used to implement scrollable lists with animated
 * transitions.
 *
 * You will need to include the ControllerMixin in the controller and the
 * ComponentMixin in the Component. See the documentation of these function for
 * more information.
 */

const DEFAULT_CONTROLLER_OPTIONS = {
  scrollSpeed: 800,
  fastScrollSpeed: 200,
  fastScrollable: true,
  mode: "cyclic",
}

const DEFAULT_COMPONENT_OPTIONS = {
  mode: "cyclic",
}

/**data:: Scrollable.DIRECTION
 * These mixins are used to implement scrollable lists with animated
 * transitions.
 *
 * You will need to include the ControllerMixin in the controller and the
 * ComponentMixin in the Component. See the documentation of these function for
 * more information.
 */
export const DIRECTION = {
  BACKWARD: -1,
  FORWARD: +1,
}

const DIRECTION_NAMES = new Map(reverseObject(DIRECTION))

/**function:: ControllerMixin(instance, options)
 * This Controller mixin automatically adds the required methods to implement a
 * scrollable list.
 *
 * The mandatory source option should be a List (see List and CircularList in
 * utils).
 *
 * The provided methods are:
 *
 * - scroll(direction): Start scrolling in the given direction (forward or
 *   backward);
 * - stopScrolling(): Stops scrolling and call the function specified with the
 *   onScrollStop option if given;
 * - jumpTo(): Jumps to a specific item in the list (by index);
 * - getSelectedItem(): Returns the selected item in the list.
 *
 * Other options:
 *
 * - fastScrollable: if true, scroll accelerates after a few iterations
 * - scrollSpeed: delay between scrolls (in ms)
 * - fastScrollSpeed: delay between scrolls when in fastScroll mode (in ms)
 * - mode: bounded or cyclic
 */
function ControllerMixin(instance, options) {
  options = Object.assign({}, DEFAULT_CONTROLLER_OPTIONS, options)

  if (!("source" in options)) {
    throw new Error("Missing mandatory argument source")
  }

  const source = options.source
  const scrollTicker = createTicker(options.scrollSpeed)
  let scrollIndex = -1
  let scrollStart = null

  instance.scroll = function scroll(direction) {
    if (scrollTicker.running) {
      return
    }

    if (instance.view.startScrolling) {
      instance.view.startScrolling()
    }
    scrollStart = new Date()

    scrollTicker.start(() => {
      // Accelerate after scrolling two elements if fastScrollable is enabled
      if (options.fastScrollable &&
          scrollTicker.rate !== options.fastScrollSpeed &&
          ((new Date() - scrollStart) > options.scrollSpeed)) {
        scrollTicker.rate = options.fastScrollSpeed
        if (instance.view.enableFastScroll) {
          instance.view.enableFastScroll()
        }
      }

      const newIndex = instance.next(direction)
      if (newIndex !== scrollIndex) {
        const directionName = DIRECTION_NAMES.get(direction).toLowerCase()
        const eventName = `scroll${string.capitalize(directionName)}`

        scrollIndex = newIndex
        instance.listview[eventName](newIndex)
      }
    })
  }

  instance.jumpTo = function jumpTo(newIndex) {
    if (newIndex !== scrollIndex && source.length > 0) {
      scrollIndex = newIndex
      instance.listview.jumpTo(newIndex, source.get(newIndex))
      if (instance.view.jumpTo) {
        instance.view.jumpTo(newIndex, source.get(newIndex))
      }
    }
  }

  instance.getSelectedItem = function getSelectedItem() {
    return source.get(scrollIndex)
  }

  instance.stopScrolling = function stopScrolling() {
    if (!scrollTicker.running) {
      return
    }

    scrollTicker.rate = options.scrollSpeed
    scrollTicker.stop()
    if (options.onScrollStop) {
      options.onScrollStop.call(instance)
    }
    if (options.fastScrollable) {
      if (instance.view.disableFastScroll) {
        instance.view.disableFastScroll()
      }
    }
    instance.listview.stopScrolling()
    if (instance.view.stopScrolling) {
      instance.view.stopScrolling()
    }
  }

  instance.next = function next(direction) {
    switch (options.mode) {
    case "cyclic":
      return mod(scrollIndex + direction, source.length)
    case "bounded":
      return Math.max(0, Math.min(scrollIndex + direction, source.length - 1))
    default:
      throw new Error(`Unknown mode ${options.mode}`)
    }
  }
}

/**function:: ComponentMixin(instance, options)
 */
function ComponentMixin(instance, options) {
  options = Object.assign({}, DEFAULT_COMPONENT_OPTIONS, options)

  const requiredOptions = ["controller", "collection", "size"]
  for (const option of requiredOptions) {
    if (!(option in options)) {
      throw new Error(`Missing mandatory option ${option}`)
    }
  }

  let currentIndex = 0
  let source = null
  const listSize = options.size
  const halfListSize = ~~(listSize / 2)

  instance.setScrollableSource = function setScrollableSource(newSource) {
    source = newSource
    instance.jumpTo(currentIndex, "force")
  }

  instance.jumpTo = function jumpTo(index, force = false) {
    if (!force && index === currentIndex) {
      return
    }
    currentIndex = index
    const itemsToShow = source.getRange(currentIndex - halfListSize, listSize)

    itemsToShow.forEach((item, i) => {
      instance[options.collection][i].update(item)
    })

    instance.applyScroll()

    const items = instance[options.collection]
    items[halfListSize].pushState("selected")
  }

  switch (options.mode) {
  case "bounded":
    instance.scrollBackward = function scrollBackward(newIndex) {
      const items = instance[options.collection]
      items[halfListSize].pullState("selected")

      const exitingItem = items.pop()
      const previousItemIdx = currentIndex - halfListSize - 1
      if (previousItemIdx >= 0) {
        const previousItem = source.get(previousItemIdx)
        exitingItem.update(previousItem)
      } else {
        exitingItem.hide()
      }
      items.unshift(exitingItem)

      currentIndex = newIndex
      instance.applyScroll()
    }
    instance.scrollForward = function scrollForward(newIndex) {

      const items = instance[options.collection]
      items[halfListSize].pullState("selected")

      const exitingItem = items.shift()
      const nextItemIdx = currentIndex + halfListSize + 1

      if (nextItemIdx < source.length) {
        const nextItem = source.get(nextItemIdx)
        exitingItem.update(nextItem)
      } else {
        exitingItem.hide()
      }
      items.push(exitingItem)

      currentIndex = newIndex
      instance.applyScroll()
    }
    break
  case "cyclic":
  default:
    instance.scrollBackward = function scrollBackward(newIndex) {

      const items = instance[options.collection]
      items[halfListSize].pullState("selected")

      const exitingItem = items.pop()
      const previousItemIdx = currentIndex - halfListSize - 1
      const previousItem = source.get(previousItemIdx)

      exitingItem.update(previousItem)
      items.unshift(exitingItem)

      currentIndex = newIndex
      instance.applyScroll()
    }

    instance.scrollForward = function scrollForward(newIndex) {

      const items = instance[options.collection]
      items[halfListSize].pullState("selected")

      const exitingItem = items.shift()
      const nextItemIdx = currentIndex + halfListSize + 1
      const nextItem = source.get(nextItemIdx)

      exitingItem.update(nextItem)
      items.push(exitingItem)

      currentIndex = newIndex
      instance.applyScroll()
    }
    break
  }

  instance.stopScrolling = function stopScrolling() {

    const items = instance[options.collection]

    items[halfListSize].pushState("selected")
    if (options.onScrollStop) {
      options.onScrollStop.call(instance)
    }
  }
}

export default {
  ControllerMixin,
  ComponentMixin,
  DIRECTION,
}
