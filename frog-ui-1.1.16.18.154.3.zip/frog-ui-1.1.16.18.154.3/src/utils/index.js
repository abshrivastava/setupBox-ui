//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {POST} from "services/http"
import config from "./config"

/**function:: utils.noop()
 * A function that does nothing
 */
export function noop() {}

/**function:: utils.constructorOf(obj)
 * Returns the function used to construct an object
 *
 *   :param Object obj:
 *   :returns Function: obj's constructor
 *
 * .. code-block:: js
 *
 *    const animal = new Animal()
 *    constructorOf(animal) //=> Animal
 */
export function constructorOf(obj) {
  if (!obj) {
    return null
  }

  return obj.constructor
}

/**function:: utils.isObject(obj)
 * Tests if an object has the Object constructor
 *
 *   :returns Boolean:
 */
export function isObject(obj) {
  return constructorOf(obj) === Object
}

/**function:: utils.isArray(obj)
 * Tests if an object has the Array constructor
 *
 *   :returns Boolean:
 */
export function isArray(obj) {
  return constructorOf(obj) === Array
}

/**function:: utils.isFunction(obj)
 * Tests if an object has the Function constructor
 *
 *   :returns Boolean:
 */
export function isFunction(obj) {
  return obj instanceof Function
}

/**function:: utils.isDefined(obj)
 * Tests if a variable is defined
 *
 *   :returns Boolean:
 */
export function isDefined(foo) {
  return typeof foo !== "undefined"
}

/**function:: utils.trace()
 * This logging decorator provides additional information about a class method
 * calls.
 *
 * Add it before any method that you want to trace in the console and you will
 * get a detail stack trace and arguments inspection whenever the method is
 * called.
 *
 * Keep in mind that this is a costly operation and that it will not be
 * available in production because of this.
 *
 *   :implements: |-ext-js-decorators|_
 *
 * .. code-block:: js
 *
 *    class Foo() {
 *      @trace
 *      hello() { console.log("Hello") }
 *    }
 */
export function trace(target, name, descriptor) {
  if (!config.DEBUG) {
    return descriptor
  }

  const original = descriptor.value

  const traced = function(...args) {
    const callerString = `${this.constructor.name}#${name}`
    traceCall(callerString, args)
    return original.call(this, ...args)
  }

  descriptor.value = traced

  return descriptor
}

const TRACE_STYLES = new Map([
  // Replace by Bus?
  // [/Router#handleKeyEvent/, "color: #d9983f; font-weight: bold"],
  // [/Router#setContext/, "color: #ed5e7d; font-weight: bold"],
  // [/Router#/, "color: #256ee4; font-weight: bold"],
  [/Controller#/, "color: #28a140; font-weight: bold"],
])

export function traceCall(callerString, args = []) {
  if (!config.DEBUG) {
    return
  }

  const traceStyle = Array.from(TRACE_STYLES.keys())
    .find((re) => re.test(callerString))
  const styles = traceStyle ? TRACE_STYLES.get(traceStyle) : ""

  if (config.LOG_IP) {
    POST(`http://${config.LOG_IP}/`, {callerString, styles, args})
      .catch((err) => console.error("Cannot trace call", err))
  }
  console.trace(`%c${callerString}`, styles, args)
}

/**function:: utils.mod(a, b)
 * Returns the a mod b, fixing JavaScript's behaviour when working with negative
 * numbers.
 *
 *   :returns Number:
 *
 * .. code-block:: js
 *
 *    -4 % 3 //=> -1
 *    mod(-4, 3) //=> 2
 */
export function mod(a, b) {
  return ((a % b) + b) % b
}

/**function:: utils.throttle(func, delay)
 * Creates a throttled function that only invokes fn at most once per every threshold milliseconds.
 *
 *   :param Function func: Target function
 *   :param Number delay: Maximal execution rate
 *   :returns Function: A new function capped to the maximal execution rate
 */
export function throttle(func, delay, context=this) {
  let timeout = null
  let callbackArgs = null

  const later = () => {
    func.apply(context, callbackArgs)
    timeout = null
  }

  return function() {
    if (!timeout) {
      callbackArgs = arguments
      timeout = setTimeout(later, delay)
    }
  }
}


/**function:: utils.debounce(fn, delay)
 * Creates a new function that defers its execution until it has stopped being
 * called for a specific delay.
 *
 *   :param Function fn: Target function
 *   :param Number delay: Debounce delay
 *   :returns Function: The debounced function
 */
export function debounce(fn, delay) {
  let timer

  return function(...args) {
    clearTimeout(timer)
    timer = setTimeout(() => fn.call(this, ...args), delay)
  }
}

/**function:: utils.createTicker()
 * Creates a programmable ticker that can be stopped and started and which
 * executes a given callback at a specified rate.
 *
 * See :js:func:`~utils.ticker.start` and :js:func:`~utils.ticker.stop`
 *
 *   :param Number rate: Call rate of the ticker
 *   :returns Object: The ticker object with ``start`` and ``stop`` methods
 */
export function createTicker(rate) {
  return {
    rate,
    running: false,
    timer: null,

    /**function:: utils.ticker.start(fn)
     * Starts executing a callback function using the ticker's rate.
     *
     *   :param Function fn: The callback to execute
     */
    start(fn, delayed) {
      if (this.running) {
        return
      }

      const tickStart = +new Date()

      const tick = () => {
        fn.call(null, tickStart)
        if (this.running) {
          this.timer = setTimeout(tick, this.rate)
        }
      }

      this.running = true
      if (delayed) {
        this.timer = setTimeout(tick, this.rate)
      } else {
        tick()
      }
    },

    /**function:: utils.ticker.stop()
     * Stops execution of the current callback.
     */
    stop() {
      if (!this.running) {
        return
      }

      this.running = false
      clearTimeout(this.timer)
    },
  }
}

/**function:: utils.wait(ms)
 * Creates a Promise that automatically resolves after a given amount of time.
 *
 *   :param number ms: Miliseconds to wait before resolving
 *   :returns Promise:
 */
export function wait(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms)
  })
}

/**function:: utils.pick(source, ...props)
 * Remove the given properties from an object and return a new object
 * containing them.
 *
 *   :param Object source: The object to get properties from
 *   :param ...string props: The properties to keep
 *   :returns Object: The filtered object
 */
export function pick(source, ...props) {
  return props.reduce((target, prop) => {
    if (source[prop]) {
      target[prop] = source[prop]
      delete source[prop]
    }
    return target
  }, {})
}

/**function:: utils.reverseObject(obj)
 * Returns an array of [values, keys] using the keys and values from the given
 * object.
 *
 *   :param Object obj: The object to reverse
 *   :returns Array: A list of [value, key]
 */
export function reverseObject(obj) {
  return Object.entries(obj).map(e => e.reverse())
}

/**function:: utils.findKey(obj, val)
 * Returns the key associated with a given value in an object.
 *
 *   :param Object obj: The object to search
 *   :param Object value: The value used to find the key for
 *   :returns String: The key associated with the given value, or null
 */
export function findKey(obj, val) {
  for (const key in obj) {
    if (isArray(val) && val.equals(obj[key])) {
      return key
    }
    if (obj[key] === val) {
      return key
    }
  }

  return null
}

/**function:: utils.findWhere(array, criteria)
 * Returns the object associated with a given criteria in an object.
 *
 *   :param Object array: The array to search
 *   :param Object criteria: The value used to find the object for
 *   :returns Object: The object associated with the given criteria, or undefined
 */
export function findWhere(array, criteria) {
  return array.find(item => Object.keys(criteria).every(key => item[key] === criteria[key]))
}

/**function:: utils.findObjInArrayByValue(array, val)
 * Returns the objet associated with a given value in an array of object.
 *
 *   :param Object array: The array to search
 *   :param Object value: The value used to find the key for
 *   :returns Object: The object associated with the given value, or null
 */
export function findObjInArrayByValue(array, val) {
  for (let i=0; i < array.length; i++) {
    for (const key in array[i]) {
      if (array[i][key] === val) {
        return array[i]
      }
    }
  }

  return null
}

/**function:: utils.findKeyInArrayByValue(array, val)
 * Returns the key associated with a given value in an array of object.
 *
 *   :param Object array: The array to search
 *   :param Object value: The value used to find the key
 *   :returns Object: The key associated with the given value, or null
 */
export function findKeyInArrayByValue(array, val) {
  for (let i=0; i < array.length; i++) {
    for (const key in array[i]) {
      if (array[i][key] === val) {
        return i
      }
    }
  }

  return null
}

export function matchFilters(filters, data) {
  return Object.keys(filters).every((key) => {
    if (!data.hasOwnProperty(key)) {
      // data doesn't even have key, it can't match
      return false
    } else if (isFunction(filters[key])) {
      // Check if the filter's function matches w/ data
      return filters[key](data[key], key)
    } else if (isObject(filters[key])) {
      // Filter contains filter(s), go deeper
      return matchFilters(filters[key], data[key])
    } else if (isArray(filters[key])) {
      // Check if data matches at least one of the given values in filter
      return filters[key].indexOf(data[key]) !== -1
    } else {
      // Check if filter is equal to given data
      return filters[key] === data[key]
    }
  })
}


/**function:: utils.filterRedundantOnThreshold(func, thrsld)
 * Creates a filter redundant function that only invokes fn at most once per every threshold milliseconds,
 * first and last will be always call.
 *
 *   :param Function func: Target function
 *   :param Number thrsld: Maximal execution rate
 *   :returns Function: A new function capped to the maximal execution rate
 */
export function filterRedundantOnThreshold(func, thrsld) {
  let ctInThrottle
  let ctLastFunc
  let ctLastRange
  return function(...args) {
    if (!ctInThrottle) {
      func.call(this, ...args)
      ctLastRange = Date.now()
      ctInThrottle = true
    } else {
      clearTimeout(ctLastFunc)
      ctLastFunc = setTimeout(() => {
        if ((Date.now() - ctLastRange) >= thrsld) {
          func.call(this, ...args)
          ctLastRange = Date.now()
          ctInThrottle = false
        }
      }, thrsld - (Date.now() - ctLastRange))
    }
  }
}

/**function:: utils.avoidRedundantOnThreshold(fn, thrsld)
 * Creates a new avoid redundant function that defers its execution until it has stopped being
 * called for a specific thrsld, first and last will be always call.
 *
 *   :param Function fn: Target function
 *   :param Number thrsld: Debounce thrsld
 *   :returns Function: A new function capped by threshold
 */
export function avoidRedundantOnThreshold(func, thrsld) {
  let ctInDebounce
  let ctLastFunc
  return function(...args) {
    if (!ctInDebounce) {
      func.call(this, ...args)
      ctInDebounce = true
      clearTimeout(ctLastFunc)
      ctLastFunc = setTimeout(() => {
        ctInDebounce = false
      }, thrsld)
    } else {
      clearTimeout(ctLastFunc)
      ctLastFunc = setTimeout(() => {
        func.call(this, ...args)
        ctInDebounce = false
      }, thrsld)
    }
  }
}

/**function:: utils.channelLogo(title)
 * Filter special character from channel title and replace with "_"
 * convert it lowerCase string for case sensitive..
 * compatable for showing channel logo...
 *
 *   :param Function title: channel title
 *   :returns Function: A channel title with no special character expect "_"
 */
export function channelLogo(title) {
  const logo = title.replace(/[*|\¿?;:'"<>\ \/]/gi,"_").toLowerCase()
  return logo
}
