//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "../../../../config.json"

let rucMapping = null

const liberty = {
  UP: 38,
  DOWN: 40,
  LEFT: 37,
  RIGHT: 39,
  OK: 13,
  BACK: 8,
  INFO: 73,
  HOME: 36,
  PROGRAM_PLUS: 33,
  PROGRAM_MINUS: 34,
  VOLUME_PLUS: 175,
  VOLUME_MINUS: 174,
  REC: 82,
  PLAY: 179,
  PAUSE: 80,
  STOP: 178,
  FAST_FORWARD: 176,
  FAST_REWIND: 177,
  POWER: 115,
  KEY_0: 48,
  KEY_1: 49,
  KEY_2: 50,
  KEY_3: 51,
  KEY_4: 52,
  KEY_5: 53,
  KEY_6: 54,
  KEY_7: 55,
  KEY_8: 56,
  KEY_9: 57,
  EPG: 119,
  MYFILES: 120,
  MOD: 121,
  LANG: 87,
  MYACC:113,
  APPSTORE:112,
  KEY_RED: 83, // S
  KEY_GREEN: 68, // D
  KEY_YELLOW: 70, // F
  KEY_BLUE: 71, // G
  KEY_FAV:72,
  MUTE: 173,
}

const sdZapper = {
  UP: 38,
  DOWN: 40,
  LEFT: 37,
  RIGHT: 39,
  OK: 13,
  BACK: 8,
  INFO: 73,
  HOME: 36,
  PROGRAM_PLUS: 33,
  PROGRAM_MINUS: 34,
  VOLUME_PLUS: 175,
  VOLUME_MINUS: 174,
  POWER: 115,
  KEY_0: 48,
  KEY_1: 49,
  KEY_2: 50,
  KEY_3: 51,
  KEY_4: 52,
  KEY_5: 53,
  KEY_6: 54,
  KEY_7: 55,
  KEY_8: 56,
  KEY_9: 57,
  EPG: 119,
  MOD: 121,
  LANG: 87,
  MYACC:113,
  APPSTORE:112,
  KEY_RED: 83,
  KEY_GREEN: 68,
  KEY_YELLOW: 70,
  KEY_BLUE: 71,
  KEY_FAV:72,
  MUTE: 173,
  EXIT : 116,
  PREVIOUS_CHANNEL : 117,
  HELP : 47,
  TOOLS : 114,
  MAIL : 122,
  REMINDER : 118,
}

if (config.sdzapper) {
  rucMapping = Object.assign({},sdZapper)
} else {
  rucMapping = Object.assign({},liberty)
}

const keys = rucMapping

keys.ANY = Object.keys(keys).map((key) => {
  return keys[key]
})

keys.ANY_NUMERIC = [
  keys.KEY_0,
  keys.KEY_1,
  keys.KEY_2,
  keys.KEY_3,
  keys.KEY_4,
  keys.KEY_5,
  keys.KEY_6,
  keys.KEY_7,
  keys.KEY_8,
  keys.KEY_9,
]

export {keys as defaultRCU}
