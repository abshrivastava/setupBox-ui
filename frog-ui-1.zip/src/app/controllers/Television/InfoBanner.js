//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"
import PlayerManager from "services/managers/PlayerManager"
import UsbManger from "services/managers/StorageManager"
import ChannelManager from "services/managers/ChannelManager"

const TIMEOUT = 5000   // Make Infobar timeout 5 second on inactivity

export default class InfoBannerController extends Controller {
  constructor() {
    super()
    this.timer = null
    this.view = $("channelList")
    this.playerControlView = $("playerControl")
  }

  show(recording, closeOnTimeshift) {
    this.clearTimer()
    this.timer = window.setTimeout(() => {
      bus.emit("tv:infoBannerTimeout", closeOnTimeshift)
    }, TIMEOUT)

    if (recording) {
      this.playerControlView.recording()
    }
    if (!this.channelListOpen) {
      // bus.emit("adbanner:open", "tv")
      bus.emit("clock:open", "tv")
      if (UsbManger.showBannerIcon !== null && UsbManger.showBannerIcon !== false) {
        this.showUsbBanner(UsbManger.showBannerIcon)
      }
    }
    ChannelManager.displayMode = "infoBanner"
    return  this.view.openInfoBanner()
  }

  showDolbyLogo() {
    PlayerManager.getAudioTracks()
      .then((data) => {
        if (!this.timer) return false


        let isDolbyLogoEnableForCurrent=false

        for (let iCounter=0;iCounter < data.length ; iCounter++) {
          if (data[iCounter]._attributes["AudioCodec"] === "ac3" && data[iCounter].default === true) {
            isDolbyLogoEnableForCurrent = true
            break
          }
        }
        if (isDolbyLogoEnableForCurrent) {
          this.view.updateDolbyInfo(true)
        } else {
          this.view.hideDolbyInfo()
        }
      }).catch((err) => {
        console.error(err)
        return false
      })
  }

  getTrack() {
    PlayerManager.getAudioTracks()
  }

  @on("InfoBanner:showUsbBanner")
  showUsbBanner(data) {
    if (UsbManger.showBannerIcon) {
      this.view.openUSBlist()
      this.view.updateUsb("USB: My Usb " + data)
    }
  }

  @on("InfoBanner:showUsbAndUnsetBanner")
  onshowUsbAndUnsetBanner(value) {
    this.channelListOpen = value
  }


  @on("InfoBanner:close")
  hide() {
    this.clearTimer()
    this.playerControlView.disableImmediately()
    return this.view.closeInfoBanner()
  }

  close() {
    return this.hide()
  }

  clearTimer() {
    if (this.timer) {
      window.clearTimeout(this.timer)
      this.timer = null
    }
    return Promise.resolve()
  }
}
