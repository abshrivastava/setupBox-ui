//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {createTicker} from "utils"
import {on} from "services/events"
import bus from "services/bus"
import {$} from "widgets/Component"

const REFRESH_INTERVAL = 15000 // milliseconds

export default class ClockController extends Controller {
  constructor() {
    super()
    this.clockUpdater = createTicker(REFRESH_INTERVAL)
    this.view = $("clock")
  }

  @on("clock:open")
  open(context,isChannelList = false,isAdBannerOpen = false) {
    /* Hide Operator Logo on Universe - home, epg, pvr */
    bus.emit("adBanner:clockOpen", true)
    this.view.unfold(context)
    if (!isAdBannerOpen) bus.emit("adbanner:open", context,isChannelList)
    this.clockUpdater.start(() => this.update())
  }

  @on("clock:close")
  close() {
    bus.emit("adBanner:clockOpen", false)
    this.clockUpdater.stop()
    bus.emit("adbanner:close")
    return this.view.fold()
  }

  update() {
    this.view.update(new Date())
  }
}
