//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import {on} from "services/events"
import {reverseObject} from "utils"
import config from "utils/config"

const KEY_NAMES = new Map(reverseObject(config.KEYMAP))

export default class DevToolBarController extends Controller {
  constructor() {
    super()
    this.view = $("devToolBar")
  }

  @on("bus:universe")
  onBusUniverse(newUniverse) {
    this.view.setProp("universe", newUniverse)
  }

  @on("window:keyPressed")
  onKeyPressed(keyCode, keyIdentifier) {
    const keyName = KEY_NAMES.get(keyCode) || ""
    this.view.setProp("lastKey", `${keyIdentifier} (${keyName || keyCode})`)
  }
}
