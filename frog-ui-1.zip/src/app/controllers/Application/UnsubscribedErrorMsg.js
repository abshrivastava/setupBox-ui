//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import config from "utils/config"
import bus from "services/bus"
import NumZap from "app/controllers/Application/NumZap"
import {on, rcu} from "services/events"
import {_} from "utils/locale"
import ChannelManager from "services/managers/ChannelManager"
import CasManager from "services/managers/CasManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import PVRManager from "services/managers/PVRManager"

export default class UnsubscribedErrorMsgController extends Controller {
  static delegates = [
    NumZap,
  ]
  constructor(props) {
    super(props)
    this._reset()
    this.lastUniverse = null
    this.view = $("UnsubscribedErrorMsg")
    this.PopDisabled=false
    this.forceFreeze=false
    this.okMessage = _("Press OK to exit")
  }

  _initNumZap(lcn) {
    console.log("lcn", lcn)
    this.NumZap.setTriggerFunction((lcn) => {
      return ChannelManager.getChannelFromLcn(lcn)
    })
  }

  get selectedIdx() {
    return this._selectedIdx
  }

  set selectedIdx(value) {
    if (this.isConfirmUnsubscribedErrorMsg) {
      this._selectedIdx = value
      this.view.selectButton(this._selectedIdx)
    }
  }

  _setButtons(buttons = []) {
    this.buttons = buttons
    this.view.setButtons(buttons)
    this._selectedIdx = Math.min(this.buttons.length - 1, 1)
    buttons.forEach((button, idx) => {
      if (button.default) {
        this.selectedIdx = idx
      }
    })
  }

  _setDefaultButton() {
    if (this.buttons.length) {
      this.buttons.forEach((button, idx) => {
        if (button.default) {
          this.selectedIdx = idx
        }
      })
    }
  }

  _reset() {
    this.buttons = []
    this.autoHideTicker = null
    this.isConfirmUnsubscribedErrorMsg = false
    this.closeCallback = null
    this.legacyUniverse = null
    this.PopDisabled=false
    if (this.startCounter) {
      clearInterval(this.startCounter)
    }
    if (this.forceFreeze) {
      return
    }
  }

  _setComeDownInterval(timeout) {

    if (this.startCounter) {
      clearInterval(this.startCounter)
    }

    const setCounter = timeout/1000
    let setIncremental = 0

    this.startCounter = window.setInterval(() => {
      this.view.startCountDown(setCounter-setIncremental)
      if (setCounter === setIncremental + 1) {
        clearInterval(this.startCounter)
        this.close()
      }
      this.valid = true
      setIncremental++
    }, 1000)
  }

  _setLastUniverse(value) {
    if (value !== "UnsubscribedErrorMsg" || value !== null || value !== "") {
      this.lastUniverse = value
    }
  }

  /* ************************************************************************ */

  /* ********* Open/Close functions ********* */

  open() {
    this._setLastUniverse(bus.universe)
    this.legacyUniverse = bus.universe
    this.view.onOpen()
    CasManager.unsubscribedPopupOpen = true
    const isFtaActive = FtaBlockManager.isNavigationRestricted()
    if (isFtaActive) bus.universe = "blackuniverse"
    if (this.autoHideTicker) {
      this.autoHideTicker.start(this.close.bind(this), true)
    }
    if (bus.universe === "blackuniverse") {
      this.view.onBtnShow()
    } else {
      this.view.onBtnClose()
    }

    if (CasManager.BackgroundShow) {
      this.view.onBackgroundShow()
    }
  }

  @on("blackuniverse:hide")
  hideFtaMsg() {
    this.close()
  }

  @on("UnsubscribedErrorMsg:close")
  close() {
    if (config.SD_ZAPPER && ChannelManager.current && ChannelManager.current.serviceType
      && ChannelManager.current.serviceType === "HD") return

    this.view.onClose()
    CasManager.unsubscribedPopupOpen = false
    PVRManager.disableOnUnsubscribed = false
    if (this.autoHideTicker) {
      this.autoHideTicker.stop()
    }
    if (this.closeCallback) {
      this.closeCallback()
    }
    if (bus.universe === "blackuniverse") {
      this.view.onBtnClose()
    }
    if (!CasManager.BackgroundShow) {
      this.view.onBackgroundClose()
    }

    this._reset()
  }

  /* ************************************************************************ */

  /* ********* Arrow Keys ********* */
  @rcu("UnsubscribedErrorMsg:left:press")
  onLeft() {
    if (this.selectedIdx > 0) {
      this.selectedIdx--
    }
  }

  @rcu("UnsubscribedErrorMsg:right:press")
  onRight() {
    if (this.selectedIdx < this.buttons.length - 1) {
      this.selectedIdx++
    }
  }

  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back) ********* */
  @rcu("UnsubscribedErrorMsg:back:press")
  onBack() {
    this.close()
    bus.emit("tv:tunePrevious")
  }


  @on("tv:backToLive")
  @rcu("UnsubscribedErrorMsg:ok:press")
  onOk() {
    if (this.isConfirmUnsubscribedErrorMsg) {
      this.closeCallback = null
      this.buttons[this.selectedIdx].action()
      this.close()
    } else if (this.closeOnOk) {
      this.closeCallback = null
      this.close()
    }
  }

/* ********* Special Buttons (Number zap) ********* */


  @rcu("UnsubscribedErrorMsg:numeric:press")
  onInput(key, kbd) {
    const triggerNew = true
    const triggerEach = true
    this._initNumZap(kbd.key)
    this.NumZap.open(kbd, triggerNew, triggerEach)
  }

  /* ************************************************************************ */
  /* ********* Buttons (Home Press) ********* */

  @rcu("UnsubscribedErrorMsg:home:press")
  _OnHomePress() {
    this.close()
    bus.closeCurrentUniverse()
    bus.openUniverse("home")
  }

  /* ********* P+/P- & Arrow Keys ********* */

  @rcu("UnsubscribedErrorMsg:program_plus:press")
  nextChannel() {
    bus.emit("tv:nextChannel")
    this.close()
  }

  @rcu("UnsubscribedErrorMsg:program_minus:press")
  previousChannel() {
    bus.emit("tv:previousChannel")
    this.close()
  }

  @on("blackuniverse:standby")
  onClose() {
    const isInFtaMode = FtaBlockManager.isNavigationRestricted()
    const isInFtaAdvanceScreen = FtaBlockManager.onAdvancedScan
    if (isInFtaMode && !isInFtaAdvanceScreen) {
      const page = FtaBlockManager.ftaPopupStatus.page
      switch (page) {
      case "error":
        bus.emit("blackuniverse:hide")
        break
      case "stb":
      case "tp":
        bus.emit("STBInfoSheet:close")
        bus.emit("ftaBlockManager:close")
        break
      default:
        console.log("default")
      }
    }

    if (isInFtaAdvanceScreen) {
      bus.emit("settings:close")
      FtaBlockManager.onAdvancedScan = false
    }
  }


  /* ********* Pop up build (Alert, Confirm) ********* */
  @on("UnsubscribedErrorMsg:alert")
  _buildUnsubscribedErrorMsg(title, message, message2, message3, message4, {timeout, buttons, closeCallback, closeOnOk},
     disableUnsubscribedErrorMsgMessage, forceFreeze) {

    this.view.onClose()
    if (disableUnsubscribedErrorMsgMessage) {
      this.PopDisabled=true
    }
    this.view.updateTitle(title)
    this.view.updateMessage(message)
    message2 && this.view.updateMessage2(message2)
    message3 && this.view.updateMessage3(message3)
    message4 && this.view.updateMessage4(message4)
    this.isConfirmUnsubscribedErrorMsg = (buttons)
    this._setButtons(buttons)
    this._setDefaultButton()
    this.isConfirmPopUp = (buttons && buttons.length > 0)
    if (closeOnOk) {
      if (!message2) {
        this.view.alignMessage()
      }
      this.view.updateMessage3(this.okMessage)
    }
    this.closeCallback = closeCallback
    this.closeOnOk = closeOnOk
    if (timeout) {
      this._setComeDownInterval(timeout)
    }
    PVRManager.disableOnUnsubscribed = true
    this.open()
    if (forceFreeze === true) {
      this.view.displayTop()
      return
    }
  }
}
