//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"

import bus from "services/bus"
import {on, rcu} from "services/events"
import {_} from "utils/locale"
import ScanManager from "services/managers/ScanManager"
import standby from "services/managers/PowerManager"

/*
  =============
  Some snippets
  =============

  A simple alert pop up without actions
  -------------------------------------
 onAlert() {
  const title = "Title"
  const message = "A simple Message Pop Up, press back to exit"
  bus.emit("popup:alert", title, message, {})
  }

 An alert pop up with timeout
 ----------------------------
 onTimeOutAlert() {
  const title = "Title"
  const message = "A simple Message Pop Up, press back to exit, " +
    "or wait 5 seconds for auto hide"
  const timeout = 5000 // ms
  bus.emit("popup:alert", title, message, {timeout})
 }

 A confirm pop up with a callback triggered when pressing OK on YES button
 -------------------------------------------------------------------------
 openEpg() {
   const title = "EPG"
   const message = "Are you sure you want to enter the " +
    "Electronic Program Guide?"
   const callback = () => {
     bus.closeCurrentUniverse()
     bus.openUniverse("epg")
   }
   bus.emit("popup:confirm", title, message, {closeCallback: callback})
 }
 */
export default class PopUpController extends Controller {
  constructor(props) {
    super(props)
    this._reset()
    this.lastUniverse = null
    this.view = $("popUp")
    this.PopDisabled=false
    this.forceFreeze=false
    this.okMessage = _("Press OK to exit")
    this.waitMessage = _("Please Wait ...")
    this.okContinueMessage_FI = _("Press OK for details")
    this.okContinueMessage = _("Press BACK to save & exit or OK for details")
    this.displayPicto = false
    this.popUpExit = false
  }

  get selectedIdx() {
    return this._selectedIdx
  }

  set selectedIdx(value) {
    if (this.isConfirmPopUp) {
      this._selectedIdx = value
      this.view.selectButton(this._selectedIdx)
    }
  }

  _setButtons(buttons = []) {
    this.buttons = buttons
    this.view.setButtons(buttons)
    this._selectedIdx = Math.min(this.buttons.length - 1, 1)
    buttons.forEach((button, idx) => {
      if (button.default) {
        this.selectedIdx = idx
      }
    })
  }

  _setDefaultButton() {
    if (this.buttons.length) {
      this.buttons.forEach((button, idx) => {
        if (button.default) {
          this.selectedIdx = idx
        }
      })
    }
  }

  _reset() {
    this.displayPicto = false
    this.buttons = []
    this.autoHideTicker = null
    this.isConfirmPopUp = false
    this.closeCallback = null
    this.legacyUniverse = null
    this.PopDisabled=false
    if (this.startCounter) {
      clearInterval(this.startCounter)
    }
    this.onOpenCall = null
    if (this.forceFreeze) {
      return
    }
  }

  _setComeDownInterval(timeout) {

    if (this.startCounter) {
      clearInterval(this.startCounter)
    }

    const setCounter = timeout/1000
    let setIncremental = 0

    this.startCounter = window.setInterval(() => {
      this.view.updateCountDown(setCounter-setIncremental)
      if (setCounter === setIncremental + 1) {
        clearInterval(this.startCounter)
        this.close()
      }
      this.valid = true
      setIncremental++
    }, 1000)
  }

  _setLastUniverse(value) {
    if (value !== "popup" || value !== null || value !== "") {
      this.lastUniverse = value
    }
  }

  @on("popup:setLegacy")
  _setLegacyUniverse(value) {
    this.legacyUniverse = value
  }

  /* ************************************************************************ */

  /* ********* Open/Close functions ********* */
  open() {
    if (bus.universe === "popup") {
      return
    }
    this._setLastUniverse(bus.universe)
    this.legacyUniverse = bus.universe
    bus.universe = "popup"
    if (this.autoHideTicker) {
      this.autoHideTicker.start(this.close.bind(this), true)
    }
    this.view.onOpen()
    if (this.onOpenCall) {
      this.onOpenCall()
    }
    this.popUpExit = false
  }

  @on("popup:close")
  close(setUniverse) {
    this.displayPicto = false
    bus.universe = this.legacyUniverse
    if (bus.universe === null || bus.universe === "") {
      bus.universe = this.lastUniverse
    }
    if (setUniverse) {
      bus.universe = setUniverse
    }
    if (this.autoHideTicker) {
      this.autoHideTicker.stop()
    }
    if (this.closeCallback) {
      this.closeCallback()
    }
    this.view.onClose()
    this._reset()
  }

  @on("popup:updateProgress")
  updateProgress(data) {
    this.view.updateProgressBar(data)
  }
  /* ************************************************************************ */

  /* ********* Arrow Keys ********* */
  // !isStandbyState :: Igonoring RCU keys handling in standby
  @rcu("popup:left:press")
  onLeft() {
    if (this.selectedIdx > 0 && !standby.isStandbyState) {
      this.selectedIdx--
    }
  }

  @rcu("popup:right:press")
  onRight() {
    if (this.selectedIdx < this.buttons.length - 1 && !standby.isStandbyState) {
      this.selectedIdx++
    }
  }

  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back) ********* */
  // !isStandbyState :: Igonoring RCU keys handling in standby
  @rcu("popup:back:press")
  onBack() {
    if (this.PopDisabled && !standby.isStandbyState) {
      return
    }
    this.close()
  }

  @on("popup:exitTrue")
  onExitTrue() {
    this.popUpExit= true
  }

  @rcu("popup:exit:press")
  onExit() {

    if (this.popUpExit) {
      this.displayPicto = false
      bus.universe = this.legacyUniverse

      if (this.autoHideTicker) {
        this.autoHideTicker.stop()
      }
      if (this.closeCallback) {
        this.closeCallback()
      }
      this.view.onClose()
      this._reset()
      bus.emit(`${bus.universe}:close`)
      bus.closeCurrentUniverse()
      bus.universe = "tv"
      if (bus.universe !== "tv") {
        bus.openUniverse("tv")
      }
      if (this.PopDisabled && !standby.isStandbyState) {
        return
      }
    }
  }


  @rcu("popup:ok:press")
  onOk() {
    if (!standby.isStandbyState) {
      if (ScanManager.running) {
        return
      }
      if (this.isConfirmPopUp) {
        this.closeCallback = null
        this.buttons[this.selectedIdx].action()
        this.close()
      } else if (this.closeOnOk) {
        this.closeCallback = null
        this.close()
      } else if (!this.displayPicto && this.openTPList) {
        this.close()
        bus.emit("transponderList:show", true)
      }
    }
  }

  /* ************************************************************************ */

  /* ********* Pop up build (Alert, Confirm) ********* */
  @on("popup:alert")
  @on("popup:confirm")
  _buildPopup(title, message, {timeout, buttons, closeCallback, closeOnOk,openTPList,hideScanBar,
    displayPicto,onOpenCall}, message2, message3,disablePopupMessage,forceFreeze, showProgress) {
    this.view.onClose()
    if (this.legacyUniverse !== null) {
      this.close()
    }
    if (disablePopupMessage) {
      this.PopDisabled=true
    }
    this.view.updateTitle(title || "")
    if (title === "Instant Message" || title === "इंस्टेंट मैसेज " ||
    title === "इंस्टेंट मैसेज" || title === "त्वरित संदेश" || title === "తక్షణ సందేశం") {
      if (message.match(/\d/g) !== null) {
        const code = message.match(/\d/g).join("")
        const instant_message = message.replace(/[0-9]/g, "")
        this.view.updateInstantMessage(instant_message, code)
      } else {
        this.view.updateMessage(message || "")
      }
    } else {
      this.view.updateMessage(message || "")
    }

    message2 && this.view.updateMessage2(message2 || "")
    message3 && this.view.updateMessage3(message3 || "")
    this.isConfirmPopUp = (buttons)
    this._setButtons(buttons)
    this._setDefaultButton()
    this.isConfirmPopUp = (buttons && buttons.length > 0)
    if (closeOnOk) {
      if (!message2) {
        this.view.alignMessage()
      }
      this.view.updateMessage3(this.okMessage)
    }

    if (hideScanBar === true) {
      this.view.updatePopForEasyScan(hideScanBar)
    } else {
      hideScanBar = false
      this.view.updatePopForEasyScan(hideScanBar)
    }
    this.hideScanBar = hideScanBar
    this.closeCallback = closeCallback
    this.closeOnOk = closeOnOk
    this.openTPList = openTPList
    this.displayPicto = displayPicto
    if (timeout) {
      // this.view.setCountDown(timeout / 1000)
      // this.autoHideTicker = createTicker(timeout)
      this._setComeDownInterval(timeout)
    }

    // Updating Please Wait message and disable ok or back on the popup
    if (displayPicto) {
      this.view.updateMessage3(this.waitMessage)
      this.PopDisabled=true
    }
    if (onOpenCall) {
      this.onOpenCall = onOpenCall
    }
    if (showProgress === true) {
      this.view.showProgressBar()
    }
    this.open()
    if (forceFreeze === true) {
      this.view.displayTop()
      return
    }
  }
  @on("popup:hidePicto")
  hidePicto() {
    if (this.displayPicto) {
      this.displayPicto =false
      this.PopDisabled=false
      if (ScanManager.isFirstInstall) {
        this.view.updateMessage3(this.okContinueMessage_FI)
      } else {
        this.view.updateMessage3(this.okContinueMessage)
      }
    }
  }

}
