//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on, rcu} from "services/events"

import {
  ScanManager,
  PlayerManager,
  PowerManager,
  ChannelManager,
  FtaBlockManager, StorageManager} from "services/managers"

import FIlanguage from "./FIlanguage"
import FINetwork from "./FINetwork"

const INSTALLATION = Object.freeze({
  FTA_ACTIVE:3,
})


export default class FirstInstallController extends Controller {
  static delegates = [
    FIlanguage,
    FINetwork,
  ]

  constructor() {
    super()
    this.activeDelegate = null
  }

  /* ********* Open/Close functions ********* */
  @on("FirstInstall:open")
  open() {
    bus.universe = "FirstInstall"
    bus.emit("TransponderList:back")
    bus.emit("settings:updateSettingsHeader", "", false)
    this.activeDelegate = this.FIlanguage
    this.FIlanguage.open()
  }

  @on("FirstInstall:openNetwork")
  openNetwork() {
    bus.universe = "FirstInstall"
    bus.emit("TransponderList:back")
    bus.emit("settings:closeSettingsView")
    this.activeDelegate = this.FINetwork
    this.FINetwork.open()
  }

  @on("FirstInstall:openResolution")
  openResolution(currLanguage) {
    this.activeDelegate.close()
    this.activeDelegate = this.Resolution
    this.Resolution.open(currLanguage)
  }

  @rcu("FirstInstall:ok:press")
  onOk() {
    this.activeDelegate.onOk()
  }
  @rcu("FirstInstall:up:press")
  onUp() {
    this.activeDelegate.onUp()
  }

  @rcu("FirstInstall:down:press")
  onDown() {
    this.activeDelegate.onDown()
  }

  @rcu("FirstInstall:right:press")
  onRight() {
    this.activeDelegate.onRight()
  }

  @rcu("FirstInstall:left:press")
  onLeft() {
    this.activeDelegate.onLeft()
  }

  @on("FirstInstall:backResolution")
  @rcu("FirstInstall:back:press")
  onBack() {
    if (this.activeDelegate === this.Resolution) {
      this.activeDelegate.close()
      this.activeDelegate = this.FIlanguage
      this.FIlanguage.open()
    }
  }

  @on("FirstInstall:close")
  close() {
    bus.emit("settings:updateSettingsHeader", "", false)
    bus.emit("settings:closeSettingsView")
    this.closing = true
    this.activeDelegate = null
    for (const delegate of this.delegates) {
      bus.emit(`${delegate.displayName}:close`)
    }
    FtaBlockManager.callFromBoot = true
    FtaBlockManager.isFtaBlockMode()
    .then((response) => {
      ScanManager.isFirstInstall = false
      if (INSTALLATION.FTA_ACTIVE === response) {
        PowerManager.getDynamicDefaultLC().then((defaultChannel) => {
          return ChannelManager.getChannelZapInformation(defaultChannel)
        })
        .then((response) => {
          const channel = response.resource.real || response.resource.fallback
          ChannelManager.setCurrent(channel)
          return channel
        })
        .then((channel) => {
          return PlayerManager.play(channel)
        })
        .then(() => {
          bus.openUniverse("home")
        }).then(() => {
          if (StorageManager.storageled === 0) {
            bus.emit("popup:setLegacy", "home")
            bus.universe = "popup"
          }
        }).catch(() => {
          bus.openUniverse("home")
        })
      }
    })
    .catch(() => {
      ScanManager.isFirstInstall = false
    })
  }

}
