//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {$} from "widgets/Component"
import bus from "services/bus"
import {on, rcu} from "services/events"
import {_} from "utils/locale"

import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import VodManager from "services/managers/VodManager"
import * as popUpMsg from "app/utils/PopUpMsg"

import Playback from "../Playback"
import VodMenuController from "./VodMenuController"
import VoucherPopUp from "./VoucherPopUp"

const VOUCHER_DIGITS_COUNT = 16

export default class VodController extends VodMenuController {

  static delegates = [
    Playback,
    VoucherPopUp,
  ]

  get isLoading() {
    return this._isLoading
  }

  set isLoading(value) {
    this._isLoading = value
    if (!this._isLoading) {
      this.loadingView.hide()
    }
  }

  constructor() {
    super()
    this.loadingView = $("vodLoding")
    this.view = $("vodMenu")
    this.activeDelegate = null
  }

  /* ************************************************************************ */

  /* ********* Open/Close functions ********* */
  @on("vod:open")
  open() {
    if (!this.isLoading) {
      this.isLoading = true
      this.loadingView.show(_("[vod]loadingTitle"))
      PlayerManager.stop()
      this.initVod()
    }
  }

  initVod() {
    return VodManager.login()
      .then(() => {
        if (!this.isLoading) {
          return Promise.reject(_("Vod initialization aborted."))
        }
        return VodManager.initializeSVod()
      })
      .catch((err) => {
        const errorMsg = err || _("Error when trying to connect to Alpha Networks backend.")
        return Promise.reject(errorMsg)
      })
      .then(() => {
        if (!this.isLoading) {
          return Promise.reject(_("Vod catalog loading aborted by user."))
        }
        return VodManager.loadCatalogue()
      })
      .then(() => {
        if (!this.isLoading) {
          return Promise.reject(_("Vod catalog loading aborted by user."))
        }
        return this.buildCategories()
      })
      .then(() => {
        if (!this.isLoading) {
          return Promise.reject(_("Vod catalog loading aborted by user."))
        }
        return this.show()
      }).catch((err) => {
        popUpMsg.vodLoadErrorPopUp(err, () => this.onQuit())
      })
  }

  show() {
    super.open()
    this.nextLevel()
    this.isLoading = false
  }

  @on("vod:close")
  close() {
    if (this.isLoading) {
      this.isLoading = false
    }
    super.close()
    return this.clearDelegates().then(() => {
      if (ChannelManager.current) {
        return PlayerManager.play(ChannelManager.current, "channel")
      }
      return Promise.resolve()
    })
  }

  @on("vod:quit")
  onQuit() {
    this.close()
    bus.openUniverse("home")
  }

  clearDelegates() {
    this.activeDelegate = null
    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    return Promise.all(promises)
  }

  /* ************************************************************************ */

  /* ********* Detail view build and actions functions ********* */
  buildCategories() {
    this.addCategories()
    this.addSubscribedPacks()
  }

  addCategories() {
    VodManager.getCategories().forEach((category) => {
      this.addNewCategory(category, VodManager.getAssetsFromCategory(category))
    })
  }

  addSubscribedPacks() {
    VodManager.getSubscribedPackages().forEach((pack) => {
      this.addNewCategory(pack, VodManager.getAssetsFromPack(pack))
    })
  }

  addNewCategory(category, assets) {
    category.items = assets
    this.addFocusMethodOnAssets(category.items)
    super.addNewEntryInMenu(category)
  }

  addFocusMethodOnAssets(assets) {
    assets.forEach((asset) => {
      asset.focus = (timeout) => this.addAssetActions(asset, timeout)
    })
  }

  addAssetActions(asset, timeout) {
    this.addCancelAction(asset)
    this.addBuyPackAction(asset)
    this.addRentOrPlayAction(asset)
    this.currentAsset = asset
    window.setTimeout(() => {
      if (this.currentAsset === asset) {
        this.view.update(asset)
      }
    }, timeout + 50)
  }

  updateAssetActions(asset) {
    this.addAssetActions(asset)
    super.updateTopMenuItems(asset.items)
  }

  addRentOrPlayAction(asset) {
    (asset.isRented() || asset.hasActivePack()) ?
      this.addPlayAction(asset) : this.addRentAction(asset)
  }

  addCancelAction(asset) {
    asset.items = [{
      label: _("Cancel"),
      action: () => this.prevLevel(),
    }]
  }

  addBuyPackAction(asset) {
    if (asset.hasPackToSubscribe()) {
      asset.items.unshift({
        label: _("[vod]buyPack"),
        action: () => this.showBuyPackPopUp(asset),
      })
    }
  }

  addRentAction(asset) {
    asset.items.unshift({
      label: _("[vod]Rent"),
      action: () => this.showRentAssetPopUp(asset),
    })
  }

  addPlayAction(asset) {
    asset.items.unshift({
      label: _("[vod]Play"),
      action: () => this.tryToPlayAsset(asset),
    })
  }

  /* ************************************************************************ */

  /* ********* Playback functions ********* */
  /*
    You must call the buy asset method, even if the asset is available from a
    package. In this case, just call the buy asset method with an empty price
  */
  tryToPlayAsset(asset) {
    const promise = (asset.isPlayable()) ? Promise.resolve() : VodManager.rentAsset(asset)
    promise.then(() => this.playAsset(asset))
  }

  playAsset(asset) {
    this.onVideoLoading()
    VodManager.playAsset(asset)
      .then(() => this.onPlaySuccess(asset))
      .catch(() => this.onPlayError())
  }

  onVideoLoading() {
    this.activeDelegate = this.Playback
    this.isLoading = true
    this.loadingView.show(_("[vod]VideoLoading"))
  }

  onPlaySuccess(asset) {
    PlayerManager.play(asset.getFormattedUrl(), "media")
      .then(() => {
        super.hideView()
        this.isLoading = false
        this.Playback.open(asset)
      })
      .catch(() => {
        this.isLoading = false
        this.activeDelegate = null
        this.onPlayError()
      })
  }

  onPlayError() {
    this.isLoading = false
    popUpMsg.vodPlayErrorPopUp()
  }

  stopAssetPlayback() {
    this.Playback.stop()
      .then(() => {
        this.showView()
        this.activeDelegate = null
      })
  }

  /* ************************************************************************ */

  /* ********* T-VOD and S-VOD rental ********* */
  rentAsset(asset) {
    VodManager.rentAsset(asset, null)
      .then(() => this.onRentAssetSuccess(asset))
      .catch((err) => this.onVoucherError(err))
  }

  onRentAssetSuccess(asset) {
    this.isRenting = false
    this.updateAssetActions(asset)
    this.closeVoucherPopUp()
  }

  buyPack(asset, voucherCode) {
    VodManager.buyPack(asset.option, voucherCode)
      .then(() => this.onBuyPackSuccess(asset))
      .catch((err) => this.onVoucherError(err))
  }

  onBuyPackSuccess(asset) {
    const pack = asset.pack
    this.updateAssetActions(asset)
    this.addNewCategory(pack, VodManager.getAssetsFromPack(pack))
    super.addItemToRoot(pack)
    this.isRenting = false
    this.closeVoucherPopUp()
  }

  /* ************************************************************************ */

  /* ********* Voucher functions ********* */
  showRentAssetPopUp(asset) {
    const title = _("[vod]AssetVoucherCodeTitle")
    const message = _("[vod]AssetVoucherCodeMessage")
    const okAction = () => this.validateVoucher(asset, (asset) => {
      if (!this.isRenting) {
        this.isRenting = true
        this.rentAsset(asset)
      }
    })
    this.showVoucherPopUp(title, message, okAction)
  }

  showBuyPackPopUp(asset) {
    const title = _("[vod]PackVoucherCodeTitle")
    const message = _("[vod]PackVoucherCodeMessage")
    const okAction = () => this.validateVoucher(asset, (asset, voucher) => {
      if (!this.isRenting) {
        this.isRenting = true
        this.buyPack(asset, voucher)
      }
    })
    this.showVoucherPopUp(title, message, okAction)
  }

  showVoucherPopUp(title, message, okAction) {
    this.activeDelegate = this.VoucherPopUp
    this.VoucherPopUp.open(title, message, [{
      label: _("Cancel"),
      action: () => this.closeVoucherPopUp(),
    },{
      label: _("OK"),
      action: () => okAction(),
    }], VOUCHER_DIGITS_COUNT)
  }

  validateVoucher(asset, callback) {
    const voucherCode = this.VoucherPopUp.getVoucherCode()
    if (this.isVoucherValid(voucherCode)) {
      callback(asset, voucherCode)
    } else {
      let message = _("[vod]VoucherDigitError")
      message = message.replace("{digitCount}", VOUCHER_DIGITS_COUNT)
      this.VoucherPopUp.showVoucherError(message, true)
    }
  }

  isVoucherValid(voucher) {
    return (voucher && voucher.toString().length === VOUCHER_DIGITS_COUNT)
  }

  onVoucherError(err) {
    this.isRenting = false
    this.VoucherPopUp.showVoucherError(err, true)
  }

  closeVoucherPopUp() {
    this.VoucherPopUp.close()
    this.activeDelegate = null
  }

  /* ************************************************************************ */

  /* ********* P+/P- & Arrow Keys ********* */
  @rcu("vod:up:press")
  nextLevel() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      break
    case this.VoucherPopUp:
      this.VoucherPopUp.onUp()
      break
    default:
      super.nextLevel()
      break
    }
  }

  @rcu("vod:down:press")
  prevLevel() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      break
    case this.VoucherPopUp:
      this.VoucherPopUp.onDown()
      break
    default:
      super.prevLevel()
      break
    }
  }

  /* ************************************************************************ */

  /* ********* Others RCU events ********* */
  @rcu("vod:ok:press")
  onOk() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      break
    case this.VoucherPopUp:
      this.VoucherPopUp.onOk()
      break
    default:
      super.trigger(true)
      break
    }
  }

  @rcu("vod:back:press")
  onBack() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.stopAssetPlayback()
      break
    case this.VoucherPopUp:
      this.VoucherPopUp.onBack()
      break
    default:
      this.prevLevel()
      break
    }
  }

  @rcu("vod:right:press")
  onRight() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.VoucherPopUp:
      this.VoucherPopUp.onRight()
      break
    default:
      super.next()
      break
    }
  }

  @rcu("vod:left:press")
  onLeft() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.VoucherPopUp:
      this.VoucherPopUp.onLeft()
      break
    default:
      super.prev()
      break
    }
  }

  @rcu("vod:play:press")
  onPlay() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.resume()
      break
    default:
      break
    }
  }

  @on("vod:stopped")
  @rcu("vod:stop:press")
  onStop() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      this.stopAssetPlayback()
      break
    default:
      break
    }
  }

  @rcu("vod:pause:press")
  onPause() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.pause()
      break
    default:
      break
    }
  }

  @rcu("vod:fast_rewind:press")
  onFastRewind() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.fastRewind()
      break
    default:
      break
    }
  }

  @rcu("vod:fast_forward:press")
  onFastForward() {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.fastForward()
      break
    default:
      break
    }
  }

  @rcu("vod:numeric:press")
  onNumeric(key) {
    if (this.isLoading) {
      return
    }
    switch (this.activeDelegate) {
    case this.VoucherPopUp:
      this.VoucherPopUp.onDigitPress(key)
    default:
      break
    }
  }
}
