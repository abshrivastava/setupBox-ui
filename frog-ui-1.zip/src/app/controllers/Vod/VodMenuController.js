//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"

const CAROUSEL_TIMEOUT = 200

export default class VodMenuController extends Controller {
  constructor() {
    super()
    this.defaultItems = [{label: ""}]
    this.model = {
      orientation : "horizontal",
      scroll : true,
      withBg : false,
      animBg : false,
      handleIcons : true,
      delaySelected : 0,
      withArrow : false,
      items : [],
    }
    Object.assign(this, this.model)
    this.flush()
  }

  /* ***************************************** */

  /* ********* Utils ********* */
  get currentLevelLastIndex() {
    return this.lastIndexes[this.level]
  }

  /* ***************************************** */

  /* ********* Open / Close functions ********* */
  open() {
    this.init()
    this.showView()
  }

  close() {
    this.hideView()
    this.clearViews()
    this.flush()
  }

  flush() {
    this.level = 0
    this.levels = []
    this.lastLevel = 0
    this.lastIndexes = []
    this.selectedIndexes = []
    this.items = []
  }

  showView() {
    this.view.show()
  }

  hideView() {
    this.view.hide()
  }

  addNewEntryInMenu(item) {
    if (!this.items) this.items = []
    this.items.push(item)
  }

  init() {
    this.lastLevel = 2
    this.buildLevels()
    this.initViews()
    this.selectFirstView()
  }

  buildLevels() {
    for (let level = 0; level <= this.lastLevel; level++) {
      this.levels[level] = level
      this.lastIndexes.push(0)
      this.selectedIndexes.push(0)
    }
  }

  initViews() {
    for (const level of this.levels) {
      this.selectedIndexes[level] = 0
      this.view[this.displayName + level].onInit(this.model, this.lastLevel)
      this.view[this.displayName + level].onLoad(this.items)
    }
  }

  clearViews() {
    for (const level of this.levels) {
      this.view[this.displayName + level].clear()
    }
  }

  selectFirstView() {
    this.updateSelectedItem(this.items)
    this.updateLevels(0,0, true)
    this.view[this.displayName + this.level].onFocus(true)
  }

  updateSelectedItem(items) {
    this.item = items[this.selectedIndexes[this.level]]
  }

  updateLevels(startLevel, timeout, onLoad) {
    let currentLevelItems = this.items || this.defaultItems
    if (!Number.isInteger(timeout)) {
      timeout = (this.level === 1) ? CAROUSEL_TIMEOUT : 0
    }

    for (const level of this.levels) {
      if (level === this.level) {
        this.updateSelectedItem(currentLevelItems)
      }

      if (level > this.level) {
        this.selectedIndexes[level] = 0
        this.view[this.displayName + level].onLoad(currentLevelItems)
      }

      if (level >= this.level || onLoad) {
        this.updateView(level, startLevel, this.selectedIndexes[level], timeout)
        this.lastIndexes[level] = currentLevelItems.length - 1
      }

      if (level === 1) {
        this.items[this.selectedIndexes[0]].items[this.selectedIndexes[1]].focus(timeout)
      }

      currentLevelItems = currentLevelItems[this.selectedIndexes[level]].items || false
    }
  }

  updateView(level, prevIndex, nextIndex, timeout) {
    this.view[this.displayName + level].onStyle().then((style) => this.view.onStyle(style))
    this.view[this.displayName + level].onSelect(
      prevIndex,
      nextIndex,
      timeout,
    )
  }

  addItemToRoot(item) {
    this.view[this.displayName + 0].addItem(item, this.items.length -1)
  }

  updateTopMenuItems(items) {
    this.item = items[0]
    this.selectedIndexes[2] = 0
    this.view[this.displayName + 2].onLoad(items)
    this.updateLevels(2, 0)
  }

  /* *********************************************** */

  /* ********* Previons / Next / Up / Down ********* */
  prev() {
    const oldIndex = this.selectedIndexes[this.level]
    if (this.currentLevelLastIndex > 0 && oldIndex > 0) {
      this.selectedIndexes[this.level]--
      this.updateLevels(oldIndex)
    }
  }

  next() {
    const oldIndex = this.selectedIndexes[this.level]
    if (this.currentLevelLastIndex > 0 && oldIndex < this.currentLevelLastIndex) {
      this.selectedIndexes[this.level]++
      this.updateLevels(oldIndex)
    }
  }

  hasPrevLevel() {
    return this.level > 0
  }

  hasNextLevel() {
    return (this.level < this.lastLevel && this.lastIndexes[this.level + 1] >= 0)
  }

  prevLevel() {
    if (this.hasPrevLevel()) {
      this.level--
      this.updateCurrentLevel()
      this.dispatchPrevLevelToView()
    }
    if (this.level === 1) {
      this.view.hideItemDetail()
    }
  }

  nextLevel() {
    if (this.hasNextLevel()) {
      this.level ++
      this.updateCurrentLevel()
      this.updateLevels(this.level, 0)
      this.dispatchNextLevelToView()
    }
    if (this.level === 2) {
      this.view.showItemDetail()
    }
  }

  updateCurrentLevel() {
    let currentLevelItems = this.items
    for (const level of this.levels) {
      const currentIndex = this.selectedIndexes[level]
      if (level < this.level) {
        currentLevelItems = currentLevelItems[currentIndex].items
        this.updateSelectedItem(currentLevelItems)
      }
    }
  }

  dispatchPrevLevelToView() {
    const currentLevelView = this.view[this.displayName + this.level]
    const oldLevelView = this.view[this.displayName + (this.level + 1)]
    const nextLevelView = this.view[this.displayName + (this.level + 2)]

    oldLevelView.onBlur(false)
    currentLevelView.onFocus()

    if (nextLevelView) {
      if (this.level + 1 < this.lastLevel) {
        nextLevelView.onFold()
      } else {
        nextLevelView.onUnfold()
      }
    }
  }

  dispatchNextLevelToView() {
    this.view[this.displayName + (this.level-1)].onBlur(true)
    this.view[this.displayName + this.level].onFocus()

    const nextNext = this.level + 1
    if (this.level < this.lastLevel) {
      this.view[this.displayName + nextNext].onUnfold()
    }
  }

  trigger(keyOk = false) {
    if (!keyOk && this.item.focus) {
      return this.item.focus()
    }

    if (this.item.action) {
      return this.item.action()
    }

    return this.nextLevel()
  }
}
