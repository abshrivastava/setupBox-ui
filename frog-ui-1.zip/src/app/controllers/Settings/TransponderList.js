//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {_} from "utils/locale"
import {$} from "widgets/Component"
import {on, enableEvents} from "services/events"

import transponders from "services/managers/transponders"
import {getTransponderStatus, getcurrentTPSignalStatus} from "services/api/transponders"
import {listTune, removeAllTune} from "services/api/scan"

import {
  PlayerManager,
  ChannelManager,
  ScanManager,
  NetworkTp,
} from "services/managers"

import {ListObj} from "app/utils/widgets/lists"
import {pushState, pullState} from "utils/dom"
import {createTicker} from "utils"

import AbstractSetting from "./AbstractSetting"

const OPTION_ITEMS_D2H = [{
  name: "ST2",
  action: "",
},{
  name: _("Back"),
  action: "settings:subClose",
},{
  name: _("Exit"),
  action: "settings:close",
}]

const OPTION_ITEMS_DISH = [{
  name: "SES8 SAT",
  action: "TPList:loadTpListForSSE8",
}, {
  name: "AsiaSAT",
  action: "TPList:loadTpListForAsia",
}, {
  name: _("Back"),
  action: "settings:subClose",
},{
  name: _("Exit"),
  action: "settings:close",
}]


const OPTION_ITEMS_POPUP = [{
  name: _("Back"),
  action: "settings:subClose",
},{
  name: _("Exit"),
  action: "settings:close",
}]

const OPTION_FIRST_INSTALL = [{
  name: _("Next"),
  action: "FirstInstall:open",
}]


const TpListConst = Object.freeze({
  ZERO_INDEX: 0,
  FIRST_INDEX:1,
  FIFTH_INDEX: 5,
  PAGE_SIZE:6,
  STATUS_TIMEOUT:2000,
})

export default class TransponderList extends AbstractSetting {
  constructor() {
    super()
    this.TPListSelected = false
    this.homeTPProp =null
    this.homeTP= null
    this.activeDelegate = null
    this.scrollStart = null
    this.pageNumber=1
    this.list = 0
    this.indexForSSQ = 0
    this.focusId = 0
    this.transponderData={}
    this.TransSignal ={}
    this.TPArray= []
    this.AsiaSATData=[]
    this.TransponderListFull= []
    this.SSE8Data =[]
    this.scrollTicker = createTicker(800)
    this.view = $("transponderList")
    enableEvents(this)
  }


  open(sub) {
    this.sub = sub
    transponders.isTPListScreen = true
    this.pageNumber=1
    this.l2ID = 0
    this.gethomeTpValue()

    return super.open()
  }

  load() {
    this.view.onLoad(this.sub)
    if (ScanManager.isFirstInstall) {
      this.optionList = OPTION_FIRST_INSTALL
    } else if (this.sub.isfromPopUp) {
      this.optionList = OPTION_ITEMS_POPUP
    } else {
      if (NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H) {
        this.optionList = OPTION_ITEMS_D2H
      } else {
        this.optionList = OPTION_ITEMS_DISH
      }
    }
    this.view.loadItems(this.optionList)
    this.view.loadTPList(this.SSE8Data)
    bus.emit("settings:subForeground")
    this.view.onForeground()
    this.view.show()
  }

  getTransponderListData() {
    return new Promise((resolve) => {
      const list = Object.assign(transponders.transpondersList)
      delete list.headers
      if (!list > 0) {
        resolve(false)
      } else {
        if (this.sub.isfromPopUp === true) {
          this.TransponderListFull = list
          this.list = 2
          resolve(true)
        } else {
          for (const item in list) {
            if (list[item].name === "NSS6") {
              this.SSE8Data.push(list[item])
            } else if (list[item].name === "ASIASAT5S") {
              this.AsiaSATData.push(list[item])
            } else {
              this.SSE8Data.push(list[item])
            }
          }
          resolve(true)
        }
      }
    })
  }

  gethomeTpValue() {
    const rsp = ScanManager.homeTP
    this.homeTPProp = rsp
    PlayerManager.stop()
    this.getTransponderListData()
     .then(()=>{
       this.loadTransponders(this.list, TpListConst.ZERO_INDEX, TpListConst.PAGE_SIZE)
       this.onLeft()
       this.getSignalStrengthquality(this.list)
     })
    .catch((rsp) => {
      console.log("rsp",rsp)
    })
  }

/** loading list of transponders page by page**/
  loadTransponders(list, startIndex, lastIndex) {
    this.homeTP = null
    this.newTransArr=[]
    this.TPArray = null
    if (list === 0) {
      this.TPArray = this.SSE8Data
    } else if (list === 1) {
      this.TPArray = this.AsiaSATData
    } else if (list === 2) {
      this.TPArray =this.TransponderListFull
    }
  //  this.TPArray = (list === 0) ? this.SSE8Data : this.AsiaSATData
    this.focusId = 0
    if (this.l2ID) {
      this.focusId = this.l2ID
      this.l2ID = 0
    }
  /** to set the current home tp at the top of the Transponder List **/

    if (this.TPArray.length > 0) {
      const TPsList = this.TPArray.slice(startIndex, lastIndex)
      const length = TPsList.length
      for (let iCounter = 0; iCounter < length; iCounter++) {
        const obj = {}

        /** arranging the data in required format **/
        const splited = TPsList[iCounter].properties.split(" ")
        const temp = splited[1].substring(0,splited[1].length -3)  + "MHz" + " "
         + splited[3].substring(0,splited[1].length -3) + "Kbps"
        const polarization = splited[2]=== "V" ? "Vertical" : "Horizontal"
        let noOfServices= null
        if (this.sub.isfromPopUp && ScanManager.serviceFound ===0) {
          noOfServices = 0
        } else {
          noOfServices =  TPsList[iCounter].total_services
        }
        const finalVal= (this.list ===2) ? `${temp} ${polarization},  Number of services: ${noOfServices}`
        : `${temp} ${polarization}`
        const currentProp = (TPsList[iCounter].properties).substring(0,21)
        if (currentProp === this.homeTPProp) {
          this.finalValue = `${finalVal} (Home Transponder)`
        } else {
          this. finalValue = `${finalVal}`
        }
        obj.label = this.finalValue
        obj.id = iCounter
        this.newTransArr.push(obj)
      }
    }
    this.TPListObj = new ListObj(this.newTransArr,this.view.TPList.TPTransponderList)
    this.TPListObj.select(Number(this.focusId))
  }

/** to get the signal strength an dsignal quality of each transponder on moving up or down the list **/
  getSignalStrengthquality(list) {
    return new Promise((resolve) => {
      if (list === 0) {
        this.TPArray = this.SSE8Data
      } else if (list === 1) {
        this.TPArray = this.AsiaSATData
      } else if (list === 2) {
        this.TPArray =this.TransponderListFull
      }
      this.indexForSSQ = ((TpListConst.PAGE_SIZE * (this.pageNumber-1)) + this.TPListObj.selected)
      if (!this.TPArray.length) {
        this.TransSignal.SignalStrength = 0
        this.TransSignal.SignalQuality = 0
        this.updateTuneStatus(this.TransSignal)
        resolve(true)
      }
      if (this.TPArray.length > this.indexForSSQ) {
        const uri = this.TPArray [this.indexForSSQ].wydvb_uri
        const wydvbUri = encodeURIComponent(uri)
        getTransponderStatus(wydvbUri)
        .then((rsp)=> {
          this.TransSignal.SignalStrength = 0
          this.TransSignal.SignalQuality = 0
          if (rsp.agc || parseInt(rsp.agc)>=0) {
            this.TransSignal.SignalStrength = rsp.agc
            this.TransSignal.SignalQuality = rsp.snr
          }
          this.getTuneId()
          this.updateTuneStatus(this.TransSignal)
          resolve(true)
        })
        .catch((error)=>{
          console.log("error",error)
        })
      }
    })
  }


// getting tune id of the current Transponder
  getTuneId() {
    this.tune_id = ""
    listTune().then((data)=>{
      if (data) {
        const tune = data.tunes[0].href
        this.tune_id = tune.split("/")[3]
        this.getContinousTPSignalStatus(this.tune_id)
      }
    })
  }

//* updating the Signal strength and qulity to View *//
@on("transpondersList:tune_status_update")
  updateTuneStatus(data) {
    if (data) this.view.updateSignalDetails(data)
  }

//*  for dynamic signal status update of the currently tuned transponder *//
@on("transpondersList:startTPStatus")
  getContinousTPSignalStatus(tune_id) {
    this.stopContinousTPSignalStatus()
    this.continousStatus(tune_id,TpListConst.STATUS_TIMEOUT)
  }

  statusAfterTimeout(tune_id,timeout) {
    if (this.checkTPSattus) window.clearTimeout(this.checkTPSattus)
    this.checkTPSattus = window.setTimeout(() => this.continousStatus(tune_id, timeout), timeout)
  }

  continousStatus(tune_id,timeout) {
    getcurrentTPSignalStatus(tune_id, 1)
    .then((rsp)=>{
      if (rsp) {
        this.TransSignal.SignalStrength = rsp.agc
        this.TransSignal.SignalQuality = rsp.snr
        this.updateTuneStatus(this.TransSignal)
        if (transponders.isTPListScreen) this.statusAfterTimeout(tune_id,timeout)
      }
    })
  }

//*  stopping the dynamic signal status update of the currently tuned transponder *//
@on("transpondersList:stopContinousTPStatus")
  stopContinousTPSignalStatus() {
    if (this.checkTPSattus) window.clearTimeout(this.checkTPSattus)
  }

  onOk() {
    if (!this.TPListSelected) {
      super.select()
    }
  }

  moveUp() {
    let isPerfectLength = null
    isPerfectLength = (this.TPArray.length %TpListConst.PAGE_SIZE === 0) ? true : false

    /** when tp list in on focus or intial **/
    if (this.TPListSelected) {
      if (this.TPListObj.selected % TpListConst.PAGE_SIZE === TpListConst.ZERO_INDEX) {
        if (this.pageNumber === TpListConst.FIRST_INDEX) {
          /** for first element of first page **/
          this.pageNumber = Math.ceil(this.TPArray.length /(TpListConst.PAGE_SIZE))
          const pageupStartIndex = ((this.pageNumber - TpListConst.FIRST_INDEX) * TpListConst.PAGE_SIZE)
          const pageupLastIndex = (this.TPArray.length)
          this.loadTransponders(this.list,pageupStartIndex, pageupLastIndex)
          if (isPerfectLength) this.TPListObj.selected = TpListConst.PAGE_SIZE
          else this.TPListObj.selected = Math.ceil(this.TPArray.length %TpListConst.PAGE_SIZE)
        } else {
          /** for first element of any other page **/
          this.pageNumber--
          const pageupStartIndex = ((this.pageNumber - TpListConst.FIRST_INDEX) * TpListConst.FIFTH_INDEX)
          + (this.pageNumber - TpListConst.FIRST_INDEX)
          const pageupLastIndex = ((this.pageNumber - TpListConst.FIRST_INDEX) * TpListConst.FIFTH_INDEX) +
          TpListConst.PAGE_SIZE + (this.pageNumber - TpListConst.FIRST_INDEX)
          this.loadTransponders(this.list,pageupStartIndex, pageupLastIndex)
          this.TPListObj.selected = TpListConst.PAGE_SIZE
        }
      }
      /** for up  movement on any other element on al pages except first **/
      this.TPListObj.up()
      this.l2Page = this.pageNumber

    }
    /* When action List is on focus */
    if (!this.TPListSelected) {
      const selectedMenu = super.moveUp()
      this.view.optionList.select(this.selectedIndex, selectedMenu)
    }
  }

  moveDown() {
    /** when tp list in on focus or intial **/
    if (this.TPListSelected) {
      let isPerfectLength = null
      isPerfectLength = (this.TPArray.length %TpListConst.PAGE_SIZE === 0) ? true : false

      if (isPerfectLength) {
        if (this.TPListObj.selected % TpListConst.FIFTH_INDEX === 0 &&
          this.TPListObj.selected !== TpListConst.ZERO_INDEX) {
          if (this.pageNumber !== (this.TPArray.length /TpListConst.PAGE_SIZE)) {
            /** for last element of any page **/
            const pagedownStartIndex = (this.pageNumber * TpListConst.FIFTH_INDEX) + this.pageNumber
            const pagedownLastIndex = (this.pageNumber * TpListConst.FIFTH_INDEX) +
            TpListConst.PAGE_SIZE + this.pageNumber
            this.pageNumber++
            this.loadTransponders(this.list,pagedownStartIndex, pagedownLastIndex)
          } else  if (this.pageNumber === (this.TPArray.length /TpListConst.PAGE_SIZE)) {
            /** for last element of last page  i.e. last element of the TP Array**/
            const pagedownStartIndex = TpListConst.ZERO_INDEX
            let pagedownLastIndex = null
            if (this.TPArray.length > TpListConst.PAGE_SIZE) pagedownLastIndex = TpListConst.PAGE_SIZE
            else pagedownLastIndex = this.TPArray.length
            this.pageNumber = TpListConst.FIRST_INDEX
            this.loadTransponders(this.list, pagedownStartIndex, pagedownLastIndex)
          }
        } else {
          /** for up  movementon any other element on al pages except first **/
          this.TPListObj.down()
        }
        this.l2Page = this.pageNumber
      }
      if (!isPerfectLength) {
        if (this.TPListObj.selected % TpListConst.FIFTH_INDEX === 0 &&
          this.TPListObj.selected !== TpListConst.ZERO_INDEX) {
          /** for last element of any page **/
          const pagedownStartIndex = (this.pageNumber * TpListConst.FIFTH_INDEX) + this.pageNumber
          const pagedownLastIndex = (this.pageNumber * TpListConst.FIFTH_INDEX) +
          TpListConst.PAGE_SIZE + this.pageNumber
          this.pageNumber++
          this.loadTransponders(this.list,pagedownStartIndex, pagedownLastIndex)
        } else if ((this.pageNumber === (Math.ceil(this.TPArray.length /TpListConst.PAGE_SIZE))) &&
         this.TPListObj.selected ===((this.TPArray.length -((this.pageNumber-1)*TpListConst.PAGE_SIZE))-1)) {
          /** for last element of last page  i.e. last element of the TP Array**/
          const pagedownStartIndex = TpListConst.ZERO_INDEX
          let pagedownLastIndex = null
          if (this.TPArray.length > TpListConst.PAGE_SIZE) pagedownLastIndex = TpListConst.PAGE_SIZE
          else pagedownLastIndex = this.TPArray.length
          this.pageNumber = TpListConst.FIRST_INDEX
          this.loadTransponders(this.list, pagedownStartIndex, pagedownLastIndex)
        } else {
          /** for up  movementon any other element on al pages except first **/
          this.TPListObj.down()
        }
        this.l2Page = this.pageNumber
      }
    }
    /** when action List is on focus **/
    if (!this.TPListSelected) {
      const selectedMenu = super.moveDown()
      this.view.optionList.select(this.selectedIndex, selectedMenu)
    }
  }
  @on("transpondersList:stopTimeout")
  stopCheckTimeoutForSignalStatus() {
    this.currentTicker = null
    window.clearTimeout(this.timeoutforSS)
  }

  @on("transpondersList:startTimeout")
  startCheckTimeoutForSignalStatus() {
    if (this.timeoutforSS) this.stopCheckTimeoutForSignalStatus(this.timeoutforSS)
    this.startTicker = new Date()
    this.timeoutforSS = window.setTimeout(()=>{
      this.currentTicker = new Date()
      this.getSignalStrengthquality(this.selectedIndex)
    }, 800)
  }

  onLeft() {
    if (this.TPArray.length === 0) return
    this.TPListSelected = true
    pullState(this.view.TPList.TPTransponderList.selector.TransponderSelector, "hidden")
    this.view.optionList.onFocusLeft(this.list)
  }

  onRight() {
    this.TPListSelected = false
    pushState(this.view.TPList.TPTransponderList.selector.TransponderSelector, "hidden")
    this.view.optionList.onFocusRight(this.list)
  }

  resetTPList() {
    this.AsiaSATData=[]
    this.SSE8Data =[]
    this.TransponderListFull =[]
    this.TPArray = []
    this.newTransArr = []
    this.TPListSelected = false
    this.homeTPProp =null
    this.homeTP= null
    this.transponderData={}
    this.pageNumber=1
    this.TPArray= []
    this.list = 0
    this.indexForSSQ = 0
    this.selectedIndex = 0
  }


  @on("TPList:loadTpListForSSE8")
  loadSSE8() {
    this.list = 0
    this.indexForSSQ = 0
    this.pageNumber = TpListConst.FIRST_INDEX
    if (this.SSE8Data.length > TpListConst.PAGE_SIZE) {
      this.loadTransponders(this.list, TpListConst.ZERO_INDEX, TpListConst.PAGE_SIZE)
    } else {
      this.loadTransponders(this.list, TpListConst.ZERO_INDEX, this.SSE8Data.length)
    }
    this.view.optionList.onDefaultUpdate(1)
    this.onLeft()
    this.signalStrengthQualityUpdate()
  }

  @on("TPList:loadTpListForAsia")
  loadAsiaSAT() {
    this.list = 1
    this.indexForSSQ = 0
    this.pageNumber = TpListConst.FIRST_INDEX
    if (this.AsiaSATData.length > TpListConst.PAGE_SIZE) {
      this.loadTransponders(this.list, TpListConst.ZERO_INDEX, TpListConst.PAGE_SIZE)
    } else {
      this.loadTransponders(this.list, TpListConst.ZERO_INDEX, (this.AsiaSATData.length))
    }
    this.view.optionList.onDefaultUpdate(0)
    this.AsiaSATData.length && this.onLeft()
    this.signalStrengthQualityUpdate()
  }

  signalStrengthQualityUpdate() {
    if (this.timeoutforSS) this.stopCheckTimeoutForSignalStatus(this.timeoutforSS)
    this.startCheckTimeoutForSignalStatus()
    this.stopContinousTPSignalStatus()
  }

  @on("TransponderList:close")
  close(openHome = true) {
    if (this.checkTPSattus) window.clearTimeout(this.checkTPSattus)
    this.closeTp()
    if (bus.universe === "settings" && !ScanManager.isFirstInstall && openHome) bus.openUniverse("home")
  }

  closeTp() {
    transponders.isTPListScreen = false
    this.stopContinousTPSignalStatus()
    this.resetTPList()
    this.stopContinousTPSignalStatus()
    removeAllTune()
    this.view.onBackground()
  }

  @on("TransponderList:back")
  onBack() {
    if (this.checkTPSattus) window.clearTimeout(this.checkTPSattus)
    PlayerManager.play(ChannelManager.current)
    this.closeTp()
    return Promise.resolve()
  }
}
