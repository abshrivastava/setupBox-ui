//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {on} from "services/events"
import bus from "services/bus"
import {CircularList, List} from "widgets"
import {$} from "widgets/Component"
import {_} from "utils/locale"

import StaticListView from "widgets/list/views/StaticListView"
import NumZap from "app/controllers/Application/NumZap"
import ChannelItem from "app/components/universes/Settings/FavoriteScreen/ChannelItem"
import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import AbstractSetting from "./AbstractSetting"

const ORDER_BY_LCN = {
  name: _("Order by LCN"),
  action: "favorite:updateOrder",
  option: "ChannelLCN",
}

const ORDER_BY_CHANNEL_NAME = {
  name: _("Order by Channel Name"),
  action: "favorite:updateOrder",
  option: "ChannelName",
}

const ORDER_BY_CHANNEL_NAME_FTA = {
  name: _("Order by Channel Name - FTA Only"),
  action: "favorite:updateOrder",
  option: "ChannelNameFTA",
}

const ORDER_BY_CHANNEL_NAME_CAS = {
  name: _("Order by Channel Name - CAS Only"),
  action: "favorite:updateOrder",
  option: "ChannelNameCAS",
}

const USE_FAVORITE_AS_CHANNEL_LIST = {
  name: _("Use Favourites List As Channel List"),
  action: "favorite:toggleFavoriteListAsChannelList",
}

const SAVE = {
  name: _("Save & Exit"),
  action: "favorite:save",
}

const CANCEL = {
  name: _("Cancel & Exit"),
  action: "settings:favorites:close",
}

export default class Favorites extends AbstractSetting {
  static delegates = [
    NumZap,
  ]

  constructor() {
    super()

    this._currentOrder = ORDER_BY_LCN

    this.toggleUse = false
    this.isLoaded = false
    this.toggled = false
    this.view = $("favoriteScreen")
    this.optionList = [
      ORDER_BY_LCN,
      ORDER_BY_CHANNEL_NAME,
      // ORDER_BY_CHANNEL_NAME_FTA,
      // ORDER_BY_CHANNEL_NAME_CAS,
      USE_FAVORITE_AS_CHANNEL_LIST,
      SAVE,
      CANCEL,
    ]
    this._initNumZap()
    this.idFavButton = this.optionList.length - 3
  }

  open() {
    PlayerManager.stop()
    this.currentScreen = "channelList"
    this.view.show()
    if (ChannelManager.useFav) {
      this.setFavoriteListAsChannelList()
    }
    this.useFavState = ChannelManager.useFav
    return super.open()
  }

  @on("Favorites:close")
  close() {
    if (ChannelManager.useFav || this.toggled) {
      if (this.toggled || this.useFavState !== undefined && this.useFavState !== ChannelManager.useFav) {
        ChannelManager.toggleFavoriteListAsChannelList()
      }
      this.toggled = false
    }
    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    this.activeDelegate = null
    promises.push(this.view.clearChannelList())
    promises.push(ChannelManager.cancelFavorites())
    promises.push(this.view.hide())
    return Promise.all(promises)
  }

  onBack() {
    PlayerManager.playCurrentChannel(ChannelManager.current)
    return this.close()
  }

  load() {
    this.selectedIndex = 0
    this.initActionList()
    this.initChannelList()
  }

  initChannelList() {
    this._usedList = null
    this._createOrUpdateList(ChannelManager.getTvChannelsOrderByLcn())
    this.channelList.focus()
    this.isLoaded  = true
  }

  _createOrUpdateList(items) {
    const list = (items.length <= 6) ? List : CircularList
    if (list !== this._usedList) {
      this._usedList = list
      if (this.channelList) {
        this.view.clearChannelList()
      }
      this.channelList = new list(
        items,
        this.view.getChannelList(),
        StaticListView,
        {
          "EXTRA_VISIBLE_ITEMS_BEFORE": 0,
          "EXTRA_VISIBLE_ITEMS_AFTER": 6,
        },
        {
          "itemView" : ChannelItem,
        }
      )
    } else {
      this.channelList.update(items)
    }
  }

  initActionList() {
    this.view.loadItems(this.optionList)
    if (ChannelManager.useFav) {
      this.view.optionList.setActive(this.idFavButton)
    }
    this.view.optionList.blur()
    this.view.optionList.setCurrent()
  }

  @on("favorite:updateOrder")
  updateOrder(newOrder) {
    let items
    switch (newOrder) {
    case ORDER_BY_LCN.option:
      items = ChannelManager.getTvChannelsOrderByLcn()
      break
    case ORDER_BY_CHANNEL_NAME.option:
      items = ChannelManager.getTvChannelsOrderByName()
      break
    case ORDER_BY_CHANNEL_NAME_FTA.option:
      items = ChannelManager.getTvChannelsOrderByNameFTA()
      break
    case ORDER_BY_CHANNEL_NAME_CAS.option:
      items = ChannelManager.getTvChannelsOrderByNameCAS()
      break
    }

    this._createOrUpdateList(items)
    this.view.optionList.updateCurrent()
  }

  moveUp() {
    if (this.isLoaded) {
      if (this.currentScreen === "channelList") {
        this.channelList.prev()
      } else {
        const selectedMenu = super.moveUp()
        this.view.optionList.select(this.selectedIndex, selectedMenu)
      }
    }
  }

  moveDown() {
    if (this.isLoaded) {
      if (this.currentScreen === "channelList") {
        this.channelList.next()
      } else {
        const selectedMenu = super.moveDown()
        this.view.optionList.select(this.selectedIndex, selectedMenu)
      }
    }
  }

  onLeft() {
    if (this.isLoaded && this.currentScreen === "actionList") {
      this.view.optionList.blur()
      this.channelList.focus()
      this.currentScreen = "channelList"
    }
  }

  onRight() {
    if (this.isLoaded && this.currentScreen === "channelList") {
      this.channelList.blur()
      this.view.optionList.focus()
      this.selectedIndex = 0
      this.currentScreen = "actionList"
    }
  }

  onOk() {
    if (this.isLoaded) {
      if (this.currentScreen === "channelList") {
        this.toggleFavorite()
      } else {
        super.onOk()
      }
    }
  }

  onInput(kbd) {
    const triggerEach = false
    const triggerNew = true
    const MAX_DIGIT = 4
    const doTimeOut = true
    const from = "isFav"
    this.NumZap.open(kbd, triggerEach, triggerNew, MAX_DIGIT, doTimeOut, from)
  }

  _initNumZap() {
    this.NumZap.setTriggerFunction((lcn) => {
      const allChannels = true
      return ChannelManager.getChannelFromLcn(lcn,allChannels)
    })
  }

  @on("settings:numzap_real")
  @on("settings:numzap_fallback")
  onNumZapEach(channel) {
    if (channel && this.master.activeDelegate.displayName === "Favorites") {
      this.channelList.selectItem(channel)
    }
  }

  toggleFavorite() {
    const beforeLength = ChannelManager.futurFavoriteChannels.length

    if (this.channelList.currentItem.favorite) {
      ChannelManager.setChannelFavorite(this.channelList.currentItem.id, false)
      this.channelList.view.selectedNode.disableFavorite()
    } else {
      ChannelManager.setChannelFavorite(this.channelList.currentItem.id, true)
      this.channelList.view.selectedNode.enableFavorite()
    }

    const afterLength = ChannelManager.futurFavoriteChannels.length

    if (beforeLength === 0 || afterLength === 0) {
      this.toggleFavoriteListAsChannelList()
    }
  }

  setFavoriteListAsChannelList() {
    if (ChannelManager.futurFavoriteChannels.length === 0) {
      ChannelManager.unsetFavoriteListAsChannelList().then(() => {
        this.view.optionList.actions[this.idFavButton] && this.view.optionList.actions[this.idFavButton].desactivate()
      })
    } else {
      ChannelManager.setFavoriteListAsChannelList().then(() => {
        this.view.optionList.actions[this.idFavButton].activate()
      })
    }
  }

  @on("favorite:DeselectCheckbox")
  DeselectCheckbox() {
    ChannelManager.useFav = false
    this.view.optionList.actions[this.idFavButton].desactivate()
  }

  @on("favorite:toggleFavoriteListAsChannelList")
  toggleFavoriteListAsChannelList() {
    this.toggled = true
    if (ChannelManager.futurFavoriteChannels.length === 0) {
      ChannelManager.unsetFavoriteListAsChannelList().then(() => {
        this.view.optionList.actions[this.idFavButton].desactivate()
      })
      return
    }
    if (!this.toggleUse) {
      this.view.optionList.showSpinner()
      this.toggleUse = true
      ChannelManager.toggleFavoriteListAsChannelList(null,true).then(() => {
        this.view.optionList.hideSpinner()
        this.toggleUse = false
        if (ChannelManager.useFav) {
          this.view.optionList.actions[this.idFavButton].activate()
        } else {
          this.view.optionList.actions[this.idFavButton].desactivate()
        }
      })
    }
  }


  @on("favorite:save")
  onSave() {
    const forceUpdateChannelList = this.useFavState !== ChannelManager.useFav
    this.useFavState = ChannelManager.useFav
    this.view.optionList.showSpinner()
    this.toggled = false
    if (this.useFavState) {
      ChannelManager.saveFavorites(forceUpdateChannelList).then(() => {
        this.view.optionList.hideSpinner()
        if (ChannelManager.futurFavoriteChannels.indexOf(ChannelManager.current) === -1) {
          ChannelManager.current = ChannelManager.channels[0]
        }
        bus.emit("settings:favorites:close")
      })
    } else {
      ChannelManager.saveFavorites(forceUpdateChannelList).then(() => {
        this.view.optionList.hideSpinner()
        bus.emit("settings:favorites:close")
      })
    }

  }
}
