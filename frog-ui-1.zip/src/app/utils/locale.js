//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {locale} from "utils/locale"
import bus from "services/bus"

export function translate() {
  const classNamesToTranslate = [
    "SettingsMenu",
    "ManualRecord",
    "ScanProgress-services-found",
  ]
  classNamesToTranslate.forEach((className) => {
    locale.translateTextNodes(document.getElementsByClassName(className)[0])
  })
  bus.emit("locale:update")
}
