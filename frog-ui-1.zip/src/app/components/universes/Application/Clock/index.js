//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import TimezoneManager from "services/managers/TimezoneManager"
import {
  toDayString,
  toClockDateString,
} from "utils/date"
import {
  pullState,
  pushState,
} from "utils/dom"
import "./index.css"

export default class Clock extends Component {
  constructor(props) {
    const defaultProps = {
      time: "",
      day: "",
      date: "",
      context: "",
    }
    super(Object.assign({}, defaultProps, props))
    this.context = null
  }

  render() {
    return (
      <div className="Clock">
        <div className="Clock-background" />
        <div className="Clock-inner" key="inner">
          <span className="Clock-time" key="time" prop="time" />
          <span className="Clock-day" key="day" prop="day" />
          <span className="Clock-date" key="date" prop="date" />
          <div className="Clock-logo" key="contextLogo" />
          <span
            className="Clock-logo-context"
            key="contextLabel"
            prop="context" />
        </div>
      </div>
    )
  }

  fold() {
    return this.pullState("unfold")
  }

  unfold(context) {
    this.updateContextImg(context)
    return this.pushState("unfold")
  }

  updateContextImg(context) {
    pullState(this.contextLogo, this.context)
    this.context = context
    pushState(this.contextLogo, this.context)
  }

  update(d) {
    const time = TimezoneManager.getFormatTime(d)
    const day = toDayString(d)
    const dateTime = toClockDateString(d)
    this.setProp("time", time)
    this.setProp("day", day)
    this.setProp("date", dateTime)
  }
}
