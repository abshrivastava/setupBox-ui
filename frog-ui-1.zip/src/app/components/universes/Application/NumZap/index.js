//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {MAX_DIGITS} from "app/controllers/Application/NumZap"
import {waitReflow} from "utils/dom"
import "./index.css"

const WITH_ARROW = false
const CLOSE_VIEW_TIMEOUT = 800

export default class NumZap extends Component {
  constructor(props) {
    super(props)
    this.CLOSE_VIEW_TIMEOUT = CLOSE_VIEW_TIMEOUT
    this.closeViewTimer = null
  }

  render() {
    const baseClassName = WITH_ARROW ? "NumZap NumZap--withArrow" : "NumZap"
    return (
      <div className={`${baseClassName} NumZap--hidden`}>
        <div className="NumZap-inner" key="numzapInner">
          <kbd key="digits" />
          <span key="nextDigit" className="" prop="DigitNext" />
        </div>
        {WITH_ARROW ? <div className="NumZap-arrow" key="arrow" /> : ""}
      </div>
    )
  }

  onOpen(from) {
    return new Promise((resolve) => {
      this.pullState("hidden")
      waitReflow(this.dom)
      this.pullState("error")
      this.pullState("success")
      this.nextDigit.className = ""
      this.pushState("running")
      if (from==="isFav") {
        this.pushState("favorite")
        this.numzapInner.className="NumZapInnerFavorite"
      } else {
        this.pullState("favorite")
        this.numzapInner.className="NumZap-inner"
      }
      resolve()
    })
  }

  onClose() {
    window.clearTimeout(this.closeViewTimer)
    this.closeViewTimer = window.setTimeout(() => {
      this.pullState("running", true)
        .then(() => this.pushState("hidden"))
    }, this.CLOSE_VIEW_TIMEOUT)
  }

  onError() {
    return new Promise((resolve) => {
      this.nextDigit.className = "max"
      this.pushState("error")
      resolve()
    })
  }

  onSuccess() {
    return new Promise((resolve) => {
      this.nextDigit.className = "max"
      this.pushState("success")
      resolve()
    })
  }

  onUpdate(digits) {
    return new Promise((resolve) => {
      if (digits.length > (MAX_DIGITS - 1)) {
        this.nextDigit.className = "max"
      } else {
        this.nextDigit.className = ""
        this.setProp("DigitNext", "_")
      }
      this.digits.textContent = digits.join("")
      resolve()
    })
  }
}
