//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"

export default class Dasri extends Component {

  render() {
    return (
      <div className="Dasri Dasri--hidden">
        <div>Sorry, an issue is occurring, please wait.</div>
      </div>
    )
  }
  show() {
    return super.show()
  }
}
