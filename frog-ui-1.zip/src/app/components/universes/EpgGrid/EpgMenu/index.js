//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {HybridListComponent} from "app/utils/widgets/lists"
import ActionsList from "app/components/universes/EpgGrid/EpgMenu/ActionList"
import EpgScreen from "./EpgScreen"

import "./index.css"



export default class EpgMenu extends Component {
  constructor() {
    const props = {}
    super(props)
  }

  render() {
    return (
      <div className="EpgGenre EpgGenre--hidden">
        <img className="background" src="./app/assets/backgrounds/list-full.png" />
        <EpgScreen key="epgScreen" />
        <div className="EpgActions">
          <div className="EpgMenu-title" prop="title"/>
          <ActionsList key="optionList"/>
        </div>
      </div>
    )
  }

  hideSpinner() {
    this.epgScreen.hideSpinner()
  }

  getEpgList() {
    return this.epgScreen.EpgList
  }

  clearEpgList() {
    this.epgScreen.clearEpgList()
  }

  loadItems(itemList) {
    this.optionList.setActions(itemList)
    this.epgScreen.onloaded()
  }

  unsetOption() {
    this.optionList.blur()
  }

  hide() {
    this.fold()
    return this.pushState("hidden")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

}
