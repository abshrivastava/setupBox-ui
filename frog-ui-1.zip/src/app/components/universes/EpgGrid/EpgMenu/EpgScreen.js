//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {_} from "utils/locale"
import "./EpgScreen.css"

export default class EpgScreen extends Component {
  constructor() {
    const props = {
      title: "",
      subTitle: "",
    }
    super(props)
  }

  render() {
    return (
      <div className="EpgScreen">
        <div className="EpgMenu-title" prop="title" />
        <div className="EpgList">
          <div className="list" key="EpgList"/>
        </div>
      </div>
    )
  }

  showSpinner() {
    this.hamsterWheel.classList.remove("hamsterWheel--hidden")
  }

  hideSpinner() {
    this.hamsterWheel.classList.add("hamsterWheel--hidden")
  }

  clearEpgList() {
    if (this.EpgList.firstChild) {
      this.EpgList.removeChild(this.EpgList.firstChild)
    }
  }

  onloaded() {
    this.setProp("title", _("SELECT GENRE"))
  }

}
