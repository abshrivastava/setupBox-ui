//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"
import {formatDuration} from "utils/date"
import "./index.css"

const DEFAULT_PROPS = {
  duration: "Unkwnon duration",
}

export default class CurrentSong extends Component {
  constructor(props) {
    super(Object.assign({}, DEFAULT_PROPS, props))
    this.song = null
  }

  render() {
    return (
      <div className="CurrentSong">
        <div className="CurrentSong-inner" key="inner">
          <div className="CurrentSong-duration" prop="duration" />
        </div>
      </div>
    )
  }

  update(song) {
    this.song = song
    if (this.isValidSong()) {
      this.setProp("duration", formatDuration(parseInt(song.length)))
    } else {
      this.setProps(DEFAULT_PROPS)
    }
    this.unfold()
  }

  isValidSong() {
    return this.song && this.song.length
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }
}
