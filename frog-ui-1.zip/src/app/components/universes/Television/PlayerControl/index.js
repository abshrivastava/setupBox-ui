//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {padLeft} from "utils/string"
import {waitReflow} from "utils/dom"
import {_} from "utils/locale"
import pausePicto from "assets/pictos/trickmode-pause.png"
import playPicto from "assets/pictos/trickmode-play.png"
import recordPicto from "assets/pictos/trickmode-record.png"
import forwardPicto from "assets/pictos/trickmode-forward.png"
import rewindPicto from "assets/pictos/trickmode-rewind.png"
import "./index.css"

const MODES = {
  record: "Rec",
  play: "Play",
  pause: "Pause",
  fastForward: "Fast Forward",
  fastRewind: "Fast Rewind",
}
const PICTO = {
  record: recordPicto,
  play: playPicto,
  pause: pausePicto,
  fastForward: forwardPicto,
  fastRewind: rewindPicto,
}

export default class PlayerControl extends Component {
  constructor(props) {
    const defaultProps = {
      mode: "play",
      time: 0,
    }
    super(Object.assign({}, defaultProps, props))
    this.currentMode = "play"
  }

  render() {
    return (
      <div className="PlayerControl">
        <div className="PlayerControl-icon">
          <div className="PlayerControl-speedinfo" key="speedInfo"/>
          <img key="icon" src={playPicto} />
        </div>
        <div className="PlayerControl-details" key="state">
          <div className="PlayerControl-mode" key="mode" prop="mode" />
          <div className="PlayerControl-time" key="time" />
        </div>
      </div>
    )
  }

  fold() {
    return this.pullState("unfold")
  }

  unfold() {
    if (this.delayedDisable) {
      window.clearTimeout(this.delayedDisable)
    }
    return this.pushState("unfold")
  }

  disableWithDelay() {
    this.setMode("play")
    if (this.delayedDisable) {
      window.clearTimeout(this.delayedDisable)
    }
    this.delayedDisable = window.setTimeout(()=>this.disableImmediately(), 3000)
  }

  disableImmediately() {
    return this.fold()
  }

  setMode(mode) {
    this.currentMode = mode
    this.setSpeedInfo()
    this.mode.textContent = _(MODES[mode])
    this.icon.setAttribute("src", PICTO[mode])
  }

  setSpeedInfo() {
    this.speedInfo.classList.remove("PlayerControl-speedinfo--hidden")
    if (this.currentMode === "fastRewind") {
      this.speedInfo.classList.add("PlayerControl-speedinfo--rewind")
    } else if (this.currentMode === "fastForward") {
      this.speedInfo.classList.remove("PlayerControl-speedinfo--rewind")
    } else {
      this.speedInfo.classList.add("PlayerControl-speedinfo--hidden")
    }
  }

  showPaused(fromPvr) {
    // Hide textcontent for pause in timeshift
    if (fromPvr) {
      this.time.textContent = ""
    }
    waitReflow(this.dom)
    this.setMode("pause")
    return this.unfold()
  }

  recording() {
    this.setMode("record")
    this.time.textContent = ""
    this.unfold()
  }

  fastForward(speed) {
    this.setMode("fastForward")
    this.speedInfo.textContent = `x${~~(speed)}`
    this.time.textContent = ""
    this.unfold()
  }

  fastRewind(speed) {
    this.setMode("fastRewind")
    this.speedInfo.textContent = `x${~~(-speed)}`
    this.time.textContent = ""
    this.unfold()
  }

  updateTimeshiftDelta(delta) {
    const minutes = String(~~(delta / 60))
    const seconds = String(delta % 60)
    const deltaString = [
      (minutes > 0) ? `${minutes}’` : "",
      (minutes > 0) ? `${padLeft(seconds, "0", 2)}\’\’` : `${seconds}\’\’`,
      _(" from live"),
    ].join("")
    this.time.textContent = /^fast/.test(this.currentMode) ? "" : deltaString
  }
}
