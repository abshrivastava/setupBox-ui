//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"

import "./index.css"

export default class AppDetail extends Component {
  render() {
    return (
      <div className="AppDetail AppDetail--hidden">
        <div className="name" prop="title" />
        <div className="description" prop="description" />
      </div>
    )
  }

  allowedTags(str) {
    const allowTags = ["SPAN","P","BR","B"]
    const div = document.createElement("div")
    div.innerHTML = str
    const tags = div.getElementsByTagName("*")
    if (!tags.length) return str
    for (let idx=0; idx<tags.length; idx++) {
      if (allowTags.indexOf(tags[idx].tagName) === -1)
        tags[idx].remove()
    }
    return div.innerHTML
  }

  show(item) {
    this.setProp("title", item.title)
    if (item.description)
      this.dom.lastElementChild.innerHTML = this.allowedTags(item.description)
    else if (item._attributes && item._attributes.description)
      this.dom.lastElementChild.innerHTML = this.allowedTags(item._attributes.description)
    this.pullState("hidden")
  }

  hide() {
    this.pushState("hidden")
  }
}
