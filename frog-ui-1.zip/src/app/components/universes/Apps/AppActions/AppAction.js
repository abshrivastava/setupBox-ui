//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"

import "./AppAction.css"

export default class AppAction extends Component {
  constructor(item) {
    super()
    this.init(item)
  }

  render() {
    return (
      <div className="AppAction">
        <div className="AppAction-title" prop="title" />
      </div>
    )
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }

  init(item) {
    this.setProp("title", item)
  }
}
