//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import ActionsList from "./ActionList"
import "./index.css"

class ChannelSelector extends Component {
  render() {
    return (< div className = "ChannelSelector" key = "ChannelSelector">
      <div className = "ChannelSelector-bg" / >
        <div className = "ChannelSelector-arrow" key = "arrow" / >
        </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class ChannelItem extends Component {
  render() {
    return (
      <div className = "ChannelItem lockChannel"
      prop = "label" / >
    )
  }
}

export class ChannelsList extends HybridListComponent {
  constructor() {
    super(ChannelSelector, ChannelItem)
    this.ITEM_HEIGHT = 45
    this.WINDOW_SIZE = 9
    this.EXTRA_VISIBLE_ITEMS = 1

  }


  render() {
    return (<div className = "ChannelsList" />)
  }

  showSelector() {

  }

  addLock(iCounter) {
    this.dom.childNodes[1].childNodes[iCounter].classList.remove("lockChannel")
    this.dom.childNodes[1].childNodes[iCounter].classList.add("lockedChannel")
  }

  removeLock(iCounter) {
    this.dom.childNodes[1].childNodes[iCounter].classList.remove("lockedChannel")
    this.dom.childNodes[1].childNodes[iCounter].classList.add("lockChannel")
  }
}


export default class ChannelsMenu extends Component {
  constructor() {
    const props = {channelHeading: "Channel block",channelsSubHeading:"Channels"}
    super(props)
  }

  render() {
    return (
      <div className="ChannelsMenu ChannelsMenu--hidden">
        <div className="ChannelsMenu-inner">
          <div className = "ChannelsMenu-container" >
          <div className = "ChannelsMenu-heading" prop="channelHeading" />
          <div className = "ChannelsMenu-channels" prop="channelsSubHeading" />

          <ChannelsList key="channelsList"/>

          </div>
          <ActionsList key="optionList"/>
        </div>
      </div>
    )
  }

  loadItems(itemList) {
    this.optionList.setActions(itemList)
  }

  show() {
    this.pullState("onBackground")
    // this.channelsTree.show()
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    // this.channelsTree.reset()
    return this.pushState("hidden")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

}
