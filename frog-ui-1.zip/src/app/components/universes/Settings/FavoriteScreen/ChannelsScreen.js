//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {_} from "utils/locale"

import {default as hamsterWheelUrl} from "assets/loaders/wheel.png"

import "./ChannelsScreen.css"

export default class ChannelsScreen extends Component {
  constructor() {
    const props = {
      title: "",
      subTitle: "",
    }
    super(props)
  }

  render() {
    return (
      <div className="ChannelsScreen">
        <div className="title" prop="title" />
        <div className="subTitle" prop="subTitle" />
        <div className="ChannelList">
          <div className="arrow-up" />
          <img className="hamsterWheel hamsterWheel--hidden"
               src={hamsterWheelUrl}
               key="hamsterWheel"/>
          <div className="list" key="channelList"/>
          <div className="arrow-down" />
        </div>
      </div>
    )
  }

  showSpinner() {
    this.hamsterWheel.classList.remove("hamsterWheel--hidden")
  }

  hideSpinner() {
    this.hamsterWheel.classList.add("hamsterWheel--hidden")
  }

  clearChannelList() {
    if (this.channelList.firstChild) {
      this.channelList.removeChild(this.channelList.firstChild)
    }
  }

  onloaded() {
    this.setProp("title", _("Favourites"))
    this.setProp("subTitle", _("Channel List"))
  }

}
