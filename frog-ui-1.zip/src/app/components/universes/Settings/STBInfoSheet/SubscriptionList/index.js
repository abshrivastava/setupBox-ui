//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import {_} from "utils/locale"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import "./index.css"

class SubscriptionSelector extends Component {
  render() {
    return (
      <div className = "SubscriptionSelector" key = "SubscriptionSelector">
        <div className = "SubscriptionSelector-bg" />
        <div className = "SubscriptionSelector-arrow" key = "arrow" />
      </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class SubscriptionItem extends Component {
  render() {
    return (
      <div className = "SubscriptionItem">
        <div className = "SubscriptionName" prop="SubscriptionName"/>
        <div className = "LastSet">
          <span className = "LastValidStartDate" prop= "LastValidStartDate"/>
          <span className = "LastValidEndDate" prop= "LastValidEndDate"/>
          <span className = "LastBitSet" prop= "LastBitSet"/>
        </div>
        <div className = "CurrentSet">
          <span className = "CurrentValidStartDate" prop= "CurrentValidStartDate"/>
          <span className = "CurrentValidEndDate" prop= "CurrentValidEndDate"/>
          <span className = "CurrentBitSet" prop= "CurrentBitSet"/>
        </div>
      </div>
    )
  }
}

export class SubscriptionHList extends HybridListComponent {
  constructor() {
    super(SubscriptionSelector, SubscriptionItem)
    this.ITEM_HEIGHT = 100
    if (config.SD_ZAPPER) this.ITEM_HEIGHT = 80
  }

  render() {
    return (<div className = "SubscriptionHList" />)
  }
  showSelector() {
  }

}

export default class TPmain extends Component {
  render() {
    return (
      <div className="SubscriptionsMenu">
        <div className="SubscriptionsMenu-inner">
          <div className = "SubscriptionsMenu-container" >
          <div className = "Subscription-heading" prop= "Subscription"/>
            <div className = "SubscriptionContent">
            <div className= "SubscriptionHList-before" key="beforeArrow"/>
              <SubscriptionHList key="SubscriptionList"/>
              <div className="SubscriptionHList-after" key="AfterArrow"/>
            </div>
          </div>
        </div>
      </div>
    )
  }


  showSubscriptions() {
    this.setProp("Subscription", _("Subscription Information"))
    this.SubscriptionList.pullState("hidden")
  }

  hideAllSubscriptions() {
    this.SubscriptionList.pushState("hidden")
    this.SubscriptionList.hide()
  }

  show() {
    this.pullState("onBackground")
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    this.pushState("hidden")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  loadSubscriptionList() {
    this.showSubscriptions()
  }

  hideBeforeArrow() {
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className)
    this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className="HiddenArrow"
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className)
  }

  hideAfterArrow() {
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[2].className)
    this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[2].className="HiddenArrow"
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[2].className)
  }

  ShowAllArrow() {
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className)
    this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className="SubscriptionHList-before"
    this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[2].className="SubscriptionHList-after"
    console.log("this",this.dom.childNodes[0].childNodes[0]
    .childNodes[1].childNodes[0].className)
  }

}
