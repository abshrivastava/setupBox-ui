//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import SpinnerList, {SpinnerItem} from "app/components/widgets/Spinner"
import "./index.css"

class ManualRecordSpinnerList extends SpinnerList {
  constructor({itemClass}) {
    super(itemClass || null)
    this.ITEM_HEIGHT = 59
    this.WINDOW_SIZE = 5
    this.EXTRA_VISIBLE_ITEMS= 2
  }
}

export class ManualRecordSpinner extends Component {

  render() {
    return (
      <div className="ManualRecord-Spinner">
        <div className="ManualRecord-Spinner-title" prop="title"/>
        <ManualRecordSpinnerList key="list"/>
      </div>
    )
  }
}

class MonthItem extends SpinnerItem {
  render() {
    return (
      <div className="SpinnerItem">
        <div className="SpinnerItem-title" prop="title" />
      </div>
    )
  }
}

class MonthSpinnerList extends ManualRecordSpinnerList {
  constructor() {
    super({itemClass: MonthItem})
  }
}

export class ManualRecordMonthSpinner extends ManualRecordSpinner {

  render() {
    return (
      <div className="ManualRecord-Spinner">
        <div className="ManualRecord-Spinner-title" prop="title"/>
        <MonthSpinnerList key="list"/>
      </div>
    )
  }
}

export default {
  ManualRecordMonthSpinner,
  ManualRecordSpinner,
}
