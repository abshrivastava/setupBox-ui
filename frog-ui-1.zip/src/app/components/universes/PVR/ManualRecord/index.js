//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {_} from "utils/locale"
import {ManualRecordMonthSpinner, ManualRecordSpinner as Spinner} from "./Spinner"
import "./index.css"

export default class ManualRecord extends Component {
  constructor() {
    const props = {header: "",footer:""}
    super(props)
  }

  render() {
    return (
      <div className="ManualRecord ManualRecord--hidden">
        <div className="ManualRecord-header" prop="header"/>
        <div className="ManualRecord-spinners">
          <Spinner key="channelSpinner" title="Channel:"/>
          <span className="separator"/>

          <Spinner key="daySpinner" title="Date:"/>
          <span className="mini-separator"/>
          <ManualRecordMonthSpinner key="monthSpinner"/>
          <span className="mini-separator"/>
          <Spinner key="yearSpinner"/>
          <span className="separator"/>


          <Spinner key="durationSpinner" title="Duration:"/>
          <span className="separator"/>

          <Spinner key="recurrenceSpinner" title="Recurrence:"/>
          <span className="separator"/>

          <Spinner key="hoursSpinner" title="Hours:"/>
          <span className="mini-separator">:</span>
          <Spinner key="minutesSpinner"/>
          <span className="separator"/>
          <Spinner key="tfSpinner" title="AM/PM:"/>

        </div>
        <div className="ManualRecord-footer" prop="footer"/>
      </div>
    )
  }

  updateHeaderFooter() {
    this.setProp("header", _("Schedule Your Recording"))
    this.setProp("footer", _("Press OK to Save my schedule"))
  }
}
