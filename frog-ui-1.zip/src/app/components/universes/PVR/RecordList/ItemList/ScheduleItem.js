//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {formatDate, formatDuration} from "utils/date"
import TimezoneManager from "services/managers/TimezoneManager"
import config from "utils/config"
import {channelLogo as logoName} from "utils"
import {testImage} from "utils/image"

import schedulePictoUrl from "assets/pictos/schedule.png"
import defaultLogoUrl from "assets/fallbacks/channel-logo.png"

export default class ScheduleItem extends Component {
  constructor() {
    super({
      title: "Untitled",
      channelTitle: "Unknown channel",
      startDate: new Date(),
    })
  }

  render() {
    return (
      <div className="ScheduleItem ScheduleItem--hidden">
        <div className="ScheduleItem-summary">
          <img className="ScheduleItem-picto" src={schedulePictoUrl} />
          <div className="ScheduleItem-title" prop="title" />
        </div>
        <div className="ScheduleItem-details">
          <div className="ScheduleItem-channel" prop="channelTitle" />
          <div className="ScheduleItem-date" prop="startDate" />
          <div className="ScheduleItem-hour-container">
            <span className="ScheduleItem-hour" prop="startHour" />
            <span className="ScheduleItem-duration" prop="duration" />
          </div>
          <img
            className="ScheduleItem-channelLogo"
            src={defaultLogoUrl} key="logo"/>
        </div>
      </div>
    )
  }

  update(item) {
    if (!item) {
      this.hide()
      return
    }

    this.show()

    let duration
    try {
      duration = formatDuration(item.duration)
    } catch (err) {
      duration = "Unknown duration"
    }

    this.setProps({
      title: item.title,
      startDate: formatDate(item.startDate),
      startHour: TimezoneManager.getFormatTime(item.startDate)+" -",
      channelTitle: item.channelTitle,
      duration: duration,
    })

    const channelLogo =
    `http://${config.STB_IP}${config.LOGO_BASE}${logoName(item.channelTitle)}.png`
    testImage(this.logo, channelLogo, defaultLogoUrl)
  }
}
