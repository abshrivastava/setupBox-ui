//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as date from "utils/date"
import config from "utils/config"
import {channelLogo as logoName} from "utils"
import {testImage} from "utils/image"
import defaultLogoUrl from "assets/fallbacks/channel-logo.png"
import ActionsTree from "./actions"

import "./index.css"

const CRIcon = "\u2022"
export default class ItemDetails extends Component {
  constructor() {
    super({
      title: "Untitled",
      category: "Uncategorized",
      details: "Unknown channel, Unreleased, Infinite",
      channelLogo: defaultLogoUrl,
      description: "No synopsis available",
    })
  }

  render() {
    return (
      <div className="ItemDetails ItemDetails--hidden">
        <div className="ItemDetails-summary">
          <img className="ItemDetails-channelLogo" src={defaultLogoUrl} key="logo"/>
          <div className="ItemDetails-title" prop="title" />
          <div className="ItemDetails-category" prop="category" />
          <div className="ItemDetails-details" prop="details" />
          <div className="ItemDetails-synopsis" prop="description" />
        </div>
        <ActionsTree key="actionsTree" />
        <div className="ItemDetails-CRI"  prop="cri1" />
        <div className="ItemDetails-CRI2" prop="cri2" />
      </div>
    )
  }

  open(item, showCRIcon) {
    if (item.changeTitle) {
      this.setProps({
        title: item.changeTitle,
        category: item.category || "",
        details: this._details(item),
        description: item.description || "",
      })
    } else {
      this.setProps({
        title: item.title,
        category: item.category || "",
        details: this._details(item),
        description: item.description || "",
      })
    }

    if (showCRIcon) {
      if (item.accStats === "SCRMBLD_CRI") {
        this.setProp("cri1",CRIcon)
        this.setProp("cri2",CRIcon)
      } else if (item.accStats === "SCRMBLD_WO_CRI") {
        this.setProp("cri1",CRIcon)
        this.setProp("cri2","")
      } else {
        this.setProp("cri1","")
        this.setProp("cri2","")
      }
    } else {
      this.setProp("cri1","")
      this.setProp("cri2","")
    }

    const channelLogo =`http://${config.STB_IP}${config.LOGO_BASE}${logoName(item.channelTitle)}.png`
    testImage(this.logo, channelLogo, defaultLogoUrl)
    .then(() => {
      this.actionsTree.show()
      return this.show()
    })
  }

  _details(item) {
    const details = []
    let duration
    try {
      duration = date.formatDuration(item.duration)
    } catch (err) {
      duration = "Unknown duration"
    }
    details.push(item.channelTitle)
    details.push(item.genre)
    details.push(date.formatDate(item.startDate))
    details.push(duration)

    return details.filter(Boolean).join(", ")
  }

  close() {
    return this.hide()
  }
}
