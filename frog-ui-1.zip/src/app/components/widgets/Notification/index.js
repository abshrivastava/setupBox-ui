//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Component from "widgets/Component"
import "./index.css"

const SCRAMBLED_CHANNEL_H_MESSAGE = "SCRAMBLED CHANNEL"
const SCRAMBLED_CHANNEL_S_MESSAGE = "Please check your subscription"

const NO_TV_SIGNAL_H_MESSAGE = "NO SIGNAL DETECTED"
const NO_TV_SIGNAL_S_MESSAGE = "Please check your antenna cable"

export default class Notification extends Component {
  constructor(props) {
    const defaultProps = {
      messageHead: "NO SIGNAL DETECTED",
      messageSub: "Please check your antenna cable",
    }
    super(Object.assign({}, defaultProps, props))

    this.notificationShown = null
  }

  render() {
    return (
      <div className="Notification Notification--hidden">
        <div className="Notification-icon "/>
        <table className="Message-wrapper">
          <tr>
            <th className="Message-head" prop="messageHead" />
          </tr>
          <tr>
            <th className="Message-sub" prop="messageSub" />
          </tr>
        </table>
      </div>
    )
  }

  showNoTvMessage() {
    if (this.notificationShown !== "noTv") {
      this.setProp("messageHead", NO_TV_SIGNAL_H_MESSAGE)
      this.setProp("messageSub", NO_TV_SIGNAL_S_MESSAGE)
    }
    this.notificationShown = "noTv"
    this.show()
  }

  hideNoTvMessage() {
    if (this.notificationShown === "noTv") {
      this.notificationShown = null
      this.hide()
    }
  }

  showScrambledMessage() {
    this.setProp("messageHead", SCRAMBLED_CHANNEL_H_MESSAGE)
    this.setProp("messageSub", SCRAMBLED_CHANNEL_S_MESSAGE)
    this.notificationShown = "scrambled"
    this.show()
  }

  hideScrambledMessage() {
    this.notificationShown = null
    this.hide()
  }

  close() {
    this.notificationShown = null
    this.hide()
  }
}
