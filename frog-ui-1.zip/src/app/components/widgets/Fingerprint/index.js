//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import TimeoutsManager from "services/managers/TimeoutsManager"
import {on} from "services/events"
import bus from "services/bus"
import PlayerManager from "services/managers/PlayerManager"
import "./index.css"

const POSITIONS = Object.freeze({
  TOP_LEFT: 1,
  TOP_RIGHT: 2,
  BOTTOM_RIGHT: 3,
  BOTTOM_LEFT: 4,
})

export default class Fingerprint extends Component {
  constructor(props) {
    const defaultProps = {
    }
    super(Object.assign({}, defaultProps, props))
    this.isFingerprintActive = false
    this.lastPosition = null
  }

  render() {
    return (
      <div className="Fingerprint Fingerprint--hidden" >
        <div className="Fingerprint-Wrapper" key="fingerbox" >
          <div className="Fingerprint-ID" prop="fingerID" key="fingerid" />
        </div>
      </div>
    )
  }

  /** function:: showFingerprint()
   * Trigger.. show Fingerprint on Live Stream...
   *
   */
  showFingerprint(data) {
    const type = PlayerManager.tvType
    const playerHeight = PlayerManager.playerHeight
    let x = null
    let y = null
    x = (data.x_cord-3)*1280/720
    y = (data.y_cord-10)*720/576
    if (type === "Letter" && (playerHeight === 1080 || playerHeight === 720)) {
      y = 72+ (data.y_cord-10)
    } else if (type === "Pillar" &&  playerHeight === 576) {
      x = 190 + (data.x_cord-3)*720/576
    }
    let margin = {x:0, y:0}
    if (config.SD_ZAPPER) {
      margin = {x:40, y:5}
      x = (data.x_cord/1280)*720 - margin.x
      y = (data.y_cord/720)*576 - margin.y
    }
    x = (x <= 0) ? margin.x : x
    y = (y <= 0) ? margin.y  : y
    this.fingerbox.style.marginLeft = x + "px"
    this.fingerbox.style.marginTop = y + "px"
    this.fingerbox.style.background = "black"
    this.fingerid.style.color = "white"
    if (data.height) this.fingerid.style.fontSize = (data.height*2.5) + "px"
    this.setProp("fingerID", data.id)
    this.show()
    TimeoutsManager.setTimer(data.duration*10, function() {
      bus.emit("fingerprint:close")
    })
  }

  /** function:: showFingerprintTimeshift()
   * Trigger.. show Fingerprint on Recoding and TimeShift...
   *
   */
  showFingerprintTimeshift(vc) {
    const type = PlayerManager.tvType
    const playerHeight = PlayerManager.playerHeight

    let position = this.getRandomPosition(POSITIONS.TOP_LEFT, POSITIONS.BOTTOM_LEFT+1)
    while (position === this.lastPosition) {
      position = this.getRandomPosition(POSITIONS.TOP_LEFT, POSITIONS.BOTTOM_LEFT+1)
      this.lastPosition = position
    }

    let x = 0
    let y = 0
    if (type === "Letter" && (playerHeight === 1080 || playerHeight === 720)) {
      y = 72
    } else if (type === "Pillar" &&  playerHeight === 576) {
      x = 190
    }

    switch (Number(position)) {
    case 1: // TOP-LEFT
      this.fingerbox.style.top = (y + 6) + "px"
      this.fingerbox.style.left = (x + 20) + "px"
      this.fingerbox.style.right = "auto"
      this.fingerbox.style.bottom = "auto"
      break
    case 2: // TOP-RIGHT
      this.fingerbox.style.top = (y + 6) +  "px"
      this.fingerbox.style.right = (x + 20) + "px"
      this.fingerbox.style.left = "auto"
      this.fingerbox.style.bottom = "auto"
      break
    case 3: // BOTTOM-RIGHT
      this.fingerbox.style.bottom = (y + 6) + "px"
      this.fingerbox.style.right = (x + 20) + "px"
      this.fingerbox.style.top = "auto"
      this.fingerbox.style.left = "auto"
      break
    case 4: // BOTTOM-LEFT
      this.fingerbox.style.bottom = (y + 6) + "px"
      this.fingerbox.style.left = (x + 20) + "px"
      this.fingerbox.style.top = "auto"
      this.fingerbox.style.right = "auto"
      break
    default: // TOP-RIGHT
      this.fingerbox.style.top = (y + 6) + "px"
      this.fingerbox.style.right = (x + 20) + "px"
      this.fingerbox.style.left = "auto"
      this.fingerbox.style.bottom = "auto"
    }
    this.fingerbox.style.background = "black"
    this.fingerid.style.color = "white"

    this.setProp("fingerID", vc)
    this.show()
  }

  @on("fingerprint:close")
  closeFingerprint() {
    this.fingerbox.style.bottom = ""
    this.fingerbox.style.top = ""
    this.fingerbox.style.left = ""
    this.fingerbox.style.right = ""
    this.hide()
  }

  close() {
    // bus.emit("fingerprint:close")
    this.hide()
  }

  getRandomPosition(min, max) {
    min = Math.ceil(min)
    max = Math.floor(max)
    return Math.floor(Math.random() * (max - min)) + min
  }

}
