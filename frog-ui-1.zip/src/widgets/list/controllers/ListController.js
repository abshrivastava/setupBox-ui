//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Controller from "utils/Controller"
import List from "utils/List"

/**
 * Controller class for {@link List} object.
 */
export default class ListController extends Controller {

  static defaultOptions = {
    "EXTRA_VISIBLE_ITEMS_BEFORE": 0,
    "EXTRA_VISIBLE_ITEMS_AFTER": 0,
  }

  /**
   * ListController constructor
   *
   * @name constructor
   * @public
   * @param {!Array<Object>} [items] - Non empty Array of Object
   * @param {?ListControllerOptions} [options=null] - ListController options
   */
  constructor(items, options) {
    super()
    /**
     * List Object used by the Controller
     * @type {List}
     * @protected
     */
    this.list = null

    /**
     * Current selectedIdx in {@link ListController#list}
     * @type {Number} Integer
     * @protected
     */
    this.selectedIdx = 0

    /**
     * Option object
     * @type {Object}
     * @protected
     */
    this.options = Object.assign({}, this.constructor.defaultOptions,
      options)

    /* Set the list with the items */
    this._setList(items)
  }

  /**
   * Create the attribute {@link ListController#list} from a Array<Object>
   *
   * @name _setList
   * @private
   * @param {Array<Object>} items Array of Object
   */
  _setList(items) {
    this.list = new List(items)
  }

  /**
   * Current selected item
   *
   * @type {Object}
   */
  get currentItem() {
    return this.list.get(this.selectedIdx)
  }

  /**
    * Update the list with new items
    *
    * @name update
    * @param {Array<Object>} items Array of Object
    **/
  update(items) {
    const idx = items.indexOf(this.currentItem)
    this._setList(items)
    this.selectedIdx = idx === -1 ? 0 : idx
    this._updateView()
  }

  /**
   * Select the next item Object in {@link ListController#list} and
   * notify View
   *
   * @name next
   * @public
   */
  next() {
    const moveIdx = this.selectedIdx === this.list.count - 1 ? 0 : 1
    this.selectedIdx = Math.min(this.selectedIdx + 1, this.list.count - 1)
    this._notifyView(moveIdx)
  }

  /**
   * Select the previous item Object in {@link ListController#list} and
   * notify View
   *
   * @name prev
   * @public
   */
  prev() {
    const moveIdx = this.selectedIdx === 0 ? 0 : -1
    this.selectedIdx = Math.max(this.selectedIdx - 1, 0)
    this._notifyView(moveIdx)
  }

  /**
   * Select item at position idx in {@link ListController#list}
   *
   * @name select
   * @public
   * @param {Number} idx Integer
   */
  select(idx) {
    const moveIdx = idx - this.selectedIdx
    this.selectedIdx = idx < 0 ? 0 :
      idx >= this.list.count ? this.list.count - 1 : idx
    this._notifyView(moveIdx)
  }

  /**
   * Select item in {@link ListController#list}
   *
   * @name selectItem
   * @public
   * @param {Object} item An Object of the {@link ListController#list}
   */
  selectItem(item) {
    const idx = this.list.indexOf(item)
    if (idx !== -1) {
      this.select(idx)
    } else {
      throw new Error("Trying to select non-existing item")
    }
  }

  /**
   * Notify the view, triggered when a select is made.
   *
   * @name _notifyView
   * @private
   * @param {Number} moveIdx Integer, describe the movement index.
   */
  _notifyView(moveIdx) {
    const before = this.options.EXTRA_VISIBLE_ITEMS_BEFORE
    const after  = this.options.EXTRA_VISIBLE_ITEMS_AFTER
    const nbItems = before + after + 1
    this.view.update(
      this.list.getRange(this.selectedIdx-before, nbItems),
      before, moveIdx)
  }

  _updateView() {
    const before = this.options.EXTRA_VISIBLE_ITEMS_BEFORE
    const after  = this.options.EXTRA_VISIBLE_ITEMS_AFTER
    const nbItems = before + after + 1
    this.view.redraw(
      this.list.getRange(this.selectedIdx-before, nbItems),
      before)
  }

  /**
   * Focus the list
   *
   * @name focus
   * @public
   */
  focus() {
    this.view.onFocus()
  }

  /**
   * Blur the list
   *
   * @name blur
   * @public
   */
  blur() {
    this.view.onBlur()
  }
}
