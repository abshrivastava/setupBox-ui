//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import CircularList from "utils/CircularList"
import ListController from "./ListController"

/**
 * Controller class for {@link CircularList} object.
 */
export default class CircularListController extends ListController {
  /**
   * Current selected item
   *
   * @type {Object}
   * @public
   */
  get currentItem() {
    return this.list.get(this.selectedIdx)
  }
  /**
   * Select the next item Object in {@link CircularListController#list} and
   * notify View
   *
   * @name next
   * @function
   * @public
   */
  next() {
    this.selectedIdx = this.list.getIdx(this.selectedIdx + 1)
    this._notifyView(1)
  }

  /**
   * Select the previous item Object in {@link CircularListController#list} and
   * notify View
   *
   * @name prev
   * @function
   * @public
   */
  prev() {
    this.selectedIdx = this.list.getIdx(this.selectedIdx - 1)
    this._notifyView(-1)
  }

  /**
   * Create the attribute {@link CircularListController#list} from a
   * Array<Object>
   *
   * @name _setList
   * @function
   * @private
   * @param {Array<Object>} items Array of Object
   */
  _setList(items) {
    /**
     * List Object used by the Controller
     * @type {CircularList}
     *
     */
    this.list = new CircularList(items)
  }
}
