//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import langs from "langs"

/**function:: utils.string.padLeft(string, padChar, size)
 * Pads a string on its left using up to a given size
 *
 *   :param String string: String to pad
 *   :param String padChar: Character to use for padding
 *   :param Number size: Size of the output string
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    padLeft("1", "0", 4") // => "0001"
 */
export function padLeft(string, padChar, size) {
  const pad = Array.from({length: size}, () => padChar).join("")

  return pad.substring(0, size - string.length) + string
}

/**function:: utils.string.capitalize(string)
 * Capitalizes the first letter of a string.
 *
 *   :param String string: The string to capitalize
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    capitalize("hello") //=> "Hello"
 */
export function capitalize(string) {
  return string[0].toUpperCase() + string.slice(1)
}

/**function:: utils.string.camelCase(string)
 * Transforms a snake_case_string to a camelCaseString.
 *
 *   :param String string: The string to camelcase
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    camelCase("record_task_created") //=> "recordTaskCreated"
 */
export function camelCase(string) {
  return string.replace(/_(\w)/g, (_, l) => l.toUpperCase())
}

/**function:: utils.string.isoToName(isoVersion, isoCode)
 * Transforms a iso code to a language.
 *
 *   :param String isoVersion: The iso Version
 *   :param String isoCode:
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    isoToName("eng") //=> "English"
 */
export function isoToName(isoCode) {
  if (!isoCode) {
    return "Unknown"
  }
  // Specials Codes
  switch (isoCode) {
  case "mis":
    return "Miscellaneous"
  case "mul":
    return "Multiple"
  case "und":
    return "Undetermined"
  case "zxx":
    return "Animal"
  case "qad":
    return "Audio description"
  case "qaa":
    return "Original version"
  default:
    break
  }

  let lang = null
  const isoVersions = ["1", "2", "2T", "2B", "3"]
  for (let i=0; i<isoVersions.length; i++) {
    if (langs.has(isoVersions[i], isoCode)) {
      lang = langs.where(isoVersions[i], isoCode).local
      break
    } else {
      lang = "Unknown"
    }
  }
  return capitalize(lang)
}
