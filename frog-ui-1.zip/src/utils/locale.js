//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Jed from "jed"
import {LOCALE_DATA} from "locales"
import bus from "services/bus"

function _formatDomain(locale) {
  return `locale-${locale}_${locale.toUpperCase()}`
}

class i18n extends Jed {

  constructor(wantedLocale, data) {
    const domain = _formatDomain(wantedLocale)
    const localeData = data
    const options = {
      "domain" : domain,
      "locale_data": localeData,
      "missing_key_callback": (_key) => {
        // console.warn(`Missing locale key : ${_key}`)
      },
    }
    super(options)
  }

  translate(msgId) {
    if (typeof msgId !== "string" || msgId === "")
      return msgId || ""
    return super.translate(msgId).ifPlural(2, "").fetch()
  }
}

export class Locale {
  constructor(data) {
    this.data = data || LOCALE_DATA
    this._currentLocale = null
    this.i18n = null
  }

  set current(locale) {
    this.i18n = new i18n(locale, this.data)
    this._currentLocale = locale
    bus.emit("locale:translate")
  }

  get current() {
    return this._currentLocale
  }

  translate(msgId) {
    return (this.i18n) ? this.i18n.translate(msgId) : msgId
  }

  translateTextNodes(rootNode) {
    let node
    const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT, null, false)
    while ((node = walker.nextNode())) {
      const t = this.translate(node.msgId)
      if (node.limit && Number.isInteger(node.limit.start) && Number.isInteger(node.limit.end)) {
        node.textContent = t.substring(node.limit.start, node.limit.end)
      } else {
        node.textContent = t
      }
    }
  }
}

export const locale = new Locale()

export function _(msg) {
  return locale.translate(msg)
}
