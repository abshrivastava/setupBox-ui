//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {sse, enableEvents} from "services/events"
import * as casApi from "services/api/cas"
import * as popUpMsg from "app/utils/PopUpMsg"
import ScanManager from "services/managers/ScanManager"
import PowerManager from "services/managers/PowerManager"
import FtaBlockManager from "services/managers/FtaBlockManager"

const startTimeDefault = 4294967295 // 0xFFFFFFFF

class InstantMessageManager {
  constructor() {
    enableEvents(this)
    this.processingMessage = false
    this.lastMsgID = null
    this.lastMsgSeqNo = null
    this.isCAmenuOpen = false
    this.isPPVOpen = false
  }

  /* ********** SSE Event handling for Unsubscribe PopUp Information ********* */

  @sse("scan", {subtype: "Messaging_info"})
  _onInstantMessage(msg) {
    // Ignore message if Home Unuverse is not launched after boot-up
    if (FtaBlockManager.isFtaComplete === false) return
    // Avoiding Schedule Message...By Displaying...
    if (Number(msg.content.startTime) !== startTimeDefault) return
    // Ignore if Scan is in progress OR STB is in Standby
    if (ScanManager.running || PowerManager.isStandbyState) return
    // Ignore if same message is received again
    if (msg.content.msgID === this.lastMsgID && msg.content.seq_no === this.lastMsgSeqNo) return
    // Ignore if 501-Conditional Access Popup is open OR CA menu is Open
    if (this.isPPVOpen === true || this.isCAmenuOpen === true) return
    // Storing MsgID and MsgSeqNo
    this.lastMsgID = msg.content.msgID
    this.lastMsgSeqNo = msg.content.seq_no
    // Setting the processing flag, not in use currently
    this.processingMessage = true
    // Converting Hex string into Ascii string
    const msgToDisplay = this.HexToAscii(msg.content.text)
    // Constructing parameters for Acknowledging API
    const params = {"msgID":msg.content.msgID,"Seq_no":msg.content.seq_no}
    // Displaying the message
    if (msg.content.duration)
      popUpMsg.instantMessage(msgToDisplay, msg.content.duration*1000)

    // Acknowledging Message
    casApi.setInstantMessageFlag(params)
    .then(() => {
      this.processingMessage = false
    })
  }

  /* ********** SSE Event handling for Unsubscribe PopUp Information ********* */

  HexToAscii(hex_string) {
    const hex = hex_string.toString()
    let ascii_string = ""
    for (let i = 0; i < hex.length-2; i += 2) { // Discarding null character at end
      ascii_string += String.fromCharCode(parseInt(hex.substr(i, 2), 16))
    }
    return ascii_string
  }
}

export default new InstantMessageManager()
