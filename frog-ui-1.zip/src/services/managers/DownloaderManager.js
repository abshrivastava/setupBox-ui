//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {sse, enableEvents} from "services/events"
import * as downloaderApi from "services/api/downloader"

import {
  VersionManagers,
  PowerManager,
} from "services/managers"

/**
 * 10000 ==> 10second
 * 600000 == > 10min
 * 10000 == > 10second
 */
const DOWNLOADTIMEOUT = Object.freeze({
  TENSECOND: 10000,
  TENMINUTE: 600000,
  TIME : 10000,
})

const DOWNLOAD = Object.freeze({
  ADS: 208,
  APPS: 209,
  STANDY : "standby",
})

class DownloaderManager {
  constructor() {
    enableEvents(this)
    this.isDownloaderStarted = false
    this.applicationDn = false
    this.waitForDownload = null
    this.playStoreTitle = null
    this.fakeBar = null
    this.progressValue = 0
    this.requestDw = false
    this.appsPersist = false
    this.download = {
      "adsTaskUri" : null,
      "appsTaskUri" : null,
      "adsCurrentTask" : null,
      "appsCurrentTask" : null,
      "appCurrentTask" : null,
      "adsCurrentTaskStandy" : null,
      "adsContend" : null,
      "appsContend" : null,
      "appContend" : null,
      "adsContendStandy" : null,
    }
    this.watcher = {
      "tuner" : null,
      "IFtoIF" : null,
      "diseqc" : null,
      "transponder_list" : [],
    }
  }

  addContent(uri, type) {
    return new Promise((resolve) => {
      const data = VersionManagers.config
      /**
       * Content if Type is Ads...
       */
      if (type === data.ADSCATALOG) {
        this.download.adsContend = {
          download_uri: uri,
          dest_path: data.ADS,
          properties: {
            "progress_notification": "true",
            "fw_update": "false",
          },
          transponder_list: this.watcher.transponder_list,
        }
      }
      /**
       * Content if Type is Apps...
       */
      if (type === data.APPSCATALOG) {
        this.download.appsContend = {
          download_uri: uri,
          dest_path: data.APPS,
          properties: {
            "progress_notification": "true",
            "fw_update": "false",
          },
        }
      }
      resolve(true)
    })
  }

  /* ********** Application Download..********* */
  downloadApplication() {
    return new Promise((resolve,reject) => {
      const type = DOWNLOAD.APPS
      const dvbUri = this.download.appsTaskUri
      const downloadFlag = VersionManagers.config.APPS
      VersionManagers.downlaodAction = downloadFlag

      if (!dvbUri) {
        throw "Download Task Not Available.."
      }

      return this.addContent(VersionManagers.addTransactionId(type, dvbUri), type).then(() => {
        return this.startDownloading(type)
      }).then(() => {
        resolve(`Request for ${type} Downloading`)
      }).catch((error) => {
        reject(error)
      })
    })
  }

  /* ********** Advertise Download..********* */

  downloadAdvertise() {
    return new Promise((resolve,reject) => {
      const type = DOWNLOAD.ADS
      const dvbUri = this.download.adsTaskUri
      const downloadFlag = VersionManagers.config.ADS
      VersionManagers.downlaodAction = downloadFlag

      if (!dvbUri) {
        throw "Download Task Not Available.."
      }

      return VersionManagers.manageDvbUri(dvbUri).then((uri) => {
        return this.addContent(VersionManagers.addTransactionId(type, uri), type)
      }).then(() => {
        return this.startDownloading(type)
      }).then(() => {
        resolve(`Request for ${type} Downloading`)
      }).catch((error) => {
        reject(`Fail to Start Downloading for ${type} ::`,error)
      })
    })
  }

  startDownloading(type) {
    let options = null
    const data = VersionManagers.config

    if (type === data.ADSCATALOG) options = this.download.adsContend
    if (type === data.APPSCATALOG) options = this.download.appsContend
    if (type === data.APPFILE) options = this.download.appContend

    return this.launchDownload(type,options)
    .catch(() => {
      // Now Silent...
    })
  }


  launchDownload(type,options) {
    let task = null
    const data = VersionManagers.config

    if (type === data.ADSCATALOG) {
      task = "adsCurrentTask"
    } else if (type === data.APPSCATALOG) {
      task = "appsCurrentTask"
    } else if (type === data.APPFILE) {
      task = "appCurrentTask"
    }

    return this._createTask(type,options)
    .then(() => {
      return this._startDownload(this.download[task])
    }).then(() => {
      /**
       * Adding Timmer :: If New Version for Application
       * Does not Downlod for 10 Second... Previous Version
       * Catalog will Dispaly
       * @@Case on for Application Catalog
       */
      if (type === data.APPSCATALOG && this.appsPersist) {
        this.createDwTimmer()
        this.setFakeBar()
      }

    })
    .catch(() => {
      if (type === data.ADSCATALOG) {
        VersionManagers.onCanceled(false, false,data.ADSCATALOG)
      }
    })
  }

  stopAdsOngoing() {
    return new Promise((reslove) => {
      if (this.download.adsCurrentTask) {
        this._stopDownload(this.download.adsCurrentTask).then(() => {
          reslove(true)
        })
        .catch(() => reslove(false))
      } else {
        reslove(false)
      }
    })
  }

  restartAdsDownloadTask() {
    if (this.download.adsCurrentTask) {
      this._startDownload(this.download.adsCurrentTask)
    }
  }

  clearDwTimmer() {
    window.clearTimeout(this.waitForDownload)
    clearInterval(this.fakeBar)
  }

  createDwTimmer() {
    if (this.waitForDownload) window.clearTimeout(this.waitForDownload)
    this.waitForDownload = window.setTimeout(() => {
      clearInterval(this.fakeBar)
      this.waitForDownload = null
      this.fakeBar = null
      VersionManagers.showResults(true,false,true,VersionManagers.config.APPSCATALOG)
      this._clearDownloaderSession(this.download.appsCurrentTask)
    },DOWNLOADTIMEOUT.TIME)
  }

  setFakeBar() {
    let x = 0
    let y = 0
    const universe = bus.universe
    this.progressValue = 0

    if (this.appsPersist && universe === "popup") {
      this.fakeBar = window.setInterval(() => {

        const option = {"progress" : x}
        bus.emit("popup:updateProgress", option)

        if (y === 1000 || y === 2000 || y === 3000 ||
            y === 4000 || y === 5000 || y === 6000 ||
            y === 7000) {
          x += 3
        }

        if (y > 7000) {
          x += 6.5
        }

        y += 200

        if (x > 100) {
          clearInterval(this.fakeBar)
          this.fakeBar = null
        }
        this.progressValue = x

      },200)
    } else {
      clearInterval(this.fakeBar)
      this.fakeBar = null
    }
  }

  loadApp(uri) {
    return new Promise((resolve) => {
      this.download.appContend = {
        download_uri: uri,
        dest_path: "playStore",
        properties: {
          "progress_notification": "true",
          "fw_update": "false",
        },
      }
      resolve()
    })
  }

  removePendingDwtasks() {
    return this._getDowloaderTasks().then(({tasks}) => {
      if (tasks && tasks.length) {
        const promises = []
        for (let i=0; i<tasks.length; i++) {
          const task = tasks[0]
          if (task.href) {
            const promise = downloaderApi.stopDownloaderTask(task.href).then(() => {
              return downloaderApi.deleteDownloaderTask(task.href)
            })
            promises.push(promise)
          }
        }
        return Promise.all(promises)
      }
      return false
    })
  }

  /* **********************************
   *        PRIVATE METHODS           *
   ********************************** */
  _createTask(type,options) {

    let task = null
    const data = VersionManagers.config

    if (type === data.ADSCATALOG) {
      task = "taskWatcher"
    } else {
      task = "createDowloaderTask"
    }

    return downloaderApi[task](options)
      .then((href) => {
        if (type === data.ADSCATALOG) {
          return this.download.adsCurrentTask = href
        } else if (type === data.APPSCATALOG) {
          return this.download.appsCurrentTask = href
        } else if (type === data.APPFILE) {
          return this.download.appCurrentTask = href
        } else {
          return null
        }
      })
  }

  _updateTask(href,params) {
    return downloaderApi.updateDownloaderTask(href, params)
  }

  _getDowloaderTasks() {
    return downloaderApi.listDowloaderTasks()
  }

  _deleteTask(href) {
    return downloaderApi.deleteDownloaderTask(href)
  }

  _getTaskProgress(href) {
    return downloaderApi.getDownloaderTaskProgress(href)
  }

  _startDownload(href) {
    return downloaderApi.startDownloaderTask(href)
  }

  _pauseDownload(href) {
    return downloaderApi.pauseDownloaderTask(href)
  }

  _resumeDownload(href) {
    return downloaderApi.resumeDownloaderTask(href)
  }

  _stopDownload(href) {
    return downloaderApi.stopDownloaderTask(href)
  }

  clearDownloader(href) {
    return this._deleteTask(href)
  }

  _clearDownloaderSession(uri) {
    return downloaderApi.stopDownloaderTask(uri)
    .then(() => {
      return downloaderApi.deleteDownloaderTask(uri)
    })
  }

  _cancelDownloader(href) {
    return this._stopDownload(href)
  }

  /* ******************************************************************
   *             .......SSE EVENTS .............                *
   ********************************** *********************************/

   /*
   *{
   *  1: 'ecreated',
   *  2: 'estarted',
   *  3: 'eupdated',
   *  4: 'epaused',
   *  5: 'eresumed',
   *  6: 'edone'
   * }
   */
  @sse("downloader", {subtype: "status_changed", content: {event: "estarted"}})
  onDownloaderStarted(event) {
    this.progressValue = 0
    VersionManagers.onDownloaderStarted(event.content)
  }

  @sse("downloader", {subtype: "download_completed"})
  onDownloaderComplete(event) {
    this.requestDw = true
    const content = event.content
    let href = null
    if (event && content && content.href) href = content.href

    VersionManagers.currentTaskCompleted(href)
    VersionManagers.askForchecker(content)
    VersionManagers.UpdateVersion(content)

    if (href && (href === this.download.adsCurrentTask)) {
      this.download.adsCurrentTask = null
    } else if (href && href === this.download.appsCurrentTask) {
      this.download.appsCurrentTask = null
    } else if (href && href === this.download.appCurrentTask) {
      this.download.appCurrentTask = null
    }

    if (href) this._clearDownloaderSession(href)

  }

  /**
   *  ENOENT = No such file or directory
   *  ENXIO = Either "No such device or address" or "DVB: Couldn't get PAT. Couldn't reserve TUNER"
   *  TEMPORARY: to fix first ENXIO error
   */
  @sse("downloader", {subtype: "download_failed"})
  onDownloaderFailed(param) {
    let href = null
    let errorCode = null
    if (param && param.content && param.content.href) href = param.content.href
    if (param && param.content && param.content.error_code) errorCode = param.content.error_code

    if (href && (href === this.download.appCurrentTask)) {
      VersionManagers.onDownloaderFailed(true,false,VersionManagers.config.APPFILE)
    }

    if (href && (href === this.download.appsCurrentTask) && bus.universe === "popup"
    && !VersionManagers.appsCatalogVersion && errorCode !== "enxio") {
      bus.emit("appstore:downloadfailed")
    }

    if (href && (href === this.download.adsCurrentTask)) {
      bus.emit("downloader:onAdsFailed")
    }

  }

  @sse("downloader", {subtype: "download_progress"})
  onDownloaderProgress(event) {
    this.clearDwTimmer()
    let href = null
    if (event && event.content && event.content.href) href = event.content.href
    if (href && (href === this.download.appsCurrentTask || href === this.download.appCurrentTask)) {
      const value = +event.content.progress
      if (value > this.progressValue) {
        bus.emit("popup:updateProgress", event.content)
      }
    }
  }

  /* ********************************** *********************
   *                 ASSET-UPDATE SSE EVENT           *
   ********************************** ***********************/

  @sse("scan", {subtype: "asset_update"})
  onAssetUpdate(asset) {
    let uri
    let carouselId = null
    const data = asset.update.content
    const id = data.asset.id
    if (!data || !id) return

    /**
     * For ADS Configuration...
     * Store value in AdsTaskUri
     */
    if (id === DOWNLOAD.ADS) {
      uri = data["uri"]
      carouselId = data["carousel_id"]
      uri = `${uri}&pid=${carouselId}&broadcast_id=7`
      this.download.adsTaskUri = uri
    }

    /**
     * For AppS Configuration...
     * * Store value in AppsTaskUri
     */
    if (id === DOWNLOAD.APPS) {
      uri = data["uri"]
      carouselId = data["carousel_id"]
      uri = `${uri}&pid=${carouselId}&broadcast_id=7`
      this.download.appsTaskUri = uri
    }

    /**
     * Save the task uri on config webcfg...
     */
    VersionManagers.saveDvbUri(id,uri)

  }

  /* ********************************** *********************
   *                 CHECKER SSE EVENT           *
   ********************************** ***********************/

  _cleanCheckerOnceTrusted(checkerId, currentCheckerItem, checkerList, type) {
    if (currentCheckerItem && currentCheckerItem.user_data.indexOf(type) !== -1) {
      for (let i=0; i<checkerList.length; i++) {
        const checkerItem = checkerList[i]
        const isAdvertising = checkerItem.user_data.indexOf(type) !== -1
        const isCurrent = checkerItem.href === checkerId
        if (isAdvertising && !isCurrent) {
          return VersionManagers.unInstallChecker(checkerItem.href).then(() => {
            return VersionManagers.deleteChecker(checkerItem.href)
          }).then(() => {
            return Promise.resolve(` previous checker of type: '${type}' has been uninstalled and deleted`)
          })
        }
      }
    }
    return Promise.resolve(`no previous checker of type: '${type}' to clean`)
  }


  @sse("checker", {subtype: "state_changed"})
  _onCheckerStateChangeTrusted(option) {
    const newState = option.content.new_state
    const oldState = option.content.old_state
    const href = option.content.href
    const checketId = href.split("/")[2]
    const dataConfig = VersionManagers.config

    // Checker Trusted State...Process Complete
    if (newState === "state_trusted" && oldState === "state_started") {
      return Promise.all([VersionManagers.getCheckerTask(checketId), VersionManagers.getCheckers()]).then((data) => {
        const currentCheckerItem = data[0]
        const checkerList = data[1]

        const promises = [
          // Promise.resolve(),
          this._cleanCheckerOnceTrusted(checketId, currentCheckerItem, checkerList, "advertising"),
          this._cleanCheckerOnceTrusted(checketId, currentCheckerItem, checkerList, "application"),
        ]
        return Promise.all(promises)
      }).then((data) => {
        console.info(data)
        return VersionManagers.onInstallChecker(checketId)
      })
    }

    if (newState === "state_untrusted" && oldState === "state_started") {
      return VersionManagers.getCheckerTask(checketId).then((data) => {
        if (data.user_data.indexOf("advertising") !== -1) {
          return VersionManagers.setUpdateVersion(dataConfig.ADSCATALOG, "0").then(() => {
            return VersionManagers.deleteChecker(checketId)
          }).then(() => {
            return VersionManagers.onBootInstallAdsChecker()
          })
        }
      })
    }
    // Checker Install state...Process Complete
    if (newState === "state_data_installed" && oldState === "state_trusted") {
      if (VersionManagers.disableDasri) {
        PowerManager.reboot()
      }
      if (checketId === dataConfig.ADS_CHECKER_ID) {
        return VersionManagers.showResults(true,false,true,dataConfig.ADSCATALOG)
      } else if (checketId === dataConfig.APPS_CHECKER_ID) {
        this.appsPersist = true
        VersionManagers.showResults(true,false,true,dataConfig.APPSCATALOG)
      } else if (checketId === dataConfig.APPFILE_CHECKER_ID) {
        VersionManagers.showResults(true,false,true,dataConfig.APPFILE)
      } else {
        VersionManagers.showResults(true,false,true)
      }

    }

    // Checker UnInstalled.. State... Process Complete
    // if (newState === "state_trusted" && oldState === "state_data_installed") {
    //   VersionManagers.deleteChecker(checketId)
    // }
  }

  // @sse("checker", {subtype: "state_changed", content: {new_state: "state_untrusted"}})
  // _onCheckerStateChangeUnTrusted() {
  //   VersionManagers.showResults(false,true,true)
  // }
}

export default new DownloaderManager()
