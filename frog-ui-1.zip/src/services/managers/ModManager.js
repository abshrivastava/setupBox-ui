//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on,enableEvents} from "services/events"
import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import PVRManager from "services/managers/PVRManager"
import NetworkTp from "services/managers/NetworkTp"
import * as ChannelApi from "services/api/channels"
import * as popUpMsg from "app/utils/PopUpMsg"
import {_} from "utils/locale"

const MOD_DEFAULT_QUERY = {
  order: ["lcn"],
  metadata: [
    "id", "play_info", "service_id", "title", "lcn", "obj_class",
    "scrambled", "genre",
  ],
  criteria: "obj_class==CHANNEL_TV",
}

const MOD_CHANNEL_IDS = [31,32,33,34,35]

const MOD_SERVICE = {
  DISH : "4308107848",
  D2H : "249108496418",
}
class ModManager {
  constructor() {
    enableEvents(this)
    this._currentModChannel = null
    this.modServiceId = null
  }

  get currentMod() {
    return this._currentModChannel
  }

  set currentMod(lcn) {
    this._currentModChannel = lcn
  }

  @on("mod:open")
  open() {
    const serviceId = NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H ? MOD_SERVICE.D2H : MOD_SERVICE.DISH
    const channelExit = ChannelManager.getChannelFromServiceId(serviceId)
    if (channelExit && Object.keys(channelExit).length && channelExit.lcn) {
      this.load(channelExit)
    } else {
      this.modClose(null)
    }
  }

  getModChannels() {
    const temp = []
    let current = Promise.resolve()
    return Promise.all(MOD_CHANNEL_IDS.map((id) =>  {
      current = current.then(() =>  {
        MOD_DEFAULT_QUERY.criteria = `obj_class==CHANNEL_TV AND genre = ${id}`
        return ChannelApi.getChannels(MOD_DEFAULT_QUERY)
      }).then((result) =>  {
        const data = result.channels
        const dataLength = result.channels.length
        if (dataLength > 0) {
          data.forEach((value) => {
            temp.push(value)
          })
        }
        return data
      })
      return current
    })).then(function() {
      return temp
    }).catch(() => {
      return temp
    })
  }

  load(modChannels) {
    if (modChannels) {
      // Check if recording ongoing on current channel
      if (PVRManager.ongoing.length > 0) {
        bus.universe = "tv"
        return this.showZapConflictPopUp(modChannels)
      }
      this.viewMod(modChannels)
    } else {
      this.viewMod(null)
    }
  }

  _closeLegacyUniverse() {
    let i = 0
    do {
      i += 1
      const busUniverse = bus.universe
      if (busUniverse === "popup" || busUniverse === "parentalpopup") {
        bus.emit(`${busUniverse}:close`)
      } else {
        if (ChannelManager.displayMode === "infoBanner") {
          // nothing to do...
        } else if (ChannelManager.displayMode === "channelList") {
          bus.emit("tv:ChannelListClose", false)
        } else {
          bus.closeCurrentUniverse()
          bus.emit("home:close")
          bus.openUniverse("tv")
        }
        bus.emit("home:activeMenuItem", "vod")
        break
      }
    } while (i < 3)
  }

  viewMod(channel) {
    if (channel) {
      this.modClose(channel)
    } else {
      this.modClose(false)
    }
  }

  modClose(channel) {
    if (channel) {
      PlayerManager.play(channel, "channel")
      this._closeLegacyUniverse()
    } else {
      PlayerManager.play(ChannelManager.current).then(() => {
        bus.universe = "tv"
      })
      .catch(() => bus.universe = "tv")
    }
  }

  isCurrentChannelMod(channel = ChannelManager.current) {
    let genre
    let recRestriction = false
    if (channel) {
      genre = channel.genre ? channel.genre.split(",") : undefined
    }
    if (channel) {
      if (genre && genre.length) {
        for (let i=0; i<genre.length; i++) {
          genre[i] = parseInt(genre[i], 10)

          if (NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H) {
            if ((genre[i] === 32)) {
              recRestriction = true
            }
          }

          if (!recRestriction &&(genre[i] >= 31) && (genre[i] <= 35)) {
            popUpMsg.RecordBlockOnMOD()
            return 1
          }
        }
      }
    }
    return 0
  }

  showZapConflictPopUp(channel) {
    const buttons = [
      {
        label: _("Ok"),
        action: () => {
          PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
            this.viewMod(channel)
          })
        },
      },
      {
        label: "Back",
        action: () => {
          this.viewMod(null)
        },
      },
    ]
    popUpMsg.zapConflict(buttons)
  }
}

export default new ModManager()
