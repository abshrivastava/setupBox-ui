//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {dateToCdsTimestamp} from "utils/date"
import CDSQueryFactory from "services/api/cds"
import {Program} from "services/models/"

export function getCurrentProgram(channel) {
  if (!channel) {
    return Promise.resolve(null)
  }

  const serviceId = channel.serviceId
  const now = dateToCdsTimestamp(new Date())

  return this.queryPrograms()
    .filter("service_id", "==", serviceId)
    .filter("start_date", "<", now)
    .filter("end_date", ">", now)
    .direct().then((response) => {
      if (response.length) {
        return new Program(response[0])
      } else {
        return new Program({service_id: serviceId})
      }
    })
}

export function getNextProgram(channel) {
  if (!channel) {
    return Promise.resolve(null)
  }

  const serviceId = channel.serviceId
  const now = dateToCdsTimestamp(new Date())

  return this.queryPrograms()
    .filter("service_id", "==", serviceId)
    .filter("start_date", ">", now)
    .direct().then((response) => {
      if (response.length) {
        return new Program(response[0])
      } else {
        return new Program({service_id: serviceId})
      }
    })
}

export function queryPrograms() {
  return new CDSQueryFactory("programs")
    .metadata("service_id", "title", "start_date", "end_date",
    "content_nibble_level_1", "description",
    "short_description", "program_id")
    .order("+start_date")
    .limit(1)
}

export default {
  getCurrentProgram,
  getNextProgram,
}
