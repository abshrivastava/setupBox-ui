//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as ChannelApi from "services/api/channels"
import {setChannelAsFavorite} from "services/api/channel"
import {_} from "utils/locale"
import config from "utils/config"
import {setUseFavorite, getUseFavorite, setUseLinear, getUseLinear} from "services/managers/config"
import {findObjInArrayByValue, findWhere} from "utils"
import bus from "services/bus"
import {on, enableEvents} from "services/events"
import TvChannel from "services/models/channels/TvChannel"
import RadioChannel from "services/models/channels/RadioChannel"
import GenreChannel from "services/models/channels/GenreChannel"
import EpgFilterModel from "services/models/EpgFilterModel"
import ModManager from "services/managers/ModManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import PVRManager from "services/managers/PVRManager"
import ScanManager from "services/managers/ScanManager"
import PlayerManager from "services/managers/PlayerManager"
import PowerManager from "services/managers/PowerManager"
import NetworkTp from "services/managers/NetworkTp"

import CDSQueryFactory from "services/api/cds"

const DEFAULT_QUERY = {
  order: ["lcn"],
  metadata: [
    "id", "play_info", "service_id", "service_type", "title", "lcn", "obj_class",
    "scrambled", "genre",
  ],
  // criteria: "obj_class!=CHANNEL_DATA",
}
const EpgModel = new EpgFilterModel()

class ChannelManager {
  constructor() {
    this.current = null
    this.previous = null
    this._channels = []
    this._channelsMap = {}
    this.useFav = false
    this.channelsForGenre = []
    this.firstUpdate = 0
    this.setToUpdate = false
    this._displayMode = null
    this.activeServices = false
    this.genreIdOfLS = 39
    enableEvents(this)
  }

  @on("tv:zap")
  setCurrent(data) {
    this.current = data
  }

  showZapConflictPopUp(expectedChannel = null) {
    // const currentChannelName = this.ChannelList.getSelectedItem().title
    if (expectedChannel.title) {
      const currentChannelName = this.current.title
      if (expectedChannel.title !== currentChannelName) {
        const buttons = [
          {
            label: _("Ok"),
            action: () => {
              if (PVRManager.ongoing.length) {
                // Request for cancel current Recording...
                PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
                  if (expectedChannel) PlayerManager.play(expectedChannel)
                })
              } else {
                // current recording has completed, popup is opened...
                if (expectedChannel) PlayerManager.play(expectedChannel)
              }
            },
          },
          {
            label: "Back",
            action: () => {
              this.activeDelegate = null
            },
          },
        ]
        popUpMsg.zapConflict(buttons)
      }
    } else {
      // In case of conflict with MOD, compare LCN
      const currentChannelLcn = this.current.lcn
      if (expectedChannel !== currentChannelLcn) {
        const buttons = [
          {
            label: _("Ok"),
            action: () => {
              // Request to cancel current recording
              PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
                ModManager.viewMod(expectedChannel)
              })
            },
          },
          {
            label: "Back",
            action: () => {
              this.activeDelegate = null
            },
          },
        ]
        popUpMsg.zapConflict(buttons)
      }
    }
  }

  update(showScrambled, showFreeToAir) {
    // Reset Fav flag on a new scan
    setUseFavorite(false).then(() => {
      this.useFav = false
      this.useLinear = false
    })
    // Updating Process is Ongoing While SDT Changes Occur..
    ScanManager.sdtChange = true
    let criteriaFirst = null
    let criteriaSecond = null
    let criteriaThird = null

    if (NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H) {
      criteriaFirst = "scrambled==0 AND genre !='224'"
      criteriaSecond =  "scrambled==1 AND genre !='224'"
      criteriaThird = "genre !='224'"
    }

    if (NetworkTp.currentHomeTp === NetworkTp.config.TP.DISH) {
      criteriaFirst = "scrambled==0"
      criteriaSecond =  "scrambled==1"
    }

    // Update Search Criteria with Scrambled/FreeToAir filter
    const criterias = []
    if (showFreeToAir && !showScrambled) {
      criterias["scrambled"] = 0
      DEFAULT_QUERY.criteria = criteriaFirst
    } else if (!showFreeToAir && showScrambled) {
      criterias["scrambled"] = 1
      DEFAULT_QUERY.criteria = criteriaSecond
    } else {
      if (criteriaThird) {
        criterias["genre_NotEqalTo"] = "224"
        DEFAULT_QUERY.criteria = criteriaThird
      }
    }
    return this.getUseFavorite()
      .then(() => this._fetchChannels(criterias))
      .then(() => this._fetchFavoriteChannels())
      .then(() => this._fetchLinearChannels())
      .then(() => {
        if (this.channels) {
          if (this.useFav && this.favoriteChannels === 0) {
            this.unsetFavoriteListAsChannelList()
          }
          if (this.useLinear && this.linearChannels === 0) {
            this.unsetLinearListAsChannelList()
          }
          if (!PowerManager.bootTimeRunning) bus.emit("channels:updated")
        }
      })
  }

  /* **********************************
   *        GETTER/SETTER             *
   ********************************** */
  set displayMode(mode) {
    this._displayMode = mode
  }

  get displayMode() {
    return this._displayMode
  }

  get channels() {
    if (this.useFav && this.favoriteChannels.length > 0) {
      return this.favoriteChannels
    } else if (this.useLinear && this.linearChannels.length > 0) {
      return this.linearChannels
    } else {
      return this.tvChannels
    }
  }

  get tvChannels() {
    return this._channels
  }

  get favoriteChannels() {
    return this.tvChannels.filter((item) => {
      return item.favorite && item.initialState === undefined
    })
  }

  get futurFavoriteChannels() {
    return this.tvChannels.filter(item => item.favorite)
  }

  get changedChannels() {
    return this.tvChannels.filter((item) => {
      return item.initialState !== undefined
    })
  }

  /* **********************************
   *        HELPERS METHODS           *
   ********************************** */
  getServiceIdFromDVBUrl(dvbUrl) {
    try {
      const urlArr = dvbUrl.split("//")[1].split(".")
      urlArr.splice(urlArr.length-1, 1)
      let str = ""
      if (urlArr[1].length < 4) {
        str = ""
        for (let i=0; i<4-urlArr[1].length; i++) str += "0"
        urlArr[1] = str+urlArr[1]
      }
      if (urlArr[2].length < 4) {
        str = ""
        for (let i=0; i<4-urlArr[2].length; i++) str += "0"
        urlArr[2] = str+urlArr[2]
      }
      return parseInt(urlArr.join(""), 16)
    } catch (er) {
      return null
    }
  }

  getChannelFromServiceId(serviceId) {
    return this._channelsMap[serviceId] || null
  }

  getChannelFromLcn(lcn,allChannels=false) {
    return new Promise((resolve) => {

      let response
      let channels

      if (allChannels) {
        channels = this.tvChannels
      } else {
        channels = this.channels
      }
      const channel = findObjInArrayByValue(channels, Number(lcn))

      if (channel) {
        response = {
          lcn: {real: lcn, expected: Number(lcn)},
          resource: {real: channel, fallback: null},
          playing: allChannels?false:(this.current && this.current.lcn === lcn),
        }
      } else {
        response = this._findNearestChannel(lcn, allChannels)
      }

      resolve(response)
    })
  }

  getAbsoluteChannelFromLcn(lcn) {
    return new Promise((resolve) => {

      let response = null
      const channel = findObjInArrayByValue(this.channels, Number(lcn))

      if (channel) {
        response = {
          lcn: {real: lcn, expected: Number(lcn)},
          resource: {real: channel, fallback: null},
          playing: (this.current && this.current.lcn === lcn),
        }
      }
      resolve(response)
    })
  }

  getChannelZapInformation(lcn) {
    return new Promise((resolve) => {

      let response
      const channel = findObjInArrayByValue(this.channels, Number(lcn))

      if (channel) {
        response = {
          lcn: {real: lcn, expected: Number(lcn)},
          resource: {real: channel, fallback: null},
          playing: (this.current && this.current.lcn === lcn),
        }
      } else {
        response = this._findNearestChannel(lcn)
      }

      resolve(response)
    })
  }

  getTvChannelsOrderByLcn() {
    return this.tvChannels.slice().sort((a, b) => a.lcn - b.lcn)
  }

  getTvChannelsOrderByName() {
    return this.tvChannels.slice().sort((a, b) => ((a.title.toLowerCase() <= b.title.toLowerCase())) ? -1 : 1)
  }

  getTvChannelsOrderByNameFTA() {
    return this.tvChannels.slice().filter(item => !item.scrambled)
      .sort((a, b) => ((a.title.toLowerCase() <= b.title.toLowerCase())) ? -1 : 1)
  }

  getTvChannelsOrderByNameCAS() {
    return this.tvChannels.slice().filter(item => item.scrambled)
      .sort((a, b) => ((a.title.toLowerCase() <= b.title.toLowerCase())) ? -1 : 1)
  }

  /* **********************************
   *        Favorite Methods          *
   ********************************** */
  isUsingFavorite() {
    return this.useFav
  }

  setChannelFavorite(idChannel, isFavorite) {
    const channel = findWhere(this.tvChannels, {id: idChannel})
    if (channel.initialState === undefined) {
      channel.initialState = channel.favorite
    }
    channel.favorite = isFavorite
  }

  getFavoriteLength() {
    return this.favoriteChannels.length
  }

  toggleFavoriteListAsChannelList(channel,pFlag=false) {
    let promise
    if (this.useLinear) // if linear list set
      promise = this.toggleLinearListAsChannelList()
    else
      promise = Promise.resolve()

    return promise.then(() => {
      this.useFav = !this.useFav

      if (this.useFav) {
        const idx = this.favoriteChannels.indexOf(this.current)
        if (idx === -1) {
          if (pFlag) {
            if (PVRManager.ongoing.length > 0) {
              const cb = () => {
                PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
                  PlayerManager.play(this.favoriteChannels[0])
                })
              }
              const buttons = [
                {
                  label: _("Ok "),
                  action: cb,
                },
                {
                  label: _("Cancel"),
                  action: () => {
                    bus.emit("favorite:DeselectCheckbox")
                    this.activeDelegate = null
                  },
                },
              ]
              popUpMsg.FavListConflictRecording(this.current.title, buttons, cb)
            }
          } else {
            if (!PVRManager.ongoing.length) {
              PlayerManager.play(this.favoriteChannels[0])
            }
          }
        }
      } else if (channel) {
        PlayerManager.play(channel)
      }
      setUseFavorite(this.useFav)
      return Promise.resolve()
    })
  }

  unsetFavoriteListAsChannelList() {
    if (this.useFav !== false) {
      this.useFav = false
      setUseFavorite(this.useFav)
    }
    return Promise.resolve()
  }

  setFavoriteListAsChannelList() {
    if (this.useFav !== true) {
      this.useFav = true
      setUseFavorite(this.useFav)
    }
    return Promise.resolve()
  }

  getUseFavorite() {
    return getUseFavorite()
      .then((value) => {
        this.useFav = value
      })
  }

  saveFavorites(forceUpdate = false) {
    if (this.changedChannels.length) {
      const actions = this.changedChannels.map(channel => {
        delete channel.initialState
        return setChannelAsFavorite(channel.id, (channel.favorite) ? 1 : "")
      })
      if (bus.universe !== "tv") {
        if (this.useFav || this.favoriteChannels.length === 0) {
          bus.emit("channels:updated")
        } else {
          if (!this.useFav && this.favoriteChannels.length > 0) {
            bus.emit("channels:updated")
          }
        }
      }
      return Promise.all(actions)
    }
    if (forceUpdate) {
      bus.emit("channels:updated")
    }

    return Promise.resolve()
  }

  cancelFavorites() {
    if (this.changedChannels.length) {
      this.changedChannels.map(channel => {
        channel.favorite = channel.initialState
        delete channel.initialState
        return channel
      })
    }
  }

  /**
   * Query CDS direct Api for channels
   * @param {object} criterias - criterias use to filter out the query result
   * @return {Promise}
   */
  _getCdsChannels(criterias) {
    const queryFactory = new CDSQueryFactory("channels")
      .metadata("id", "play_info", "service_id", "service_type", "title", "lcn", "obj_class", "scrambled", "genre")
      .order("+lcn")
      .filter("obj_class", "==", "CHANNEL_TV")
      .filter("obj_class", "==", "CHANNEL_AUDIO")

    if (criterias) {
      for (const key of Object.keys(criterias)) {
        if (key === "genre_NotEqalTo") queryFactory.filter("genre", "!=", criterias[key])
        else queryFactory.filter(key, "==", criterias[key])
      }
    }

    return queryFactory.direct()
  }
  /* **********************************
   *        PRIVATE METHODS           *
   ********************************** */
  _findNearestChannel(lcn, allChannels=false) {
    let channels
    if (allChannels) {
      channels = this.tvChannels
    } else {
      channels = this.channels
    }

    const channelObject = {
      lcn: {real: false, expected: Number(lcn)},
      resource: {real: null, fallback: null},
      playing: (this.current && this.current.lcn === lcn),
    }

    for (const channel of channels) {
      // this.channels.items is ordered by lcn
      if (Number(channel.lcn) < channelObject.lcn.expected) {
        channelObject.resource.fallback = channel
      } else {
        break
      }
    }

    return channelObject
  }

  _fetchChannels(criterias) {
    return this._getCdsChannels(criterias).then((channels) => {
      const channels_ = []
      const channelMap_ = {}
      for (const channelData of channels) {
        let newChannel = undefined
        switch (channelData.obj_class) {
        case "CHANNEL_TV":
          newChannel = new TvChannel(channelData)
          break
        case "CHANNEL_AUDIO":
          newChannel = new RadioChannel(channelData)
          break
        default:
          continue
        }
        channels_.push(newChannel)
        channelMap_[newChannel.serviceId] = newChannel
      }
      this._channels = channels_
      this._channelsMap = channelMap_
    })
  }

  _fetchFavoriteChannels() {
    return ChannelApi.createFavoriteList({"title": "favorite TV", "obj_class": "tv_service_list"})
      .then(() => {
        return ChannelApi.getFavoriteChannels()
      })
      .then((result) => {
        const favoriteChannels = result.channels
        favoriteChannels.forEach((favoriteChannel) => {
          const channel = findWhere(this.tvChannels, {id: favoriteChannel.id})
          channel.favorite = true
        })
      })
  }

  getGenreInfo(id) {
    return EpgModel.getGenre(id)
  }

  getGenreFilterList() {
    return EpgModel.items
  }

  getGenreSubFilterList(id) {
    return EpgModel.getSecondLevelFilter(id)
  }

  getChannelsByGenre(genreId) {
    return new Promise((resolve) => {
      this.channelsForGenre = []
      let criteria = null

      if (NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H) {
        criteria = "obj_class==CHANNEL_TV AND genre !='224'"
      }

      if (NetworkTp.currentHomeTp === NetworkTp.config.TP.DISH) {
        criteria = "obj_class==CHANNEL_TV"
      }

      if (Number(genreId) === 999) {
        DEFAULT_QUERY.criteria = criteria
      } else {
        DEFAULT_QUERY.criteria = "obj_class==CHANNEL_TV AND genre IN " + "{" + genreId.join(",") + "}"
      }

      if (this.useFav) {
        DEFAULT_QUERY.criteria += " AND parent=='/channel_list/1/'"
      }

      ChannelApi.getChannels(DEFAULT_QUERY)
        .then(({channels}) => {
          DEFAULT_QUERY.criteria = "obj_class==CHANNEL_TV"
          for (const channelDataGenre of channels) {
            this.channelsForGenre.push(new GenreChannel(channelDataGenre))
          }
          resolve()
        })
    })
  }

  /* ************  Active/Linear Services  ************ */

  get linearChannels() {
    return this.tvChannels.filter((item) => {
      return item.linear && item.initialState === undefined
    })
  }

  setChannelLinear(idChannel, isLinear) {
    const channel = findWhere(this.tvChannels, {id: idChannel})
    if (channel.initialState === undefined) {
      channel.initialState = channel.linear
    }
    channel.linear = isLinear
  }

  isUsingLinear() {
    return this.useLinear
  }

  getLinearLength() {
    return this.favoriteChannels.length
  }

  toggleLinearListAsChannelList() {
    let promise
    if (this.useFav) // if fav list set
      promise = this.toggleFavoriteListAsChannelList()
    else
      promise = Promise.resolve()

    return promise.then(() => {
      this.useLinear = !this.useLinear
      setUseLinear(this.useLinear)
      return Promise.resolve()
    })
  }

  unsetLinearListAsChannelList() {
    if (this.useLinear !== false) {
      this.useLinear = false
      setUseLinear(this.useLinear)
    }
    return Promise.resolve()
  }

  setLinearListAsChannelList() {
    if (this.useLinear !== true) {
      this.useLinear = true
      setUseLinear(this.useLinear)
    }
    return Promise.resolve()
  }

  getUseLinear() {
    return getUseLinear()
      .then((value) => {
        this.useLinear = value
      })
  }

  saveLinear(forceUpdate = false) {
    if (this.changedChannels.length) {
      const actions = this.changedChannels.map(channel => {
        delete channel.initialState
        return setChannelAsFavorite(channel.id, (channel.linear) ? 1 : "")
      })
      if (bus.universe !== "tv") {
        if (this.useLinear || this.linearChannels.length === 0) {
          bus.emit("channels:updated")
        } else {
          if (!this.useLinear && this.linearChannels.length > 0) {
            bus.emit("channels:updated")
          }
        }
      }
      return Promise.all(actions)
    }
    if (forceUpdate) {
      bus.emit("channels:updated")
    }

    return Promise.resolve()
  }

  cancelLinear() {
    if (this.changedChannels.length) {
      this.changedChannels.map(channel => {
        channel.linear = channel.initialState
        delete channel.initialState
        return channel
      })
    }
  }

  _fetchLinearChannels() {
    if (!config.SD_ZAPPER) return true
    const criterias = {"genre": ""+this.genreIdOfLS}
    return this._getCdsChannels(criterias).then((linearChannels) => {
      linearChannels.forEach((linearChannel) => {
        const channel = findWhere(this.tvChannels, {id: linearChannel.id})
        channel.linear = true
      })
    })
  }

  setActiveServices() {
    console.log("****************** setActiveServices ******************")
    return this.toggleLinearListAsChannelList().then(() => {
      this.activeServices = true
      bus.emit("channels:updated")
      bus.emit("tv:channelList:open")
      return Promise.resolve()
    })
  }

  unsetActiveServices() {
    console.log("****************** unsetActiveServices ******************")
    this.activeServices = false
    return this.unsetLinearListAsChannelList().then(() => {
      bus.emit("channels:updated")
      return Promise.resolve()
    })
  }
}

export default new ChannelManager()
