//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as MediaApi from "services/api/medias"
import {isDefined} from "utils"
import {enableEvents} from "services/events"

import MediacenterEmpty from "services/models/mediacenter/MediacenterEmpty"
import Volume from "services/models/mediacenter/Volume"
import Folder from "services/models/mediacenter/Folder"
import AudioFile from "services/models/mediacenter/AudioFile"
import VideoFile from "services/models/mediacenter/VideoFile"
import ImageFile from "services/models/mediacenter/ImageFile"
import UnknownFile from "services/models/mediacenter/UnknownFile"

const VOLUME_QUERY = {object_type: ["mctr_volume"]}

class MediaCenterManager {
  constructor() {
    this.current = null
    this.history = []
    enableEvents(this)
  }

  setCurrent(media) {
    this.current = media
  }

  getHistoryPaths() {
    const historyPaths = []
    this.history.forEach((media) => {
      if (!isDefined(media.hideInHistoryPath)) {
        historyPaths.push(media.title)
      }
    })
    return historyPaths
  }

  clearHistory() {
    this.history = []
  }

  addCurrentMediaToHistory(hideInHistoryPath) {
    if (hideInHistoryPath) {
      this.current.hideInHistoryPath = true
    }
    this.history.push(this.current)
  }

  removeCurrentMediaFromHistory() {
    this.history.pop()
    this.setCurrent(this.history[this.history.length-1])
  }

  backToParent() {
    if (this.history.length > 2) {
      this.removeCurrentMediaFromHistory()
      return this.fetchChildren()
    // back to root
    } else if (this.history.length > 1) {
      this.clearHistory()
      return this.fetchVolumes()
    } else {
      return Promise.reject("No parent found for this media")
    }
  }

  loadChildren() {
    if (this.current instanceof Volume) {
      this.addCurrentMediaToHistory()
      return this.fetchGrandChildren()
    } else if (this.hasChildren()) {
      this.addCurrentMediaToHistory()
      return this.fetchChildren()
    }
    return Promise.reject("No children found for this media")
  }

  hasChildren() {
    return (this.current instanceof Folder && this.current.child_count > 0)
  }

  fetchChildren() {
    const query = {
      criteria: "parent='" + this.current.href + "'",
      order: ["title"],
    }
    return this._fetchMedias(query)
  }

  // case of volumes: jump the first child
  fetchGrandChildren() {
    return this.fetchChildren().then((medias) => {
      this.current = medias[0]
      this.addCurrentMediaToHistory(true)
      return this.fetchChildren()
    })
  }

  fetchVolumes() {
    return this._fetchMedias(VOLUME_QUERY)
  }

  /* ************************************************************************ */

  /* ********* API calls and objects models instanciation ********* */
  _fetchMedias(query) {
    const mediaModels = []
    return MediaApi.getMedias(query)
      .then(({medias}) => {
        if (medias.length) {
          for (const currentMedia of medias) {
            mediaModels.push(this._getModelFromAPIResponse(currentMedia))
          }
          return Promise.resolve(mediaModels)
        } else {
          return Promise.resolve([new MediacenterEmpty()])
        }
      })
      .catch(() => {
        return Promise.resolve([new MediacenterEmpty()])
      })
  }

  _getModelFromAPIResponse = function(media) {
    let mediaModel
    switch (media.obj_class) {
    case "mctr_videofile":
      mediaModel = new VideoFile(media)
      break
    case "mctr_imagefile":
      mediaModel = new ImageFile(media)
      break
    case "mctr_audiofile":
      mediaModel = new AudioFile(media)
      break
    case "mctr_folder":
      mediaModel = new Folder(media)
      break
    case "mctr_volume":
      mediaModel = new Volume(media)
      break
    case "mctr_anyfile":
    default:
      mediaModel = new UnknownFile(media)
      break
    }
    return mediaModel
  }
}

export default new MediaCenterManager()
