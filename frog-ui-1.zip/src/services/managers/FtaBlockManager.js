  //
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus  from "services/bus"
import {on,sse,enableEvents} from "services/events"
import * as popUpMsg from "app/utils/PopUpMsg"

import {getHomeTpWydvbUrl} from "services/managers/config"
import * as PlayerApi from "services/api/player"
import * as FTAapi from "services/api/fta"
import {getTransponderStatus} from "services/api/transponders"
import {listTune} from "services/api/scan"

import config from "utils/config"

import {
  PlayerManager,
  CasManager,
  ChannelManager,
  ScanManager,
  PowerManager,
  RechargeReminder,
  StorageManager,
  } from "services/managers"


const NO_SIGNAL_ERROR_BOOT_TIMEOUT = 15000
const FTABLOCK = Object.freeze({
  OKSTATE:true,
  NORFCONNECT: 1,
  UNABLETOTUNE:2,
  OPENHOME:3,
  VCDEACTIVATED:4,
  NOSIGNAL:5,
  RESETLENGTH:3,
  SVL:256,
})

class FtaBlockManager {
  constructor() {
    this.homeTPTimer = null
    this.ftaSubscriptionStatusMain = null
    this.ftaSubscriptionStatus = false
    this.showSignalPopUp = true
    this.subscriptionFlag = -1
    this.discriptorFlag = -1
    this.isFtaActiveState = false
    this.standbyFtaStatus = false
    this.svlForFta = null
    this.pendingState = false
    this.onAdvancedScan = false
    this.callFromBoot = false
    this.tvSignalStatus =true
    this.isFtaComplete = false
    this.ftaPopupStatus = {
      ftaFlag : false,
      navigationRestricted : false,
      popcode : null,
      popState : null,
      page : null,
      setDefault: () => {
        this.ftaPopupStatus.ftaFlag = false
        this.ftaPopupStatus.navigationRestricted = false
        this.ftaPopupStatus.popcode = null
        this.ftaPopupStatus.popState = null
        this.ftaPopupStatus.page = null
      },
    }
    enableEvents(this)
  }

  setFTAflag(s) {
    this.isFtaActiveState = s
  }

  updateFtaPopupStatus(...options) {
    const [a,b,c,d,e] = options
    if (options) {
      this.ftaPopupStatus.ftaFlag = a
      this.ftaPopupStatus.navigationRestricted = b
      this.ftaPopupStatus.popcode = c
      this.ftaPopupStatus.popState = d
      this.ftaPopupStatus.page = e
    }
  }

  isNavigationRestricted(color = "blue") {
    if (color && this.ftaPopupStatus.navigationRestricted &&
      this.ftaPopupStatus.popState && (color === "blue" || color === "yellow")) {
      return true
    } else {
      return false
    }
  }

  isDateValids(showRfSingal = true) {
    const currentYear = new Date().getFullYear()
    if (currentYear && currentYear > 1970) {
      return true
    } else {
      this.tunehomeTPForReservation()
      if (showRfSingal) this.showRfSingal()
      return false
    }
  }

  isFtaBlockMode() {
    return new Promise((resolve) => {
      this.isFtaComplete = false
      return this.checkDateAtBoot()
      .then(() => {
        this.pendingState = false
        return this.checkTunedToDefaultChannel()
      })
      .then(() => {
        return this.checkFTADescriptor()
      })
      .then((response)=> {
        this.ftaSubscriptionStatus = true
        resolve(response)
      })
      .catch((expression) => {
        this.ftaSubscriptionStatus = true
        this.onStatus(expression)
        resolve(expression)
      })
    })
  }

  checkForValidDate() {
    this.clearHomeTpTimer()
    this.isDateValids()
    this.homeTPTimer = window.setTimeout(() => {
      const currentDate = this.isDateValids(false)
      if (currentDate) {
        this.isFtaBlockMode()
      } else {
        this.checkForValidDate()
      }
    },NO_SIGNAL_ERROR_BOOT_TIMEOUT)
  }

  clearHomeTpTimer() {
    if (this.homeTPTimer) window.clearTimeout(this.homeTPTimer)
  }

  showRfSingal() {
    this.updateFtaPopupStatus(true,true,1,true,"error")
    popUpMsg.ftaSignalNotFound(CasManager.vscNumber,true)
  }

  callForErrorPage() {
    this.isFtaBlockMode()
  }

  checkDateAtBoot() {
    return new Promise((resolve,reject) => {
      const isDateValid = this.isDateValids()
      if (isDateValid) {
        return resolve(FTABLOCK.OKSTATE)
      } else {
        return reject(FTABLOCK.NORFCONNECT)
      }
    })
  }

  noTuneSignalMsg() {
    this.ftaPopupStatus.setDefault()
    popUpMsg.ftaSignalNotFound(CasManager.vscNumber,false)
    bus.universe = "tv"
    this.noSignalErrorAtDefChTunedTime = true
  }

  onStatus(expression) {
    switch (expression) {
    case 1:
      this.checkForValidDate()
      break
    case 2:
      this.noTuneSignalMsg()
      break
    case 3:
      this.showHomeMenu()
      break
    default:
      // console.log("default")
    }
  }

  /** function:: showHomeMenu()
   * open Home if STB is active and No-Signal.....
   *
   *   :function  playCurChannel :: Tune to current channel
   *   :function  refreshStorage : to refresh the details of USB if connected
   */
  showHomeMenu() {
    this.setFTAflag(false)
    this.ftaPopupStatus.setDefault()

    if (!PowerManager.bootTimeRunning && !ScanManager.isFirstInstall) {
      this.isClose("stb")
    }

    if ((!PowerManager.isStandbyState && !PowerManager.bootTimeRunning && !ScanManager.isFirstInstall)) {
      if (PlayerManager._state) {
        PlayerManager._state === 10 && this.playCurChannel()
      } else {
        this.playCurChannel()
      }
      bus.openUniverse("home")
    }

    if (StorageManager.USB_key) {
      popUpMsg.UsbEstablished()
    }

    if (!PowerManager.bootTimeRunning) {
      RechargeReminder.expoReminder(false,true)
    }

    if (!PowerManager.bootTimeRunning && !config.PVR_DISABLED) {
      this.refreshStorage()
    }

    this.isFtaComplete = true
    this.callFromBoot = false
  }

  refreshStorage() {
    StorageManager.checkDataStorage()
  }

  checkTunedToDefaultChannel() {
    return new Promise((resolve,reject) => {
      const checkPlayerSignal = this.tvSignalStatus
      if (checkPlayerSignal) {
        PlayerApi.getRFConnectionStatus(PlayerManager.id)
        .then((value)=> {
          this.tvSignalStatus = false
          if (value.tvsignal === 0) {
            return reject(FTABLOCK.UNABLETOTUNE)
          } else {
            return resolve(FTABLOCK.OKSTATE)
          }
        })
        .catch(() => {
          return reject(FTABLOCK.UNABLETOTUNE)
        })
      } else {
        return resolve(FTABLOCK.OKSTATE)
      }
    })
  }

  checkFTADescriptor() {
    return new Promise((resolve,reject) => {
      return FTAapi.getFTAdescriptorStatus()
      .then((response) => {
        if (!response.ftaBlocking) {
          this.setFTAflag(true)
          this.discriptorFlag = response.ftaBlocking
          return this.checkFTASubscriptionStatus().then((response) => {
            return resolve(response)
          })
        } else {
          return reject(FTABLOCK.OPENHOME)
        }
      })
      .catch(() => {
        return reject(FTABLOCK.OPENHOME)
      })

    })
  }

  vcDeactivatedMsg() {
    this.updateFtaPopupStatus(true,true,"301",true,"error")
    popUpMsg.vcDeactivated(CasManager.vscNumber)
  }

  noTuneSignalNavigationRestricted() {
    this.updateFtaPopupStatus(true,true,"301",true,"error")
    popUpMsg.ftaSignalNotFound(CasManager.vscNumber,true)
  }

  stopPlayer() {
    if (PlayerManager.state !== "STOPPED") PlayerManager.stop().catch(()=>{})
  }

  checkFTASubscriptionStatus() {
    return new Promise((resolve,reject)=>{
      return FTAapi.getFTAsubscriptionStatus()
        .then((response) => {
          const ftaBlockStatus = response.FTABlockStatus
          RechargeReminder.absoluteEndDate = response.ActualEndDate
          this.subscriptionFlag = ftaBlockStatus
          this.ftaSubscriptionStatusMain = ftaBlockStatus
          if (ftaBlockStatus) {
            let homeTpUri = null
            // this.ftaSubscriptionStatus = true
            this.stopPlayer()
            this.vcDeactivatedMsg()
            getHomeTpWydvbUrl().then((uri) => {
              homeTpUri = uri
              return listTune()
            })
            .then((tuner) => {
              let currentTPUri = false
              if (tuner && tuner.tunes[0] && tuner.tunes[0].wydvb_uri) {
                currentTPUri = tuner.tunes[0].wydvb_uri
              }
              // Condition :: if : No need to tune to Home Tp as we're already in Home TP
              // Condition :: Else :: we're not in HomeTp so tune to HomeTp is needed
              if (homeTpUri && currentTPUri && this.compareHomeTP(homeTpUri,currentTPUri)) {
                // tuner.tunes[0].frontend_state :: if : Rf is Disconnected..
                // tuner.tunes[0].frontend_state :: Else :: is On VCDEACTIVATED State..
                if (tuner.tunes[0].frontend_state === "allowed_unlocked") {
                  this.noTuneSignalNavigationRestricted()
                  return resolve(FTABLOCK.NOSIGNAL)
                } else {
                  return resolve(FTABLOCK.VCDEACTIVATED)
                }
              } else {
                const encodeHomeTpUri = encodeURIComponent(homeTpUri)
                getTransponderStatus(encodeHomeTpUri)
                .then(() => {
                  // if (result && result.agc)
                  return resolve(FTABLOCK.VCDEACTIVATED)
                })
              }
            })
            .catch(() => {
              this.noTuneSignalNavigationRestricted()
              return resolve(FTABLOCK.NOSIGNAL)
            })
          } else {
            return reject(FTABLOCK.OPENHOME)
          }
        })
        .catch(()=>{
          return reject(FTABLOCK.OPENHOME)
        })
    })
  }

  compareHomeTP(homeURI, curURI) {
    const {frequency : frequencyHom, symbol_rate : symbol_rateHom, polarity : polarityHom} =  this.getUrlParams(homeURI)
    const {frequency : frequencyCur, symbol_rate : symbol_rateCur, polarity : polarityCur} = this.getUrlParams(curURI)
    if (frequencyHom === frequencyCur && symbol_rateHom === symbol_rateCur && polarityHom === polarityCur) {
      return true
    } else {
      return false
    }
  }

  getUrlParams(uri) {
    const hashes = uri.slice(uri.indexOf("?") + 1).split("&")
    const params = {}
    hashes.map(hash => {
      const [key, val] = hash.split("=")
      params[key] = decodeURIComponent(val)
    })
    return params
  }

  checkFirstInstall() {
    ScanManager.checkSvlVersionChange()
    .then((resp) => {
      if (resp === "launchEasyScan") {
        return true
      } else {
        return false
      }
    })
  }

  _closeLegacyUniverse() {
    let i = 0
    do {
      i += 1
      const busUniverse = bus.universe
      if (busUniverse === "popup" || busUniverse === "parentalpopup") {
        bus.emit(`${busUniverse}:close`)
      } else {
        bus.closeCurrentUniverse()
        bus.emit("home:close")
        this.stopPlayer()
        break
      }
    } while (i < FTABLOCK.RESETLENGTH)
  }

  isClose(page) {
    switch (page) {
    case "error":
      bus.emit("blackuniverse:hide")
      break
    case "stb":
    case "tp":
      bus.emit("STBInfoSheet:close")
      bus.emit("ftaBlockManager:close")
      break
    default:
      // console.log("default")
    }
  }

  playCurChannel(forceToPlay = false) {
    if (PlayerManager._state && PlayerManager._state !== 11 && !forceToPlay) {
      if (ChannelManager.current) {
        PlayerManager.play(ChannelManager.current, "channel")
      } else {
        ScanManager.tuneDefaultChannel()
      }
    } else if (forceToPlay) {
      if (ChannelManager.current) {
        PlayerManager.play(ChannelManager.current, "channel")
      }
    } else {
      if (ChannelManager.current) {
        PlayerManager.play(ChannelManager.current, "channel")
      } else {
        ScanManager.tuneDefaultChannel()
      }
    }
  }

  @on("fta:pending_state")
  callPendingState(timerForFTA = 1000) {
    const self = this
    this.pendingState = false
    this._closeLegacyUniverse()
    this.ftaPopupStatus.setDefault()

    window.setTimeout(()=> {
      self.isFtaBlockMode()
    },timerForFTA)
  }

  closeFtaMode() {
    this.isClose(this.ftaPopupStatus.page)
    this.ftaPopupStatus.setDefault()
    this.isFtaBlockMode()
    this.playCurChannel()
  }

  tunehomeTPForReservation() {
    let homeTpUri = null
    getHomeTpWydvbUrl()
    .then((uri) => {
      homeTpUri = uri
      return listTune()
    })
    .then((tuner) => {
      let currentTPUri = false
      if (tuner && tuner.tunes[0] && tuner.tunes[0].wydvb_uri) {
        currentTPUri = tuner.tunes[0].wydvb_uri
      }
      // Condition :: if : No need to tune to Home Tp as we're already in Home TP
      // Condition :: Else :: we're not in HomeTp so tune to HomeTp is needed
      if (homeTpUri && currentTPUri && this.compareHomeTP(homeTpUri,currentTPUri)) {
      } else {
        const wydvbUri = encodeURIComponent(homeTpUri)
        getTransponderStatus(wydvbUri).then(() => {})
        .catch(() => {})
      }
    })
    .catch((error) => console.log("Fail to Tune Home Tp :: ",error))
  }
  /* ***********************************************
  *** FTABlockStatus_info Event Received ***
  **** ftablock_desc_info Event Received ***
  *****************************************************/

  @sse("scan", {subtype: "FTABlockStatus_info"})
  _onFTAblockStatusChange(response) {
    let timerForFTA = 0
    // ** Condition :: Avoid Pending State if Flag are Same.... **//
    if (this.subscriptionFlag !== response.content.FTABlockStatus) this.pendingState = true

    if (!PowerManager.bootTimeRunning) {
      // Update the Force Slider if FC is under Grace Peroid
      PowerManager.CheckForceSliderGracePeriods()
      // Update the Default Counter if LC is under Grace Peroid
      PowerManager._showDefaultChannel(false,false,true,false)
    }

    // ** Condition :: this.subscriptionFlag ::  return if -1 **//
    // ** Condition :: this.subscriptionFlag  ::  return if MW return same fta status infomation...  **//
    // ** Condition :: this.svlForFta ::  return if it is First Install... **//
    // ** Condition :: ScanManager.running  ::  return if Scan is Running and Take its pritios on Scan comeplete  **//
    // ** Condition :: PowerManager.isStandbyState::Avoid When STB is on standby and Take Action When STB is Resume**//

    if (this.subscriptionFlag ===-1 || this.subscriptionFlag === response.content.FTABlockStatus ||
      this.svlForFta === FTABLOCK.SVL || ScanManager.isFirstInstall || ScanManager.running
      || PowerManager.isStandbyState) {
      this.subscriptionFlag = response.content.FTABlockStatus
      return
    }

    this.clearHomeTpTimer()
    this.subscriptionFlag = response.content.FTABlockStatus
    this.isFtaActiveState = response.content.FTABlockStatus
    this.standbyFtaStatus = response.content.FTABlockStatus
    if (response.content.FTABlockStatus) timerForFTA = 1000

    // ** Condition :: if ::  moving from FTA to normal operation **//
    // ** Condition :: Else  ::  moving from Normal operation to FTA  **//
    if (this.ftaPopupStatus.ftaFlag) {
      this.closeFtaMode()
    } else {
      this.callPendingState(timerForFTA)
    }
  }

  @sse("scan", {subtype: "ftablock_desc_info"})
  _onFTAdescriptionChange(response) {
    let timerForFTA = 0

    // ** Condition :: Avoid Pending State if Flag are Same.... **//
    if (this.discriptorFlag !== response.content.fta_block) this.pendingState = true

    // ** Condition :: this.discriptorFlag ::  return if -1 **//
    // ** Condition :: this.discriptorFlag  ::  return if MW return same fta desc infomation...  **//
    // ** Condition :: this.svlForFta ::  return if it is First Install... **//
    // ** Condition :: ScanManager.running  ::  return if Scan is Running and Take its pritios on Scan comeplete  **//
    // ** Condition :: PowerManager.isStandbyState ::Avoid When STB is on standby and Take Action When STB is Resume**//

    if (this.discriptorFlag === -1 || this.discriptorFlag === response.content.fta_block ||
      this.svlForFta === FTABLOCK.SVL|| ScanManager.isFirstInstall || ScanManager.running
      || PowerManager.isStandbyState) {
      this.discriptorFlag = response.content.fta_block
      return
    }

    this.clearHomeTpTimer()
    this.discriptorFlag = response.content.fta_block
    if (response.content.fta_block) timerForFTA = 1000

    // ** Condition :: if ::  moving from FTA to normal operation **//
    // ** Condition :: Else  ::  moving from Normal operation to FTA  **//
    if (this.ftaPopupStatus.ftaFlag) {
      this.closeFtaMode()
    } else {
      this.callPendingState(timerForFTA)
    }
  }

  @sse("scan", {subtype: "tune_state_update"})
  _onSingalStatusChanged(response) {
    if (this.ftaSubscriptionStatus && this.ftaPopupStatus.page === "error") {
      if (response.content.frontend_state === "allowed_unlocked") {
        this.noTuneSignalNavigationRestricted()
      } else if (response.content.frontend_state === "allowed_locked") {
        this.ftaSubscriptionStatus = false
        this.isFtaBlockMode()
      }
    }
  }

}

export default new FtaBlockManager()
