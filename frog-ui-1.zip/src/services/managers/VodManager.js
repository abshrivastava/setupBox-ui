//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {findWhere} from "utils"
import {_} from "utils/locale"
import {POST, formUrlencoded} from "services/http"

import VodItem from "services/models/vod/Item"
import NetworkManager from "services/managers/NetworkManager"

import anConfig from "app/config/alphanetworks.json"

const AN_IMG_HEIGHT = 180
const AN_IMG_WIDTH = 121
const AN_ENDPOINT = anConfig.endpointURL
const AN_DEFAULT_OPTIONS = {
  headers: {
    "Accept": "application/json",
    "X-AN-WebService-IdentityKey": anConfig.identityKey,
    "Content-Type": "application/x-www-form-urlencoded",
  },
}

class VodManager {
  constructor() {
    this.token = null
    this.productId = null
    this.categories = []
    this.assets = []
    this.packages = []
    this.subscribedPackages = []
    this.activeAssets = []
    this.offers = []
    this.validityOffers = []
  }

  /* ************************************************************************ */

  /* ********* Authentication ********* */
  login() {
    if (!NetworkManager.connected) {
      return Promise.reject(_("No internet connection."))
    }
    return this.anlogin(this.getFormattedMacAdress())
      .then((result) => this.token = result.newAuthToken)
      .catch((err) => {
        if (err && err.message === "Not valid.") {
          return Promise.reject(_("Mac adress isn't valid."))
        }
        return Promise.reject(err.message)
      })
  }

  getFormattedMacAdress() {
    return NetworkManager.current.mac_address.replace(/:/g, "").toUpperCase()
  }

  /* ************************************************************************ */

  /* ********* Initialization and categories building ********* */
  loadCatalogue() {
    this.assets = []
    return this.loadCategories()
      .then(() => this.loadAssets())
  }

  loadCategories() {
    return this.fetchCategories()
      .then((categories) => this.categories = categories)
  }

  loadAssets() {
    const promises = []
    this.categories.forEach((category) => {
      promises.push(this.loadAssetsFromCategory(category))
    })

    return Promise.all(promises)
  }

  loadAssetsFromCategory(category) {
    return this.fetchAssetsFromCategory(category, category.idCatalog)
      .then((result) => this.buildAssets(result.items, category))
  }

  buildAssets(assets, category) {
    assets.forEach((asset) => {
      this.assets.push(new VodItem(asset, category))
    })
  }

  /* ************************************************************************ */

  /* ********* Playback ********* */
  playAsset(asset) {
    return this.readAsset(asset)
      .then((result) => this.onPlayAssetSuccess(result, asset))
      .catch((result) => this.onPlayAssetError(result))
  }

  onPlayAssetSuccess(result, asset) {
    asset.url = result.url
    return Promise.resolve()
  }

  onPlayAssetError(result) {
    if (result && result.message) {
      return Promise.reject(result.message)
    } else {
      return Promise.reject(_("[vod]PlayAssetError"))
    }
  }

  /* ************************************************************************ */

  /* ********* T-VOD ********* */
  rentAsset(asset, voucherCode) {
    return this.buyAsset(asset, voucherCode)
      .then(() => this.loadActiveAssets())
      .catch((result) => this.onRentAssetError(result))
  }

  onRentAssetError(result) {
    if (result && result.message) {
      return Promise.reject(result.message)
    } else {
      return Promise.reject(_("[vod]RentAssetError"))
    }
  }

  /* ************************************************************************ */

  /* ********* S-VOD ********* */
  initializeSVod() {
    return this.loadProducts()
      .then(() => this.loadActiveAssets())
      .then(() => this.loadOffers())
      .then(() => this.loadPackages())
      .then(() => this.buildSVODPackages())
  }

  loadProducts() {
    return this.fetchProducts()
      .then((result) => this.productId = result.productIds[0])
  }

  loadActiveAssets() {
    return this.fetchActiveAssets()
      .then((result) => this.activeAssets = result.activeAssets)
  }

  loadOffers() {
    return this.fetchOffers()
      .then((result) => this.offers = result.options)
  }

  loadPackages() {
    return this.fetchPackages()
      .then((result) => this.packages = result.packages)
  }

  buildSVODPackages() {
    return this.loadValidOffers()
      .then(() => this.buildPackages())
  }

  loadValidOffers() {
    return this.fetchValidOffers()
      .then((result) => this.validityOffers = result.options)
  }

  buildPackages() {
    this.subscribedPackages = []
    this.offers.forEach((currentOffer) => {
      currentOffer.objectIds.forEach((packId) => {
        this.bindOfferAndPack(packId, currentOffer)
      })
    })
    return Promise.resolve()
  }

  bindOfferAndPack(packId, offer) {
    const pack = findWhere(this.packages, {idPackage: packId})
    if (pack) {
      pack.price = offer.priceWithVat
      this.addToSubscribedPackages(offer, pack)
    }
  }

  addToSubscribedPackages(offer, pack) {
    if (this.isOfferContainsPack(offer, pack) && this.isValidOffer(offer)) {
      pack.isBuy = true
      this.subscribedPackages.push(pack)
    }
  }

  buyPack(offer, voucherCode) {
    return this.startPackTransaction(offer, voucherCode)
      .then((result) => this.onBuyPackSuccess(result, offer))
      .catch((result) => this.onBuyPackError(result))
  }

  onBuyPackSuccess(result, offer) {
    if (result.transactionId) {
      return this.finishBuyPackTransaction(offer, result.transactionId)
    } else {
      return Promise.reject(_("[vod]BuyPackError"))
    }
  }

  onBuyPackError(result) {
    if (result && result.message) {
      return Promise.reject(result.message)
    } else {
      return Promise.reject(_("[vod]BuyPackError"))
    }
  }

  /**
    Expected behavior is to get an error with the message "Nothing to pay"...
    Others case are not expected => to see to AN side
  **/
  finishBuyPackTransaction(offer, transactionId) {
    return this.transactionValidate(transactionId)
      .then(() => this.onBuyPackError(err))
      .catch((err) => {
        if (err.message && err.message === "Nothing to pay") {
          return this.buildSVODPackages()
            .then(() => this.onBuyPackTransactionFinished(offer))
        } else {
          return this.onBuyPackError(err)
        }
      })
  }

  onBuyPackTransactionFinished(offer) {
    if (this.isValidOffer(offer)) {
      return Promise.resolve()
    } else {
      return Promise.reject(_("[vod]BuyPackError"))
    }
  }

  /* ************************************************************** */

  /* ********* Categories and Assets utilities ********* */
  getCategories() {
    return this.categories
  }

  getSubscribedPackages() {
    return this.subscribedPackages
  }

  getAssetsFromCategory(category) {
    return this.assets.filter((asset) => {
      return asset.categoryId === category.idCatalog
    })
  }

  getAssetsFromPack(pack) {
    return this.assets.filter((asset) => {
      return pack.assets.includes(asset.id)
    })
  }

  getOfferFromAsset(id) {
    let assetOffer = null
    this.offers.forEach((offer) => {
      // offer with id 1 will be removed on AN backend
      if (offer.idOption !== 1 && this.isOfferContainsPack(offer, this.getPackFromAsset(id))) {
        assetOffer = offer
      }
    })
    return assetOffer
  }

  getPackFromAsset(id) {
    return this.findPackForAssetInList(id, this.packages)
  }

  getActivePackFromAsset(id) {
    return this.findPackForAssetInList(id, this.subscribedPackages)
  }

  isAssetRented(id) {
    return findWhere(this.activeAssets, {idAsset: id})
  }

  findCategoryByName(name) {
    return findWhere(this.categories, {name:name})
  }

  findPackForAssetInList(id, packageList) {
    let assetPack = null
    packageList.forEach((currentPackage) => {
      if (currentPackage.assets.includes(id)) {
        assetPack = currentPackage
      }
    })
    return assetPack
  }

  isValidOffer(offer) {
    const currentOffer = findWhere(this.validityOffers, {optionId: offer.idOption})
    return (currentOffer &&
      (currentOffer.statusId === 10 || // unlimited offer
      (currentOffer.statusId === 40 && // limited offer in time
      this.isOfferActive(currentOffer))))
  }

  isOfferActive(offer) {
    return (offer.validTo * 1000 > new Date().getTime())
  }

  isOfferContainsPack(offer, pack) {
    return offer.objectIds.includes(pack.idPackage)
  }

  /* ************************************************************** */

  /* ********* API calls utilities ********* */
  anUrl(path) {
    return AN_ENDPOINT + path
  }

  anPOST(path, body, withoutHeader) {
    const options = {}
    if (!withoutHeader) {
      options.headers = Object.assign(
        {},
        AN_DEFAULT_OPTIONS.headers,
        {
          "X-AN-WebService-CustomerAuthToken": this.token,
        },
      )
    } else {
      options.headers = Object.assign(
        {},
        AN_DEFAULT_OPTIONS.headers,
      )
    }

    return POST(this.anUrl(path), body, options)
      .then(this.anDetectError)
  }

  anDetectError(resp) {
    const response = JSON.parse(resp.data)
    if (response.status) {
      return Promise.resolve(response.result)
    } else {
      return Promise.reject(response.error)
    }
  }

  getAssetImageUrl(id) {
    const params = formUrlencoded({
      objectId: id,
      languageId: _("[vod]anLanguage"),
      format_w: AN_IMG_WIDTH,
      format_h: AN_IMG_HEIGHT,
      ratio: 23,
      type: 510, // This is the type code for assets
    })

    return this.anUrl(`imgdata?${params}`)
  }

  anlogin(macAdress) {
    const body = {
      serial: macAdress,
      mac: macAdress,
    }

    return this.anPOST("loginBox", body)
  }

  fetchCategories() {
    const body = {
      languageId: _("[vod]anLanguage"),
    }

    return this.anPOST("hierarchy", body)
      .then((result) => {
        return result.hierarchy[0].categories
      })
  }

  fetchAssetsFromCategory(category, id) {
    const body = {
      languageId: _("[vod]anLanguage"),
      id: id,
    }

    return this.anPOST("listAssets", body, true)
  }

  buyAsset(asset, voucherCode) {
    const body = {
      languageId: _("[vod]anLanguage"),
      idAsset: asset.id,
      price: asset.price,
    }

    if (voucherCode) {
      body.voucherCode = voucherCode
    }

    return this.anPOST("buyAsset", body)
  }

  readAsset(asset) {
    const body = {
      languageId: _("[vod]anLanguage"),
      idAsset: asset.id,
      idAudioLang: _("[vod]anLanguage"),
      idSubtitleLang: "non",
    }

    return this.anPOST("readAsset", body)
  }

  fetchActiveAssets() {
    const body = {
      languageId: _("[vod]anLanguage"),
    }

    return this.anPOST("activeAssets", body)
  }

  fetchProducts() {
    return this.anPOST("activeProducts", {})
  }

  fetchOffers() {
    const body = {
      languageId: _("[vod]anLanguage"),
      productId: this.productId,
    }

    return this.anPOST("listOptions", body)
  }

  fetchPackages() {
    return this.anPOST("listPackages", {})
  }

  fetchValidOffers() {
    const body = {
      productId: this.productId,
    }

    return this.anPOST("optionsValidity", body)
  }

  startPackTransaction(offer, voucherCode) {
    const body = {
      typeId: 4, // typeId for options
      objectId: offer.idOption,
      displayPrice: offer.priceWithVat,
      currency: _("[vod]anCurrency"),
      voucherCode: voucherCode,
      noRestriction: false,
    }

    return this.anPOST("transactionAddItem", body)
  }

  transactionValidate(transactionId) {
    const body = {
      transactionId: transactionId,
      paymentData: JSON.stringify({"paymentProvider":"1","policyValidation":true}),
    }

    return this.anPOST("transactionValidate", body)
  }
}

export default new VodManager()
