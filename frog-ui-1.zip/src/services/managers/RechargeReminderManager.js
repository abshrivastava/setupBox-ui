//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

import * as RechargeReminderApi from "services/api/recharge_reminder"
import bus from "services/bus"
import {sse, enableEvents} from "services/events"
import * as FTAapi from "services/api/fta"
import * as PVRReminder from "services/api/reminder"
import FtaBlockManager from "services/managers/FtaBlockManager"
import PowerManager from "services/managers/PowerManager"
import ScanManager from "services/managers/ScanManager"
import ProgramReminder from "services/managers/ProgramReminder"
import {RechargeReminderLastAlert, RechargeReminderAlert}  from "app/utils/PopUpMsg"


const DEFAULT_REMINDER_OPTIONS = {
  "start_time": null,
  "name":"RechargeReminder",
  "class": "direct_manual",
  "is_active": "0",
  "user_data": "RechargeReminder",
  "frequency": null,
  "duration": 100,
}

const TIME = Object.freeze({
  HALF_HOUR: 1800,
  ONEHOUR: 3600,
  TWOHOUR: 7200,
  DAY: 86400,
  FIVEDAY: 432000,
  SIXDAY: 518400,
  SEVENDAY: 604800,
  EIGHTDAY : 691200,
  SCHEDULEDAY: 691199,
})

const  RETAINREMINDER  = Object.freeze({
  ISPENDING :1,
  SHOW:2,
  HIDE : 3,
  IGNORE:0,
})


class RechargeReminder {
  constructor() {
    this.absoluteEndDate = null
    this.showReminderSchedule = null
    this.setReminderID = null
    this.remainingDay = null
    this.isPendingRemender = false
    this.currentTask = null
    this.conflictTask = null
    enableEvents(this)
  }

  /** function:: expoReminder(notify)
   * Check for the absolute End Date of STB...
   *
   *   :checkAbsoluteEndDate :: ignore if it request from boot time.. as request is made already..
   *   :setReminderHour :: set the Reminder Hour to Populate Recharge Reminder Notification
   *   :pompReminder :: Modify Reminder Schedule for Next Notification else Create a New One...
  */
  expoReminder(notify = false,onBoot = false) {
    this.isPendingRemender = false
    this.checkAbsoluteEndDate(onBoot)
    .then(() => {
      return this.setReminderHour(this.absoluteEndDate)
    })
    .then((value) => {
      if (value) this.pompReminder(notify,false)
    })
    .catch(() => {})
  }

  /** function:: pompReminder(notify)
   * Notify User for Subscribution End..::)
   *
   *   :isAlreadySchedule :: Take descision to modify current Reminder/Create New..
   *   :deleteReminder :: Delete current Schedule Recharge Reminder..
   *   :setNextRechargeSchedule :: Create New Schedule Recharge Reminder..
   *   :showNotification :: Populate notification of Recharge Reminder...
  */
  pompReminder(notify,actScheduleAlert = false) {
    this.isAlreadySchedule()
    .then((response) => {
      if (response)
        return this.deleteReminder(response)
      else
        return true
    })
    .then(() => {
      return this.setNextRechargeSchedule(actScheduleAlert)
    })
    .then(() => {
      if (notify) {
        this.showNotification()
      }
    })
    .catch(() => {})
  }

  // show Recharge Reminder Notification..
  showNotification() {
    const showReminder = this.retainReminder()
    if (showReminder === 2) {
      const dayRemain = this.remainingDay
      if (dayRemain === 0) {
        RechargeReminderLastAlert()
        bus.emit("popup:exitTrue")
      } else {
        if (dayRemain > 0) RechargeReminderAlert(dayRemain)
        bus.emit("popup:exitTrue")
      }
    }
  }

  // Check for Subscribution End Date of current STB..
  checkAbsoluteEndDate(isFromBoot = false) {
    return new Promise((resolve) => {
      if (isFromBoot) {
        resolve(true)
      } else {
        FTAapi.getFTAsubscriptionStatus().then((response) => {
          const actualEndDate = response.ActualEndDate
          this.absoluteEndDate = actualEndDate
          resolve(true)
        }) .catch(() => {
          resolve(true)
        })
      }
    })
  }

  /** function:: setReminderHour(absoluteEndDate)
   * Condition to show Notification..
   * check :: (Absolute end date – current date) > 7 => Set Hour for Schedule Notification
   *
   *   :: if Remaining Day (0-4.. first 5day from 7day..) set Schedule Notification from (current time+2 hour)
   *   :: if Remaining Day (7-5..last 2day from 7day..) set Schedule Notification from (current time +1 hour)
   *   ::  else :: setScheduleSubscribtionEnd => Operate Normaly.. @ set the Schedule Notification if STB run continues
   *   ... till (Absolute end date – current date) > 8
  */
  setReminderHour(absoluteEndDate = this.absoluteEndDate) {
    return new Promise((resolve) => {
      const currentDate = Math.round(new Date().getTime()/1000.0)
      const diffDays = ((absoluteEndDate - currentDate))
      this.remainingDay = Math.floor(diffDays / TIME.DAY)

      if (diffDays < TIME.FIVEDAY) {
        this.showReminderSchedule = 1
        resolve(true)
      } else if (diffDays  < TIME.EIGHTDAY) {
        this.showReminderSchedule = 2
        resolve(true)
      } else {
        this.showReminderSchedule = null
        this.setScheduleSubscribtionEnd(absoluteEndDate).then((epochTime) => {
          if (epochTime) {
            return this.pompReminder(false,epochTime)
          } else {
            return false
          }
        })
        .then(() => {
          resolve(false)
        })
      }
    })
  }

  /** function:: setScheduleSubscribtionEnd(absoluteEndDate)
   * set Schedule Notification for feature...When STB Run continues...
   *
   *   :: return  (Absolute end date – SCHEDULEDAY)
  */
  setScheduleSubscribtionEnd(absoluteEndDate) {
    return new Promise((resolve) => {
      let time = null
      const remainingDay = absoluteEndDate - TIME.SCHEDULEDAY
      if (remainingDay > 0) {
        time = remainingDay
        resolve(time)
      } else {
        resolve(false)
      }
    })
  }

  /** function:: isAlreadySchedule()
   * check for Reminder Scheduled Subscribution alert
   *
   *   :: if already Reminder Subscribution than Reply to Modigy it...
   *   :: Else Reply to Create New Reminder Subscribution Alert..
  */
  isAlreadySchedule() {
    return new Promise((resolve) => {
      this.searchReminder().then((response) => {
        if (response) {
          this.setReminderID = response[0].id
          const id = response[0].id
          resolve(id)
        } else {
          resolve(false)
        }
      })
    })
  }

  // set Reminder Subscribution Alert...
  setNextRechargeSchedule(actScheduleAlert) {
    return new Promise((resolve) => {
      const options = Object.assign({}, DEFAULT_REMINDER_OPTIONS)
      if (actScheduleAlert) {
        options.start_time = actScheduleAlert
        options.frequency = actScheduleAlert
      } else {
        const time = this.aheadTime()
        options.start_time = time
        options.frequency = time
      }
      RechargeReminderApi.set(options).then(() => {
        resolve(true)
      }).catch(() => {
        resolve(false)
      })

    })
  }


  /** function:: aheadTime()
   * check for Reminder Scheduled Repeated time..
   *
   *   :: return (0-4.. first 5day from 7day..) set Repatation of Schedule Notification for 2hour
   *   :: if Remaining Day (7-5..last 2day from 7day..) set Repatation of Schedule Notification for 1hour
  */
  aheadTime() {
    let time = null
    const currentTime = Math.round(new Date().getTime()/1000.0)
    if (this.showReminderSchedule === 1) {
      time = currentTime + TIME.HALF_HOUR
    } else if (this.showReminderSchedule === 2) {
      time = currentTime + TIME.ONEHOUR
    }
    return time
  }

  // Search for RechargeReminder if Not schedule Return False
  searchReminder() {
    return new Promise((resolve) => {
      RechargeReminderApi.search("RechargeReminder")
      .then((response) => {
        if (response.length > 0) {
          resolve(response)
        } else {
          resolve(false)
        }
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  modify(id,option) {
    return new Promise((resolve) => {
      RechargeReminderApi.modify(id,option)
      .then((response) => {
        resolve(response)
      })
      .catch(() => {
        resolve(null)
      })
    })
  }

  // Modify Reminder Subscribution Alert...
  modifyRechargeSchedule() {
    return new Promise((resolve) => {
      const options = {}
      const id = this.setReminderID
      const time = this.aheadTime()
      options.start_time = time
      options.frequency = time
      this.modify(id,options).then(() => {
        resolve(true)
      }).catch(() => {
        resolve(false)
      })
    })
  }

  // Delete the Request Reminder...
  deleteReminder(id) {
    return new Promise((resolve) => {
      RechargeReminderApi.remove(id)
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  retainReminder() {
    let value = null
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    const isOnStandby = PowerManager.isStandbyState
    const isScanRunning = ScanManager.running
    if (isFtaBlock) {
      value = RETAINREMINDER.IGNORE
    } else if (isOnStandby) {
      value = RETAINREMINDER.HIDE
    }  else if (isScanRunning) {
      value = RETAINREMINDER.HIDE
    } else {
      value = RETAINREMINDER.SHOW
    }
    return value
  }

  /* ********** SSE Event handling for Recharge Reminder Subscribution Alert ********* */
  @sse("alert", {subtype: "alertUp"})
  _onScheduleDeleted(data) {
    if (data.content.name !== "RechargeReminder") {
      const busUniverse = bus.universe
      if (busUniverse && busUniverse !== "bigbang" && busUniverse !== "popup") {
        ProgramReminder.lastlegency = busUniverse
      }
      ProgramReminder.onDisplayReminder(data)
      PVRReminder.deleteAlert(data.content.id)
      return
    }
    const value = this.retainReminder()

    switch (value) {
    case 0:
      // Ignore Rechare Reminder..
      break
    case 1:
      this.isPendingRemender = false
      break
    case 2:
      this.expoReminder(true)
      break
    case 3:
      this.expoReminder(true)
      break
    default:
    }
    if (data.content.name === "RechargeReminder") {
      // Update the Default Counter if LC is under Grace Peroid
      PowerManager._showDefaultChannel(false,false,true,false)
      // Update the Force Slider if FC is under Grace Peroid
      PowerManager.CheckForceSliderGracePeriods()
    }
  }
}
export default new  RechargeReminder()
