//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import bus from "./bus"

export class AvoidMultipleEvent {
  constructor() {
    this.needLogs = true
    this.avoidKey = null
    this.passEvent = false
    this.prevTime = null
    this.currTime = ""
    this.keyHistory = {"beforePrev":"", "prev": "", "curr": ""}
    this.timer = null
    this.wait = 2000
    this.btnComb = []
    this.createBtnComb()
  }
  printLog(msg) {
    if (this.needLogs)  console.log("[avoidEvent]===>" + msg)
  }
  createBtnComb() {
    this.btnComb[config.KEYMAP.KEY_GREEN + "_" + config.KEYMAP.KEY_RED] = "green_red"
    this.btnComb[config.KEYMAP.KEY_RED + "_" + config.KEYMAP.KEY_YELLOW] = "red_yellow"
    this.btnComb[config.KEYMAP.KEY_GREEN + "_" + config.KEYMAP.KEY_YELLOW] = "green_yellow"
    this.btnComb[config.KEYMAP.KEY_BLUE + "_" + config.KEYMAP.KEY_YELLOW] = "blue_yellow"
  }
  isBtnCombination(param) {
    if (this.btnComb[param["prev"] + "_" + param["curr"]]) return true
  }
  isNumKey() {
    if (config.KEYMAP.ANY_NUMERIC.indexOf(this.keyHistory["curr"]) !== -1) {
      return true
    }
  }
  isBackKey(ev) {
    if (this.keyHistory["curr"] === config.KEYMAP.BACK) {
      if (this.keyHistory["beforePrev"] === this.keyHistory["prev"]
      && this.keyHistory["prev"] === this.keyHistory["curr"]) {
        this.avoidKey = this.keyHistory["curr"]
        this.timer = window.setTimeout(()=>this.doPassEvent(ev), this.wait)
      }
      return true
    }
  }
  isNavigationKey() {
    let flag = false
    switch (this.keyHistory["curr"]) {
    case config.KEYMAP.UP:
    case config.KEYMAP.DOWN:
    case config.KEYMAP.RIGHT:
    case config.KEYMAP.LEFT:
      flag = true
      break
    default:
      flag = false
      break
    }
    return flag
  }
  restKeyHandling(ev) {
    if (this.keyHistory["beforePrev"] !== this.keyHistory["prev"]
    && this.keyHistory["prev"] !== this.keyHistory["curr"]
    && this.keyHistory["beforePrev"] !== this.keyHistory["curr"]) {
      this.avoidKey = this.keyHistory["curr"]
      this.timer = window.setTimeout(()=>this.doPassEvent(ev), this.wait)
    } else {
      return true
    }
  }
  isInWaitRange() {
    this.currTime = new Date()
    this.currTime = this.currTime.getTime()
    const timeDiff = (this.currTime - this.prevTime)/1000
    if (timeDiff<this.wait/1000) {
      return true
    }
  }
  updateKeyHistory(ev) {
    this.keyHistory["beforePrev"] = this.keyHistory["prev"]
    this.keyHistory["prev"] = this.keyHistory["curr"]
    this.keyHistory["curr"] = ev.keyCode
  }
  doPassEvent(ev) {
    window.clearTimeout(this.timer)
    bus.handleRcuEvent(ev.keyCode, "press", ev)
    const ev2 = ev
    window.setTimeout(()=> {
      bus.emit("window:keyPressed", ev2.keyCode, ev2.key)
      bus.handleRcuEvent(ev2.keyCode, "release", ev2)
      ev.preventDefault()
    },0)
  }
  resetVal() {
    this.avoidKey = null
    this.passEvent = false
    window.clearTimeout(this.timer)
  }
  filterEvent(ev) {
    this.resetVal()
    this.updateKeyHistory(ev)
    if (this.isNumKey()) {
      this.passEvent = true
    } else if (this.isBtnCombination(this.keyHistory)) {
      this.passEvent = true
    } else if (this.isNavigationKey()) {
      this.passEvent = true
    } else {
      if (this.prevTime && this.isInWaitRange()) {
        if (this.isBackKey(ev)) this.passEvent = true
        else this.passEvent = this.restKeyHandling(ev)
      } else {
        this.passEvent = true
      }
      this.prevTime = this.currTime
    }
    return this.passEvent
  }
}

export default new AvoidMultipleEvent()