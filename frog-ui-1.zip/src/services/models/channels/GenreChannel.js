//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
// import config from "utils/config"

@Model.defineAttributes({
  id: {
    from: "href",
    convert: x => x.split("/")[2],
  },
  title: {
    default: "Unknown",
  },
  lcn: {
    convert: x => parseInt(x, 10),
  },
  scrambled: {
    from: "scrambled",
    convert: x => x === "1",
  },
  playInfo: {
    from: "play_info",
  },
  serviceId: {
    from: "service_id",
  },
  serviceType: {
    from: "service_type",
  },
  ott: {
    from: "ott",
    default: false,
  },
  genre: {
    from: "genre",
    convert: x => x.split(",")[1],
  },
  /* logo: {
    from: "title",
    convert: x => `http://${config.STB_IP}${config.LOGO_BASE}${x}.png`,
  },*/
})
export default class GenreChannel extends Model {
}
