//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"


function _getHourFromDelay(delay) {
  const d = Math.trunc(delay/3600)
  switch (true) {
  case (d <= -10):
    return `-${Math.abs(d)}`
  case (d < 0 && d > -10):
    return `-0${Math.abs(d)}`
  case (d >= 0 && d < 10):
    return `+0${d}`
  case (d >= 10):
    return `+${d}`
  }
}

function _getMinFromDelay(delay) {
  const m = Math.abs(delay % 3600 / 3600 * 60)
  if (Math.abs(m) < 10) {
    return `0${m}`
  }
  return m
}

function _getGMT(delay) {
  const hour = _getHourFromDelay(delay)
  const minutes = _getMinFromDelay(delay)
  return `(GMT ${hour}:${minutes})`
}

@Model.defineAttributes({
  gmt: {
    from: "timezone",
    convert: x => _getGMT(x),
  },
  timezone: {
    from: "timezone",
  },
  dayLight: {
    from: "daylight",
  },
  name: {
    from: "name",
  },
})
export default class TimezoneModel extends Model {

}
