//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import {getCategory} from "utils/dvb"

@Model.defineAttributes({
  id: {
    from: "id",
  },
  _title: {
    from: "title",
  },
  _userContent: {
    from: "user_content",
  },
  playInfo: {
    from: "play_info",
  },
  startDate: {
    from: "start_date",
    convert: x => new Date(x * 1000),
  },
  endDate: {
    from: "end_date",
    convert: x => new Date(x * 1000),
  },
  status: {
    from: "status",
  },
  lastPosition: {
    from: "position",
    convert: x => parseInt(x, 10),
  },
  recordCategory: {
    from: "content_nibble_level_1",
    convert: (x) => getCategory(x),
  },
})
export default class Record extends Model {
  get title() {
    return this._title
  }
  get userContent() {
    if (this._userContent) {
      return JSON.parse(this._userContent)
    } else {
      return {
        title: this._title,
        channelTitle : "",
      }
    }
  }

  get description() {
    return this.userContent._description || this.userContent._short_description || ""
  }

  get category() {
    return this.userContent.category || this.recordCategory || ""
  }

  get channelTitle() {
    return this.userContent.channelTitle
  }

  get duration() {
    if (this.endDate < this.startDate) {
      return null
    }
    return ~~((this.endDate - this.startDate) / 1000)
  }
}
