//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import {formatPlayInfo} from "utils/medias"

@Model.defineAttributes({
  id: {
    from: "id",
  },
  title: {
    from: "title",
  },
  href: {
    from: "href",
  },
  parent: {
    from: "parent",
  },
  playInfo: {
    from: "play_info",
    convert: x => formatPlayInfo(x),
  },
  size: {
    from: "size",
  },
  child_count: {
    from: "child_count",
  },
  objClass: {
    from: "obj_class",
  },
  category: {
    from: "category",
  },
  album: {
    from: "album",
  },
  artist: {
    from: "artist",
  },
  track: {
    from: "track",
  },
  channels: {
    from: "channels",
  },
  length: {
    from: "length",
  },
  year: {
    from: "year",
  },
  samplerate: {
    from: "samplerate",
  },
  bitrate: {
    from: "bitrate",
  },
})

export default class AudioFile extends Model {}
