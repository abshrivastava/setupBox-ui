//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import {_} from "utils/locale"

export default class EpgFilterModel extends Model {

  constructor(props = {}) {
    super(props)

    this.items = [
      {title: _("HD Channels"), id: 23},
      {title: _("Entertainment"), id: 4},
      {title: _("Movies"), id: 1},
      {title: _("Music & Lifestyle"), id: 2},
      {title: _("Sports"), id: 8},
      {title: _("News & Business"), id: 6},
      {title: _("Kids & Infotainment"), id: 5},
      {title: _("Family & Devotional"), id: 11},
      {title: _("Regional"), id: 888},
      {title: _("All Channels"), id: 999},
    ]

    this.subFilterItem = [
      // {title: _("All"), id: 999},
      // {title: _("HD"), id: 23},
      {title: _("Hindi"), id: 44},
      {title: _("English"), id: 45},
    ]

    this.regionalItems = [
      {title: _("Punjabi"), id: 13},
      {title: _("Marathi"), id: 46},
      {title: _("Gujarati"), id: 17},
      {title: _("Oriya"), id: 14},
      {title: _("Bangla"), id: 15},
      {title: _("Assamese/North East"), id: 27},
      {title: _("Bihar"), id: 26},
      {title: _("Urdu"), id: 29},
      {title: _("Regional Hindi"), id: 28},
      {title: _("Telugu"), id: 19},
      {title: _("Kannada"), id: 18},
      {title: _("Tamil"), id: 20},
      {title: _("Malayalam"), id: 21},
    ]
  }

  getGenre(id) {
    const genreTitle = this.items.filter((obj) => {
      if (obj.id === parseInt(id)) {
        return obj
      }
    })[0]

    if (typeof genreTitle !== "undefined") {
      return genreTitle.title
    }   else {
      return ""
    }
  }

  getFirstLevelFilter() {
    return this.items
  }

  getSecondLevelFilter(id) {
    if (id === 888) {
      return this.regionalItems
    } else {
      return this.subFilterItem
    }

  }

  getRegionalFilter() {
    return this.regionalItems
  }



}
