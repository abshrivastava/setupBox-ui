//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, POST, PUT, DELETE, createQueryString} from "../http"

export function getAll() {
  return GET("/player/")
}

export function get(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }
  return GET(`/player/${id}/`)
}

export function create(body) {
  return POST("/player/", body)
}

export function destroy(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return DELETE(`/player/${id}/`)
}

export function play(id, payload) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return PUT(`/player/${id}/play`, payload)
}

export function stop(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return PUT(`/player/${id}/stop`)
}

export function pause(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return PUT(`/player/${id}/pause`)
}

export function setSpeed(id, speed) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return PUT(`/player/${id}/speed/`, {speed})
}

export function getSpeed(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return GET(`/player/${id}/speed/`)
}

export function getPosition(id, posType = "mr_pos_abs_time") {
  const queryString = createQueryString({
    pos_type: posType,
  })
  return GET(`/player/${id}/position/${queryString}`)
}

export function seek(id, body) {
  return PUT(`/player/${id}/seek`, body)
}
export function getRFConnectionStatus(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }
  return GET(`/player/${id}/signal_status/`)
}

export function frameDisplay() {
  return GET("/avio/player/WyPlayer/")
}

export default {
  getAll,
  get,
  create,
  destroy,
  play,
  stop,
  pause,
  setSpeed,
  getSpeed,
  getPosition,
  seek,
  getRFConnectionStatus,
  frameDisplay,
}
