
//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT} from "../http"

export function getTransponderCompleteData(diseqcRef, if2if_mode_status) {
  return GET (`/scanplugin/transponder_set/${diseqcRef}/?if2if_mode_status=${if2if_mode_status}`)
}
export function getTranspondersList() {
  return GET("/scan/transponder_set/9998/transponder/")
}

export function getTranspondersInfo(no) {
  return GET(`/scanplugin/transponder_set/9998/transponder/${no}/`)
}
export function getCurrentTransponder(serviceId) {
  return GET(`/scan/transponder/service/${serviceId}`)
}

export function getCurrentTransponderDetails(serviceId) {
  return GET(`/scan/signal_quality/?service_id=${serviceId}`)
}

export function getTransponderStatus(wydvbUri) {
  return GET(`/scan/signal_status/?wydvb_uri=${wydvbUri}`)
}

export function getcurrentTPSignalStatus(tune_id,tone_enabled) {
  return GET(`/scan/signal_status_on_current_tp/?tune_id=${tune_id}&tone_enabled=${tone_enabled}`)
}

export function getToneForTP(params) {
  return PUT("/software/playtone/",params)
}

export function stopToneForTP() {
  return PUT("/software/stoptone/")
}

export function subscriptionStatus() {
  return GET("/subscription/status/")
}

export default {
  getTransponderCompleteData,
  getTranspondersList,
  getTranspondersInfo,
  getCurrentTransponder,
  getCurrentTransponderDetails,
  getTransponderStatus,
  getToneForTP,
  stopToneForTP,
  subscriptionStatus,
}
