//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT} from "../http"

/** function:: myAccount
 * Gets MyAccount Data
 *
 *   :param Object options:
 *
 *  "acntInfo_str": {
 *    "ActualEndDate": 756510,
 *    "VSCNumber": 2499991000,
 *      "RechargeAmountInINR": 400,
 *        "RechargeDate": 787252
 *   }
 *  }
 *   :returns Promise:
 */

// API getting for CAS account data
export function getMyAccountDetails() {
  return GET("/account/data/")
}

// API getting for CAS information
export function getAccessStatus() {
  return GET("/current/access/")
}

// API getting for CRI information
export function getCriStatus() {
  return GET("/service/cristatus/")
}

// API getting for CA Menu
export function getCaMenu() {
  return GET("/ca_menu/info/")
}

// API for HD Channel price information
export function getPriceTag(serviceId) {
  return GET(`/price_tag/${serviceId}/`)
}

export function setInstantMessageFlag(params) {
  return PUT("/message/displayed/", params)
}

export default {
  getMyAccountDetails,
  getAccessStatus,
  getCriStatus,
  getCaMenu,
  getPriceTag,
  setInstantMessageFlag,
}
