//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

/** class:: List(items)
 *
 *  :param Array<> items: Items.
 */
export default class List {
  constructor(items) {
    /** attribute:: items
     * Items to store in List Object
     *
     *   :type: Array
     */
    this.items = []

    /** attribute:: count
     * Number of item
     *
     *   :type: Int
     */
    this.count = 0

    this.update(items)
  }

  [Symbol.iterator]() {
    return this.items[Symbol.iterator]()
  }

  /** attribute:: length
   * Returns the length of the List
   *
   *   :returns Int: Number of items in the list
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c"])
   *    list.length //=> 3
   */
  get length() {
    return this.count
  }

  /** function:: get(index)
   * Returns item at specified index
   *
   *   :param Int index: List Index
   *   :return Object: Item at the index
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c"])
   *    list.get(1) //=> "b"
   */
  get(index) {
    // if (this.count === 0) {
    //   throw new Error("empty list")
    // }
    // if (index < 0 || index >= this.count) {
    //   throw new Error("out of range")
    // }
    return this.items[index]
  }

  /** function:: set(index, value)
   * Set item at specified index
   *
   *   :param Int index: List Index
   *   :param Object value: Item to put in list
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c"])
   *    list.set(2 "C") //=> ["a", "b", "C"]
   */
  set(index, value) {
    // if (this.count === 0) {
    //   throw new Error("empty list")
    // }
    // if (index < 0 || index >= this.count) {
    //   throw new Error("out of range")
    // }
    this.items[index] = value
  }

  /** function:: push(...items)
   * Appends items at the end of the List
   *
   *   :param ?Object items: Items to append
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c"])
   *    list.push("d", "e") //=> ["a", "b", "c", "d", "e"]
   */
  push(...items) {
    this.items.push(...items)
    this.count += items.length
  }

  /** function:: indexOf(item)
   * Returns index of specified item
   *
   *   :param ?Object item: Item
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c"])
   *    list.indexOf("c") //=> 2
   */
  indexOf(item) {
    return this.items.indexOf(item)
  }

  /** function:: update(items)
   * Update items
   *
   *   :param ?Object items: Items to put in the List
   *
   * .. code-block:: js
   *
   *    const list = new List()
   *    list.update(["a", "b", "c"]) //=> ["a", "b", "c"]
   */
  update(items) {
    items = items || []
    items = Array.isArray(items) ? items : [items]
    this.items = items
    this.count = items.length
  }

  /** function:: getRange(start, length)
   * Return all items in the specified range
   *
   *   :param Int start: Index
   *   :param Int length: Number of items to return
   *   :returns Array:
   *
   * .. code-block:: js
   *
   *    const list = new List(["a", "b", "c", "d", "e", "f"])
   *    list.getRange(2, 2) //=> ["c", "d"]
   */
  getRange(start, length) {
    const range = []

    const add = length < 0 ? range.unshift : range.push
    const s = length < 0 ? start + length + 1 : start
    const e = length < 0 ? start + 1 : start + length
    const list = this

    for (let i = s; i < e; i++) {
      add.apply(range, [(i < 0 || i >= list.count) ? null : list.get(i)])
    }

    return range
  }
}
