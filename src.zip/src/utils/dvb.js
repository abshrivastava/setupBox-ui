//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

const CATEGORIES = {
  "cat_0x0": "",
  "cat_0x1": "Movie",
  "cat_0x2": "News",
  "cat_0x3": "Show",
  "cat_0x4": "Sports",
  "cat_0x5": "Youth",
  "cat_0x6": "Music",
  "cat_0x7": "Arts/Culture",
  "cat_0x8": "Social/Politics",
  "cat_0x9": "Education",
  "cat_0xA": "Leisure hobbies",
  "cat_0xB": "",
  "cat_0xC": "",
  "cat_0xD": "",
  "cat_0xE": "",
  "cat_0xF": "Serie",
}

/**function:: utils.dvb.getCategory(nibbleLevel1)
 * Return a category from given nibble 1 value
 *
 *   :param int nibbleLevel1: Nibble to translate
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    getCategory(1) // => "Movie"
 */
export function getCategory(nibble1) {
  return CATEGORIES["cat_0x" + parseInt(nibble1, 10).toString(16).toUpperCase()] || ""
}

export default {
  getCategory,
}
