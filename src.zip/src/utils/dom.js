//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {noop} from "./"

/**function:: utils.dom.pushState(domNode, bemState, willTransition, className)
 * Adds a new class on specific Element
 *
 *   :param Element domNode: DOM Element to push new class
 *   :param String bemState:
 *   :param Boolean willTransition:
 *   :param String className:
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    pushState(document.getElementById("body"), "selected", false, "item")
 */
export function pushState(domNode, bemState, willTransition, className) {
  const stateClassName = computeStateClass(domNode, bemState, className)

  if (domNode.classList.contains(stateClassName)) {
    return Promise.resolve()
  }

  return mutateState(domNode, "add", stateClassName, willTransition)
}

/**function:: utils.dom.pullState(domNode, bemState, willTransition, className)
 * Removes a class on specific Element
 *
 *   :param Element domNode: DOM Element to push new class
 *   :param String bemState:
 *   :param Boolean willTransition:
 *   :param String className:
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    pushState(document.getElementById("body"), "selected", false, "item")
 */
export function pullState(domNode, bemState, willTransition, className) {
  const stateClassName = computeStateClass(domNode, bemState, className)

  if (!domNode.classList.contains(stateClassName)) {
    return Promise.resolve()
  }

  return mutateState(domNode, "remove", stateClassName, willTransition)
}

/**function:: utils.dom.addTransitionListener(domNode, callback)
 * Registers the specified callback on the Element it's called on.
 *
 *   :param Element domNode: DOM Element
 *   :param Function callback: function
 */
export function addTransitionListener(domNode, callback) {
  domNode.addEventListener("webkitTransitionEnd", callback, true)
}

/**function:: utils.dom.removeTransitionListener(domNode, callback)
 * Unregisters the specified callback on the Element it's called on.
 *
 *   :param Element domNode: DOM Element
 *   :param Function callback: function
 */
export function removeTransitionListener(domNode, callback) {
  domNode.removeEventListener("webkitTransitionEnd", callback, true)
}

/**function:: utils.dom.disableTransitions(domNode)
 * Adds a class u-noTransitions on Element
 *
 *   :param Element domNode: DOM Element
 */
export function disableTransitions(domNode) {
  domNode.classList.add("u-noTransitions")
}

/**function:: utils.dom.restoreTransitions(domNode, callback)
 * Removes class u-noTransitions from Element
 *
 *   :param Element domNode: DOM Element
 */
export function restoreTransitions(domNode) {
  domNode.classList.remove("u-noTransitions")
}

/**function:: utils.dom.waitReflow(domNode)
 * Force reset of any Element animation
 *
 *   :param Element domNode: DOM Element
 */
export function waitReflow(domNode) {
  noop(domNode.offsetHeight)
}

/**function:: utils.dom.clearNode(node)
 * Remove all children of an Element
 *
 *   :param Element node: DOM Element
 */
export function clearNode(node) {
  while (node.firstChild) {
    node.removeChild(node.firstChild)
  }
}

function computeStateClass(domNode, state, originalClassName) {
  const className = originalClassName || domNode.classList[0]

  return className ? `${className}--${state}` : `u--${state}`
}

function mutateState(domNode, method, className, willTransition) {
  return new Promise((resolve, reject) => {
    if (willTransition) {
      const transitionCb = (ev) => {
        if (ev.target !== domNode) {
          return
        }

        removeTransitionListener(domNode, transitionCb)
        const hasClass = ev.target.classList.contains(className)
        if (method === "add" && !hasClass || method === "remove" && hasClass) {
          // reject the Promise because the transition result is not the
          // expected, the className has not been add(ed)/remove(d) in the end.
          reject("mutateState: transition result: the className has not been add(ed)/remove(d) in the end.")
        } else {
          resolve()
        }
      }

      addTransitionListener(domNode, transitionCb)
    }

    domNode.classList[method](className)

    if (!willTransition) {
      resolve()
    }
  })
}
