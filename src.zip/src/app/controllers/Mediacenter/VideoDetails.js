//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {on} from "services/events"
import {$} from "widgets/Component"
import {TreeObj} from "app/utils/widgets/lists"

export default class VideoDetailsController extends Controller {
  constructor() {
    super()
    this.selected = 0
    this.actions = []
    this.view = $("videoDetails")
    this.tree = new TreeObj(this.view.actionsTree)
  }

  open(item) {
    this.selected = 0
    this.actions = this._actionsFactory()
    this.tree.setItems(0, this.actions)

    return this.view.open(item)
  }

  @on("VideoDetails:close")
  close() {
    this.tree.reset()
    return this.view.close()
  }

  up() {
    this.tree.up()
  }

  down() {
    this.tree.down()
  }

  right() {
    this.tree.right()
  }

  left() {
    this.tree.left()
  }

  trigger() {
    this.tree.trigger()
  }

  _actionsFactory() {
    const actions = [{
      label: "Play",
      signal: "mediacenter:play",
    }]

    return actions
  }
}
