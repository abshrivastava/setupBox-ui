//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import {ListObj} from "app/utils/widgets/lists"
import {pushState, pullState} from "utils/dom"
import {_} from "utils/locale"
import bus from "services/bus"
import {setEntry} from "services/managers/config"
import {on} from "services/events"
import {NetworkTp} from "services/managers"

const ZERO_INDEX = 0
const PAGE_SIZE = 2

export default class FINetworkController extends Controller {

  constructor() {
    super()
    this.view = $("firstInstall_Network")
    this.NetworkSelected = true
    this.selected = false
    this.options = [{
      name: _("Next"),
      action: "FirstInstall:next",
    }]
    this.list = 0
  }

  open() {
    bus.emit("settings:FINetwork")
    this.updateScreen()
    this.view.show()
    this.NetworkSelected = true
    return Promise.resolve()
  }

  updateScreen() {
    this.loadFINetworks(ZERO_INDEX, PAGE_SIZE)
    this.view.loadItems(this.options)
  }

  close() {
    this.view.hide()
  }

  loadFINetworks() {
    this.newFINetworkArr = [{label: NetworkTp.config.TP.DISH_Label, value: NetworkTp.config.TP.DISH},
      {label: NetworkTp.config.TP.D2H_Label, value: NetworkTp.config.TP.D2H}]
    this.NetworkListObj = new ListObj(this.newFINetworkArr,this.view.fINetworkList)
    this.newFINetworkArr.forEach((obj, i) => {
      if (obj.value === "D2H_OFF") {
        this.currNetwork = obj.label
        this.NetworkListObj.select(i)
      }
    })
  }

  setNetwork(idx) {
    const network = this.newFINetworkArr[idx].value
    this.view.highlightDefault(idx)
    setEntry("scan","NetworkHomeTp",network).then(() => {
      this.selected = true
      NetworkTp.currentHomeTp = network
      bus.emit("network:selection")
      this.onRight()
    })
  }

  @on("FirstInstall:next")
  firstInstallNext() {
    this.view.hide()
    bus.emit("network:scan")
  }

  onOk() {
    if (this.NetworkSelected) {
      this.setNetwork(this.view.fINetworkList.focusedIdx)
    } else {
      const signal = this.options[0].action
      bus.emit(signal, this.currNetwork)
    }
  }

  onUp() {
    if (this.NetworkSelected) {
      this.NetworkListObj.up()
    }
  }

  onDown() {
    if (this.NetworkSelected) {
      this.NetworkListObj.down()
    }
  }

  onRight() {
    if (this.NetworkSelected && this.selected) {
      this.NetworkSelected = false
      pushState(this.view.fINetworkList.selector.FINetworkSelector, "hidden")
      this.view.menuListNetwork.onFocusRight(this.list)
    }
  }

  onLeft() {
    if (!this.NetworkSelected) {
      this.NetworkSelected = true
      this.selected = false
      pullState(this.view.fINetworkList.selector.FINetworkSelector, "hidden")
      this.view.menuListNetwork.onFocusLeft(this.list)
    }
  }

}
