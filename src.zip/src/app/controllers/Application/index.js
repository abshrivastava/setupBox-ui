//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import throttle from "popmotion-throttle"
import Controller from "utils/Controller"
import {$} from "widgets/Component"
import bus from "services/bus"
import {on, rcu} from "services/events"
import {factoryReset} from "services/api/reset"
import {uiReady} from "services/api/pvr"
import config from "utils/config"

import {translate} from "app/utils/locale"
import {getDiseqcType, getHomeTP, setLastTunedLcn} from "services/managers/config"

import {
  ScanManager,
  ChannelManager,
  PVRManager,
  AppsManager,
  StorageManager,
  PowerManager,
  VersionManagers,
  LedManager,
  ModManager,
  ComboButton,
  CamManager,
  RechargeReminder} from "services/managers"

import Dasri from "./Dasri"
import DevToolBar from "./DevToolBar"
import AdBanner from "./AdBanner"
import Clock from "./Clock"
import Splash from "./Splash"
import Volume from "./Volume"
import PopUp from "./PopUp"
import ParentalPopUp from "./ParentalPopUp"
import UnsubscribedErrorMsg from "./UnsubscribedErrorMsg"

const BOOT = Object.freeze({
  INSTALLATION:"installation",
  SCAN: "launchEasyScan",
  HOME:"home",
  FTA_ACTIVE:3,
  FTA_BLOCK:"block",
})


export default class ApplicationController extends Controller {
  static delegates = [
    AdBanner,
    Clock,
    Splash,
    Volume,
    PopUp,
    ParentalPopUp,
    UnsubscribedErrorMsg,
    Dasri,
  ]

  constructor() {
    if (config.DEBUG) {
      ApplicationController.delegates.push(DevToolBar)
    }

    super()
    this.activeDelegate = this.Splash
    this.throttleVolumeUp = throttle(() => {
      this.Volume.volumeUp()
    }, 500)
    this.throttleVolumeDown = throttle(() => {
      this.Volume.volumeDown()
    }, 500)
    this._longpressVolume =  undefined
    this.view = $("application")
    this.diseqcVal = null
  }

  @on("locale:translate")
  _onTranslate() {
    translate()
  }

  @on("application:scale")
  _onScale(value) {
    this.view.setScale(value)
  }

  @on("application:output")
  _onOutput(value) {
    this.view.setAnalog(value)
  }

  @on("dasri")
  _onDasri(data) {
    if (data.content.enabled && data.content.enabled === true) {
      VersionManagers.disableDasri = false
      bus.closeCurrentUniverse()
      bus.openUniverse("dasri")
    } else {
      VersionManagers.disableDasri = true
    }
  }

  /** function:: initialize()
   * On Boot open the application.....
   *
   *   :function  onBootInstallAdsChecker :: Install checker on boot
   *   :function  getAdsCatalogVersion : get Ads Version
   *   :function  onFlyDownload :: Trigger on Ads fly Downoad
   *   :function  checkDataStorage : check for External Hard Disk
   *
   *   :function  checkCamStatusAtBoot :: check for Cam status..
   *   :function  expoReminder : check for Reminder
   *   :function  uiReady :: Inform SRS UI is Ready..
   */
  @on("application:open")
  open() {
    let params
    PowerManager.bootTimeRunning = true
    this.Splash.startup().then((param) => {
      params = param
      this.activeDelegate = null
      return Promise.all([getDiseqcType(), getHomeTP()])
    })
    .then(([diseqcVal, homeTP]) => {
      ScanManager.homeTP = homeTP
      if (params === BOOT.INSTALLATION) {
        this.diseqcVal = diseqcVal
        bus.emit("FirstInstall:openNetwork")
      } else if (params === BOOT.SCAN) {
        this.launchEasyScan(diseqcVal,false)
      } else if (params === BOOT.HOME) {
        bus.openUniverse("home")
      }
    })
    .then(() => {
      bus.emit("boot:medium-priority")
    })
    .then(() => {
      return this.consfigSplashLandingChannel()
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION) ? VersionManagers.getAdsCatalogVersion() : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION) ? VersionManagers.getAppsCatalogVersion() : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION) ? VersionManagers.getDownLoadUri() : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION) ? VersionManagers.onBootInstallAdsChecker() : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION &&  params !== BOOT.SCAN) ?
      VersionManagers.onFlyDownload(true) : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION) ? VersionManagers.onBootInstallAppsChecker() : null
    })
    .then(() => {
      return uiReady()
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION &&  params !== BOOT.SCAN && !config.PVR_DISABLED) ?
      StorageManager.checkDataStorage(true) : null
    })
    .then(() => {
      return (params !== BOOT.INSTALLATION &&  params !== BOOT.SCAN) ? CamManager.checkCamStatusAtBoot() : null
    })
    .then(() => {
      (params !== BOOT.INSTALLATION &&  params !== BOOT.SCAN) ?
      RechargeReminder.expoReminder(true,true) : null

      PowerManager.bootTimeRunning = false

      if (PowerManager.isStandbyState) {
        bus.universe = "standby"
        bus.emit("power:standby")
      }

    })
    .catch(() => {
      (params !== BOOT.INSTALLATION ||  params !== BOOT.SCAN) ?
      RechargeReminder.expoReminder(true,true) : null

      PowerManager.bootTimeRunning = false

      if (PowerManager.isStandbyState) {
        bus.universe = "standby"
        bus.emit("power:standby")
      }

    })
  }

  @on("network:scan")
  firstInstall() {
    if (this.diseqcVal) {
      bus.emit("scan:diseqcUpdate", this.diseqcVal)
      bus.openUniverse("settings")
      bus.emit("scan:launchEasyScan",{"univ":null,"scanType":"EASY_SCAN"})
    } else {
      bus.openUniverse("home")
    }
  }

  launchEasyScan(diseqcVal,isStandbyState = false) {
    const state = isStandbyState ? "resume" : "home"
    bus.emit("scan:diseqcUpdate", diseqcVal)
    bus.openUniverse("settings")
    ScanManager.svlDvbUri = true
    bus.emit("scan:launchEasyScan",{"univ":state,"scanType":"EASY_SCAN"})
  }

  consfigSplashLandingChannel() {
    // Check NIT Version Increase...
    // Check for LC,FC,GracePeriods Update Entry.
    ScanManager.checkNitVersion()
    .then((version) => {
      if (version) {
        ScanManager._updateForceLandingChannel()
      } else {
        // Update the Default Counter if LC is under Grace Peroid
        PowerManager._showDefaultChannel(false,false,true,false)
        // Update the Force Slider if FC is under Grace Peroid
        PowerManager.CheckForceSliderGracePeriods()
      }
    })
    .catch(() => {
      // Update the Default Counter if LC is under Grace Peroid
      PowerManager._showDefaultChannel(false,false,true,false)
      // Update the Force Slider if FC is under Grace Peroid
      PowerManager.CheckForceSliderGracePeriods()
    })
  }

  @on("conflict:tuner")
  _onTunerConflict(schedule) {
    switch (bus.universe) {
    case "tv":
    case "home":
    case "epg":
    case "settings":
      !schedule.isAlert && bus.emit("tv:conflict:tuner", schedule, bus.universe)
      break
    case "pvr":
    case "popup":
      !schedule.isAlert && bus.emit("pvr:conflict:tuner", schedule)
      break
    case "appstore":
      !schedule.isAlert && bus.emit("appstore:conflict:tuner", schedule)
      break
    default:
      LedManager.SetRecordOpen()
      ChannelManager.current = ChannelManager.getChannelFromServiceId(schedule.serviceId || schedule.service_Id)
      setLastTunedLcn(ChannelManager.current.lcn)
    }
  }


  @on("tv:myfiles:press")
  @rcu("tv:myfiles:press")
  @rcu("epg:myfiles:press")
  @rcu("settings:myfiles:press")
  @rcu("home:myfiles:press")
  @rcu("appstore:myfiles:press")
  _openMyFiles() {
    if (!config.SD_ZAPPER && !ScanManager.isFirstInstall && !ScanManager.running) {
      bus.closeCurrentUniverse()
      bus.emit("home:close")
      bus.emit("home:activeMenuItem", "pvr")
      bus.openUniverse("pvr")
    }
  }

  @on("tv:myacc:press")
  @rcu("tv:myacc:press")
  @rcu("epg:myacc:press")
  @rcu("settings:myacc:press")
  @rcu("home:myacc:press")
  @rcu("pvr:myacc:press")
  @rcu("appstore:myacc:press")
  _openMyAccount() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.closeCurrentUniverse()
      bus.emit("home:close")
      window.setTimeout(()=>{
        bus.openUniverse("settings")
      },500)
    }
  }

  @on("tv:mod:press")
  @rcu("tv:mod:press")
  @rcu("epg:mod:press")
  @rcu("settings:mod:press")
  @rcu("home:mod:press")
  @rcu("pvr:mod:press")
  @rcu("appstore:mod:press")
  _openMOD() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      ModManager.open()
    }
  }

  @rcu("epg:key_fav:press")
  @rcu("settings:key_fav:press")
  @rcu("home:key_fav:press")
  @rcu("pvr:key_fav:press")
  @rcu("appstore:key_fav:press")
  @rcu("tv:key_fav:press")
  _onkeyfav() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      if (ChannelManager.favoriteChannels.length === 0) {
        ComboButton.openSettings("favorites")
      } else {
        bus.closeCurrentUniverse()
        bus.openUniverse("tv")
        bus.emit("tv:fav:press")
        bus.emit("home:close")
      }
    }
  }


  @on("tv:lang:press")
  @rcu("tv:lang:press")
  _openLanguage() {
    if (!ScanManager.running) {
      bus.emit("tv:language:press")
    }
  }

  @rcu("bigbang:stop:press")
  reset() {
    if (!this.resetTimeout) {
      this.resetTimeout = window.setTimeout(factoryReset, 3000)
    }
  }

  @rcu("home:stop:release")
  @rcu("bigbang:stop:release")
  cancelReset() {
    if (this.resetTimeout) {
      window.clearTimeout(this.resetTimeout)
    }
  }

  @rcu("tv:epg:press")
  @rcu("vod:epg:press")
  @rcu("pvr:epg:press")
  @rcu("mediacenter:epg:press")
  @rcu("appstore:epg:press")
  @rcu("home:epg:press")
  openEpg() {
    if (!ScanManager.running) {
      bus.closeCurrentUniverse()
      bus.emit("home:close")
      bus.emit("epg:directOpen")
      bus.emit("home:activeMenuItem", "epg")
    }
  }

  @rcu("tv:home:press")
  @rcu("home:home:press")
  @rcu("epg:home:press")
  @rcu("vod:home:press")
  @rcu("pvr:home:press")
  @rcu("mediacenter:home:press")
  @rcu("radio:home:press")
  @rcu("blackuniverse:home:press")
  @rcu("appstore:home:press")
  openHomePress() {
    if (!ScanManager.running) {
      bus.emit("comboBtn:home:press")
    }
  }

  @rcu("tv:home:release")
  @rcu("home:home:release")
  @rcu("epg:home:release")
  @rcu("vod:home:release")
  @rcu("pvr:home:release")
  @rcu("mediacenter:home:release")
  @rcu("radio:home:release")
  @rcu("blackuniverse:home:release")
  @rcu("appstore:home:press")
  openHomeRelease() {
    if (!ScanManager.running) {
      bus.emit("comboBtn:home:release")
    }
  }

  @rcu("tv:volume_plus:press")
  @rcu("popup:volume_plus:press")
  @rcu("epg:volume_plus:press")
  @rcu("vod:volume_plus:press")
  @rcu("settings:volume_plus:press")
  @rcu("pvr:volume_plus:press")
  @rcu("home:volume_plus:press")
  @rcu("appstore:volume_plus:press")
  @rcu("mediacenter:volume_plus:press")
  @rcu("radio:volume_plus:press")
  @rcu("standbypower:volume_plus:press")
  @rcu("UnsubscribedErrorMsg:volume_plus:press")
  onVolumePlusLong() {
    this._longpressVolume = window.setInterval(() => this.onVolumePlus(), 150)
  }

  @rcu("tv:volume_minus:press")
  @rcu("popup:volume_minus:press")
  @rcu("epg:volume_minus:press")
  @rcu("vod:volume_minus:press")
  @rcu("settings:volume_minus:press")
  @rcu("pvr:volume_minus:press")
  @rcu("home:volume_minus:press")
  @rcu("appstore:volume_minus:press")
  @rcu("mediacenter:volume_minus:press")
  @rcu("radio:volume_minus:press")
  @rcu("standbypower:volume_minus:press")
  @rcu("UnsubscribedErrorMsg:volume_minus:press")
  onVolumeMinusLong() {
    this._longpressVolume = window.setInterval(() => this.onVolumeMinus(), 150)
  }

  @rcu("tv:power:press")
  @rcu("epg:power:press")
  @rcu("vod:power:press")
  @rcu("settings:power:press")
  @rcu("pvr:power:press")
  @rcu("home:power:press")
  @rcu("ad:power:press")
  @rcu("radio:power:press")
  @rcu("parentalpopup:power:press")
  @rcu("popup:power:press")
  @rcu("UnsubscribedErrorMsg:power:press")
  @rcu("standbypower:power:press")
  @rcu("standby:power:press")
  @rcu("blackuniverse:power:press")
  @rcu("appstore:power:press")
  standby() {
    if (ScanManager.isFirstInstall) return

    if (!ScanManager.running || PowerManager.ctrlPowerOnStandbyScan) {
      PowerManager.controlPowerMangemant()
    }
  }

  @rcu("tv:volume_plus:press")
  @rcu("popup:volume_plus:press")
  @rcu("epg:volume_plus:press")
  @rcu("vod:volume_plus:press")
  @rcu("settings:volume_plus:press")
  @rcu("pvr:volume_plus:press")
  @rcu("home:volume_plus:press")
  @rcu("mediacenter:volume_plus:press")
  @rcu("radio:volume_plus:press")
  @rcu("standbypower:volume_plus:press")
  @rcu("UnsubscribedErrorMsg:volume_plus:press")
  @rcu("appstore:volume_plus:press")
  onVolumePlus() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      this.throttleVolumeUp()
    }
  }

  @rcu("tv:volume_minus:press")
  @rcu("popup:volume_minus:press")
  @rcu("epg:volume_minus:press")
  @rcu("vod:volume_minus:press")
  @rcu("settings:volume_minus:press")
  @rcu("pvr:volume_minus:press")
  @rcu("home:volume_minus:press")
  @rcu("mediacenter:volume_minus:press")
  @rcu("radio:volume_minus:press")
  @rcu("standbypower:volume_minus:press")
  @rcu("UnsubscribedErrorMsg:volume_minus:press")
  @rcu("appstore:volume_minus:press")
  onVolumeMinus() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      this.throttleVolumeDown()
    }
  }

  @rcu("tv:volume_plus:release")
  @rcu("popup:volume_plus:release")
  @rcu("epg:volume_plus:release")
  @rcu("vod:volume_plus:release")
  @rcu("settings:volume_plus:release")
  @rcu("pvr:volume_plus:release")
  @rcu("home:volume_plus:release")
  @rcu("appstore:volume_plus:release")
  @rcu("mediacenter:volume_plus:release")
  @rcu("radio:volume_plus:release")
  @rcu("standbypower:volume_plus:release")
  @rcu("UnsubscribedErrorMsg:volume_plus:release")
  @rcu("tv:volume_minus:release")
  @rcu("popup:volume_minus:release")
  @rcu("epg:volume_minus:release")
  @rcu("vod:volume_minus:release")
  @rcu("settings:volume_minus:release")
  @rcu("pvr:volume_minus:release")
  @rcu("home:volume_minus:release")
  @rcu("mediacenter:volume_minus:release")
  @rcu("radio:volume_minus:release")
  @rcu("standbypower:volume_minus:release")
  @rcu("UnsubscribedErrorMsg:volume_minus:release")
  @rcu("appstore:volume_minus:release")
  onVolumeMinusRelease() {
    if (this._longpressVolume) {
      window.clearInterval(this._longpressVolume)
      this._longpressVolume = null
    }
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      this.Volume.volumeMinusOnUp()
    }
  }

  @rcu("tv:mute:press")
  @rcu("epg:mute:press")
  @rcu("vod:mute:press")
  @rcu("settings:mute:press")
  @rcu("pvr:mute:press")
  @rcu("home:mute:press")
  @rcu("mediacenter:mute:press")
  @rcu("radio:mute:press")
  @rcu("standbypower:mute:press")
  @rcu("appstore:mute:press")
  onMutePress() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      this.Volume.mutePressed()
    }
  }

  @rcu("home:numeric:press")
  @rcu("tv:numeric:press")
  @rcu("epg:numeric:press")
  @rcu("pvr:numeric:press")
  @rcu("vod:numeric:press")
  @rcu("settings:numeric:press")
  @rcu("mediacenter:numeric:press")
  @rcu("radio:numeric:press")
  @rcu("appstore:numeric:press")
  onNumericPress(key) {
    if (!ScanManager.running && key === 0) {
      bus.emit("colorBtnPress", "zero")
    }
  }

  @rcu("home:appstore:press")
  @rcu("home:appstore:press")
  @rcu("tv:appstore:press")
  @rcu("epg:appstore:press")
  @rcu("pvr:appstore:press")
  @rcu("vod:appstore:press")
  @rcu("settings:appstore:press")
  @rcu("mediacenter:appstore:press")
  @rcu("radio:appstore:press")
  onAppStoreOpen() {
    if (!ScanManager.running) {
      if (PVRManager.ongoing.length > 0 || PVRManager.recordingInTransitionInfo.inTransition) {
        return AppsManager.showAppStoreConflictPopUp()
      }
      bus.emit("colorBtnPress:open:appstore")
    }
  }

  @rcu("home:key_red:press")
  @rcu("tv:key_red:press")
  @rcu("epg:key_red:press")
  @rcu("pvr:key_red:press")
  @rcu("vod:key_red:press")
  @rcu("settings:key_red:press")
  @rcu("mediacenter:key_red:press")
  @rcu("radio:key_red:press")
  @rcu("appstore:key_red:press")
  onkeyRedPress() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnPress", "red")
    }
  }

  @rcu("home:key_red:release")
  @rcu("tv:key_red:release")
  @rcu("epg:key_red:release")
  @rcu("pvr:key_red:release")
  @rcu("vod:key_red:release")
  @rcu("settings:key_red:release")
  @rcu("mediacenter:key_red:release")
  @rcu("radio:key_red:release")
  @rcu("appstore:key_red:release")
  onkeyRedRelease() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnRelease", "red")
    }
  }


  @rcu("home:key_green:press")
  @rcu("tv:key_green:press")
  @rcu("epg:key_green:press")
  @rcu("pvr:key_green:press")
  @rcu("vod:key_green:press")
  @rcu("settings:key_green:press")
  @rcu("mediacenter:key_green:press")
  @rcu("radio:key_green:press")
  @rcu("appstore:key_green:press")
  @rcu("popup:key_green:press")
  onkeyGreenPress() {
    bus.emit("greenBtnPress")
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnPress", "green")
    }
  }

  @rcu("home:key_green:release")
  @rcu("tv:key_green:release")
  @rcu("epg:key_green:release")
  @rcu("pvr:key_green:release")
  @rcu("vod:key_green:release")
  @rcu("settings:key_green:release")
  @rcu("mediacenter:key_green:release")
  @rcu("radio:key_green:release")
  @rcu("appstore:key_green:release")
  onkeyGreenRelease() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnRelease", "green")
    }
  }

  @rcu("home:key_yellow:press")
  @rcu("tv:key_yellow:press")
  @rcu("epg:key_yellow:press")
  @rcu("pvr:key_yellow:press")
  @rcu("vod:key_yellow:press")
  @rcu("settings:key_yellow:press")
  @rcu("mediacenter:key_yellow:press")
  @rcu("radio:key_yellow:press")
  @rcu("blackuniverse:key_yellow:press")
  @rcu("appstore:key_yellow:press")
  onkeyYellowPress() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnPress", "yellow")
    }
  }

  @rcu("home:key_yellow:release")
  @rcu("tv:key_yellow:release")
  @rcu("epg:key_yellow:release")
  @rcu("pvr:key_yellow:release")
  @rcu("vod:key_yellow:release")
  @rcu("settings:key_yellow:release")
  @rcu("mediacenter:key_yellow:release")
  @rcu("radio:key_yellow:release")
  @rcu("blackuniverse:key_yellow:release")
  @rcu("appstore:key_yellow:release")
  onkeyYellowRelease() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnRelease", "yellow")
    }
  }

  @rcu("home:key_blue:press")
  @rcu("tv:key_blue:press")
  @rcu("epg:key_blue:press")
  @rcu("pvr:key_blue:press")
  @rcu("vod:key_blue:press")
  @rcu("settings:key_blue:press")
  @rcu("mediacenter:key_blue:press")
  @rcu("radio:key_blue:press")
  @rcu("blackuniverse:key_blue:press")
  @rcu("appstore:key_blue:press")
  onkeyBluePress() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnPress", "blue")
    }
  }

  @rcu("home:key_blue:release")
  @rcu("tv:key_blue:release")
  @rcu("epg:key_blue:release")
  @rcu("pvr:key_blue:release")
  @rcu("vod:key_blue:release")
  @rcu("settings:key_blue:release")
  @rcu("mediacenter:key_blue:release")
  @rcu("radio:key_blue:release")
  @rcu("blackuniverse:key_blue:release")
  @rcu("appstore:key_blue:release")
  onkeyBlueRelease() {
    if (!ScanManager.isFirstInstall && !ScanManager.running) {
      bus.emit("colorBtnRelease", "blue")
    }
  }

  @rcu("home:previous_channel:press")
  @rcu("tv:previous_channel:press")
  @rcu("epg:previous_channel:press")
  @rcu("pvr:previous_channel:press")
  @rcu("vod:previous_channel:press")
  @rcu("settings:previous_channel:press")
  @rcu("mediacenter:previous_channel:press")
  @rcu("radio:previous_channel:press")
  @rcu("appstore:previous_channel:press")
  onPreviousChannel() {
    if (config.SD_ZAPPER && !ScanManager.isFirstInstall &&
    !ScanManager.running && !ScanManager.scanTriggered) {
      if (bus.universe === "tv") {
        bus.emit("tv:closeactionbox")
        bus.emit("tv:tunePrevious")
      }
    }
  }

  @rcu("home:help:press")
  @rcu("tv:help:press")
  @rcu("epg:help:press")
  @rcu("pvr:help:press")
  @rcu("vod:help:press")
  @rcu("settings:help:press")
  @rcu("mediacenter:help:press")
  @rcu("radio:help:press")
  @rcu("appstore:help:press")
  onHelppress() {
    if (config.SD_ZAPPER && !ScanManager.isFirstInstall &&
      !ScanManager.running && !ScanManager.scanTriggered) {
      bus.emit("openSettingsPage", "UIHelp")
    }
  }

  @rcu("home:tools:press")
  @rcu("tv:tools:press")
  @rcu("epg:tools:press")
  @rcu("pvr:tools:press")
  @rcu("vod:tools:press")
  @rcu("settings:tools:press")
  @rcu("mediacenter:tools:press")
  @rcu("radio:tools:press")
  @rcu("appstore:tools:press")
  onToolsPress() {
    if (config.SD_ZAPPER && !ScanManager.isFirstInstall &&
      !ScanManager.running && !ScanManager.scanTriggered) {
      bus.emit("openSettingsPage", "UITools")
    }
  }

  @rcu("home:mail:press")
  @rcu("tv:mail:press")
  @rcu("epg:mail:press")
  @rcu("pvr:mail:press")
  @rcu("vod:mail:press")
  @rcu("settings:mail:press")
  @rcu("mediacenter:mail:press")
  @rcu("radio:mail:press")
  @rcu("appstore:mail:press")
  onMailPress() {
    if (config.SD_ZAPPER && !ScanManager.isFirstInstall &&
      !ScanManager.running && !ScanManager.scanTriggered) {
      if (bus.universe === "epg") {
        bus.emit("clock:close")
      }
      if (bus.universe !== "settings") {
        bus.closeCurrentUniverse()
        bus.openUniverse("settings")
        bus.universe = "settings"
        bus.emit("settings:contactUs")
      } else {
        bus.emit("settings:hideDelegate")
        bus.universe = "settings"
        bus.emit("settings:contactUs")
      }
    }
  }

  @rcu("home:exit:press")
  @rcu("tv:exit:press")
  @rcu("epg:exit:press")
  @rcu("pvr:exit:press")
  @rcu("vod:exit:press")
  @rcu("settings:exit:press")
  @rcu("mediacenter:exit:press")
  @rcu("radio:exit:press")
  @rcu("appstore:exit:press")
  openLiveStream() {
    if (config.SD_ZAPPER && !ScanManager.isFirstInstall &&
      !ScanManager.running && !ScanManager.scanTriggered) {
      if (bus.universe === "settings") {
        bus.emit("settings:close")
        bus.emit("home:close")
        bus.emit("tv:openfull")
      } else {
        bus.closeCurrentUniverse()
      }
      bus.emit("tv:openfull")
    }
  }

  @rcu("epg:reminder:press")
  onReminderPress() {
    if (config.SD_ZAPPER && bus.universe === "epg") {
      bus.emit("epg:set_reminder", null, true)
    }
  }
}
