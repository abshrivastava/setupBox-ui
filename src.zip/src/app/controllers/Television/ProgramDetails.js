//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {$} from "widgets/Component"
import {on, rcu} from "services/events"
import {_} from "utils/locale"
import config from "utils/config"


import {favoriteIsInUse} from "app/utils/PopUpMsg"

import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import {TreeObj} from "app/utils/widgets/lists"

import {updateEntryInSection} from "services/managers/config"

export default class ProgramDetailsController extends Controller {
  constructor() {
    super()
    this.view = $("programDetails")
    this.tree = new TreeObj(this.view.actionsTree)
    this.languageLabel = null
  }

  open(item, recording, currentChannel, showCRIcon) {
    this.item = item
    this.channel = currentChannel
    this.recording = recording
    this.actions = this._actionsFactory(item, recording)
    this.tree.setItems(0, this.actions)
    this.view.open(item, showCRIcon)
    this.tree.right()
  }

  @on("ProgramDetails:close")
  close() {
    this.view.close()
    this.tree.reset()
    this.isAudioList =false
  }

  _actionsFactory(item) {
    const actions = []
    const commonActions = [{
      label: "Audio",
      onFocus: () => this.getAudioTracks(),
      action: () => this.getAudioTracks(),
      type: "AudioOption",
    }]
    if (item.currentOngoing) {
      const chType = ChannelManager.getChannelFromServiceId(item.serviceId).obj_class
      actions.push({
        label: (chType === "CHANNEL_AUDIO") ? "Listen" : "Watch",
        signal: "tv:watch",
      })
    }
    if (!item.isReminder) {
      if (!item.isOngoing && item.programId) {
        const cTm = new Date()
        if (((item.startDate.getTime() - cTm.getTime())/60000) > 2) { // is not in grace period
          actions.push({
            label: "Set Reminder",
            signal: "tv:reminder",
          })
        }
      }
    } else {
      if (item.programId) {
        actions.push({
          label: "Cancel Reminder",
          signal: "tv:cancelReminder",
        })
      }
    }
    if (!config.PVR_DISABLED) { // Disabling PVR functionality if PVR is not required
      const manualRecords = this.master.getManualRecordsFromServiceId(item.serviceId, item.startDate, item.endDate)
      if (!item.isReminder && (item.isScheduled || item.isRecording || manualRecords.length > 0)) {
        if (!item.programId) {
          if (item.isRecording) {
            actions.push({
              label: "Stop Record",
              signal: "tv:stop_record",
            })
          } else {
            actions.push({
              label: "Record",
              signal: "tv:record",
            })
          }
        } else {
          actions.push({
            label: item.isScheduled ? "Cancel Record" : "Stop Record",
            signal: "tv:stop_record",
          })
        }
      } else {
        actions.push({
          label: "Record",
          signal: "tv:record",
        })
      }
    }
    const self = this
    window.setTimeout(function() {
      self.setAudioArrow()
    }, 200)

    this.addFavoriteAction(commonActions)

    this.addFavoriteListButton(commonActions)
    return actions.concat(commonActions)
  }

  addFavoriteAction(commonActions) {
    if (this.channel.favorite) {
      commonActions.push({
        label: "Favorite Remove",
        signal: "ProgramDetails:remove_from_favorite",
      })
    } else {
      commonActions.push({
        label: "Favorite Add",
        signal: "ProgramDetails:add_to_favorite",
      })
    }
  }

  addFavoriteListButton(commonActions) {
    if (ChannelManager.useFav) {
      commonActions.push({
        label: "Use default list",
        signal: "ProgramDetails:toggleFavoriteListAsChannelList",
      })
    } else if (this.channel.favorite) {
      commonActions.push({
        label: "Use favourite list",
        signal: "ProgramDetails:toggleFavoriteListAsChannelList",
      })
    }
  }

  @on("ProgramDetails:add_to_favorite")
  addToFavorite() {
    this.toggleFavorite(true)
  }

  @on("ProgramDetails:remove_from_favorite")
  removeFromFavorite() {
    if (ChannelManager.useFav) {
      favoriteIsInUse()
    } else {
      this.toggleFavorite(false)
    }
  }

  @on("ProgramDetails:toggleFavoriteListAsChannelList")
  toggleFavoriteListAsChannelList() {
    const selectedIndex = this.tree.getSelectedIndex()
    ChannelManager.toggleFavoriteListAsChannelList().then(() => {
      this.actions = this._actionsFactory(this.item),
      this.tree.setItems(0, this.actions)
      this.tree.select(selectedIndex)
      bus.emit("channels:updated")
    })
  }

  toggleFavorite(favorite) {
    const selectedIndex = this.tree.getSelectedIndex()
    ChannelManager.setChannelFavorite(this.channel.id, favorite)
    ChannelManager.saveFavorites().then(() => {
      this.channel.favorite = favorite
      const channelsList = this.master.ChannelList
      let selectedChannelIdx = channelsList.channelList.indexOf(this.channel)
      if (selectedChannelIdx === -1) selectedChannelIdx = 0
      channelsList.view.itemList.jumpTo(selectedChannelIdx,true)
      this.actions = this._actionsFactory(this.item),
      this.tree.setItems(0, this.actions)
      this.tree.select(selectedIndex)
    })
  }

  prev() {
    this.tree.up()
    this.tree.view.moveExtendedTo(this.tree.lists[0].selected)
  }

  next() {
    this.tree.down()
    this.tree.view.moveExtendedTo(this.tree.lists[0].selected)
  }

  right() {
    this.tree.right()
  }

  left() {
    this.tree.left()
  }

  trigger() {
    this.tree.trigger()
  }

  popUpTrigger() {
    return new Promise((resolve,reject) => {
      PlayerManager.setAudioconfig = false
      if (this.tree.lists[0].items[this.tree.lists[0].selected].type === "AudioOption") {
        if ((this.tree.lists[1].view.dom.className).indexOf("ActionsList--focused") >= 0) {
          this.isAudioList = true
          reject(false)
        } else {
          PlayerManager.setAudioconfig = true
          this.isAudioList = false
          resolve(true)
        }
      } else {
        reject(false)
      }
    })
  }

  /** to get and display the list2 containing audio tracks**/
  getAudioTracks() {
    return PlayerManager.getAudioTracks()
      .then((audios) => {
        return audios.map((t, i) => {

          // hard coded audio language those which are not present in font-family
          this.languageLabel = t.lang
          if (t._attributes.AudioLang === "urd" || t._attributes.AudioLang === "guj"
          || t._attributes.AudioLang === "ben" || t._attributes.AudioLang === "kan"
          || t._attributes.AudioLang === "lat" || t._attributes.AudioLang === "mag"
          || t._attributes.AudioLang === "mni" || t._attributes.AudioLang === "nep"
          || t._attributes.AudioLang === "ori" || t._attributes.AudioLang === "pan"
          || t._attributes.AudioLang === "raj" || t._attributes.AudioLang === "asm"
          || t._attributes.AudioLang === "bho" || t._attributes.AudioLang === "bih"
          || t._attributes.AudioLang === "grn" || t._attributes.AudioLang === "mal") {
            switch (t._attributes.AudioLang) {
            case "urd":
              this.languageLabel = _("Urdu")
              break
            case "ben":
              this.languageLabel = _("Bengali")
              break
            case "guj":
              this.languageLabel = _("Gujarati")
              break
            case "kan":
              this.languageLabel = _("Kannada")
              break
            case "lat":
              this.languageLabel = _("Latin")
              break
            case "mag":
              this.languageLabel = _("Magahi")
              break
            case "mal":
              this.languageLabel = _("malayalam")
              break
            case "mni":
              this.languageLabel = _("manipuri")
              break
            case "nep":
              this.languageLabel = _("nepali")
              break
            case "ori":
              this.languageLabel = _("Oriya")
              break
            case "pan":
              this.languageLabel = _("Panjabi")
              break
            case "raj":
              this.languageLabel = _("Rajasthani")
              break
            case "asm":
              this.languageLabel = _("Assamese")
              break
            case "bho":
              this.languageLabel = _("Bhojpuri")
              break
            case "bih":
              this.languageLabel = _("Bihari")
              break
            case "grn":
              this.languageLabel = _("Guarani")
              break
            default:
              // console.log("default")
            }
          }
          return {
            label: this.languageLabel,
            signal: "tv:audio:set",
            default: t.default,
            track_id: i,
          }
        })
      })
  }

  /** to set default Audio for a Channel from the available audio tracks list **/
  @on("tv:audio:set")
  _onAudioSet(data) {
    PlayerManager.setAudioTrack(data.track_id)
      .then(() => {
        PlayerManager.audioTrackPersis.push(PlayerManager.serviceId)
        PlayerManager.findAudioLang(data.track_id).then(() => {
          PlayerManager.audioTrackPersisVal[PlayerManager.serviceId] = PlayerManager.audioLangPerfix
          updateEntryInSection("audio_lang",PlayerManager.serviceId,PlayerManager.audioLangPerfix)
          PlayerManager.audioLangPerfix = null
        })

        this.tree.lists[1].view.markAsDefault(data.track_id)
      })
  }

  /** to show the right arrow for Audio Label **/
  setAudioArrow() {
    let i= 0
    for (i of this.tree.lists[0].items) {
      if (i.label === "Audio") {
        const ind =this.tree.lists[0].items.indexOf(i)
        this.view.dom.childNodes[1].childNodes[0].childNodes[1].childNodes[ind].className=
        "ActionItemWithDefault"
      }
    }
  }

  @rcu("tv:program_minus:press")
  @rcu("tv:program_plus:press")
  onProgramPlusMinus() {
    bus.emit("ProgramDetails:close")
  }
}
