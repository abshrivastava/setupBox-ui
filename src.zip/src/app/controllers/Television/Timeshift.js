//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {on} from "services/events"
import bus  from "services/bus"
import {createTicker} from "utils"
import {$} from "widgets/Component"
import PlayerManager from "services/managers/PlayerManager"
import {getRecordMedium,getTimeShiftDuration} from "services/api/config"
import CasManager from "services/managers/CasManager"

import * as popUpMsg from "app/utils/PopUpMsg"


export default class TimeshiftController extends Controller {
  constructor() {
    super()
    this.mode = "play"
    this.recordFlag = true
    this.ticker = createTicker(1000)
    this.view = $("channelList")
    this.playerControlView = $("playerControl")
  }

  @on("player:speed:normal", {universe: "tv"})
  _onPlayerSpeedNormal() {
    PlayerManager.timeshiftMode = this.mode
    switch (this.mode) {
    case "pause":
      this.resumeFromPause()
      this.master.timeshifting = false
      this.mode = "play"
      break
    case "fastRewind":
      this.hideWithNoDelay()
      this.master.timeshifting = true
      this.mode = "play"
      break
    case "fastForward":
      PlayerManager.getDeltaFromLive()
      .then((originalDelta) => {
        if (originalDelta <= 0) {
          this.hideWithNoDelay()
          this.view.hideTSIndicator()
          this.master.timeshifting = false
          this.mode = "play"
        }
      })
      break
    default:
      this.mode = "play"
      break
    }
  }

  checkStorage() {
    return getRecordMedium().then((mediumData) => {
      return getTimeShiftDuration().then((timeData) => {
        if ((mediumData.medium==="NONE") && (timeData.timeshift_duration===0)) {
          this.recordFlag = false
          popUpMsg.storageFreeSpace()
          // return this.recordFlag
        } else {
          this.recordFlag = true
        }
      })
    })
  }

  pause() {
    if (PlayerManager.enablePVR === false) return
    return this.checkStorage()
        .then(() => {
          if (this.recordFlag===true) {
            this.mode = "pause"
            return PlayerManager.pause()
            .then(() => PlayerManager.getDeltaFromLive())
            .then((originalDelta) => {
              this.ticker.start((tickStart) => {
                const delta = ~~((+new Date() - tickStart) / 1000) + originalDelta
                this.playerControlView.updateTimeshiftDelta(delta)
              })
              bus.emit("tv:setActiveDelegate", this.master.InfoBanner)
              this.master.InfoBanner.show(false, false)
              this.view.showTSIndicator()
              this.playerControlView.showPaused(false)
            }).catch(()=>{
            })
          }
        })
  }

  resumeFromPause(isCList =false) {
    if (CasManager.isFingerprintActive === false) {
      bus.emit("fingerprint:timeshiftopen")
    }
    this.mode = "play"
    return PlayerManager.resume()
      .then(() => {
        if (isCList) this.master.ChannelList.close()
        this.hideWithDelay()
      })
  }

  backToLive() {
    this.mode = "play"
    return PlayerManager.backToLive().then(() => {
      if (CasManager.isFingerprintActive === true) {
        CasManager.closeFingerprint()
      }
      this.ticker.stop()
      this.view.hideTSIndicator()
      this.playerControlView.disableImmediately()
      this.view.closeInfoBanner()
    })
  }

  fastForward() {
    this.mode = "fastForward"
    return PlayerManager.fastForward().then((speed) => {
      this.ticker.stop()
      this.playerControlView.fastForward(speed)
      this.master.InfoBanner.show(false, false)
    })
  }

  fastRewind() {
    this.mode = "fastRewind"
    return PlayerManager.fastRewind().then((speed) => {
      if (CasManager.isFingerprintActive === false) {
        bus.emit("fingerprint:timeshiftopen")
      }
      this.ticker.stop()
      this.playerControlView.fastRewind(speed)
      this.view.showTSIndicator()
      this.master.InfoBanner.show(false, false)
    })
  }

  updateDelta(startTime) {
    const delta = ~~((new Date() / 1000) - startTime)
    this.playerControlView.updateTimeshiftDelta(delta)
  }

  show(recording) {
    this.master.InfoBanner.show(recording, true)
    if (PlayerManager.speed !== 1) {
      this.view.showTSIndicator()
      this.playerControlView.unfold()
    }
  }

  hideWithNoDelay() {
    this.ticker.stop()
    this.mode = "play"
    this.playerControlView.disableImmediately()
    this.view.closeInfoBanner()
    // bus.emit("clock:close","tv")
    bus.emit("tv:back:press")
  }

  hideWithDelay() {
    this.playerControlView.disableWithDelay()
    this.view.closeInfoBannerWithDelay()
    this.ticker.stop()
    if (!this.master.activeDelegate === this.master.ChannelList) {
      bus.emit("clock:close","tv")
    }
  }

  hide() {
    this.view.hideTSIndicator()
    this.view.closeInfoBanner()
    return this.playerControlView.disableImmediately()
  }

  close() {
    return this.hide()
  }

  quit() {
    this.ticker.stop()
    this.hide()
  }
}
