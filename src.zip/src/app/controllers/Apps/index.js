//
// Copyright (C) 2006-2017 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {$} from "widgets/Component"
import Controller from "utils/Controller"
import {on,rcu} from "services/events"
import bus from "services/bus"
import ChannelManager from "services/managers/ChannelManager"
import {removeAllTune} from "services/api/scan"
import {List} from "widgets"
import StaticListView from "widgets/list/views/StaticListView"
import * as popUpMsg from "app/utils/PopUpMsg"

import AppCategory from "app/components/universes/Apps/AppCategories/AppCategory"
import AppItem from "app/components/universes/Apps/AppItems/AppItem"
import AppAction from "app/components/universes/Apps/AppActions/AppAction"

import {
  PVRManager,
  AppsManager,
  BrowserManager,
  CamManager,
  PowerManager,
  DownloaderManager,
  PlayerManager,
} from "services/managers"

import {
  unmute,
  getMute,
  getVolume,
  setVolume,
} from "services/managers/volume"

const keys = Object.freeze({
  home: "home",
  back: "backspace",
  power: "f4",
  volumeup: "volumeup",
  volumedown: "volumedown",
  mute: "mute",
})

const Timmer = Object.freeze({
  state: 10,
  speed: 0,
  time: 4000,
  lap: 500,
})
const PLAYER = Object.freeze({
  playing: 11,
  stop: 10,
})


export default class AppsController extends Controller {
  constructor() {
    super()
    this.view = $("AppsUniverse")
    this.currentListSelected = null
    this.actions = []
    this.loaded = false
    this.loadingApplication = false
    this.applicationIsOpen = false
    this.timmer = false
    this.catalog = {
      ADSCATALOG :208,
      APPSCATALOG : 209,
      APPFILE : 210,
    }
    this.maintainVol = {
      volPostion : null,
      mutePostion : false,
    }
  }

  @on("appstore:open")
  appsDownload() {
    bus.emit("appstore:loadingApps")
    removeAllTune().then(() => {
      let state = null
      let speed = null
      let time = 500

      PlayerManager.stop()
      this.timmer = window.setInterval(() => {
        state = PlayerManager._state
        speed = PlayerManager.speed

        if ((state === Timmer.state && speed === Timmer.speed) || time === Timmer.time) {
          window.clearInterval(this.timmer)
          this.timmer = null
          DownloaderManager.stopAdsOngoing().then(() => {
            DownloaderManager.downloadApplication()
          })
          .catch(() => {
            DownloaderManager.downloadApplication()
          })
        }

        time += 500
      },500)
    })
  }

  @on("appstore:stopLoadingApps")
  onStopLoadingApps() {
    if (this.loadingApplication) this.loadingApplication = false
  }

  @on("appstore:loadingApps")
  loadingApps() {
    const isOnStandby = PowerManager.isStandbyState
    if (!isOnStandby) {
      this.loadingApplication = true
      const closeCallback = () => {
        if (this.loadingApplication) {
          this.clearTimmer()
          DownloaderManager.clearDwTimmer()
          DownloaderManager.restartAdsDownloadTask()
          bus.emit("dvbUpdate:cancel",true,true,this.catalog.APPSCATALOG)
        }
      }
      popUpMsg.appLaunched(closeCallback)
      bus.emit("popup:exitTrue")
    }
  }

  @on("appstore:downloadfailed")
  onFailed() {
    popUpMsg.appsDownloadFail()
  }

  /**
   *  @If CamManager.insertStatus True ::
   *  CAM is inserted then we have to block all the conax features
   */
  @on("appstore:view")
  open() {
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    return AppsManager.loadAppsCatalog()
      .then(() => {
        this.openDvbApps()
        this.maintainVolume()
      })
      .catch(() => {
        this.close()
        bus.openUniverse("home")
        return popUpMsg.dvbAppsNoJSonAvailable()
      })
  }

  maintainVolume() {
    getMute()
    .then((status) => {
      if (status) {
        const mute = status.value
        this.maintainVol.mutePostion = mute
      }
      return getVolume()
    })
    .then((vol) => {
      if (vol) {
        const volume = vol.volume
        this.maintainVol.volPostion = volume
      }
    })
  }

  restoreVol() {
    const muteStatus = this.maintainVol.mutePostion
    const volume = this.maintainVol.volPostion
    if (muteStatus) {
      bus.emit("volume:setmute",volume)
      setVolume(volume)
    } else {
      unmute()
      .then(() => {
        bus.emit("volume:hidebar",volume)
        setVolume(volume)
      })
    }
    this.maintainVol.mutePostion = false
    this.maintainVol.volPostion = null
  }

  itemInCenter() {
    this.itemsList.list.count > 2 && this.itemsList.next()
    this.itemsList.list.count > 4 && this.itemsList.next()
  }

  openDvbApps() {
    if (AppsManager.getCategories().length === 0) {
      this.close()
      bus.openUniverse("home")
      return popUpMsg.dvbAppsNoJSonAvailable()
    }

    this.categoriesList = new List(
      AppsManager.getCategories(),
      this.view.categories.dom,
      StaticListView,
      {
        "EXTRA_VISIBLE_ITEMS_BEFORE": 2,
        "EXTRA_VISIBLE_ITEMS_AFTER": 2,
      },
      {
        "itemView" : AppCategory,
      },
    )

    this.itemsList = new List(
      this.categoriesList.currentItem.getApplications(),
      this.view.items.dom,
      StaticListView,
      {
        "EXTRA_VISIBLE_ITEMS_BEFORE": 2,
        "EXTRA_VISIBLE_ITEMS_AFTER": 2,
      },
      {
        "itemView" : AppItem,
      },
    )

    this.actionsList = new List(
      this.actions,
      this.view.actions.dom,
      StaticListView,
      {
        "EXTRA_VISIBLE_ITEMS_BEFORE": 1,
        "EXTRA_VISIBLE_ITEMS_AFTER": 1,
      },
      {
        "itemView" : AppAction,
      },
    )

    this.currentListSelected = this.categoriesList
    this.currentListSelected.focus()
    if (this.categoriesList.list.length > 2) {
      this.onRight()
      if (this.categoriesList.list.length > 4)
        this.onRight()
    } else {
      if (this.itemsList.list.length > 2) {
        this.itemsList.next()
        if (this.itemsList.list.length > 4)
          this.itemsList.next()
      }
    }
    this.view.show()
    this.showDetails()
  }

  @on("appstore:close")
  close() {
    if (PlayerManager._state === PLAYER.playing) PlayerManager.stop()
    const promises = []
    promises.push(this.clearTimmer())
    promises.push(this.clearLists())
    promises.push(this.restoreVol())
    promises.push(this.view.hide())
    promises.push(BrowserManager.closeLayer())
    promises.push(this.unInstallChecker())
    promises.push(DownloaderManager.restartAdsDownloadTask())
    return Promise.all(promises)
  }

  /**
   *  If Back From Application Than UnInstall application
   */
  unInstallChecker() {
    if (this.applicationIsOpen) {
      this.applicationIsOpen = false
      bus.emit("checker:unInstalled")
    }
  }

  clearTimmer() {
    if (this.timmer) {
      window.clearInterval(this.timmer)
    }
  }

  clearLists() {
    while (this.view.categories.dom.hasChildNodes()) {
      this.view.categories.dom.removeChild(this.view.categories.dom.lastChild)
    }
    while (this.view.items.dom.hasChildNodes()) {
      this.view.items.dom.removeChild(this.view.items.dom.lastChild)
    }
    while (this.view.actions.dom.hasChildNodes()) {
      this.view.actions.dom.removeChild(this.view.actions.dom.lastChild)
    }
  }

  @rcu("appstore:ok:press")
  onOk() {
    switch (this.currentListSelected) {
    case this.categoriesList:
      this.moveToItemList()
      break
    case this.itemsList:
      // this.displayItemActions()
      this.sendAction()
      break
    case this.actionsList:
      this.sendAction()
      break
    default:
      break
    }
  }

  @rcu("appstore:back:press")
  onBack() {
    if (BrowserManager.currentHref) {
      BrowserManager.closeLayer()
      if (PlayerManager._state === PLAYER.playing) PlayerManager.stop()
      this.view.show()
      if (this.applicationIsOpen) {
        this.applicationIsOpen = false
        bus.emit("checker:unInstalled")
      }
      return
    }
    switch (this.currentListSelected) {
    case this.itemsList:
      this.close()
      bus.openUniverse("home")
      break
    case this.actionsList:
      this.moveToItemList()
      break
    default:
      this.close()
      bus.openUniverse("home")
      break
    }
  }

  @rcu("appstore:up:press")
  onUp() {
    switch (this.currentListSelected) {
    case this.categoriesList:
      this.moveToItemList()
      break
    case this.itemsList:
    //   this.displayItemActions()
      break
    case this.actionsList:
      this.currentListSelected.prev()
      break
    default:
      break
    }
  }

  @rcu("appstore:down:press")
  onDown() {
    switch (this.currentListSelected) {
    case this.itemsList:
      this.moveToCategoryList()
      break
    case this.actionsList:
      this.moveToItemList()
      break
    default:
      break
    }
  }

  @rcu("appstore:left:press")
  onLeft() {
    if (this.currentListSelected.selectedIdx === 0) return
    switch (this.currentListSelected) {
    case this.categoriesList:
      this.currentListSelected.prev()
      this.updateList()
      this.itemInCenter()
      this.showDetails()
      break
    case this.itemsList:
      this.currentListSelected.prev()
      this.updateList()
      break
    default:
      break
    }
  }

  @rcu("appstore:right:press")
  onRight() {
    if (this.currentListSelected.list.length-1 === this.currentListSelected.selectedIdx) return
    switch (this.currentListSelected) {
    case this.categoriesList:
      this.currentListSelected.next()
      this.updateList()
      this.itemInCenter()
      this.showDetails()
      break
    case this.itemsList:
      this.currentListSelected.next()
      this.updateList()
      break
    default:
      break
    }
  }

  @on("appstore:conflict:tuner")
  _onAppStoreConflict(schedule) {
    if (PVRManager.ongoing.length > 0) {
      PVRManager.cancel(PVRManager.ongoing[0].programId,(PVRManager.ongoing[0]))
    }
    PVRManager.remove(schedule)
  }

  moveToCategoryList() {
    this.currentListSelected.blur()
    this.currentListSelected = this.categoriesList
    this.showDetails()
    this.currentListSelected.focus()
    // this.updateListArrow()
  }

  moveToItemList() {
    this.currentListSelected.blur()
    this.currentListSelected = this.itemsList
    this.showDetails()
    this.currentListSelected.focus()
    // this.updateListArrow()
  }

  displayItemActions() {
    this.currentListSelected.blur()
    this.currentListSelected = this.actionsList
    this.currentListSelected.focus()
  }

  sendAction() {
    if (this.currentListSelected.currentItem === "Cancel") {
      this.moveToItemList()
    } else {
      if (!this.itemsList.currentItem) return
      const url = this.itemsList.currentItem.DVBUrl
      if (!url) return
      // Tuned Tv Channel from service apps...
      if (this.itemsList.currentItem.linkedToTVChannel) {
        let channel = null
        const serviceId = ChannelManager.getServiceIdFromDVBUrl(url)
        if (serviceId) channel = ChannelManager.getChannelFromServiceId(serviceId)
        if (channel === null) channel = ChannelManager.current.lcn
        PlayerManager.play(channel)
        this.close()
        bus.openUniverse("tv")
        return
      }
      DownloaderManager.loadApp(url)
      .then(() => {
        DownloaderManager.applicationDn = true
        bus.emit("download:action","app")
        const closeCallback = () => {
          this.onStopLoadingApps()
          bus.emit("version:closePopup")
          bus.emit("downloader:stopAppFileTask")
        }
        popUpMsg.appFileDownloadLoading(closeCallback)
        const title = this.itemsList.currentItem.title
        DownloaderManager.playStoreTitle = title.replace(/\s/g,"").trim()
        return DownloaderManager.startDownloading(this.catalog.APPFILE)
      })
      .then(() => {
        DownloaderManager.applicationDn = false
      })
      .catch(() => {
        DownloaderManager.applicationDn = false
      })
    }
  }

  @on("appstore:openApp")
  openApp(url) {
    if (url) {
      this.view.hide()
      return BrowserManager.openNewLayer(url,
         [keys.home, keys.back, keys.power, keys.volumeup, keys.volumedown, keys.mute])
         .then(() => {
           this.applicationIsOpen = true
         })
    } else {
      return Promise.reject("not a valid url")
    }

  }

  showDetails() {
    if (this.currentListSelected.currentItem) {
      this.view.header.show(this.currentListSelected.currentItem)
      this.view.detail.show(this.currentListSelected.currentItem)
      this.view.preview.show(this.currentListSelected.currentItem)
    }
  }

  hideDetails() {
    this.view.header.hide()
    this.view.preview.hide()
  }

  updateList() {
    switch (this.currentListSelected) {
    case this.categoriesList:
      this.itemsList.update(this.categoriesList.currentItem.getApplications())
      break
    case this.itemsList:
      this.showDetails()
      break
    default:
      break
    }
    // this.updateListArrow()
  }

  arrowShowHide() {
    this.currentListSelected.view.dom.classList.add("arrow")
    if (this.currentListSelected.list.length === 1)
      this.currentListSelected.view.dom.classList.remove("arrow")

    if (this.currentListSelected.view.dom.classList.contains("leftArrowHide"))
      this.currentListSelected.view.dom.classList.remove("leftArrowHide")
    if (this.currentListSelected.view.dom.classList.contains("rightArrowHide"))
      this.currentListSelected.view.dom.classList.remove("rightArrowHide")
  }

  updateListArrow() {
    // this.arrowShowHide()
    if (this.currentListSelected.list.length > 1) {
      if (this.currentListSelected.selectedIdx === 0) {
        this.currentListSelected.view.dom.classList.add("leftArrowHide")
      } else if (this.currentListSelected.list.length-1 === this.currentListSelected.selectedIdx) {
        this.currentListSelected.view.dom.classList.add("rightArrowHide")
      }
    }
  }
}
