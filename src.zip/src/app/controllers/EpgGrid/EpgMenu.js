//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import {$} from "widgets/Component"

import {on} from "services/events"
import bus from "services/bus"
import {epgNoChannels} from "app/utils/PopUpMsg"
import {CircularList, List} from "widgets"
import ChannelManager from "services/managers/ChannelManager"
import AbstractSetting from "app/controllers/Settings/AbstractSetting"
import StaticListView from "widgets/list/views/StaticListView"
import EpgItem from "app/components/universes/EpgGrid/EpgMenu/EpgItem"

export default class EpgMenuController extends AbstractSetting {
  constructor() {

    super()
    this.selected = 0
    this.actions = []
    this.isLoaded = false
    this.view = $("EpgMenu")
    this.selectedSubGenre = ""
    this.regionalPageId = 0
    this.optionList = []
    this.epgList = null
  }

  open(item) {

    this.view.show(item)
    this.currentScreen = "epgList"
    return super.open()
  }

  load() {

    this.selectedIndex = 0
    this.initChannelList()
    this.loadoptionList()
  }
  initChannelList() {
    this._usedList = null
    const filterArray = ChannelManager.getGenreFilterList()
    const myArr=[]
    filterArray.forEach((element) =>{
      myArr.push({id:element.id , title:element.title})
    })
    this._createOrUpdateList(myArr)
    this.epgList.focus()
    this.isLoaded  = true
  }

  _createOrUpdateList(items) {
    const list = (items.length <= 6) ? List : CircularList
    if (list !== this._usedList) {
      this._usedList = list
      if (this.epgList) {
        this.view.clearEpgList()
      }
      this.epgList = new list(
        items,
        this.view.getEpgList(),
        StaticListView,
        {
          "EXTRA_VISIBLE_ITEMS_BEFORE": 0,
          "EXTRA_VISIBLE_ITEMS_AFTER": 7,
        },
        {
          "itemView" : EpgItem,
        }
      )
    } else {
      this.epgList.update(items)
    }
  }

  moveDown() {
    if (this.isLoaded) {
      if (this.currentScreen === "epgList") {
        this.epgList.next()
        this.loadoptionList()
      } else if (this.currentScreen === "actionList") {
        if (this.regionalPageId ===1 && this.selectedIndex===4 && this.epgList.currentItem.id === 888) {
          // Case Of Last Navigation
          this.loadoptionList()
          this.selectedIndex=-1
          this.regionalPageId = 0
        }
        if (this.selectedIndex>=7 && !this.regionalPageId) {
          this.selectedIndex=-1
          this.optionList=this.optionAdditional.slice(8)
          this.regionalPageId=1
          this.view.loadItems(this.optionList)
        }
        const selectedMenu = super.moveDown()
        this.view.optionList.select(this.selectedIndex, selectedMenu)
      }
    }
  }

  moveUp() {
    if (this.isLoaded) {
      if (this.currentScreen === "epgList") {
        this.epgList.view.selectedNode.dom.childNodes[0].classList.remove("newArrow")
        this.epgList.prev()
        this.loadoptionList()
      } else if (this.currentScreen === "actionList") {
        if (this.selectedIndex === 0 && this.regionalPageId === 0 && this.epgList.currentItem.id === 888) {
          // Case when up on first index on regional
          this.optionList=this.optionAdditional.slice(8)
          this.regionalPageId = 1
          this.selectedIndex = 4
          this.view.loadItems(this.optionList)
          const selectedMenu = this.optionList[4]
          this.view.optionList.select(this.selectedIndex, selectedMenu)
          return
        }
        if (this.selectedIndex === 0 && this.regionalPageId) {
          this.optionList=this.optionAdditional.slice(0,8)
          this.regionalPageId=0
          this.view.loadItems(this.optionList)
          this.selectedIndex=8
        }
        const selectedMenu = super.moveUp()
        this.view.optionList.select(this.selectedIndex, selectedMenu)
      }
    }
  }



  onLeft() {
    if (this.isLoaded && this.currentScreen === "actionList") {
      this.view.optionList.blur()
      this.epgList.focus()
      this.currentScreen = "epgList"
      this.epgList.view.selectedNode.dom.childNodes[0].classList.remove("newArrowBlack")
      this.epgList.view.selectedNode.dom.childNodes[0].classList.add("newArrow")
    }
  }

  onRight() {
    if (this.isLoaded && this.currentScreen === "epgList") {
      console.log("this.optionList",this.optionList)
      if (this.optionList[0].name === "") return
      this.epgList.blur()
      this.view.optionList.focus()
      this.selectedIndex = 0
      this.currentScreen = "actionList"
      this.epgList.view.selectedNode.dom.childNodes[0].classList.remove("newArrow")
      this.epgList.view.selectedNode.dom.childNodes[0].classList.add("newArrowBlack")
    }

  }

  loadoptionList() {
    this.regionalPageId = 0
    if (this.epgList.currentItem.id === 1 || this.epgList.currentItem.id === 4 ||
       this.epgList.currentItem.id === 6 || this.epgList.currentItem.id === 888) {
      this.filtersSubArray = ChannelManager.getGenreSubFilterList(this.epgList.currentItem.id)
      this.optionList = []
      this.filtersSubArray.forEach((element) => {
        this.optionList.push({id:element.id , name : element.title})
      })
      if (this.optionList.length > 8) {
        this.optionAdditional = Object.assign([], this.optionList)
        this.optionList.length=8
        this.view.loadItems(this.optionList)
      }
      this.view.loadItems(this.optionList)
      this.view.unsetOption()
      this.epgList.view.selectedNode.dom.childNodes[0].classList.add("newArrow")
    } else {
      this.optionList = [
      {name:""},
      ]
      this.view.loadItems(this.optionList)
      this.view.unsetOption()
      this.epgList.view.selectedNode.dom.childNodes[0].classList.remove("newArrow")
    }
  }

  trigger() {
    if (this.isLoaded) {
      if (this.epgList.currentItem.id === 1 || this.epgList.currentItem.id === 4 ||
        this.epgList.currentItem.id === 6 || this.epgList.currentItem.id === 888) {
        if (this.currentScreen === "actionList") {
          this.filterSubArray = ChannelManager.getGenreSubFilterList(this.epgList.currentItem.id)
          if (this.regionalPageId ===1) {
            this.subFiterObj = this.filterSubArray[this.view.optionList.focusedIdx+8]
          } else {
            this.subFiterObj = this.filterSubArray[this.view.optionList.focusedIdx]
          }
          if (this.subFiterObj) {
            let selectedFilter = (this.epgList.currentItem.id === 888)
              ? [this.subFiterObj.id] : [this.epgList.currentItem.id , this.subFiterObj.id]
            if (this.subFiterObj.id === 999)  selectedFilter = [this.epgList.currentItem.id]
            if (this.epgList.currentItem.id === 888)  this.selectedSubGenre = this.subFiterObj.title
            this.loadGrid(selectedFilter)
          }
        }
      } else {
        this.loadGrid([this.epgList.currentItem.id])
      }
    }
  }
  loadGrid(arr) {
    ChannelManager.getChannelsByGenre(arr)
       .then(() =>  {
         if (ChannelManager.channelsForGenre.length === 0) {
           epgNoChannels()
           return
         }
         this.selectedFilterId = this.epgList.currentItem.id
         this.filterpage=0
         this.view.hide()
         this.selectedGenre = this.epgList.currentItem.title
         bus.emit("epg:opengrid")
         // bus.emit("channels:genreUpdated")
       })
  }

  @on("EpgMenu:close")
  close() {
    this.view.clearEpgList()
    return this.view.hide()
  }
}
