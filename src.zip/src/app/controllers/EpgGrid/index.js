//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {createReminder} from "services/api/reminder"

import CDSQueryFactory from "services/api/cds"
import {setEpgLanguage} from "services/api/program"

import Controller from "utils/Controller"
import config from "utils/config"
import bus from "services/bus"
import {_, locale} from "utils/locale"
import {on, rcu, rcuLong} from "services/events"
import {isDefined, noop, debounce} from "utils"
import CircularList from "utils/CircularList"
import ModManager from "services/managers/ModManager"
import {getLocale} from "services/managers/config"
import {
  LINE_NUMBERS,
  TIMELINE_DURATION,
  SCROLL_DIRECTIONS,
  buildView,
} from "app/utils/epg"

import {
  addHours,
  toString,
  addMinutes,
  dateToCdsTimestamp,
} from "utils/date"

import * as popUpMsg from "app/utils/PopUpMsg"

import {$} from "widgets/Component"
import Program from "services/models/Program"
import TimezoneManager from "services/managers/TimezoneManager"
import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import PVRManager from "services/managers/PVRManager"
import CamManager from "services/managers/CamManager"
import GenreChannel from "services/models/channels/GenreChannel"
import ProgramReminder from "services/managers/ProgramReminder"

import EpgDetails from "./EpgDetails"
import EpgFilter from "./EpgFilter"
import EpgMenu from "./EpgMenu"

class EpgProgram extends Program {
  constructor(props) {
    super(props)
    this.view = {
      "width": 0,
      "x": 0,
      "ongoing": false,
    }
  }

  buildView(start) {
    return buildView(this, start)
  }

  update(props) {
    this.updateAttributes(props)
  }
}

export default class EpgGridController extends Controller {
  static delegates = [EpgDetails, EpgFilter,EpgMenu]

  constructor() {
    super()
    this.channel = {
      list: new CircularList([]),
      selected: 0,
    }

    this.timeLine = {
      idx: 0,
      start: null,
      end: null,
      list: [],
    }

    this.page = {
      count: 0,
      current: 0,
    }

    this.program = {
      grid: {},
      row: 0,
      selected: 0,
    }

    this.view = $("epgGrid")
    this.defaultGrid = false
    this.gridOpenInProgress = false
    this.epgDays = config.SD_ZAPPER ? 1 : 4
  }

  get selectedChannel() {
    return this.channel.list.get(this.channel.selected)
  }

  get selectedProgram() {
    return this._currentProgram
  }

  set selectedProgram(value) {
    this._currentProgram = value
  }

  _updateProgramInfosView(program) {
    const item = {
      title: program.title,
      genre: program.category,
      description: program.description,
    }
    if (program.startDate && program.endDate) {
      const startDate = TimezoneManager.getFormatTime(program.startDate)
      const endDate = TimezoneManager.getFormatTime(program.endDate)
      item.date = startDate + " - " + endDate
    }
    return this.view.update(item)
  }

  _getSelectedProgramInfos() {
    const program = this.selectedProgram
    if (!isDefined(program)) {
      return Promise.resolve()
    } else if (!program.id) {
      return this._updateProgramInfosView(program)
    } else {
      const queryFactory = new CDSQueryFactory("programs")
        .metadata("description", "short_description")
        .filter("program_id", "==", program.programId)
        .limit(1)
      return queryFactory.direct().then((response) => {
        program.update(response[0])
        return this._updateProgramInfosView(program)
      })
    }

  }

  /* ********* Open/Close functions ********* */
  @on("epg:open")
  show() {
    if (ChannelManager.channels.length === 0) {
      return popUpMsg.noServices(() => {
        bus.openUniverse("home")
      })
    }
    bus.emit("clock:open", "epg")
    this.EpgMenu.open()
    this.activeDelegate = this.EpgMenu
  }

  @on("epg:directOpen")
  openGuide() {
    bus.universe="epg"
    if (ChannelManager.channels.length === 0) {
      return popUpMsg.noServices(() => {
        bus.openUniverse("home")
      })
    }
    this.EpgMenu.selectedGenre = "All Channels"
    this.EpgMenu.selectedFilterId = undefined
    bus.emit("clock:open", "epg")
    bus.emit("epg:opengrid", ChannelManager.current)
  }

  @on("epg:opengrid")
  openGrid(channel) {
    if (bus.universe !== "epg") {
      return
    }

    const selectOngoing = true
    return Promise.all([
      this.loadChannels(channel),
      this.showDate(new Date()),
      this.loadTimeline(),
      this.view.setGenre(this.EpgMenu),
      this.loadPrograms(selectOngoing),
    ]).then(() => {
      if (!this.defaultGrid) {
        this.activeDelegate = null
      }
      this.view.open()
    })
  }

  closeGridOpenTv() {
    this.close()
    bus.emit("clock:close")
    bus.openUniverse("tv")
  }


  @on("epg:watch")
  _onWatch() {
    if (PVRManager.ongoing.length > 0 && !this.selectedProgram.isRecording &&
      this.selectedProgram.isOngoing) {
      if (PVRManager.ongoing[0].serviceId === this.selectedProgram.serviceId) {
        this.closeGridOpenTv()
      } else {
        this.showRecordConflictPopUp(this.selectedProgram)
        bus.emit("EpgDetails:close")
      }
    } else {
      let selectedChannel
      if (this.selectedChannel instanceof GenreChannel) {
        selectedChannel = ChannelManager.getChannelFromServiceId(this.selectedChannel.serviceId)
      } else {
        selectedChannel = this.selectedChannel
      }
      PlayerManager.play(selectedChannel)
      window.setTimeout(() => {
        this.closeGridOpenTv()
      },500)
    }
  }

  @on("epg:close")
  close() {
    this.activeDelegate = null
    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    return Promise.all(promises).then(() => {
      return this.view.close()
    })
  }

  /* ************************************************************************ */

  /* ********* P+/P- & Arrow Keys ********* */
  @rcuLong("epg:up:press")
  @rcuLong("epg:down:press")
  longMoveVertical(direction) {
    this._longMoveVertical = window.setInterval(() => this.moveVertical(direction), 150)
  }

  @rcu("epg:up:press")
  @rcu("epg:down:press")
  moveVertical(direction) {

    if (this.activeDelegate === this.EpgDetails) {
      if (direction === "UP") {
        this.EpgDetails.prev()
      } else {
        this.EpgDetails.next()
      }
      return
    } else if (this.activeDelegate === this.EpgMenu) {
      if (direction === "UP") {
        this.EpgMenu.moveUp()
      } else {
        this.EpgMenu.moveDown()
      }
      return
    }

    const delta = SCROLL_DIRECTIONS[direction]
    const currentChannelIndex = this.channel.selected
    const futureChannel = currentChannelIndex + delta
    if ((futureChannel < 0) ||
          (futureChannel > this.channel.list.count - 1)) {
      return
    }
    this.channel.selected = futureChannel
    if ((currentChannelIndex % LINE_NUMBERS === 0 && delta < 0)
      || (currentChannelIndex % LINE_NUMBERS === 4 && delta > 0)) {
      this.changePage(delta)
    } else {
      this.view.move(direction, this.channel.selected)
      this.selectProgram(this.program.selected)
    }
  }

  @rcuLong("epg:left:press")
  @rcuLong("epg:right:press")
  longMoveHorizontal(direction) {
    this._longMoveHorizontal = window.setInterval(() => this.moveHorizontal(direction), 150)
  }

  @rcu("epg:left:press")
  @rcu("epg:right:press")
  moveHorizontal(direction) {
    if (this.activeDelegate === this.EpgMenu) {
      if (direction === "LEFT") {
        return this.EpgMenu.onLeft()
      } else if (direction === "RIGHT") {
        return this.EpgMenu.onRight()
      }
    }

    if (this.activeDelegate === this.EpgDetails) {
      return
    }

    const delta = SCROLL_DIRECTIONS[direction]

    if (this.program.selected === 0 && delta < 0) {
      return this.changeTimeSlot(delta)
        .catch(noop)
    } else {
      const futureItem = this.program.selected + delta
      return this.selectProgram(futureItem, true)
    }
  }

  @rcuLong("epg:program_plus:press")
  @rcuLong("epg:program_minus:press")
  longChangePage(direction) {
    this._longChangePage = window.setInterval(() => this.changePage(direction), 150)
  }

  @rcu("epg:program_plus:press")
  @rcu("epg:program_minus:press")
  changePage(direction) {
    if (this.activeDelegate === this.EpgDetails || this.activeDelegate === this.EpgMenu) {
      return
    }

    if (isNaN(direction)) {
      direction = SCROLL_DIRECTIONS[direction]
    }
    const nextPageIdx = this.page.current + direction
    if ((nextPageIdx > this.page.count) || (nextPageIdx < 0)) {
      return
    }

    let newChannelIdx = nextPageIdx * LINE_NUMBERS
    if (direction < 0) {
      newChannelIdx = newChannelIdx + (LINE_NUMBERS - 1)
    }
    let newChannel = this.channel.list.get(newChannelIdx)
    if ((nextPageIdx === this.page.count) && (direction < 0)) {
      newChannel = this.channel.list.get(this.channel.list.count - 1)
    }
    return this.selectChannel(newChannel).then(() => {
      this.page.current = nextPageIdx
      this.view.flush()
      this.view.update(null)
      this.needFill = true
    })
  }

  @rcu("epg:up:release")
  @rcu("epg:down:release")
  upDownRelased() {
    if (this._longMoveVertical) {
      window.clearInterval(this._longMoveVertical)
      this._longMoveVertical = undefined
    }
    this.directionReleased()
  }

  @rcu("epg:left:release")
  @rcu("epg:right:release")
  leftRightReleased() {
    if (this._longMoveHorizontal) {
      window.clearInterval(this._longMoveHorizontal)
      this._longMoveHorizontal = undefined
    }

    const hold = debounce(() => {
      this.directionReleased()
    },800)

    hold()
  }

  @rcu("epg:program_plus:release")
  @rcu("epg:program_minus:release")
  programReleased() {
    if (this._longChangePage) {
      window.clearInterval(this._longChangePage)
      this._longChangePage = undefined
    }
    this.directionReleased()
  }

  // @rcu("epg:up:release")
  // @rcu("epg:down:release")
  // @rcu("epg:left:release")
  // @rcu("epg:right:release")
  // @rcu("epg:program_plus:release")
  // @rcu("epg:program_minus:release")
  directionReleased() {
    if (this.needFill) {
      this.needFill = false
      this.loadPrograms()
    }
  }
  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back, Rec, Info, Ad) ********* */
  isCurrentProgramEnd() {
    return this.selectedProgram.endDate <= new Date()
  }

  @rcu("epg:ok:press")
  onOk() {

    if (this.activeDelegate === this.EpgDetails) {
      this.EpgDetails.trigger()
      return
    } else if (this.activeDelegate === this.EpgMenu) {
      this.defaultGrid = false
      this.EpgMenu.trigger()
      // this.activeDelegate = null
      return
    }

    if (!this.isCurrentProgramEnd()) {
      this.selectedProgram.channelTitle = this.selectedChannel.title
      if (this.selectedProgram.isOngoing) {
        if (this.selectedProgram.serviceId !== ChannelManager.current.serviceId)
          bus.emit("epg:watch")
        return
      }
      this.EpgDetails.open(this.selectedProgram)
      this.activeDelegate = this.EpgDetails
    }
  }

  @rcu("epg:ad:press")
  onAd() {
    bus.emit("adbanner:inflate")
  }

  @rcu("epg:key_blue:press")
  onBlueColor() {
    if (!this.gridOpenInProgress && this.activeDelegate === null) {
      this.filtersArray = ChannelManager.getGenreFilterList()
      let index = this.filtersArray.findIndex((e)=>e.title===this.EpgMenu.selectedGenre)
      if (index === this.filtersArray.length-1) {
        index=0
      } else {
        index++
      }
      const focusedGenre = this.filtersArray[index]
      this.EpgMenu.selectedGenre = focusedGenre.title
      this.EpgMenu.selectedFilterId = focusedGenre.id

      if (focusedGenre.title === "Regional") {
        this.onBlueColor()
        return
      }
      this.gridOpenInProgress = true
      ChannelManager.getChannelsByGenre([focusedGenre.id])
      .then(() =>  {
        this.gridOpenInProgress = false
        if (ChannelManager.channelsForGenre.length === 0) {
          this.onBlueColor()
          return
        }
        bus.emit("epg:opengrid")
        // bus.emit("channels:genreUpdated")
      })
    }
  }

  @rcu("epg:back:press")
  onBack() {
    if (this.activeDelegate === this.EpgDetails) {
      this.EpgDetails.close()
      this.activeDelegate = null
      return
    }

    this.close().then(() => {
      bus.openUniverse("home")
    })
  }

  @on("epg:record")
  _onRecFromDetails() {
    this.EpgDetails.close()
    this.activeDelegate = null

    this.onRec()
  }

  @rcu("epg:rec:press")
  onRec() {
    if (config.PVR_DISABLED) {
      return // Do Nothing if SD Zapper Mode is enabled
    }
    // If CAM is inserted then we have to block all the conax features
    if (CamManager.insertStatus) {
      popUpMsg.ConaxDisabled()
      return
    }
    if (ModManager.isCurrentChannelMod(this.selectedChannel)) return
    // Checking If Channel is MOD(Movie on Demand) then recording is not allowed
    if (this.activeDelegate === this.EpgDetails || this.activeDelegate === this.EpgMenu) {
      return
    }
    if (this.isCurrentProgramEnd()) {
      return popUpMsg.epgRecordEnded()
    }
    const x = this.program.selected
    const y = this.program.row
    const program = this.selectedProgram
    if (program.isReminder) {
      const closeCallback = () => {
        console.log("I am closeCallback")
      }
      const buttons = [
        {
          label: _("Ok"),
          action: () => {
          },
        },
      ]
      return popUpMsg.recordVSReminderConflictSameTime(buttons,closeCallback)
    }
    PVRManager.lastRecordingIdentify.x = x
    PVRManager.lastRecordingIdentify.y = y
    PVRManager.lastRecordingIdentify.isOngoing = this.selectedProgram.isOngoing
    PVRManager.recordProgram(program.programId,
                             Object.assign({channelTitle: this.selectedChannel.title,
                               channelNo: ChannelManager.getChannelFromServiceId(this.selectedChannel.serviceId),
                               isOngoing: this.selectedProgram.isOngoing}, program.getAttributes()),bus.universe)
      .then(() => {
        const obj = {
          x : this.program.selected,
          y : this.program.row,
          program : this.selectedProgram,
        }
        ProgramReminder.iconDetail[this.selectedProgram.programId] = obj
        this.view.markAsScheduled(x, y, program)
      })
      .catch(() => {})
  }

  @on("epg:show_recording_banner")
  _showRecordingBanner() {
    const obj = {
      x : this.program.selected,
      y : this.program.row,
      program : this.selectedProgram,
    }
    ProgramReminder.iconDetail[this.selectedProgram.programId] = obj
    this.view.markAsScheduled(this.program.selected, this.program.row, this.selectedProgram)
  }

  _showReminderBanner() {
    const obj = {
      x : this.program.selected,
      y : this.program.row,
      program : this.selectedProgram,
    }
    ProgramReminder.iconDetail[this.selectedProgram.programId] = obj
    this.view.markAsScheduled(this.program.selected, this.program.row, this.selectedProgram)
  }

  @on("epg:hide_recording_banner")
  _hideRecordingBanner() {
    this.view.unmarkScheduled(this.program.selected, this.program.row, this.selectedProgram)
  }

  @on("epg:remove_recording_banner")
  _removeRecordingBanner(objDetail) {
    if (objDetail !== null || objDetail !== undefined) {
      this.view.unmarkScheduled(objDetail.x, objDetail.y, objDetail.program)
    }
  }

  @on("epg:remove_reminder_banner")
  _removeReminderBanner(objDetail) {
    this.view.unmarkScheduled(objDetail.x, objDetail.y, objDetail.program)
  }

  @on("epg:hide_reminder_banner")
  _hideReminderBanner() {
    this.view.unmarkScheduled(this.program.selected, this.program.row, this.selectedProgram)
  }

  @on("epg:hide_unmarkRecodingBanner")
  _hideUnmarkRecodingBanner(program) {
    const obj = {}
    const x = program[0].x
    const y = program[0].y
    if (typeof x !== "undefined" &&  typeof y !== "undefined") {
      obj.id  = program[0].programId
      this.view.unmarkScheduled(x, y, obj)
    }
  }

  @on("epg:stop_record")
  _onStopRecFromDetails() {
    this.EpgDetails.close()
    this.activeDelegate = null
    this.onStop()
  }

  @rcu("epg:stop:press")
  onStop() {
    const x = this.program.selected
    const y = this.program.row
    const program = this.selectedProgram
    delete ProgramReminder.iconDetail[program.programId]
    PVRManager.cancel(program.programId)
      .then(() => this.view.unmarkScheduled(x, y, program))
      .catch(() => {
        const manualRecords = this.getManualRecordsFromServiceId(program.serviceId, program.startDate, program.endDate)
        const startDate = manualRecords[0].startDate
        PVRManager.cancel(null, manualRecords[0]).then(() => {
          this.view.unmarkManualRecord(y, startDate)
        })
      })
  }

  @on("pvr:conflict")
  _onConflict() {
    if (bus.universe === "epg") {
      const x = this.program.selected
      const y = this.program.row
      const program = this.selectedProgram
      this.view.unmarkScheduled(x, y, program)
    }
  }

  showRecordConflictPopUp(userContent) {
    const closeCallback = () => {
      this.EpgDetails.close()
      this.activeDelegate = null
    }
    const buttons = [
      {
        label: _("Ok"),
        action: () => {
          // Request for cancel current Recording...
          PVRManager.cancel(PVRManager.ongoing[0].programId).then(() => {
            // set the current Channel...which is Request for Recording and make tune to live..
            ChannelManager.current = ChannelManager.getChannelFromServiceId(userContent.serviceId)
            this.activeDelegate = null
            PlayerManager.play(this.selectedChannel)
            this.close().then(() => {
              bus.emit("clock:close")
              bus.openUniverse("tv")
            })
          })
        },
      },
      {
        label: "Back",
        action: closeCallback,
      },
    ]
    popUpMsg.zapConflict(buttons, closeCallback)
  }

  /* ************************************************************************ */

  changeTimeSlot(direction) {
    let newStart
    if (direction > 0) {
      newStart = this.timeLine.end
      this.timeLine.idx += 1
    } else {
      const delta = (config.SD_ZAPPER) ? -1 : -2
      newStart = addHours(this.timeLine.start, delta)
      this.timeLine.idx -= 1
    }

    if (this.timeLine.idx < 0) {
      this.timeLine.idx = 0
      return Promise.reject("EpgGrid: can't changeTimeslot because there is no valid timeslot before")
    } else {
      return Promise.all([
        this.showDate(newStart),
        this.loadTimeline(newStart),
      ]).then(() => {
        this.view.flush()
        this.needFill = true
        return this.view.update(null)
      })
    }
  }

  /* ********* Dates/Times functions ********* */
  showDate(d) {
    const clock = toString(d)
    return this.view.setClock(clock)
  }

  loadTimeline(start) {
    const dateArray = []
    let startDate = new Date()
    if (isDefined(start)) {
      startDate = new Date(start)
    }

    startDate = new Date(startDate.setMinutes(0))
    const endDate = addMinutes(startDate, TIMELINE_DURATION)
    let currentDate = startDate

    while (currentDate < endDate) {
      let minutes = currentDate.getMinutes()
      if (minutes < 10) {
        minutes += "0"
      }
      const data = currentDate.getHours() + ":" + minutes
      dateArray.push(data)
      currentDate = addMinutes(currentDate, 30)
    }
    const present = new Date()
    const highlimit = addMinutes(present,(this.epgDays*24*60))
    if (endDate.getTime() <= highlimit.getTime() && endDate.getTime() >= present.getTime()) {
      this.timeLine.start = startDate
      this.timeLine.end = endDate
      this.timeLine.list = dateArray
      return this.view.loadTimeline(this.timeLine)
    }
    return false

  }

  /* ************************************************************************ */

  /* ********* Channels load/select functions ********* */
  _prepareChannelForSelection(channel) {
    const channelIndex = this.channel.list.indexOf(channel)
    this.page.current = Math.floor(channelIndex / LINE_NUMBERS)
    this.channel.selected = channelIndex
  }

  _loadChannels(channels, selectedChannel) {
    this.channel.list.update(channels)
    this.page.count = Math.ceil((this.channel.list.count / LINE_NUMBERS) - 1)

    if (selectedChannel) {
      this._prepareChannelForSelection(selectedChannel)
    } else {
      this.channel.selected = 0
      this.page.current = 0
    }

    return this.view.setChannels(this.channel.list, this.channel.selected)
  }

  // @on("channels:genreUpdated")
  loadChannels(channel) {
    if (bus.universe !== "epg") {
      return Promise.reject("Not handled because not in EPG universe")
    }
    let channelList = []
    if (this.EpgMenu.selectedGenre === "All Channels") {
      channelList = channelList.concat(ChannelManager.channels)
    } else {
      ChannelManager.channelsForGenre.forEach((channel) => {
        if (channel.constructor.name === "GenreChannel") {
          channelList.push(channel)
        }
      })
    }
    return this._loadChannels(channelList, channel)
    //  .then(() => {
    //     this.loadPrograms(selectOngoing)
    //  })
  }

  selectChannel(newChannel) {
    this._prepareChannelForSelection(newChannel)
    return this.view.selectChannel(this.channel.selected)
  }
  /* ************************************************************************ */

  /* ********* Programs load/select functions ********* */

  loadPrograms(selectOngoing) {
    const serviceIdList = []
    const min = this.page.current * LINE_NUMBERS
    const max = min + LINE_NUMBERS

    this.program.grid = {}

    this.channel.list.items.slice(min, max).forEach((channelItem) => {
      serviceIdList.push(channelItem.serviceId)
      this.program.grid[channelItem.serviceId] = []
    })

    return this._queryPrograms(this.timeLine.start, this.timeLine.end, serviceIdList)
      .then(() => {
        return this.getRecordsFromServiceList(serviceIdList, this.timeLine.start, this.timeLine.end)
      }).then((manualRecords) => {
        return this.view.loadPrograms(this.program.grid, manualRecords, this.timeLine)
      }).then(() => {
        let idx = 0
        if (this.selectedProgram || selectOngoing) {
          const programList = this.program.grid[this.selectedChannel.serviceId]
          programList.find((item, index) => {
            if (selectOngoing && item.view.ongoing) {
              idx = index
              return
            } else if (this.selectedProgram && item.programId === this.selectedProgram.programId) {
              idx = index
              return
            }
          })
        }
        this.selectProgram(idx)
      })
  }

  selectProgram(programIndex, horizontal) {
    let idx = programIndex
    const channel = this.selectedChannel

    const rowIndex = this.channel.selected -
      (LINE_NUMBERS * this.page.current)
    const programList = this.program.grid[channel.serviceId]
    if (idx > programList.length - 1) {
      if (isDefined(horizontal) && horizontal === true) {
        return this.changeTimeSlot(1)
      }
      idx = programList.length - 1
    }
    const program = programList[idx]

    this.program.row = rowIndex
    this.program.selected = idx
    this.selectedProgram = program

    this.view.programChanged(rowIndex, idx)
    return this._getSelectedProgramInfos()
  }

  _getChannelPrograms(start, end, serviceId) {
    // Create the query by asking the minimal needed metaddata
    // Filter by given serviceId and specify a range
    const queryFactory = new CDSQueryFactory("programs")
      .metadata("program_id", "title", "service_id", "start_date", "end_date",
        "srs_record_task_id", "srs_record_task_class",
        "content_nibble_level_1", "content_nibble_level_2")
      .order("+start_date", "+service_id")
      .filter("service_id", "==", serviceId)
      .filter("start_date", "<=", end)
      .filter("end_date", ">=", start)

    return queryFactory.direct().then((response) => {
      const programList = []
      let previousProgramEnd = start
      response.forEach((p) => {
        const prog = new EpgProgram(p).buildView(start)

        const isNotConsecutive = (prog.cdsStartDate > previousProgramEnd)
        if (isNotConsecutive) {
          const emptyProg = new EpgProgram({
            "service_id": serviceId,
            "start_date": previousProgramEnd,
            "end_date": prog.cdsStartDate,
          }).buildView(start)
          programList.push(emptyProg)
        }
        programList.push(prog)
        previousProgramEnd = prog.cdsEndDate
      })
      if (programList.length === 0 || programList[programList.length - 1].cdsEndDate < end) {
        const emptyProg = new EpgProgram({
          "service_id": serviceId,
          "start_date": previousProgramEnd,
          "end_date": end,
        }).buildView(start)
        programList.push(emptyProg)
      }
      return this.program.grid[`${serviceId}`] = programList
    })
  }

  _queryPrograms(start, end, serviceIdList) {
    start = dateToCdsTimestamp(start)
    end = dateToCdsTimestamp(end)

    const promises = []
    for (let i=0; i<serviceIdList.length; i++) {
      promises.push(this._getChannelPrograms(start, end, serviceIdList[i]))
    }
    return Promise.all(promises)
  }


  setIndexForRecIcon(rowIndex, idx,programID) {
    if (PVRManager.ongoing.length > 0 && !PVRManager.ongoing[0].x && !PVRManager.ongoing[0].y) {
      if (programID === PVRManager.ongoing[0].programId) {
        PVRManager.ongoing[0].x = rowIndex
        PVRManager.ongoing[0].y = idx
      }
    }
  }

  /* ************************************************************************ */

  /* ********* Manual records functions ********* */
  getRecordsFromServiceList(serviceIdList, startDate) {
    const manualRecords = {}
    serviceIdList.forEach((serviceId) => {
      manualRecords[serviceId] = this.getManualRecordsFromServiceId(serviceId, startDate)
    })
    return manualRecords
  }

  getManualRecordsFromServiceId(serviceId, startDate) {
    let manualRecordsArray = []
    const schedules = PVRManager.getSchedulesFromServiceId(serviceId)
    schedules.forEach(({schedule}) => {
      if (this.isManualRecordToDisplay(schedule, startDate)) {
        manualRecordsArray.push(schedule)
      }
      // add recurrents schedules for 7 days
      const recurrentManualRecs = this.getRecurrentManualRec(schedule, startDate, 7)
      manualRecordsArray = manualRecordsArray.concat(recurrentManualRecs)
    })
    return manualRecordsArray
  }

  isManualRecordToDisplay(manualRec, startDate) {
    return (this.isManualRecToDisplayOnEpg(manualRec, startDate) && !manualRec.programId)
  }

  isManualRecToDisplayOnEpg(manualRec, startDate) {
    return manualRec &&
    ((startDate > manualRec.startDate && startDate < manualRec.endDate) ||
    (manualRec.startDate > startDate))
  }

  isDailyRecurrentManualRec(manualRec) {
    return manualRec._attributes.repetition === "daily"
  }

  getRecurrentManualRec(manualRec, startDate, period) {
    const oneDay = 1000 * 60 * 60 * 24
    const recurrentManualRec = []
    const tmsStartDate = manualRec.startDate.getTime()
    const tmsEndDate = manualRec.endDate.getTime()
    if (manualRec && this.isDailyRecurrentManualRec(manualRec)) {
      let i = 1
      while (recurrentManualRec.length < period) {
        if (tmsStartDate + (i * oneDay) > startDate.getTime()) {
          const _manualRec = Object.assign({}, manualRec, {
            startDate: new Date(tmsStartDate + (i * oneDay)),
            endDate: new Date(tmsEndDate + (i * oneDay / 1000)),
            duration: ~~((tmsEndDate - tmsStartDate) / 1000),
          })
          recurrentManualRec.push(_manualRec)
        }
        i++
      }
    }
    return recurrentManualRec
  }

  @on("epg:watch_channel")
  _onWatchChannel(data) {
    ChannelManager.getChannelFromLcn(data.channel_number)
    .then((response) => {
      const channel = response.resource.real || response.resource.fallback
      this.close(channel)
      PlayerManager.playCurrentChannel(channel)
      bus.openUniverse("tv")
    })
  }

  @on("epg:set_reminder")
  _onSetReminder(data, fromShortcutKey) {
    const {list} = PVRManager._getScheduleIdx(this.selectedProgram.id, "program")
    if (list) {
      const closeCallback = () => {
        console.log("I am closeCallback")
      }
      const buttons = [
        {
          label: _("Ok"),
          action: () => {
          },
        },
      ]
      if (config.SD_ZAPPER && fromShortcutKey) {
        PVRManager.cancel(this.selectedProgram.programId)
        this._hideRecordingBanner()
        delete ProgramReminder.iconDetail[this.selectedProgram.programId]
        return
      } else {
        popUpMsg.recordVSReminderConflictSameTime(buttons,closeCallback)
        return
      }
    }
    if (!this.selectedProgram.programId) {
      popUpMsg.reminderNotPossible()
    }
    const tmpChList=this.channel.list.items[this.channel.selected]
    const params={
      "name":this.selectedProgram.programId.toString(),
      "duration":(this.selectedProgram.cdsEndDate-this.selectedProgram.cdsStartDate).toString(),
      "event":this.selectedProgram.programId.toString(),
      "class": "content_program_id",
      "preview_time" : "60",
      "channel_name": tmpChList.title,
      "channel_number":tmpChList.lcn.toString(),
      "start_hour":this.selectedProgram.startDate.toLocaleTimeString(navigator.language,
      {hour: "2-digit", minute:"2-digit"}),
      "title": this.selectedProgram.title.trim(),
      "service_id":this.selectedProgram.serviceId.toString(),
    }
    PVRManager.lastReminderServiceId = params.service_id
    // logic for checking current program
    if (this.selectedProgram.view && !this.selectedProgram.view.ongoing) {
      createReminder(params).then(() => {
        this._showReminderBanner()
      })
    }
    if (!fromShortcutKey) {
      this.onBack()
    }
  }

  @on("epg:cancelReminder")
  onCancelReminder() {
    PVRManager.cancel(this.selectedProgram.programId)

    this._hideRecordingBanner()
    delete ProgramReminder.iconDetail[this.selectedProgram.programId]
    this.onBack()
  }
  @on("channels:updated")
  @on("epg:openDefault")
  _onOpenDefault() {
  //  const channel = ChannelManager.channels[0]
    this.EpgFilter.defaultTrigger()
    .then((isBlank = false) => {
      if (isBlank) {
        return
      }
      return new Promise((resolve) => {
        this.channel.list.update(ChannelManager.channels)
        this.page.count = Math.ceil((this.channel.list.count / LINE_NUMBERS) - 1)
        this.view.setChannels(this.channel.list, this.channel.selected)
        this.selectChannel(this.selectedChannel)
        this.loadPrograms()
        resolve()
      })
    })
  }

// Locale language change
  @on("locale:update")
  onLocaleUpdate() {
    if (bus.universe === "epg") {
      setEpgLanguage(locale.current)
      setTimeout(()=>{
        this.loadPrograms()
      },1000)
    }
  }
}
