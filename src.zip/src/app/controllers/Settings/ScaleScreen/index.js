//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {_} from "utils/locale"
import {$} from "widgets/Component"
import bus from "services/bus"
import {on} from "services/events"
import {setApplicationScale, getApplicationScale} from "services/managers/config"

export default class ScaleScreenController extends Controller {
  constructor() {
    super()
    this.view = $("scaleScreen")
    this.currentScale = null
  }

  open() {
    this.view.show()
    this.view.setTitle(_("Screen Adjustment"))
    this.view.setContent(_("Select on your remote control the biggest number displayed"))
    return getApplicationScale()
      .then((value) => this.selecteScale(value))
  }

  @on("settings:close")
  close() {
    this.view.hide()
    return Promise.resolve()
  }

  onBack() {
    return this.close()
  }

  onOk() {
    return false
  }

  moveUp() {
    return false
  }

  moveDown() {
    return false
  }

  onLeft() {
    return false
  }

  onRight() {
    return false
  }

  onInput(kbd, _) {
    switch (_) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
      this.selecteScale(_)
      break
    default:
      console.warn("Scale value is not valid")
    }
  }

  selecteScale(value) {
    this.currentScale = value
    this.view.setValue(value)
    bus.emit("application:scale", this.currentScale)
    setApplicationScale(this.currentScale)
  }
}
