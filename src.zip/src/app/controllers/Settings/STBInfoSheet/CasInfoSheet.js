//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"
import {_} from "utils/locale"
import AbstractSetting from "../AbstractSetting"

export default class CasInfoSheetController extends AbstractSetting {

  constructor() {
    super()
    this.view = $("CasInfoSheet")
    this.lastUniverse="settings"
  }
  open(sub) {
    bus.emit("settings:updateSettingsHeader", _("CA Info Sheet"), true)
    this.view.onForeground()
    this.sub = sub
    return super.open()
  }

  @on("CasInfoSheet:close")
  onBack() {
    this.view.onBackground()
    return Promise.resolve()
  }

  load() {
    this.view.onLoad(this.sub)
  }
}
