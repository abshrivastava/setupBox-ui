//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {on} from "services/events"
import bus from "services/bus"
import Controller from "utils/Controller"
import {$} from "widgets/Component"
import ScanManager from "services/managers/ScanManager"

export default class ScanProgressController extends Controller {
  constructor() {
    super()
    this.view = $("scanProgress")
    this.lastUniverse="settings"
    this.type=""
    this.setPopUpBackUniverse = false
  }

  get running() {
    return ScanManager.running
  }

  open() {
    bus.emit("settings:updateSettingsHeader")
    this.view.show()
  }

  setUniverseToDisplayOnCompletion(u) {
    this.lastUniverse=u.univ
    this.type = u.type
  }

  close() {
    return this.view.hide().then(() => {
      return Promise.resolve()
    })
  }

  load() {
    return Promise.resolve()
  }

  @on("ScanProgress:close")
  onClose() {
    this.close()
  }

  /** function:: start(parameter)
   * starts the scan based on below parameters
   *   :type ::enter the type of scan i.e. Easy or TP
   *   :tpSetId :: Tranponder Set Id
   *   :name :: DVB_NAME as per th escan type e.g. DVBT
   *   :nit: set value to true
   *   :showFreeToAir: set to true to show the FTA channels
   *   :showScrambled: set to true to show the scrambled channels
   *   :scanTp: type of scan set to NIT_SCAN or EASY_SCAN
  */

  start(type, tpSetId, name, nit, showFreeToAir, showScrambled,scanTp) {
    return new Promise((resolve) => {
      this.open()
      ScanManager.showFreeToAir = showFreeToAir
      ScanManager.showScrambled = showScrambled
      ScanManager.start(type, tpSetId, name , nit,scanTp)
      .then(() => {
        return resolve(true)
      }).catch(() => {
        return resolve(false)
      })
    })
  }

  stop() {
    ScanManager.stop()
  }

  @on("scan:after_started")
  afterScanStarted() {
    this.view.start()
    this.view.pullBlackScreen() // fake progress bar remove
    if (ScanManager.svlDvbUri) // fake progress bar add
      this.view.pushBlackScreen()
  }

  @on("scan:progress")
  onScanProgress(current, tpInfos, nit) {
    this.view.updateProgress(current, tpInfos, nit)
  }

  @on("scan:service_update")
  onServiceUpdate(serviceList) {
    this.view.update(serviceList, ScanManager.tvFound, ScanManager.radioFound, ScanManager.serviceFound)
  }

  @on("scan:finished")
  onScanFinished() {
    this.view.commitStart()
  }

  @on("scan:complete")
  @on("scan:stopHamsterWheel")
  onScanComplete() {
    this.view.commitDone()
    this.view.pullBlackScreen() // fake progress bar remove
  }
}
