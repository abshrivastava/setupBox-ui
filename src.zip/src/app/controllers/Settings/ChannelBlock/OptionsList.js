//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import AbstractSetting from "app/controllers/Settings/AbstractSetting"

export default class OptionsListController extends AbstractSetting {

  // constructor() {
  //   super()
  //  this.view = $(view)
  // this.selectedIdx = 0
  // }

  open() {
    this.optionList = []
    const START_SCAN_ITEM = {
      name: "Save & Exit",
      action: "channelblock:save",
    }
    const STOP_SCAN_ITEM = {
      name: "Cancel & Exit",
      action: "channelblock:exit",
    }
    this.optionList.push(START_SCAN_ITEM)
    this.optionList.push(STOP_SCAN_ITEM)
    this.maxInputs = 2

    this.view.loadItems(this.optionList)
    return Promise.resolve()
  }


  loadItems() {
    this.selectedIndex = 0
  }

  onOk() {
    console.log("clicked",this.selectedIndex)
  }

  setView(view) {
    this.view=view
  }


  moveUp() {
    const selectedMenu = super.moveUp()
    this.view.optionList.select(this.selectedIndex, selectedMenu)
  }

  moveDown() {
    const selectedMenu = super.moveDown()
    this.view.optionList.select(this.selectedIndex, selectedMenu)
  }

  onLeft() {
    this.view.optionList.deselect(0)
    this.view.optionList.deselect(1)
    this.selectedIndex=0
  }

  onRight() {
    this.selectedIndex=0
    this.view.optionList.select(0)
  }

  focus() {
    this.view.optionList.focus()
  }

  blur() {
    this.view.optionList.blur()
  }



}
