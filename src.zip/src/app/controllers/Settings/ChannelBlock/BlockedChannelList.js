//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import {ListObj} from "app/utils/widgets/lists"

import Controller from "utils/Controller"

import {$} from "widgets/Component"
import {pushState, pullState} from "utils/dom"


import ChannelManager from "services/managers/ChannelManager"
import BlockedChannelManager from "services/managers/BlockedChannelManager"

const ZERO_INDEX = 0
const FIRST_INDEX = 1
const SEVENTH_INDEX = 7
const PAGE_SIZE = 8

export default class BlockedChannelListController extends Controller {

  constructor() {

    super()
    this.view = $("channelsBlock")
    this.allChannelServiceIds=[]
    this.newChannelArr=[]
    this.BlockServiceIds={}
    this.removeChannelBlock = []
    this.pageNumber=1
    this.Channels = []
  }

  open() {
    const noBlockChannels = BlockedChannelManager.getNoBlockList()
    this.Channels = ChannelManager.channels.slice(0)
    for (const item in noBlockChannels) {
      const index = this.Channels.indexOf(noBlockChannels[item])
      if (index > -1) {
        this.Channels.splice(index, 1)
      }
    }
    this.pageNumber=1
    this.BlockServiceIds={}
    this.removeChannelBlock=[]
    this.loadChannels(ZERO_INDEX, PAGE_SIZE)

    return Promise.resolve()
  }

  moveUp() {
    if (this.channelListObj.selected % PAGE_SIZE === ZERO_INDEX
        && this.channelListObj.selected !== FIRST_INDEX) {
      if (this.pageNumber !== FIRST_INDEX) {
        this.pageNumber--
        const pageupStartIndex = ((this.pageNumber - FIRST_INDEX) * SEVENTH_INDEX) + (this.pageNumber - FIRST_INDEX)
        const pageupLastIndex = ((this.pageNumber - FIRST_INDEX) * SEVENTH_INDEX) +
         PAGE_SIZE + (this.pageNumber - FIRST_INDEX)
        this.loadChannels(pageupStartIndex, pageupLastIndex)
        this.channelListObj.selected = PAGE_SIZE
      }
    }
    this.channelListObj.up()


  }

  moveDown() {
    if (this.channelListObj.selected % SEVENTH_INDEX === 0 &&
      this.channelListObj.selected !== ZERO_INDEX) {
      const pagedownStartIndex = (this.pageNumber * SEVENTH_INDEX) + this.pageNumber
      const pagedownLastIndex = (this.pageNumber * SEVENTH_INDEX) + PAGE_SIZE + this.pageNumber
      this.loadChannels(pagedownStartIndex, pagedownLastIndex)
      this.pageNumber++
    } else {
      this.channelListObj.down()
    }
  }


  onOk() {
    this.eventOnChannelSelection()
  }

  onLeft() {
    pullState(this.view.channelsList.selector.ChannelSelector, "hidden")
  }

  onRight() {
    pushState(this.view.channelsList.selector.ChannelSelector, "hidden")
  }

  loadChannels(startIndex, lastIndex) {
    this.newChannelArr=[]
  //  this.applyLockOnChannelScreen()
    // return new Promise((resolve) => {
    const channelList = this.Channels.slice(startIndex, lastIndex)
    this.allChannelServiceIds = []
    for (let iCounter = 0; iCounter < channelList.length; iCounter++) {
      const obj = {}
      obj.label = channelList[iCounter].lcn + " " + channelList[iCounter].title
      obj.serviceId = channelList[iCounter].serviceId

      this.newChannelArr.push(obj)
      this.allChannelServiceIds.push(channelList[iCounter].serviceId)
    }
    this.channelListObj = new ListObj(this.newChannelArr,this.view.channelsList)

    this.applyLockOnChannelScreen()
      // resolve()
    // })
  }
      /* *********  functions used for add locks on single channel ********* */
  applyLockOnChannelScreen() {
      // geting all blocked channel list
    BlockedChannelManager.getBlockedChannels().then((serviceIds) => {

      const navigateChannelArray = []
      // This Iteration to maintain user's block/unblock channels on previous page
      for (const Item in this.BlockServiceIds) {
        if (serviceIds.indexOf(Item) === -1) {
          navigateChannelArray.push(Item)
        }
      }
      // This Iteration to maintain user's block/unblock channels on saved in Middleware
      for (let iCounter = 0; iCounter < serviceIds.length; iCounter++) {
        if (this.removeChannelBlock.indexOf(serviceIds[iCounter]) === -1) {
          this.BlockServiceIds[serviceIds[iCounter]] = iCounter
        }
        navigateChannelArray.push(serviceIds[iCounter])
      }
      // This Iteration to add/remove lock Icon
      for (let index = 0; index < navigateChannelArray.length; index++) {
        const indexOfBlockChannel = this.allChannelServiceIds.indexOf(navigateChannelArray[index])
        if (indexOfBlockChannel !== -1 && this.removeChannelBlock.indexOf(navigateChannelArray[index]) === -1) {
          this.BlockServiceIds[navigateChannelArray[index]] = this.BlockServiceIds[navigateChannelArray[index]]
          this.view.channelsList.addLock(indexOfBlockChannel)
        }
      }
    })
  }


  eventOnChannelSelection() {

    const channelList = this.Channels
    const channelBlock = channelList[((this.pageNumber - FIRST_INDEX) * PAGE_SIZE) +
           this.view.channelsList.focusedIdx]
    let isChannelInBlockList = true
    for (const item in this.BlockServiceIds) {
      if (channelBlock.serviceId === item) {
        // This block executes when user unlock one channel
        this.removeChannelBlock.push(item)
        delete this.BlockServiceIds[item]
        this.view.channelsList.removeLock(this.view.channelsList.focusedIdx)
        isChannelInBlockList = false
        if (channelBlock.serviceId === ChannelManager.current.serviceId &&
           !BlockedChannelManager.getBlockedChannelsMap().hasOwnProperty(channelBlock.serviceId)) {
          BlockedChannelManager.setCurrentChannelStatus(false)
        }
        break
      }
    }
    if (isChannelInBlockList) {
      // This block executes when user lock one channel
      if (this.removeChannelBlock.indexOf(channelBlock.serviceId) > -1) {
        const idx = this.removeChannelBlock.indexOf(channelBlock.serviceId)
        this.removeChannelBlock.splice(idx,1)
      }
      this.BlockServiceIds[channelBlock.serviceId] = this.view.channelsList.focusedIdx
      this.view.channelsList.addLock(this.view.channelsList.focusedIdx)
      if (channelBlock.serviceId === ChannelManager.current.serviceId &&
         !BlockedChannelManager.getBlockedChannelsMap().hasOwnProperty(channelBlock.serviceId)) {
        BlockedChannelManager.setCurrentChannelStatus(true)
      }
    }
  }
}
