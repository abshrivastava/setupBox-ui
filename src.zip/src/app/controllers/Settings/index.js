//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import bus from "services/bus"
import {on, rcu, rcuLong} from "services/events"
import {factoryReset} from "services/api/reset"
import * as popUpMsg from "app/utils/PopUpMsg"
import {createTicker} from "utils"
import Settings from "app/models/Settings"
import {TreeObj} from "app/utils/widgets/lists"
import * as camApi from "services/api/cam"
import {setDefaultAudio, setDefaultAvio, setTimeFormat, setLastTunedLcn,
updateTimeZone, updateDefaultTrack, setDefaultTvType, setDefaultCVBS,
deleteEntry, updateAudiotracks, setDiseqcType, getNetworkTp} from "services/managers/config"
import {setState} from "services/api/power"

import {
  TimezoneManager,
  ChannelManager,
  PlayerManager,
  FtaBlockManager,
  PVRManager,
  ScanManager,
  SoftwareUpdateManager,
  ComboButton,
  transponders,
  CamManager,
  VersionManagers,
  NetworkTp,
} from "services/managers"

import BlockedChannelManager from "services/managers/BlockedChannelManager"

import ChannelBlock from "./ChannelBlock/"
import Cam from "./Cam/"
import Scan from "./Scan"
import ScanProgress from "./ScanProgress"
import STBInfoSheet from "./STBInfoSheet/"
import AdvancedScan from "./AdvancedScan/"
import SettingsSub from "./SettingsSub"
import TransponderList from "./TransponderList"
import Favorites from "./Favorites"
import License from "./Tools"

const MODEL = new Settings()

export default class SettingsController extends Controller {
  static delegates = [
    Scan,
    AdvancedScan,
    ScanProgress,
    SettingsSub,
    ChannelBlock,
    STBInfoSheet,
    TransponderList,
    Cam,
    Favorites,
    License,
  ]

  constructor() {
    super()
    this.refreshClockTimer = 1500
    this.clockUpdater = createTicker(this.refreshClockTimer)
    this.activeDelegate = null
    this.view = $("settingsMenu")
    this.tree = new TreeObj(this.view.settingsTree)
    this.hiddenKey = []
    this.MAPPING_TIMEOUT = 3000
    this.comboMenu = false
    this.if2IF = false
  }

  updateClock() {
    this.view.updateClock(new Date())
  }

  /* ********* Open/Close functions ********* */
  @on("settings:open")
  open() {
    this.tree.setItems(0,MODEL.items)
    this.tree.getChildren().then((items) => {
      if (items) this.tree.setItems(this.tree.selected + 1, items)
      // if (!FtaBlockManager.isNavigationRestricted() && !FtaBlockManager.onAdvancedScan)
      this.view.show()
    })
    this.activeDelegate = null
    bus.emit("settings:updateSettingsHeader")
  }

  @on("settings:updateSettingsHeader")
  updateSettingsHeader(subHeading="", showDateTime=false) {
    this.view.pullState("hidden")
    this.view.setHeading(subHeading)
    if (showDateTime) {
      this.clockUpdater.start(() => this.updateClock())
    } else {
      this.clockUpdater && this.clockUpdater.stop()
      this.view.setDateTime("", "")
    }
  }

  @on("settings:closeSettingsView")
  closeView() {
    this.activeDelegate = null
    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    this.view.hide()
    if (!ScanManager.isFirstInstall && !ScanManager.svlDvbUri) bus.openUniverse("tv")
    bus.emit("home:close")
    return Promise.all(promises).then(() => {
      this.tree.reset()
    })
  }

  @on("settings:close")
  close() {
    this.updateSettingsHeader()
    this.clockUpdater.stop()
    this.activeDelegate = null
    const promises = []
    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }
    this.view.hide()
    return Promise.all(promises).then(() => {
      this.tree.reset()
    })
  }

  @on("ftaBlockManager:close")
  closefta() {
    this.view.hide()
    this.tree.reset()
  }

  /* ************************************************************************ */

  /* ********* P+/P- & Arrow Keys ********* */

  @rcuLong("settings:up:press")
  @rcuLong("blackuniverse:up:press")
  onLongUp() {
    this._longUp = window.setInterval(() => this.onUp(), 150)
  }

  @rcu("settings:up:release")
  @rcu("blackuniverse:up:release")
  onUpRelease() {
    if (this._longUp) {
      window.clearInterval(this._longUp)
      this._longUp = undefined
    }
  }

  @rcu("settings:up:press")
  @rcu("blackuniverse:up:press")
  onUp() {
    if (this.activeDelegate) {
      this.activeDelegate.moveUp()
    } else {
      this.tree.up()
    }
  }

  @rcuLong("settings:down:press")
  @rcuLong("blackuniverse:down:press")
  onLongDown() {
    this._longDown = window.setInterval(() => this.onDown(), 150)
  }

  @rcu("settings:down:release")
  @rcu("blackuniverse:down:release")
  onDownRelease() {
    if (this._longDown) {
      window.clearInterval(this._longDown)
      this._longDown = undefined
    }
  }

  @rcu("settings:down:press")
  @rcu("blackuniverse:down:press")
  @on("settings:down:press")
  onDown() {
    if (this.activeDelegate) {
      this.activeDelegate.moveDown()
    } else {
      this.tree.down()
    }
  }

  @rcu("settings:left:press")
  @rcu("blackuniverse:left:press")
  onLeft(_) {
    switch (this.activeDelegate) {
    case this.AdvancedScan:
    case this.ChannelBlock:
    case this.TransponderList:
    case this.STBInfoSheet:
    //  case this.ScaleScreen: //Commented Screen adjustment code
    case this.Favorites:
      this.activeDelegate.onLeft()
      break
    default:
      this.tree.left()
      break
    }
  }

  @rcu("settings:right:press")
  @rcu("blackuniverse:right:press")
  @on("settings:right:press")
  onRight(moveRight) {
    if (this.activeDelegate === this.AdvancedScan) {
      if (moveRight) {
        this.tree.right()
      }
      this.AdvancedScan.onRight()
    } else if (this.activeDelegate === this.Favorites) {
      this.Favorites.onRight()
    } else if (this.activeDelegate === this.ChannelBlock) {
      this.ChannelBlock.onRight()
    } else if (this.activeDelegate === this.TransponderList) {
      this.TransponderList.onRight()
    } else if (this.activeDelegate === this.STBInfoSheet) {
      this.STBInfoSheet.onRight()
    } else {

      if (this.tree.selected === 0 && this.tree.lists[0].items[this.tree.lists[0].selected] &&
        this.tree.lists[0].items[this.tree.lists[0].selected].name === "parental") {
        this.onLoadChannelList({type:"EnterPin"})
        return
      }
      this.tree.right()
    }
  }
  /* ************************************************************************ */

  /* ********* Special Buttons (OK, Back, Rec, Info, Ad) ********* */
  @rcu("settings:ok:press")
  @rcu("blackuniverse:ok:press")
  onOk() {
    const isInFtaMode = FtaBlockManager.isNavigationRestricted()
    const isInFtaAdvanceScreen = FtaBlockManager.onAdvancedScan
    if (isInFtaMode && !isInFtaAdvanceScreen) return

    if (ScanManager.running || (this.activeDelegate === this.ScanProgress && ScanManager.running)) return
    if (this.activeDelegate) {
      if (this.activeDelegate === this.ScanProgress) {
        ScanManager.stop()
      } else if (this.activeDelegate === this.AdvancedScan) {
        this.activeDelegate.onOk().then((rsp) => {
          ScanManager.alwaysCommit =true
          if (rsp) bus.emit("scan:launchEasyScan",{"univ":"settings","scanType":"EASY_SCAN"})
        })
      } else if ((this.activeDelegate === this.STBInfoSheet)  && (this.activeDelegate.cashActive === true)) {
        // STBinfosheet ok press
        // Ok feature on cas information page and return from else if
        if (this.activeDelegate.cashDelegate) {
          this.activeDelegate.onCashOk()
          return
        }

        // Ok feature on STBinfosheet page
        if (this.activeDelegate.selectedBtnIndex === 0) {
          this.activeDelegate.onOk()
        }
        if (this.activeDelegate.selectedBtnIndex === 1) {
          this.activeDelegate.cashDelegate = true
          this.activeDelegate.CasStbinfoOk()
        }
        // End of STBinfosheet ok press
      } else {
        this.activeDelegate.onOk()
      }
    } else {
      this.tree.trigger()
    }
  }

  @rcu("settings:ok:release")
  @rcu("blackuniverse:ok:release")
  onOKRelease() {
    this.comboMenu = true
  }

  @on("settings:subClose")
  @rcu("settings:back:press")
  @rcu("blackuniverse:back:press")
  onBack(_, kbd) {
    const isInFtaMode = FtaBlockManager.isNavigationRestricted()
    const isInFtaAdvanceScreen = FtaBlockManager.onAdvancedScan
    if (isInFtaMode && !isInFtaAdvanceScreen) return
    if (ScanManager.isFirstInstall || ScanManager.running ||
      (this.activeDelegate === this.ScanProgress && ScanManager.running)) return
    if (this.activeDelegate === this.TransponderList) {
      if (this.TransponderList.holdTpScreen) return
      this.TransponderList.onBack(kbd)
        .then(() => {
          this.activeDelegate = null
          this.view.onForeground()
          this.ScanProgress.close()
          // this.tree.back()
          this.TransponderList.holdTpScreen = false
        })
    } else if (this.activeDelegate) {
      this.activeDelegate.onBack(kbd)
        .then(() => {
          this.activeDelegate = null
          this.view.onForeground()
          this.ScanProgress.close()
          if (bus.universe === "blackuniverse") {
            FtaBlockManager.onAdvancedScan = false
            ComboButton.onBackFtaAdvanceScreen()
          }
        })
    } else {
      this.tree.back().catch(() => {
        bus.openUniverse("home")
        this.close()
      })
    }
  }

  @on("settings:setDefaultFocus")
  onSetDefaultFocus(name,subItem=false) {
    const totalLength = this.tree.lists[0].items.length
    let i = 0
    do {
      i += 1
      const focusName = this.tree.lists[0].items[this.tree.lists[0].selected].name
      if (name === focusName) {
        bus.emit("show:setDefaultFocus:trigger",subItem)
        break
      }
      this.tree.down()
    } while (i < totalLength)
  }

  @on("settings:setFocus")
  settingsSetFocus(from, subItem) {
    console.log("setDefaultFocus")
    console.log(from+"====="+subItem)
    new Promise((resolve) => {
      while (this.tree.selected) {
        this.tree.back()
      }
      resolve(true)
    })
    .then(() => {
      switch (from) {
      case "STBInfoSheet":
        if (this.tree.lists[this.tree.selected].selected !== 5) {
          this.tree.lists[this.tree.selected].selected = 0
          while (this.tree.lists[this.tree.selected].selected++ < 5)
            this.tree.down()
        }
        break
      case "selfHelp":
        new Promise((resolve) => {
          if (this.tree.lists[this.tree.selected].selected !== 7) {
            this.tree.lists[this.tree.selected].selected = 0
            while (this.tree.lists[this.tree.selected].selected++ < 7)
              this.tree.down()
          }
          resolve(true)
        })
        .then(() => {
          this.tree.right()
          this.tree.down()
          this.tree.down()
        })
        break
      default:
        break
      }
    })
  }

  @on("subSettings:back:press")
  subSettingsBackHandler(from) {
    switch (from) {
    case "STBInfoSheet":
      new Promise((resolve) => {
        while (this.tree.selected) {
          this.tree.back()
        }
        resolve(true)
      })
      .then(() => {
        while (this.tree.lists[this.tree.selected].selected++ < 5) {
          this.tree.down()
        }
      })
      break
    default:
      break
    }
  }

  @on("settings:setContactLevel")
  setContactLevel() {
    while (this.tree.selected > 0) {
      this.tree.left()
    }
    this.tree.setItems(0, MODEL.items)
    window.setTimeout(()=>{
      bus.emit("settings:setDefaultFocus","selfHelp")
    }, 200)
  }

  @on("settings:hideDelegate")
  hideDelegate() {
    const openHome = this.activeDelegate === this.TransponderList ? false : true
    if (this.activeDelegate) this.activeDelegate.close(openHome)
  }

  @on("settings:closeScanProgress")
  closeScanProgress() {
    this.activeDelegate.onBack()
    this.ScanProgress.close()
    // this.view.onForeground()
  }


  @rcu("settings:back:release")
  @rcu("blackuniverse:back:release")
  onBackRelease() {
    const isInFtaMode = FtaBlockManager.isNavigationRestricted()
    if (isInFtaMode) bus.universe = "blackuniverse"
    try {
      getNetworkTp().then((networkTp) => {
        NetworkTp.currentHomeTp = networkTp
      })
    } catch (error) {}
  }

  @on("settings:onSettingCam")
  onSettingCam() {
    camApi.getCamInsertStatus()
    .then((result) => {
      if (result && result.cam_insert_status) {
        this.activeDelegate=this.Cam
        this.Cam.open().then(() => {
          this.view.onBackground()
        })
        CamManager.getCamMenu()
      }  else if (result && !result.cam_insert_status) {
        popUpMsg.insertCAM()
        bus.emit("popup:exitTrue")
      }
    }).catch(() => {
      popUpMsg.insertCAM()
      bus.emit("popup:exitTrue")
    })
  }

  @rcu("settings:stop:press")
  @rcu("settings:numeric:press")
  @rcu("blackuniverse:numeric:press")
  onInput(_, kbd) {
    if (this.activeDelegate) {
      this.activeDelegate.onInput(kbd, _)
    }
  }

  @rcu("settings:home:press")
  openHome() {
    if (!ComboButton.comboBtnPress && !ScanManager.running) bus.emit("comboBtn:home:press")
  }

  @rcu("settings:home:release")
  onOpenSettingHomeRelease() {
    if (ComboButton.longPressTimmer)window.clearTimeout(ComboButton.longPressTimmer)
    if (!ComboButton.comboBtnPress && !ScanManager.running) {
      if (ScanManager.isFirstInstall) {
        return
      }
      if ((this.activeDelegate === this.Scan && this.Scan.running) ||
        (this.activeDelegate === this.AdvancedScan && ScanManager.running)) {
        return
      }
      this.close().then(() => {
        bus.emit("comboBtn:home:release")
      })
    } else {
      ComboButton.longPressTimmer = null
      ComboButton.comboBtnPress = false
    }
    try {
      getNetworkTp().then((networkTp) => {
        NetworkTp.currentHomeTp = networkTp
      })
    } catch (error) {}
  }

  @rcu("settings:epg:press")
  openguide() {
    if (ScanManager.isFirstInstall || (this.activeDelegate === this.Scan && this.Scan.running) ||
      (this.activeDelegate === this.AdvancedScan && this.AdvancedScan.ScanProgress.running)) {
      return
    }
    if (this.activeDelegate === this.ChannelBlock) {
      this.onBack()
    }
    BlockedChannelManager.setCurrentChannelStatus(false)
    bus.closeCurrentUniverse()
    bus.emit("home:close")
    bus.emit("epg:directOpen")
    bus.emit("home:activeMenuItem", "epg")
  }

  /* ************************************************************************ */

  @on("settings:setDefault")
  onSetDefaultValue(data) {
    this.tree.markAsDefault(data)
  }

  @on("locale:update")
  onLocaleUpdate(locale) {
    this.tree.hideSpinner(locale)
  }

  @on("settings:treeleft")
  onTreeLeft() {
    while (this.tree.selected !== 0) {
      this.tree.left()
    }
  }

  @on("settings:subOpen")
  onSubOpen(item) {
    if (this.activeDelegate === this.Scan) {
      this.Scan.close()
    }
    if (this.activeDelegate === this.TransponderList) {
      this.TransponderList.close(false)
    }
    if (this.activeDelegate === this.STBInfoSheet) {
      this.STBInfoSheet.close()
    }
    this.activeDelegate = this.SettingsSub
    this.SettingsSub.open(item).then(() => {
      this.view.onBackground()
    })
  }

  @on("settings:transponderList")
  onTransponderListOpen(item) {
    this.activeDelegate = this.TransponderList
    this.TransponderList.open(item).then(() => {
      this.view.onBackground()
    })
  }

  @on("settings:stbInfoSheet")
  onSTBInfoSheetOpen(item) {
    this.activeDelegate = this.STBInfoSheet
    this.STBInfoSheet.open(item).then(() => {
      this.view.onBackground()
    })
  }

  @on("settings: STBInfoSheetOk")
  onSTBInfoSheetOk() {
  }

  @on("settings:parentalLock")
  onLoadChannelList(data) {
    const self=this
    switch (data.type) {
    case "IF2IF":
    case "EnterPin":
      bus.emit("parentalpopup:parentAlert", data.type, this.tree, function() {
        self.tree.right()
      }, "parent", {})
      break
    case "ChangePin":
      bus.emit("parentalpopup:parentAlert", "ChangePin", this.tree, null, "parent", {})
      break
    case "BlockChannelList":
      if (ChannelManager.channels.length === 0) {
        popUpMsg.noServices()
      } else {
        this.activeDelegate = this.ChannelBlock

        this.ChannelBlock.open(data).then(() => {
          this.view.onBackground()
        })
      }
      break
    }
  }

  @on("settings:scan")
  onScan() {
    bus.emit("scan:showButton")

    this.activeDelegate = this.Scan
    this.Scan.showAdvanceScreen = true
    this.Scan.open().then(() => {
      this.ScanProgress.open()
      this.view.onBackground()
    })
  }

  @on("scan:factoryReset")
  startScan() {

    const closeCallback = () => {}
    const buttons = [
      {
        label: "OK",
        // signal: "settings:scan",
        action: () => {
          if (PVRManager.ongoing.length > 0) {
            PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
          }
          PlayerManager.stopCurrentChannel()
          this.beginFactoryResetScan()
        },
      },
      {
        label: "BACK",
        action: () => {
          console.log("Back")
        },
      },
    ]
    popUpMsg.confirmFactoryReset(buttons, closeCallback, true)
    bus.emit("popup:exitTrue")
  }

  @on("settings:FINetwork")
  setheaderFINetwork() {
    this.view.showHeader()
  }

  @on("settings:factoryReset")
  beginFactoryResetScan() {
    this.activeDelegate = this.Scan
    ScanManager.alwaysCommit =true
    this.setDefaultConfig().then(() => {
      this.Scan.open().then(() => {
        this.view.onBackground()
        popUpMsg.FactorySettingInProgress()
      }).then(() => this.Scan.beginFactoryScan())
    })
  }

  @on("settings:advanced_scan")
  onAdvancedScan() {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    const isPage = FtaBlockManager.ftaPopupStatus.page
    this.activeDelegate = this.AdvancedScan

    if (isFtaBlock && isPage === "stb") {
      this.AdvancedScan.open()
      .then(() => {
        this.view.onBackground()
        bus.emit("STBInfoSheet:close")
        bus.universe = "blackuniverse"
        FtaBlockManager.onAdvancedScan = true
      })
    } else if (!isFtaBlock) {
      this.AdvancedScan.open()
      .then(() => {
        this.view.onBackground()
      })
    }
  }

  @on("scan:complete")
  onScanComplete() {
    /** To handle the  auto closing od TPList when invoked from ChannelSearch**/
    if (!ScanManager.isFirstInstall) {
      if (this.activeDelegate === this.TransponderList) return
      this.activeDelegate && (this.activeDelegate.close()
      .then(() => {
        this.view.onForeground()
        this.activeDelegate = null
      }))
    }

  }

  @on("settings:reset")
  onReset() {
    const closeCallback = () => {}
    const buttons = [
      {
        label: "OK",
        action: () => {
          factoryReset()
        },
      },
      {
        label: "BACK",
        action: () => {
          console.log("Back")
        },
      },
    ]
    popUpMsg.confirmReset(buttons, closeCallback, true)
    bus.emit("popup:exitTrue")
  }

  @on("settings:softwareUpdateForcely")
  onSoftwareUPdateForcely() {
    const buttons = [
      {
        label: "OK",
        action: () => {
          SoftwareUpdateManager.forceUpdateSw()
          .then(() => {
            setState({"state":"reboot"})
          }).catch(() => {
            setState({"state":"reboot"})
          })
        },
      },
    ]
    popUpMsg.confirmSoftwareUpdate(buttons)
  }

  @on("scan:launchEasyScan")
  onLaunchScanEvent(params) {
    this.activeDelegate = this.Scan
    // check universe and set during fake progress bar
    if (params.univ === "standby") {
      ScanManager.svlDvbUri = true
    }
    if (ScanManager.svlDvbUri === true) {
      this.ScanProgress.view.pushBlackScreen()
    }
    VersionManagers.pendingDwTasks()
    PlayerManager.stop()

    this.Scan.initiateScan().then(() => {
      this.view.onBackground()
      this.Scan.launchEasyScan(params)
      if ((params.scanType === "EASY_SCAN") && (!ScanManager.svlDvbUri)) {
        popUpMsg.FactorySettingInProgress()
      }

    })
  }

  @on("settings:dvbUpdate")
  onDvbUpdate() {
    console.warn("Start update dvb")
    this.SettingsSub.view.optionList.showSpinner()
    window.setTimeout(() => {
      console.warn("Update end")
      this.SettingsSub.view.optionList.hideSpinner()
    }, 1500)
  }

  @rcu("settings:numeric:press")
  onHiddenNumeric(key) {
    if (this.activeDelegate && this.Scan.showAdvanceScreen) {
      this.hiddenKey.push(key)
    }
  }

  @rcu("settings:numeric:release")
  onHiddenNumericRelease() {
    if (!this.hiddenKey.length > 0) return

    if (this.startHiddenTimmer) {
      window.clearTimeout(this.startHiddenTimmer)
    }

    if (this.hiddenKey.length === 4) {
      const mapKeyHidden = this.hiddenKey.join("_")
      if (mapKeyHidden === "9_5_2_3" && this.Scan.showAdvanceScreen) {
        bus.emit("show:menuShortCut:homeTP")
      }
    }

    this.startHiddenTimmer = window.setTimeout(() => {
      this.hiddenKey = []
    }, this.MAPPING_TIMEOUT)

  }

  @on("show:menuShortCut:homeTP")
  onSetHomeTP() {
    this.hiddenKey = []
    bus.emit("Scan:close")
    bus.emit("settings:advanced_scan")
  }

  @on("show:setDefaultFocus:trigger")
  onSetDefaultFocusTigger(name) {
    window.setTimeout(() => {
      this.tree.right()
      name === "favourite" && bus.emit("settings:OpenFavourites",name)
    }, 0)
  }

  @on("settings:OpenFavourites")
  onFavLaunch(name) {
    if (this.tree.lists.length && this.tree.lists[1].items) {
      const totalLength = this.tree.lists[1].items.length
      MODEL.openFavInProgress = true
      for (let i = 0 ; i < totalLength; i++) {
        const focusName = this.tree.lists[1].items[this.tree.lists[1].selected].name
        if (name === focusName) {
          break
        }
        this.tree.down()
      }
    }
  }

  @on("settings:Favorites")
  onFavourites(name, subItem) {
    bus.emit("settings:favorites:open")
    while (this.tree.selected > 0) {
      this.tree.left()
    }
    this.tree.setItems(0, MODEL.items)
    bus.emit("settings:setDefaultFocus",name, subItem)
  }

  @on("settings:openpage")
  onColorBox(name) {
    if (this.activeDelegate) {
      if (this.activeDelegate.activeDelegate !== null || this.activeDelegate.cashDelegate === true) {
        this.onBack()
      }
      this.onBack()
    }
    while (this.tree.selected > 0) {
      this.tree.left()
    }
    this.tree.setItems(0, MODEL.items)
    if (this.activeDelegate) this.activeDelegate = null
    bus.emit("settings:setDefaultFocus",name)
  }

  /* ********* Favorite and timezone ********* */
  @on("settings:favorites:open")
  onFavoritesOpen() {
    if (ChannelManager.channels.length === 0) {
      popUpMsg.noServices()
    } else {
      this.SettingsSub.close()
      if (this.activeDelegate === this.STBInfoSheet) {
        transponders.isTPListScreen = false
      }
      this.activeDelegate = this.Favorites
      this.activeDelegate.open().then(()=>{
        this.view.onBackground()
      })
    }
  }

  @on("settings:favorites:close")
  onSubSettingClose() {
    this.activeDelegate.onBack().then(() => {
      this.activeDelegate = null
      this.view.onForeground()
    })
  }

  @on("network:disconnected")
  @on("network:connected")
  onNetwork() {
    if (this.activeDelegate === this.SettingsSub && this.SettingsSub.sub.context === "NetworkInfo") {
      this.activeDelegate = null
      this.SettingsSub.close()
      this.view.onForeground()
    }
  }

  @on("IF2IF:change")
  onIftoIfChange(mode) {
    this.if2IF = mode
  }

  @on("settings:license")
  onLicense() {
    this.view.onBackground()
    this.activeDelegate = this.License
    this.License.open()
  }

  setDefaultDVBUri() {
    let uriList

    if (NetworkTp.currentHomeTp === NetworkTp.config.TP.DISH) {
      uriList = NetworkTp.config.UriList.DISH
    } else if (NetworkTp.currentHomeTp === NetworkTp.config.TP.D2H) {
      uriList = NetworkTp.config.UriList.D2H
    }
    return uriList[this.if2IF]
  }

  updateLNBParams() {
    bus.emit("scan:diseqcUpdate", "DISEQC_AUTO")
    ScanManager.antennaConfig = MODEL.LNBParams
    return Promise.all([ScanManager.saveAntennaConfig(), setDiseqcType("DISEQC_AUTO")])
  }

  @on("network:selection")
  onNetworkSelection() {
    ScanManager.onUpdateDVBUri("NetworkSelection", this.setDefaultDVBUri())
  }

  setDefaultConfig() {
    return new Promise((resolve) => {
      // Reset Display Resolution to 1920x1080@60p
      setDefaultAvio(MODEL.RESET_VALUES.AVIO)
      // Reset Audio dolby Settings to OFF
      setDefaultAudio(MODEL.RESET_VALUES.AUDIO)
      .then(() => MODEL.selectedAudio = MODEL.RESET_VALUES.AUDIO.audio_codecs[1])
      // Reset Time format to 12h
      setTimeFormat(MODEL.RESET_VALUES.TIME_FORMAT)
      .then(() => TimezoneManager.displayH24 = false)
      // Reset timezone to Asia/Kolkata
      updateTimeZone(MODEL.RESET_VALUES.TIMEZONE)
      .then(() => MODEL.currentTimezone = MODEL.RESET_VALUES.TIMEZONE)
      // Reset Last Tuned Channel to 99
      setLastTunedLcn(MODEL.RESET_VALUES.LAST_TUNED_CHANNEL)
      .then(() => PlayerManager.prevChannelTuned = "")
      // Reset Default Audio track
      updateDefaultTrack(MODEL.RESET_VALUES.TRACK)
      // Reset TV Type
      setDefaultTvType(MODEL.RESET_VALUES.ARM)
      .then(() => MODEL.loadAspectRatio({reload: false}))
      // Reset CVBS Value
      setDefaultCVBS(MODEL.RESET_VALUES.CVBS)
      .then(() => MODEL.loadCVBSConfig({reload: false}))
      // Reset Prefered languages
      if (PlayerManager.audioTrackPersis.length !== 0) {
        updateAudiotracks(MODEL.RESET_VALUES.DEFAULT_AUDIO_TRACK)
        .then(() => {
          PlayerManager.audioTrackPersis.forEach((value) => {
            deleteEntry("audio_lang", value)
          })
        })
        .then(() => {
          PlayerManager.audioTrackPersis = []
          PlayerManager.audioTrackPersisVal = {}
        })
      }
      // Reset DVB URI based on If2IF config
      Promise.all([ScanManager.onUpdateDVBUri("Factory", this.setDefaultDVBUri()), this.updateLNBParams()])
      .then(() => {
        resolve()
      })
    })
  }
}
