//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import bus from "services/bus"
import {$} from "widgets/Component"
import {on} from "services/events"
import config from "utils/config"
import * as popUpMsg from "app/utils/PopUpMsg"

import {
  PlayerManager,
  ScanManager,
  PVRManager,
  VersionManagers,
} from "services/managers"

import AbstractSetting from "./AbstractSetting"

const START_SCAN_ITEM = {
  name: "Start Scan",
  action: "scan:start",
}

const FREQ_START_ITEM = {
  name: "Start Freq: ",
  value: config.FREQ_START,
  action: "scan:editOption",
  option: "start",
}
const FREQ_END_ITEM = {
  name: "End Freq: ",
  value: config.FREQ_END,
  action: "scan:editOption",
  option: "end",
}

const BLANK_SCAN_ITEM = {
  name: "",
}

export default class ScanController extends AbstractSetting {

  constructor() {
    super()
    this.optionList = [START_SCAN_ITEM]
    this.IftoIFscan = false
    switch (config.BROADCAST) {
    // DVB-C Scan
    case "dvbc":
      this.transponderSetId = 4
      this.name = "DVBC"
      this.scanType = 1
      break
    // DVB-T Scan
    case "dvbt":
      this.transponderSetId = 1
      this.name = "DVBT"
      this.scanType = 1
      break
    // DVB-S Scan
    // default
    case "dvbs":
      this.transponderSetId = 9999
      this.name = "DVBS"
      this.scanType = 2
      for (const item of [FREQ_START_ITEM, FREQ_END_ITEM]) {
        this.optionList.push(item)
      }
      this.freqStart = config.FREQ_START
      this.freqEnd = config.FREQ_END
      break
    case "custom":
      this.transponderSetId = config.TRANSPONDER_SET_ID
      this.name = "easy_scan" // config.DVB_NAME
      this.scanType = config.SCAN_TYPE
      break
    default:
      break
    }

    this.maxInputs = 5
    this.kbdInputs = {
      "start": [],
      "end": [],
    }
    this.view = $("scanScreen")
    this.activeDelegate = null
  }

  get ScanProgress() {
    return this.master.ScanProgress
  }

  get running() {
    return ScanManager.running
  }

  set running(value) {
    ScanManager.running = value
  }

  get currentFreqStart() {
    return parseInt(this.optionList[1].value, 10) || -1
  }

  get currentFreqEnd() {
    return parseInt(this.optionList[2].value, 10) || -1
  }

  set freqStart(value) {
    this.optionList[1].value = value
    ScanManager.freqStart = value
  }

  set freqEnd(value) {
    this.optionList[2].value = value
    ScanManager.freqEnd = value
  }

  open() {
    this.ScanProgress.open()
    return super.open()
  }

  @on("IF2IF:change")
  ifTOifChange(mode) {
    switch (mode) {
    case "ON":
      this.transponderSetId = "9998"
      break
    case "OFF":
      this.transponderSetId = config.TRANSPONDER_SET_ID
      break
    default:
      this.transponderSetId = config.TRANSPONDER_SET_ID

    }
  }

@on("scan:diseqcUpdate")
  onDiseqcUpdate(diseqc) {
    switch (diseqc) {
    case "DISEQC_AUTO":
      this.transponderSetId = config.TRANSPONDER_SET_ID
      break
    case "DISEQC_PORT1":
      this.transponderSetId = config.TRANSPONDER_SET_ID
      break
    case "DISEQC_PORT2":
      this.transponderSetId = "9996"
      break
    case "DISEQC_PORT3":
      this.transponderSetId = "9995"
      break
    case "DISEQC_PORT4":
      this.transponderSetId = "9994"
      break
    default:
      this.transponderSetId = config.TRANSPONDER_SET_ID
    }
  }

  @on("Scan:close")
  close() {
    this.activeDelegate = null
    ScanManager.alwaysCommit =false
    this.ScanProgress.close()
    this.selectedIndex = 0
    this.showAdvanceScreen =  false
    return super.close()
  }

  load() {
    this.selectedIndex = 0
    this.view.loadItems(this.optionList, this.maxInputs)
  }

  setOption() {
    super.setOption()
    if (this.checkFreqValidity(this.currentFreqStart, this.currentFreqEnd)) {
      this.updateFreq()
    } else {
      if (this.currentFreqStart === 0 && this.currentFreqEnd === 0) {
        this.restoreDefaultsFreqParams()
      } else {
        this.view.optionList.onError(this.selectedIndex)
        this.select()
      }
    }
  }

  checkFreqValidity(freqStart, freqEnd) {
    if (freqStart === 0) {
      return false
    }
    if (freqStart === -1 || freqEnd === -1) {
      return true
    }
    return (freqStart < freqEnd)
  }

  updateFreq() {
    const selectedMenu = this.optionList[this.selectedIndex]
    if (selectedMenu.option === "start") {
      this.freqStart = selectedMenu.value
    } else if (selectedMenu.option === "end") {
      this.freqEnd = selectedMenu.value
    }
    this.view.optionList.onSet()
  }

  restoreDefaultsFreqParams() {
    this.freqStart = config.FREQ_START
    this.freqEnd = config.FREQ_END
    this.load()
  }

  initiateScan() {
    this.ScanProgress.open()
    return super.open()
  }

  @on("scan:editOption")
  onEditOption() {
    super.editOption()
    this.view.optionList.onEdit()
  }

  updateOption(kbd) {
    const input = super.updateOption(kbd)
    this.view.optionList.onUpdate(input)
  }

  cancelOption() {
    const input = super.cancelOption()
    this.view.optionList.onCancel(input)
  }

  moveUp() {
    if (!this.running) {
      const selectedMenu = super.moveUp()
      this.view.optionList.select(this.selectedIndex, selectedMenu)
    }
  }

  moveDown() {
    if (!this.running) {
      const selectedMenu = super.moveDown()
      this.view.optionList.select(this.selectedIndex, selectedMenu)
    }
  }

  @on("scan:start")
  startScan() {
    this.optionList[0] = START_SCAN_ITEM
    this.view.loadItems(this.optionList)
    const closeCallback = () => {}
    const buttons = [
      {
        label: "OK",
        action: () => {
          ScanManager.scanTriggered = true
          if (PVRManager.ongoing.length > 0) {
            PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
          }
          VersionManagers.pendingDwTasks()
          PlayerManager.stopCurrentChannel()
          this.beginScan()
        },
      },
      {
        label: "BACK",
        action: () => {
          console.log("Back")
        },
      },
    ]
    popUpMsg.confirmSCAN(buttons, closeCallback)
    bus.emit("popup:exitTrue")
  }
  @on("scan:startOnIF2IF")
  startScanOnIF2IF() {
    ScanManager.alwaysCommit =true
    bus.emit("settings:scan")
    this.IftoIFscan = true
    this.optionList[0] = BLANK_SCAN_ITEM
    this.view.loadItems(this.optionList)
    this.beginScan()
  }


  @on("scan:startMenuShortCut")
  scanStartMenuShortCut() {
    bus.emit("settings:scan")
    this.optionList[0] = START_SCAN_ITEM
    this.view.loadItems(this.optionList)
    this.beginScan()
  }

  beginScan() {
    if ((config.BROADCAST === "dvbs") && !this.checkFreqValidity(this.currentFreqStart, this.currentFreqEnd)) {
      return this.setOption()
    }
    this.view.optionList.blur()
    this.activeDelegate = this.ScanProgress
    ScanManager.revokeOnScanComplete = "settings"
    this.ScanProgress.start(
      this.scanType,
      this.transponderSetId,
      this.name,
      true,
      true,
      true,
      "NIT_SCAN"
    )
  }

  beginFactoryScan() {
    if ((config.BROADCAST === "dvbs") && !this.checkFreqValidity(this.currentFreqStart, this.currentFreqEnd)) {
      return this.setOption()
    }
    this.view.optionList.blur()
    this.activeDelegate = this.ScanProgress
    ScanManager.revokeOnScanComplete = "settings"
    ScanManager.scanFromFactoryReset = true
    this.ScanProgress.start(
      this.scanType,
      this.transponderSetId,
      this.name,
      true,
      true,
      true,
      "EASY_SCAN"
    )
  }

  @on("scan:quickscan")
  onQuickScan() {
    bus.emit("scan:launchEasyScan",{"univ":"home","scanType":"EASY_SCAN"})
    bus.emit("settings:updateSettingsHeader")
  }

  @on("scan:showButton")
  onShowButton() {
    if (!this.IftoIFscan) {
      this.optionList[0] = START_SCAN_ITEM
      this.view.loadItems(this.optionList)
    }

  }

  @on("scan:stop")
  _onStopScan() {
    this.ScanProgress.stop()
  }

  launchEasyScan(params) {
    this.view.optionList.blur()
    this.activeDelegate = this.ScanProgress
    ScanManager.revokeOnScanComplete = params?params.univ:null
    this.ScanProgress.start(
      this.scanType,
      this.transponderSetId,
      this.name,
      true,
      true,
      true,
      params.scanType
    )
    .then((response) => {
      if (response && (params.univ === "standby" || params.univ === "resume")) {
        bus.emit("power:activeScan")
      } else {
        bus.emit("power:deactiveScan")
      }
    })
    .catch(() => {
      bus.emit("power:deactiveScan")
    })
  }

  @on("scan:finished")
  _onScanFinished() {
    if (!this.IftoIFscan === true) {
      this.optionList[0] = START_SCAN_ITEM
      this.view.loadItems(this.optionList)
    } else {
      ScanManager.alwaysCommit = false
      this.IftoIFscan = false
    }

  }
}
