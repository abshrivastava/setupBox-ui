//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"

export default class AbstractItem extends Component {
  /*
   * Special item for ItemLists (such as RecordList) that display the Component
   * that matches the type of item given when updating.
   */
  constructor(props) {
    /*
     * Needs a map of item such as:
     * {Model: "item"}
     *
     * Previous case means that if a Model item is given, the Component w/
     * 'item' as key will be updated w/ item
     */
    super()
    this.itemsMap = props.map
    this.current = null
  }

  update(item) {
    if (!item) {
      if (this.current) {
        this[this.current].hide()
      }
      this.hide()
      this.current = null
      return
    }

    this.show()
    const previous = this.current
    const itemType = item.constructor.name

    if (itemType in this.itemsMap) {
      this.current = this.itemsMap[itemType]
    } else {
      console.warn("Unexpected item:", item)
      this.current = null
    }

    if (this.current !== previous) {
      if (previous) {
        this[previous].hide()
      }
      this[this.current].show()
    }

    this[this.current].update(item)
  }
}
