//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"

class ActionItem extends Component {
  render() {
    return (
      <div className="FISubListItem">
        <span className="FISubListItem-name" prop="name" />
      </div>
    )
  }
}

export default class ActionsList extends Component {
  render() {
    return (
      <div className="FISubList" />
    )
  }

  _flush() {
    this.actions = []
    this.focusedIdx = 0
    while (this.dom.firstChild) {
      this.dom.removeChild(this.dom.firstChild)
    }
  }

  setActions(actions) {
    this._flush()
    for (const action of actions) {
      const item = new ActionItem(action)
      this.dom.appendChild(item.build())
      this.actions.push(item)
    }

  //  this.select(0)
  }

  select(idx) {
    this.actions[this.focusedIdx].pullState("selected")
    this.focusedIdx = idx
    this.actions[idx].pushState("selected")
  }

  onFocusLeft(list) {
    this.actions[this.focusedIdx].pullState("selected")
    if (list !== 2) this.actions[list].pushState("default")
  }
  onFocusRight() {
    this.actions[this.focusedIdx].pushState("selected")
  }

  setDefault(id) {
    this.actions[id].pushState("default")
  }

  onDefaultUpdate(id) {
    this.actions[id].pullState("default")
  }
}
