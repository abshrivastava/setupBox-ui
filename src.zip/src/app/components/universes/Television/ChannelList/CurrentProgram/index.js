//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import PlayerManager from "services/managers/PlayerManager"
import TimezoneManager from "services/managers/TimezoneManager"
import Component from "widgets/Component"
import {createTicker, noop} from "utils"
import {pushState, pullState} from "utils/dom"
import {dateToCdsTimestamp, unixToUpnp} from "utils/date"
import "./index.css"
import LangInfoBar from "app/components/universes/Application/LangInfoBar"
import * as images from "./images/"

const DEFAULT_PROPS = {
  title: "No information",
  genre: "",
  category: "",
  startTime: "00:00",
  endTime: "00:00",
  progress: 0.5,
}

export default class CurrentProgram extends Component {
  constructor(props) {
    super(Object.assign({}, DEFAULT_PROPS, props))
    this.program = null
    this.refreshTicker = createTicker(10000)
  }

  render() {
    return (
      <div className="CurrentProgram">
        <div className="CurrentProgram-inner" key="inner">
          <img className="CurrentProgram-recordIndicator" src={images.rec} key="recordIndicator" />
          <div className="CurrentProgram-epgTitle" prop="title" />
          <div className="CurrentProgram-epgGenre" prop="genre" />
          <div className="CurrentProgram-dolby CurrentProgram-dolby--hidden" prop="dolby" key="dolbyLogo" />
          <div className="CurrentProgram-timeInfo CurrentProgram-timeInfo--hidden" key="timeInfo">
            <div className="CurrentProgram-epgStart" prop="startTime" />
            <div className="CurrentProgram-progressBar">
              <div className="CurrentProgram-ts-indicator" key="tsIndicator">
                <div className="CurrentProgram-indicator" />
              </div>
              <div className="CurrentProgram-progress" key="progress" />
            </div>
            <div className="CurrentProgram-epgEnd" prop="endTime" />
          </div>
        </div>
        <div className="LangInfoBar-sec"><LangInfoBar /></div>
      </div>
    )
  }

  update(program,genre) {
    this.program = program
    this.hideRecordIndicator()
    if (!program || !program.id) {
      this.setProps(DEFAULT_PROPS)
      if (genre) {
        this.setProp("genre", genre)
      }
      pushState(this.timeInfo, "hidden")
      return
    }
    pullState(this.timeInfo, "hidden")
    this.setProp("title", program.title)

    this.setProp("genre", genre)
    this.setProp("category", program.category)
    this.setProp("startTime", TimezoneManager.getFormatTime(program.startDate))
    this.setProp("endTime", TimezoneManager.getFormatTime(program.endDate))
    this._updateProgressRemaining()
    if (program.isRecording) {
      this.showRecordIndicator()
    }
  }

  updateDolbyInfo() {
    pushState(this.dolbyLogo, "show")
    pullState(this.dolbyLogo,"nobackground")
    this.setProp("dolby", "5.1")
  }

  hideDolbyInfo() {
    pushState(this.dolbyLogo, "hidden")
    pushState(this.dolbyLogo,"nobackground")
    this.setProp("dolby", "")
  }

  fold() {
    return this.pullState("unfold", true)
      .then(() => this.refreshTicker.stop())
  }

  unfold() {
    return this.pushState("unfold", true)
      .then(() => {
        const update = () => this._updateProgressRemaining()
        this.refreshTicker.start(update)
      })
  }

  fade() {
    this.recordIndicator.src = images.recNotSelected
    return this.pushState("faded", true)
  }

  focus() {
    this.recordIndicator.src = images.rec
    return this.pullState("faded", true)
  }

  onScrollStart() {
    this.pushState("faded")
  }

  onScrollStop() {
    this.pullState("faded")
  }

  showRecordIndicator() {
    pushState(this.recordIndicator, "visible", false)
  }

  hideRecordIndicator() {
    pullState(this.recordIndicator, "visible", false)
  }

  showTSIndicator() {
    pushState(this.tsIndicator, "visible", false)
  }

  hideTSIndicator() {
    pullState(this.tsIndicator, "visible", false)
  }

  _updateProgressRemaining() {
    if (!this.program) {
      return
    }
    const programLength = this.program.duration
    const progStartDate = this.program.cdsStartDate
    const currentCdsDate = dateToCdsTimestamp(new Date())
    const currentLength = currentCdsDate - progStartDate

    const progress = Math.min(~~(currentLength * 100 / programLength), 100)
    this.progress.style.width = progress + "%"

    PlayerManager.getAbsoluteTimestampPosition()
      .then((ppos) => {
        const currentPlayerPos = unixToUpnp(ppos.position)

        const tsPosition = ~~((currentPlayerPos - progStartDate) *100 / programLength)
        this.tsIndicator.style.webkitTransform = `translate3d(${tsPosition}%, 0, 0)`
      })
      .catch(() => {
        // Impossible to get AbsoluteTimestampPosition, ignore redraw of TS Indicator
        noop()
      })
  }
}
