//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import {pick} from "utils"
import defaultLogoUrl from "assets/fallbacks/channel-logo.png"
import {default as heartBlue} from "assets/pictos/heart-blue.png"

const logoArr = []
export default class ChannelItem extends Component {

  constructor(props) {
    const {hasLogo} = pick(props, "hasLogo")
    super(props)
    this.hasLogo = hasLogo
  }

  render() {
    if (this.hasLogo) {
      return (
        <div className="ChannelListItem ChannelListItemList-item">
          <div className="ChannelListItem-lcn" key="lcn" />
          <img
            key="logoImg"
            className="ChannelListItem-logo"
            src={this.props.logo} />
          <img
            key="favLogo"
            className="ChannelListItem-favLogo"
            src={this.props.defaultSrc} />
          <div className="ChannelListItem-title" key="title" />
        </div>
      )
    } else {
      return (
        <div className="ChannelListItem ChannelListItemList-item">
          <div className="ChannelListItem-lcn" key="lcn" />
          <div className="ChannelListItem-title" key="title" />
        </div>
      )
    }
  }

  update(channel) {
    this.channel = channel
    this.logoImg.style.display = (this.channel) ? "" : "none"
    this.channel = this.channel || {lcn: "", title: "", logo: "", favorite: false}
    this.lcn.textContent = this.channel.lcn
    this.title.textContent = this.channel.title
    if (this.channel.favorite) {
      this.favLogo.src = heartBlue
      this.favLogo.style.display = ""
    } else {
      this.favLogo.style.display = "none"
    }
    if (this.logoImg) {
      if (logoArr[this.channel.lcn]) {
        this.logoImg.src = logoArr[this.channel.lcn]
      } else {
        this.logoImg.src = defaultLogoUrl
        if (!config.SD_ZAPPER) {
          this.attachLogo(this.channel)
        }
      }
    }
  }
  attachLogo(channel) {
    this.channel = channel
    this.img = new Image()
    this.img.src = this.channel.logo
    this.img.onload = ()  => {
      if ("naturalHeight" in this.img) {
        if (this.img.naturalHeight + this.img.naturalWidth === 0) {
          this.logoImg.src = defaultLogoUrl
          logoArr[this.channel.lcn] =  this.logoImg.src
        } else {
          this.logoImg.src = this.channel.logo
          logoArr[this.channel.lcn] = this.channel.logo
        }
      }
    }
  }
}
