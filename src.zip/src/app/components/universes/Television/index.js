//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import config from "utils/config"
import Component from "widgets/Component"

import Notification from "app/components/widgets/Notification"
import Fingerprint from "app/components/widgets/Fingerprint"
import ItemDetails from "app/components/widgets/ItemDetails"
import ChannelList from "./ChannelList"
import PlayerControl from "./PlayerControl"

export default class TelevisionUniverse extends Component {
  render() {
    return (
      <div className="Television-universe">
        <ChannelList variant={config.CHANNEL_LIST_STYLE} ref="channelList"/>
        <PlayerControl ref="playerControl"/>
        <ItemDetails ref="programDetails"/>
        <Notification ref="tvNotification"/>
        <Fingerprint ref="fingerprint"/>
      </div>
    )
  }
}
