//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"
import {_} from "utils/locale"

// class ActionItem extends Component {
//   render() {
//     return (
//       <div className="STBInfoSheetItem">
//         <span className="STBInfoSheetItem-name"  prop="name" />
//       </div>
//     )
//   }
// }

export default class ActionsList extends Component {
  render() {
    return (
      <div className="STBInfoSheetList">

        <div className="STBInfoSheetItem-name"  prop="name" />
      </div>
    )
  }

  setActions() {
    this.setProp("name", _("Subscription Information"))
  }

}
