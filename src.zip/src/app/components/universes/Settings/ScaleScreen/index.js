//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"

export default class ScaleScreen extends Component {
  render() {
    return (
      <div className="ScaleScreen ScaleScreen--hidden">
        <div className="ScaleScreen-7" key="scale7"/>
        <div className="ScaleScreen-6" key="scale6"/>
        <div className="ScaleScreen-5" key="scale5"/>
        <div className="ScaleScreen-4" key="scale4"/>
        <div className="ScaleScreen-3" key="scale3"/>
        <div className="ScaleScreen-2" key="scale2"/>
        <div className="ScaleScreen-1" key="scale1"/>
        <div className="ScaleScreenInner">
          <div className="scaleTitle" prop="title"/>
          <div className="scaleContent" prop="content"/>
        </div>
      </div>
    )
  }

  setTitle(title) {
    this.setProp("title", title)
  }

  setContent(content) {
    this.setProp("content", content)
  }

  setValue(value) {
    this.setProp("scaleValue", value)
  }
}
