//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//


const heading = `The software included in this product contains copyrighted software that is licensed under the GNU GPL 
(‘General Public License’), LGPL (‘Lesser General Public License’) and AFL (‘Academic Free License’). A copy of these 
licenses is included in the product in the My Dishtv/Tools/ Copyright menu. You may obtain the complete Corresponding 
Source code from us by sending an email to opensource@dishtv.in. Please write Liberty HD Boxes in the subject line 
of your mail.
<br/><br/>
The software is based in part of the work of the FreeType Team.
<br/><br/>
This software is based in part on the work of the Independent JPEG Group
<br/><br/>
This product includes software developed by the OpenSSL Project for use in the 
OpenSSL Toolkit (http://www.openssl.org/). 
This product includes software written by Eric Young (eay@cryptsoft.com)
`


//  /* ******************** First *************************************** */

// const heading_1 = "Popmotion"
// const detail_1 =`The MIT License (MIT) Copyright (c) 2017 Popmotion <br/><br/>

// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
//  associated documentation files (the "Software"), to deal in the Software without restriction,
//   including without limitation the rights to use, copy, modify, merge, publish, distribute,
//    sublicense, and/or sell copies of the Software, and to permit persons to
//  whom the Software is furnished to do so, subject to the following conditions:<br/><br/>

// The above copyright notice and this permission notice shall be included in all copies or substantial
// portions of the Software.<br/><br/>

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
//  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.`

//  /* ******************** Second classnames *************************************** */
// const heading_2 = "classnames"
// const detail_2 = `The MIT License (MIT)<br/><br/>

// Copyright (c) 2016 Jed Watson<br/><br/>

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:<br/><br/>

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.<br/><br/>

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.`

// /* ******************** Component-emitter *************************************** */
// const heading_3 = "Component-emitter"
// const detail_3 = `(The MIT License)<br/><br/>

// Copyright (c) 2014 Component contributors dev@component.io<br/><br/>

// Permission is hereby granted, free of charge, to any person
// obtaining a copy of this software and associated documentation
// files (the "Software"), to deal in the Software without
// restriction, including without limitation the rights to use,
// copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following
// conditions:<br/><br/>

// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.<br/><br/>

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.`

// /* ******************** jed *************************************** */
// const heading_4 = "jed"
// const detail_4 = `Copyright JS Foundation and other contributors, https://js.foundation/<br/><br/>

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:<br/><br/>

// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.<br/><br/>

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.`

// /* ******************** langs *************************************** */
// const heading_5 = "langs"
// const detail_5 = `The MIT License (MIT)<br/><br/>

// Copyright (c) 2014 Andrew Lawson http://adlawson.com<br/><br/>

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:<br/><br/>

// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.<br/><br/>

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.`

// /* ******************** End *************************************** */



const licenses = {
  "heading" : heading,
  // "heading_1" : heading_1,
  // "detail_1" : detail_1,
  // "heading_2" : heading_2,
  // "detail_2" : detail_2,
  // "heading_3" : heading_3,
  // "detail_3" : detail_3,
  // "heading_4" : heading_4,
  // "detail_4" : detail_4,
  // "heading_5" : heading_5,
  // "detail_5" : detail_5,
}

export default licenses