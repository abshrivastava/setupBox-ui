//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import {pushState, pullState} from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import TimezoneManager from "services/managers/TimezoneManager"
import ScanManager from "services/managers/ScanManager"
import "./index.css"
import {_} from "utils/locale"

class SettingSelector extends Component {
  render() {
    return (
      <div className="SettingSelector">
        <div className="SettingSelector-bg"/>
        <div className="SettingSelector-arrow SettingSelector-arrow--hidden" key="arrow"/>
      </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    pushState(this.arrow, "hidden")
  }

  showArrow() {
    pullState(this.arrow, "hidden")
  }
}

class SettingItem extends Component {
  render() {
    return (
      <div className="SettingItem" prop="label" />
    )
  }

  showSpinner() {
    window.setTimeout(() => {
      this.pushState("hamsterWheel")
    })
  }

  hideSpinner() {
    window.setTimeout(() => {
      this.pullState("hamsterWheel")
    })
  }
}

export class SettingsList extends HybridListComponent {
  constructor() {
    super(SettingSelector, SettingItem)
    this.ITEM_HEIGHT = 58
    if (config.SD_ZAPPER) this.ITEM_HEIGHT = 46
    this.WINDOW_SIZE = 9
    this.EXTRA_VISIBLE_ITEMS= 1
  }

  render() {
    return (
      <div className="SettingsList"/>
    )
  }
}

export class SettingsTree extends Component {
  constructor() {
    super()
    this.focusedIdx = 0
  }

  render() {
    return (
      <div className="SettingsTree SettingsMenu-inner">
        <SettingsList key="list0"/>
        <SettingsList key="list1"/>
        <SettingsList key="list2"/>
      </div>
    )
  }
  showTree() {
    this.pullState("hidden")
  }
  hideTree() {
    this.pushState("hidden")
  }
  show() {
    this.list0.pushState("focused")
  }

  reset() {
    for (let i=0; i< this.dom.children.length; i++) {
      const list = this["list" + i]
      list.reset()
    }
    this.focusedIdx = 0
  }

  left(idx) {
    this["list" + this.focusedIdx].pullState("focused")
    this["list" + this.focusedIdx].pullState("leaved")
    this.focusedIdx = idx
    this["list" + this.focusedIdx].pushState("focused")
  }

  right(idx) {
    if (idx < 0) return
    this["list" + this.focusedIdx].pullState("focused")
    this["list" + this.focusedIdx].pushState("leaved")
    this.focusedIdx = idx
    this["list" + this.focusedIdx].pushState("focused")
  }
}

export default class SettingsMenu extends Component {
  constructor() {
    const props = {settingTitle: _("My DishTV"), fiTitle: _("Installation")}
    super(props)
  }

  render() {
    return (
      <div className="SettingsMenu SettingsMenu--hidden">
        <div className="SettingsMenu-heading-bg">
          <div className="SettingsMenu-heading-wrapper">
            <div className="SettingsMenu-title">
              <div className="Settings-title Settings-title--hidden" key="settingTitle" prop="settingTitle"/>
              <div className="FI-title FI-title--hidden" key="fiTitle" prop="fiTitle"/>
            </div>
            <div className="SettingsMenu-heading" prop="heading"/>
            <div className="SettingsMenu-date-Wrapper">
              <span className="SettingsMenu-date" prop="date"/>
              <span className="SettingsMenu-time" prop="time"/>
            </div>
          </div>
        </div>
        <SettingsTree key="settingsTree"/>
      </div>
    )
  }

  show() {
    this.pullState("onBackground")
    this.settingsTree.show()
    this.pullState("hidden")
    this.unfold()
    this.setTitle()
  }

  setTitle() {
    if (ScanManager.isFirstInstall) {
      this.fiTitle && pullState(this.fiTitle, "hidden")
      this.settingTitle && pushState(this.settingTitle, "hidden")
    } else {
      this.settingTitle && pullState(this.settingTitle, "hidden")
      this.fiTitle && pushState(this.fiTitle, "hidden")
    }
  }

  setcahnnelBlocked(id) {
    this.settingsTree.setItem(id)
  }

  hide() {
    this.fold()
    this.settingsTree.reset()
    this.pushState("hidden")
  }

  showHeader() {
    this.pullState("hidden")
    this.pushState("unfold")
    this.pushState("onBackground")
    this.setTitle()
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

  setHeading(heading) {
    this.setProp("heading", heading)
  }

  setDateTime(date, time) {
    this.setProp("date", date)
    this.setProp("time", time)
  }

  updateClock(d) {
    const time = TimezoneManager.getFormatTime(d)
    const d1 =  ((d).toString()).slice(0,16)
    const itemDate = d1.split(" ")
    const date = _(itemDate[0]) +(",") +(" ")+(_(itemDate[2]))+(" ")
    +(_(itemDate[1]))+(" ")+(_(itemDate[3]))+(" ")
    this.setDateTime(date, time)
  }
}
