//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pullState, pushState, clearNode} from "utils/dom"
import {default as hamsterWheelUrl} from "assets/loaders/wheel.png"
import "./index.css"

import {_} from "utils/locale"

const MAX_ITEM_COUNT = 6

class Item extends Component {
  constructor(props) {
    const defaultProps = {
      name: "",
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="ScanResultItem">
        <span className="ScanResultItem-name" prop="name" />
      </div>
    )
  }

  update(item) {
    this.setProp("name", item.name)
  }
}
export default class ScanProgress extends Component {
  constructor(props) {
    const defaultProps = {
      title: _("Channel search"),
      tvFound: _("TV") + ": 0",
      radioFound:  _("Radios") + ": 0",
      totalFound: _("Total services found") + ": 0",
      satName: "",
      frequency: "",
      polarization: "",
      symbolRate: "",
    }
    super(Object.assign({}, defaultProps, props))
  }

  render() {
    return (
      <div className="ScanProgress ScanProgress--hidden">
        <span className="ScanProgress-title" prop="title"/>
        <div className="ScanProgress-services-found">
          <span prop="tvFound"/>
          <span prop="radioFound"/>
          <span prop="totalFound"/>
        </div>
        <div className="ScanProgress-value" key="progressValue"> 0 % </div>
        <progress className="ScanProgress-progressBar" min="0"
                  max="1" value="0" key="progressBar" />
        <img className="ScanProgress-hamsterWheel
                        ScanProgress-hamsterWheel--hidden"
             src={hamsterWheelUrl}
             key="hamsterWheel"/>
        <div className="blackScreenTitile" prop="screenTitle" />
        <div className="ScanProgress-tuner-infos">
          <span prop="satName"/>
          <span prop="frequency"/>
          <span prop="polarization"/>
          <span prop="symbolRate"/>
        </div>
        <div className="ScanProgress-result">
          <div className="ScanProgress-result-inner" key="inner" />
        </div>
      </div>
    )
  }

  hide() {
    this.reset()
    return super.hide()
  }

  show() {
    this.setProp("title",  _("Channel search"))
    this.setProp("tvFound", _("TV") + ": 0")
    this.setProp("radioFound",  _("Radios") + ": 0")
    this.setProp("totalFound",  _("Total services found") + ": 0")
    return super.show()
  }

  start() {
    // USEless ??
    clearNode(this.inner)
  }

  updateProgress(val, tpInfos) {
    if (!val) val = 0
    this.progressBar.value = val
    const computedValue = Math.floor((val * 100))
    this.progressValue.textContent = `${computedValue} %`

    let satName = null
    let frequency = null
    let polarization = null
    let symbolRate = null
    if (tpInfos) {
      satName = `Scanning: ${tpInfos.satName}`
  //    frequency = `${tpInfos.transponder.toFixed(2)} Mhz`
      frequency = `${tpInfos.transponder} MHz`
      polarization = `${tpInfos.polarization}`
      symbolRate = `${parseInt(tpInfos.symbolRate/1000)} Kb/s`
    }
    this.setProp("satName", satName)
    this.setProp("frequency", frequency)
    this.setProp("polarization", polarization)
    this.setProp("symbolRate", symbolRate)
    this.setProp("screenTitle", _("Updates Ongoing...."))
  }

  update(itemList, tvCount, radioCount, serviceCount) {
    if (this.inner.children.length + itemList.length >= MAX_ITEM_COUNT) {
      const childrenToRemoveCount = this.inner.children.length + itemList.length - MAX_ITEM_COUNT
      for (let i = 0, l = childrenToRemoveCount; i < l; ++i) {
        if (this.inner.lastChild) {
          this.inner.removeChild(this.inner.lastChild)
        }
      }
    }
    let i = 0
    itemList.forEach((channel) => {
      if (i <= MAX_ITEM_COUNT) {
        const toAdd = new Item(channel)
        this.inner.insertBefore(toAdd.build(), this.inner.firstChild)
      }
      i++
    })

    this.setProp("tvFound", _("TV") + `: ${tvCount}`)
    this.setProp("radioFound",  _("Radios") + `: ${radioCount}`)
    this.setProp("totalFound",  _("Total services found") + `: ${serviceCount}`)
  }

  reset() {
    clearNode(this.inner)
    const defaultItem = new Item()
    this.inner.appendChild(defaultItem.build())
    this.updateProgress(0, null)
    this.setProp("tvFound", _("TV") + ": 0")
    this.setProp("radioFound",  _("Radios") + ": 0")
    this.setProp("totalFound",  _("Total services found") + ": 0")
  }

  commitStart() {
    return pullState(this.hamsterWheel, "hidden")
  }

  commitDone() {
    return pushState(this.hamsterWheel, "hidden")
  }

  pushBlackScreen() {
    this.pushState("blackScreen")
  }
  pullBlackScreen() {
    this.pullState("blackScreen")
  }
}
