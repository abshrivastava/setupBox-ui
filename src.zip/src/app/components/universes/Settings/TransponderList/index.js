//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import ActionsList from "./ActionList"
import TPList from "./TPList"
import "./index.css"


export default class TransponderList extends Component {
  constructor(props) {
    super(props)
    this.subItems = []
  }
  render() {
    return (
      <div className="TransponderList TransponderList--hidden">
        <div className="TransponderList-inner"  key="STBparent">
          <div className="TransponderList-main">
            <div className="TransponderList-context" prop="title"/>
            <div className="TransponderList-details">
              <TPList key="TPList"/>
            </div>
            <div className="TransponderList-info">
              <span className="TransponderList-Name" prop="ssName"/>
              <span className="TransponderList-Value" prop="ssValue"/>
              <div className="TransponderList-progressBar">
                <div className="TransponderList-progress" key="progressSS" />
              </div>
            </div>
            <div className="TransponderList-info">
              <span className="TransponderList-Name" prop="sqName"/>
              <span className="TransponderList-Value" prop="sqValue"/>
              <div className="TransponderList-progressBar">
                <div className="TransponderList-progress" key="progressSQ" />
              </div>
            </div>
          </div>
          <ActionsList key="optionList"/>
        </div>
      </div>
    )
  }

  onLoad(sub) {
    this.setProp("title", sub.title)
    this.setProp("ssName", "Signal Strength")
    this.setProp("sqName", "Signal Quality")
    this.setProp("ssValue", "0%")
    this.setProp("sqValue","0%")
  }

  loadItems(itemList) {
    this.optionList.setActions(itemList)
  }

  loadTPList() {
    this.TPList.showFirstLevelTransponder()
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  updateSignalDetails(TransSignal) {
    let strength = 0
    let quality = 0

    if (TransSignal) {
      if (TransSignal.SignalStrength !== undefined) {
        if (TransSignal.SignalStrength >= 100) {
          strength = 100
        } else if (TransSignal.SignalStrength <= 0) {
          strength = 0
        } else {
          strength = TransSignal.SignalStrength
        }
      }
      if (TransSignal.SignalQuality !== undefined) {
        if (TransSignal.SignalQuality >= 100) {
          quality = 100
        } else if (TransSignal.SignalQuality <= 0) {
          quality = 0
        } else {
          quality = TransSignal.SignalQuality
        }
      }
    }

    this.setProp("ssValue", `${strength} %`)
    this.setProp("sqValue", `${quality} %`)
    this.progressSS.style.width = (strength) + "%"
    this.progressSQ.style.width = (quality) + "%"
  }

}
