//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {} from "utils/dom"
import "./index.css"

export default class LangInfoBar extends Component {
  constructor(props) {
    const defaultProps = {
      content: "Language",
    }
    super(Object.assign({}, defaultProps, props))
    this.context = null
  }

  render() {
    return (
      <div className="LangInfoBar">
        <div className="LangInfoBar-btn" prop="context" />
        <div className="LangInfoBar-content" prop="content" />
      </div>
    )
  }
  onOpen() {
    console.log("open")
  }

  fold() {
    return this.pullState("unfold")
  }

  unfold() {
    console.log("unfold")
    return this.pushState("unfold")
  }
}
