//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import classNames from "classnames"
import Component from "widgets/Component"
import bus from "services/bus"
import config from "utils/config"

import "./index.css"

export default class DevToolBar extends Component {
  constructor() {
    const defaultProps = {
      universe: bus.universe,
      lastKey: null,
    }
    super(defaultProps)
  }

  render() {
    const toolBarStyles = classNames(
      "DevToolBar",
      config.IS_REMOTE && "DevToolBar--remote",
    )

    return (
      <div className={toolBarStyles}>
        <dl class="DevToolBar-busInfo">
          <dt>Universe</dt>
          <dd className="bus-universe" prop="universe" />
          <dt>Last Key</dt>
          <dd className="lastKey" prop="lastKey" />
        </dl>
      </div>
    )
  }

  build() {
    const dom = super.build()
    const universeEl = dom.querySelector(".bus-universe")
    const lastKeyEl = dom.querySelector(".lastKey")

    universeEl.addEventListener("click", () => {
      const newUniverse = prompt("Force universe:")
      if (newUniverse && newUniverse.length) {
        bus.universe = newUniverse
      }
    }, true)

    lastKeyEl.addEventListener("click", () => {
      const keys = Object.keys(config.KEYMAP)
        .map((name) => `${name}: ${config.KEYMAP[name]}`)
        .join("\n")
      alert(keys)
    }, true)

    return dom
  }
}
