//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import "./index.css"
import {pushState, pullState} from "utils/dom"
import LangInfoBar from "app/components/universes/Application/LangInfoBar"

export class PopUpButton extends Component {
  render() {
    return (
      <div className="PopUp-button" prop="label" />
    )
  }

  update(value) {
    this.setProp("label", value)
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }
}

export default class PopUp extends Component {
  constructor(props) {
    const defaultProps = {
      title: "",
      message: "",
      countdown: "",
    }
    super(Object.assign({}, defaultProps, props))

    this._flush()
  }

  render() {
    return (
      <div class="PopUp PopUp--hidden"  key="popupLevel">
        <div className="PopUp-icon " />
        <div className="PopUp-wrapper">
          <span className="PopUp-title" prop="title" />
          <div className="PopUp-message" key="message" prop="message"/>
          <div className="PopUp-message-code" key="message_code" prop="message_code"/>
          <div className="PopUp-message2 PopUp-message2--hidden" key="message2" prop="message2" />
          <div className="PopUp-message3 PopUp-message3--hidden" key="message3" prop="message3" />
          <div className="PopUp-buttons-wrapper" key="buttonWrapper" />
          <span className="PopUp-countdown hidden" prop="countdown" />
          <div className="PopUp-progressBar PopUp-progressBar--hidden" key="progressBar">
            <div className="PopUp-progress" key="PopUpProgress" prop="PopUpProgress" />
          </div>
          <LangInfoBar />
        </div>
      </div>
    )
  }

  onOpen() {
    return this.show()
  }

  onClose() {
    if (this.PopUpProgress) this.PopUpProgress.style.width = "1px"
    this.progressBar && pushState(this.progressBar, "hidden")
    this.message2 && pushState(this.message2, "hidden")
    this.message3 && pushState(this.message3, "hidden")
    this.resetMessage()
    this.clearCountDown()
    return this.hide()
  }

  updatePopForEasyScan(hideScanBar) {
    if (hideScanBar === true) {
      this.dom.className = "PopUpForEasyScanUpdate"
      this.dom.childNodes[1].className = "PopUp-wrapperForEasyScanUpdate"
    } else if (hideScanBar === false) {
      if (this.dom.className !== "PopUp") this.dom.className = "PopUp"
      if (this.dom.className !== "PopUp-wrapper") this.dom.childNodes[1].className = "PopUp-wrapper"
    }
  }

  showProgressBar() {
    pullState(this.progressBar, "hidden")
  }

  updateProgressBar(data) {
    if (data.progress) {
      const progress = (data.progress) * 5.09
      this.PopUpProgress.style.width = progress + "px"
    }
  }

  updateTitle(title) {
    this.setProp("title", title)
  }

  updateMessage(message) {
    this.setProp("message", message)
  }

  updateInstantMessage(message, code) {
    this.setProp("message_code", code)
    this.setProp("message", message)
    this.message.style.float = "left"
    this.message.style.marginTop = "5%"
    this.message.style.marginLeft = "12%"
    this.message.style.width = "auto"
    this.message.style.fontSize = "35px"
    if (this.message_code)  this.message_code.style.display = "block"
  }

  alignMessage() {
    pushState(this.message, "alertMessage")
  }

  resetMessage() {
    pullState(this.message, "alertMessage")
    this.message.style.float = "none"
    this.message.style.marginTop = "10px"
    this.message.style.marginLeft = ""
    this.message.style.width = "100%"
    this.message.style.fontSize = "15px"
    if (config.SD_ZAPPER) {
      this.message.style.marginTop = "8px"
      this.message.style.fontSize = "12px"
    }
    this.setProp("message_code", "")
    if (this.message_code) this.message_code.style.display = "none"
  }

  updateMessage2(message) {
    pullState(this.message2, "hidden")
    this.setProp("message2", message)
  }

  updateMessage3(message) {
    pullState(this.message3, "hidden")
    this.setProp("message3", message)
  }

  updateCountDown(value) {
    this.setProp("countdown", value  + " sec")
  }

  clearCountDown() {
    this.setProp("countdown", "")
  }

  setButtons(buttons) {
    this._flush()
    if (buttons.length > 0) {
      for (const button of buttons) {
        const item = new PopUpButton(button)
        this.buttonWrapper.appendChild(item.build())
        this.buttons.push(item)
      }
      pushState(this.buttonWrapper, "hidden")
      this.selectButton(Math.min(this.buttons.length - 1, 1))
    }
  }

  selectButton(index) {
    this.buttons[this.focusedIdx].blur()
    this.focusedIdx = index
    this.buttons[index].focus()
  }

  displayTop() {
    pushState(this.popupLevel, "displayTop")
  }

  _flush() {
    this.focusedIdx = 0
    this.countDown = null
    this.buttons = []
    this.clearCountDown()
    if (this.buttonWrapper) {
      while (this.buttonWrapper.firstChild) {
        this.buttonWrapper.removeChild(this.buttonWrapper.firstChild)
      }
      pullState(this.buttonWrapper, "hidden")
    }
  }
}
