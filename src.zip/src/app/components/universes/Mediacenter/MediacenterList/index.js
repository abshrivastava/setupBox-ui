//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {waitReflow} from "utils/dom"

import MediaCenterManager from "services/managers/MediaCenterManager"
import MainBackground from "app/components/widgets/MainBackground"

import breadCrumbImageUrl from "assets/pictos/subfolder.png"

import Background from "./Background"
import Selection from "./Selection"
import ItemList from "./ItemList"

import "./index.css"

export default class MediacenterList extends Component {

  render() {
    return (
      <div className="MediacenterList MediacenterList--hidden">
        <MainBackground key="mainBackground" />
        <Background key="background" />
        <ItemList key="itemList" />
        <Selection key="selection" />
        <div className="MediacenterBreadCrumb" key="breadCrumb" />
      </div>
    )
  }

  open() {
    this.show()
    this.mainBackground.show()
    waitReflow(this.dom)

    const promises = [
      this.selection.unfold(),
      this.itemList.unfold(),
      this.background.unfold(),
    ]

    return Promise.all(promises)
  }

  close() {
    const promises = [
      this.mainBackground.hide(),
      this.selection.fold(),
      this.itemList.fold(),
      this.background.fold(),
      this.clearBreadCrumb(),
      MediaCenterManager.clearHistory(),
    ]

    return Promise.all(promises)
      .then(() => this.hide())
  }

  update(data) {
    this.itemList.setScrollableSource(data)
    this.setBreadCrumb()
  }

  setBreadCrumb() {
    this.clearBreadCrumb()
    MediaCenterManager.getHistoryPaths().forEach((segment) => {
      this.addBreadCrumbSeparator()
      this.addSegmentToBreadCrumb(segment)
    })
  }

  clearBreadCrumb() {
    while (this.breadCrumb.firstChild) {
      this.breadCrumb.removeChild(this.breadCrumb.firstChild)
    }
  }

  addBreadCrumbSeparator() {
    const breadCrumbSeparator = document.createElement("IMG")
    breadCrumbSeparator.setAttribute("src", breadCrumbImageUrl)
    breadCrumbSeparator.setAttribute("class", "BreadCrumbSeparator")
    this.breadCrumb.appendChild(breadCrumbSeparator)
  }

  addSegmentToBreadCrumb(segment) {
    const segmentNode = document.createElement("SPAN")
    segmentNode.innerHTML = segment
    segmentNode.setAttribute("class", "BreadCrumbText")
    this.breadCrumb.appendChild(segmentNode)
  }
}
