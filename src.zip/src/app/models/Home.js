//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import config from "utils/config"

let ITEMS = {}
if (config.PVR_DISABLED === true) {
  ITEMS = {
    "tv": {
      label: "Channels",
      icon: "tv",
      signal: "goto",
      args: "tv",
    },
    "epg": {
      label: "TV Guide",
      icon: "epg",
      signal: "goto",
      args: "epg",
    },
    "mod": {
      label: "MOD",
      icon: "vod",
      signal: "goto",
      args: "mod",
    },
    "application store": {
      label: "Active Services",
      icon: "apps",
      signal: "goto",
      args: "activeServices",
    },
    "settings": {
      label: "My DishTV",
      icon: "sets",
      signal: "goto",
      args: "settings",
    },
  }
} else {
  ITEMS = {
    "tv": {
      label: "Channels",
      icon: "tv",
      signal: "goto",
      args: "tv",
    },
    "tv recordings": {
      label: "My Recordings",
      icon: "rec",
      signal: "goto",
      args: "pvr",
    },
    "epg": {
      label: "TV Guide",
      icon: "epg",
      signal: "goto",
      args: "epg",
    },
    "vod": {
      label: "MOD",
      icon: "vod",
      signal: "vod:load",
      args: "vod",
      player: false,
    },
    "mod": {
      label: "MOD",
      icon: "vod",
      signal: "goto",
      args: "mod",
    },
    "application store": {
      label: "Active Services",
      icon: "apps",
      signal: "goto",
      args: "appstore",
    },
    "media player": {
      label: "Media Center",
      icon: "mplay",
      signal: "goto",
      args: "mediacenter",
    },
    "radio": {
      label: "Radio",
      icon: "radio",
      signal: "goto",
      args: "radio",
    },
    "settings": {
      label: "My DishTV",
      icon: "sets",
      signal: "goto",
      args: "settings",
    },
  }
}
export default class Home extends Model {
  constructor(props) {
    super(props)
    this.orientation = config.HOME_ORIENTATION
    this.items = []
    config.HOME_ITEMS.forEach((item) => {
      if (item in ITEMS) {
        this.items.push(ITEMS[item])
      }
    })

    this.hybrid = {
      "vertical": Math.min(this.items.length, 4),
      "horizontal": Math.min(this.items.length, 6),
    }
    this.handleIcons = true
    this.delaySelected = 350
  }
}
