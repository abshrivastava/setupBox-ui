//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import {dateToCdsTimestamp} from "utils/date"

export const DEFAULT_OPTIONS = {
  order: ["service_id", "start_date"],
  metadata: [
    "service_id", "title", "start_date", "end_date",
    "content_nibble_level_1", "content_nibble_level_2",
    "description", "short_description", "program_id",
  ],
}

export const LINE_NUMBERS = 5
export const TIMELINE_DURATION = config.SD_ZAPPER?84:150

export const SCROLL_DIRECTIONS = {
  UP: -1,
  DOWN: +1,
  PROGRAM_PLUS: -1,
  PROGRAM_MINUS: +1,
  LEFT: -1,
  RIGHT: +1,
}

export const MINUTE_TO_PIXEL = 7

export function minuteToPixel(duration) {
  if (isNaN(duration)) {
    return config.SD_ZAPPER ? 607 : 1080
  }
  return (duration / 60) * MINUTE_TO_PIXEL
}
export function buildView(program, originalDelta) {
  let deltaTime = originalDelta
  const now = dateToCdsTimestamp(new Date())
  const start = program.cdsStartDate
  const end = program.cdsEndDate
  const ongoing = (start < now && end > now)
  let duration = program.duration
  let x = 0
  if (start < deltaTime) {
    deltaTime = deltaTime - start
    duration = duration - deltaTime
  } else if (!isNaN(start)) {
    x = start - deltaTime
  }
  const maxWidth = (config.SD_ZAPPER) ? "607px" : "1080px"
  const width = (duration !== 0) ? minuteToPixel(duration) + "px" : maxWidth
  x = minuteToPixel(x) + "px"
  program.view = {
    "width": width,
    "x": x,
    "ongoing": ongoing,
  }
  return program
}
