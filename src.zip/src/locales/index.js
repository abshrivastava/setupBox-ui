//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//

export const LOCALE_DATA = {
"locale-eng_ENG":{ 
    "": {
        "Content-Transfer-Encoding": "8bit",
        "Content-Type": "text/plain; charset=UTF-8",
        "Generated-By": "Babel 1.3",
        "Language": "eng_ENG",
        "Language-Team": "none",
        "Last-Translator": "Automatically generated",
        "MIME-Version": "1.0",
        "PO-Revision-Date": "2017-05-03 19:45+0530",
        "POT-Creation-Date": "2018-06-19 11:08+0530",
        "Project-Id-Version": "PROJECT VERSION",
        "Report-Msgid-Bugs-To": "EMAIL@ADDRESS"
    },
    " Soon Recording Functions & Timeshift feature will be available. Retry later.": [
        null,
        " Recording & Timeshift related functions will be available soon. Please try again later. "
    ],
    " You have run out of disk space on the connected USB device.Please delete existing recordings to record further.": [
        null,
        " You have run out of space on the connected USB device. Please delete existing recordings to record further."
    ],
    "102 - Viewing Card (VC) Deactivated": [
        null,
        "102 - Low Account Balance"
    ],
    "103 - HD Channel not subscribed": [
        null,
        "103 - Upgrade To HD Pack"
    ],
    "301 – Signal not found": [
        null,
        "301 – Signal not found"
    ],
    "303 Re-Install Services": [
        null,
        "303 - Channel Scan Error"
    ],
    "5.1 OFF": [
        null,
        "5.1 Off"
    ],
    "5.1 ON": [
        null,
        "5.1 On"
    ],
    "5.1 Setting": [
        null,
        "5.1 Audio Settings"
    ],
    "501 - Conditional Access": [
        null,
        "501 - Order this Movie"
    ],
    "701 – detecting External USB Device…": [
        null,
        "701 – Detecting USB Device…"
    ],
    "704 – USB device Alert": [
        null,
        "704 – USB Device Alert"
    ],
    "803 – Recording Alert": [
        null,
        "804 – Recording Alert"
    ],
    "A Record or a Reminder is already scheduled \nfor this channel for the same hour. We can’t take into account your action.": [
        null,
        "A Record or a Reminder is already scheduled \nfor this channel for the same hour. We can’t take your action into account ."
    ],
    "A new USB Device has been detected. OK to start format. All data in the disk will be lost": [
        null,
        "A new USB Device has been detected. Press \"OK\" to start formatting. All data in the disk will be lost."
    ],
    "A recording is going on, changing the channel shall discard the current recording.": [
        null,
        "Recording is going on. Changing the channel shall discard the current recording."
    ],
    "AM": [
        null,
        "AM"
    ],
    "Advanced Setting Screen": [
        null,
        "Advanced Settings "
    ],
    "Arts/Culture": [
        null,
        "Arts & Culture"
    ],
    "Assamese/North East": [
        null,
        "Assamese/ North East"
    ],
    "Bangla": [
        null,
        "Bangla"
    ],
    "Call me to 57575 from your Registered Mobile Number.": [
        null,
        "CALL ME to 57575 from your Registered Mobile Number."
    ],
    "Cancel": [
        null,
        "Cancel"
    ],
    "Cancel & Exit": [
        null,
        "Cancel & Exit"
    ],
    "Cancel Record": [
        null,
        "Cancel Record"
    ],
    "Cancel Reminder": [
        null,
        "Cancel Reminder"
    ],
    "Change Freq:": [
        null,
        "Change Frequency:"
    ],
    "Change Language": [
        null,
        "Change Language"
    ],
    "Change Pin Code": [
        null,
        "Change PIN Code"
    ],
    "Change UI Language": [
        null,
        "Change Menu Language"
    ],
    "Change pin code": [
        null,
        "Change PIN code"
    ],
    "Channel No. {channelNum} is not subscribed by you.": [
        null,
        "You are not subscribed to {channelNum}."
    ],
    "Channel search completed": [
        null,
        "Channel Search Completed"
    ],
    "Confirm new pin code": [
        null,
        "Confirm new PIN code"
    ],
    "Connected USB device is not compatible to the STB.": [
        null,
        "Connected USB device is not compatible with your Set-Top-Box."
    ],
    "Currently no channels are available under this category.": [
        null,
        "Currently no channels are available under this category."
    ],
    "Default List Mode": [
        null,
        "Default List Mode"
    ],
    "DishTV add <a-la-carte code> <11 digit VC No.> to 57575": [
        null,
        "DishTV ADD <Add-On code> <11 digit VC No.> to 57575"
    ],
    "DishTV refresh <11 digit VC No.> to 57575": [
        null,
        "DishTV REFRESH <11 digit VC No.> to 57575"
    ],
    "DishTV up <Pack Price> <11 digit VC No.> to 57575": [
        null,
        "DishTV UP <Pack Price> <11 digit VC No.> to 57575"
    ],
    "Do you want to apply this HDMI resolution?": [
        null,
        "Do you want to use this HDMI resolution?"
    ],
    "Do you want to change IFtoIF mode and launch scan?  Launching scan will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it": [
        null,
        "Do you want to change IF2IF mode and launch scan?  Launching the scan will delete your current list of channels and your Favourites list. Also if a record is in progress you will lose it."
    ],
    "End Freq: ": [
        null,
        "End Frequency:"
    ],
    "Enter current pin code": [
        null,
        "Enter current PIN code"
    ],
    "Enter new pin code": [
        null,
        "Enter new PIN code"
    ],
    "Enter pin code": [
        null,
        "Enter PIN Code"
    ],
    "Factory Setting Confirmation": [
        null,
        "Factory Reset Confirmation"
    ],
    "Favorite Add": [
        null,
        "Add to Favourites"
    ],
    "Favorite Remove": [
        null,
        "Remove Favourite"
    ],
    "Favorite channels": [
        null,
        "Favourite Channels"
    ],
    "Favourite List Mode": [
        null,
        "Favourite List Mode"
    ],
    "First Install, Sw Update": [
        null,
        "First Time Installation, Software Update."
    ],
    "For resolving no access/unsubscribed channel/card refresh errors:": [
        null,
        "Refresh channel list:"
    ],
    "Forgot to recharge! Give a Missed Call on \n1800 274 9050 to get your channels NOW. \nPay in next 3 days to enjoy NON STOP TV.": [
        null,
        "For help, SMS: CALLME to 57575 from your Registered Mobile Number."
    ],
    "Give a missed call on 1800 274 9511 from your or SMS CALLME to 57575 from your Registered Mobile Number (RMN).": [
        null,
        "For help, call 1860-258-3474 or SMS: CALLME to 57575 from your Registered Mobile Number."
    ],
    "HDMI resolution": [
        null,
        "HDMI Resolution"
    ],
    "IF2IF MODE": [
        null,
        "IF2IF MODE"
    ],
    "IF2IF OFF": [
        null,
        "IF2IF Off"
    ],
    "IF2IF ON": [
        null,
        "IF2IF On"
    ],
    "IN CASE OF HEAVY RAIN, WAIT TILL RAIN STOPS TO REGAIN SIGNAL": [
        null,
        "If the weather is clear but signal problem persists, turn off your Set-Top-Box, check all cable connections and turn the box on."
    ],
    "If already recharged, please, switch-off & switch-on your Set-Top-Box from the mains and keep it ON for 15 minutes on channel 99": [
        null,
        "To update your account switch the Set-Top-Box off & on, from main power."
    ],
    "If problem continues, SMS DISHTV 301 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "If problem continues, call 1860-258-3474 or SMS: CALLME to 57575 from your Registered Mobile Number. "
    ],
    "If problem continues, SMS DISHTV 302 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "If problem continues, call 1860-258-3474 or SMS: CALLME to 57575 from your Registered Mobile Number."
    ],
    "Impossible to create a record, please set a valid date/time in the future.": [
        null,
        "Impossible to create a record. Please set a valid future date and time. "
    ],
    "Impossible to remove a channel from favorite while currently browsing Favorite List": [
        null,
        "You cannot remove a channel from Favourites while browsing favourite list."
    ],
    "In order to give you the state of the Transponder we need to stop the records.": [
        null,
        "In order to give you information about the Transponder we need to stop your ongoing recordings."
    ],
    "Informations": [
        null,
        "Information"
    ],
    "LNB Hi Frequency:": [
        null,
        "LNB High Frequency:"
    ],
    "Last Payment details:": [
        null,
        "Last Payment Details:"
    ],
    "Leisure hobbies": [
        null,
        "Leisure & Hobbies"
    ],
    "MEDIACENTER": [
        null,
        "Media Centre"
    ],
    "MOD": [
        null,
        "Specials"
    ],
    "Mac adress isn't valid.": [
        null,
        "MAC address is not valid. "
    ],
    "Manage favorites": [
        null,
        "Manage Favourites"
    ],
    "Media center": [
        null,
        "Media Centre"
    ],
    "Mediaplayer Error": [
        null,
        "Media Player Error"
    ],
    "Movie": [
        null,
        "Movies"
    ],
    "NO SIGNAL DETECTED": [
        null,
        "No Signal Detected"
    ],
    "Network Selection": [
        null,
        "Network Information"
    ],
    "Network information": [
        null,
        "Network Information"
    ],
    "No USB Device connected. Connect USB Device to use Recorder features": [
        null,
        "No USB device is connected. Connect a compatible USB device to use recorder features."
    ],
    "No applications found.": [
        null,
        "No Applications Found"
    ],
    "No information": [
        null,
        "No Information"
    ],
    "No internet connection.": [
        null,
        "No Internet Connection"
    ],
    "No services available. Perform a scan.": [
        null,
        "No services available. Please perform a scan."
    ],
    "Not able to launch application/game": [
        null,
        "Sorry, We are not able to launch your Application/games, retry later."
    ],
    "OK": [
        null,
        "OK"
    ],
    "Ok": [
        null,
        "OK"
    ],
    "Ok ": [
        null,
        "OK"
    ],
    "One Time": [
        null,
        "One Time"
    ],
    "Order an A-La-Carte pack:": [
        null,
        "Order an Add-On pack:"
    ],
    "PM": [
        null,
        "PM"
    ],
    "PVR & TS": [
        null,
        "Personal Video Recorder (PVR) and Timeshift (TS)"
    ],
    "Panjabi": [
        null,
        "Punjabi"
    ],
    "Play": [
        null,
        "Play"
    ],
    "Please Plug-in CAM to view CAM Menu.": [
        null,
        "Please plug-in CAM to view CAM menu."
    ],
    "Please Plugin USB Device Properly": [
        null,
        "Please plugin USB device properly."
    ],
    "Please RECHARGE YOUR DISHTV VC No {vcNum} \nLog on www.dishtv.in use Credit/Debit card walk into: Nearest Recharge Outlet": [
        null,
        "VC No. {vcNum} is due for Recharge.\nRecharge at any DishTV dealer or visit dishtv.in."
    ],
    "Please Wait ...": [
        null,
        "Please wait..."
    ],
    "Please choose a Filter": [
        null,
        "Please choose a filter"
    ],
    "Please ensure that your set-Top-Box is properly connected to the DISHTV antenna": [
        null,
        "This could be due to Heavy Rain or Bad Weather.\nPlease wait till weather clears."
    ],
    "Please enter PIN to select IF2IF mode, this will launch scan and it will delete your recording and favourite list.": [
        null,
        "Please enter PIN to select IF2IF mode. This will launch a scan and it will delete your recording and favourite list."
    ],
    "Please enter Symbol rate:": [
        null,
        "Please enter Symbol Rate:"
    ],
    "Please, POWER OFF – POWER ON your Set-Top-Box from switch.": [
        null,
        "Please switch off the Set-Top-Box from main power and switch it on again."
    ],
    "Press \"OK\" on your remote to re-install channels and services. \nIf problem continues, SMS DISHTV 303 to 57575 from your registered Mobile Number (RMN). To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "Please press OK button on your remote to restore your channels.\nIf problem continues, call 1860-258-3474 or SMS: CALLME to 57575 from your Registered Mobile Number."
    ],
    "Press Back for Tools": [
        null,
        "Press OK for details"
    ],
    "Press Back to exit from active service": [
        null,
        "Press BACK to exit"
    ],
    "Press Menu to Exit": [
        null,
        "Press Menu to exit"
    ],
    "Press OK for details": [
        null,
        "Press OK for details"
    ],
    "Press OK to Save my schedule": [
        null,
        "Press OK to save your schedule"
    ],
    "Press OK to launch EASY SCAN": [
        null,
        "Press OK to launch Easy Scan"
    ],
    "RECORDS": [
        null,
        "Records"
    ],
    "Recording failed": [
        null,
        "Recording Failed"
    ],
    "Recording features are not authorized on this channel": [
        null,
        "Recording features are not available on this channel."
    ],
    "Recording in progress. If you continue you will lose your record.": [
        null,
        "Recording is in progress. Changing the channel will stop this recording."
    ],
    "Recording is not possible on past event.": [
        null,
        "Recording is not possible on a past event."
    ],
    "Reminder can't be applied as program has no information.": [
        null,
        "Reminder can't be set as information is not available for this program."
    ],
    "Reset favorites": [
        null,
        "Reset Favourites"
    ],
    "Retrieving active service, please wait.": [
        null,
        "Please wait while we retrieve your Active Services"
    ],
    "SCRAMBLED CHANNEL": [
        null,
        "Scrambled Channel"
    ],
    "SMS DISHTV CALL ME to 57575 from your registered mobile number (RMN).": [
        null,
        "For help, call 1860-258-3474 or SMS: CALLME to 57575 from your Registered Mobile Number."
    ],
    "SMS MOD {vcNum} {PurchaseCode} to 57575. If you do not get the movie with in 10 minutes after sending ": [
        null,
        "To order, SMS: MOD {vcNum} {PurchaseCode} to 57575."
    ],
    "SMS: DISHTV ADD {channelNum} to 57575 \nfrom your Registered Mobile Number": [
        null,
        "For pricing information, please visit dishtv.in."
    ],
    "STB No": [
        null,
        "STB No"
    ],
    "STB No:": [
        null,
        "STB No"
    ],
    "Schedule Your Recording": [
        null,
        "Schedule Your Recording"
    ],
    "Select on your remote control the biggest number displayed": [
        null,
        "On your remote control, select the biggest number displayed"
    ],
    "Self-help": [
        null,
        "Help"
    ],
    "Serie": [
        null,
        "Series"
    ],
    "Should your services not restart in 15 minutes, \nSMS DISHTV REFRESH to 57575 \nfrom your registred Mobile Number": [
        null,
        "If services do not resume in 15 minutes, \ngive a missed call on 18002702102 from your Registered Mobile Number"
    ],
    "Social/Politics": [
        null,
        "Social & Politics"
    ],
    "Sorry this action is not permitted with a CAM, remove it and switch off switch on your box in order to use this feature.": [
        null,
        "This action is not permitted with a CAM module. To use this feature, please remove the CAM module then turn off your set-top-box and turn it on again."
    ],
    "Start Freq: ": [
        null,
        "Start Frequency:"
    ],
    "Subscribe to this channel in HD picture \nquality along with {noOfHdChannels} more HD channels \nat  Rs. {priceTag} per month.": [
        null,
        "To subscribe SMS DISHTV GET {channelNum} to 57575 from your RMN."
    ],
    "System information": [
        null,
        "System information"
    ],
    "TP Info": [
        null,
        "Transponder(TP) Info"
    ],
    "TP list screen": [
        null,
        "Transponder list"
    ],
    "TV: {tvFound}     Radios: {radioFound}      Network: {networkFound}": [
        null,
        "TV channels: {tvFound}     Radio channels: {radioFound}      Network: {networkFound}"
    ],
    "The STB is not able to format the connected USB device. Use Another device": [
        null,
        "The STB is not able to format the connected USB device. Use another device."
    ],
    "The Sw version details are not provided, System can’t verify if a new Sw version is available": [
        null,
        "Software version details are not provided. System can’t verify if a new software version is available."
    ],
    "The program {scheduleTitle} can't be recorded because no compliant USB device connected.": [
        null,
        "The program {scheduleTitle} can't be recorded because no USB device is connected to support this feature. "
    ],
    "The signal to your Set-Top-Box is temporarily unavailable.": [
        null,
        "Connection to your Set-Top-Box is unavailable."
    ],
    "There is a TV recording in progress. You cannot access to radio universe": [
        null,
        "There is a TV recording in progress. You cannot access the radio universe."
    ],
    "This Channel Is Blocked": [
        null,
        "This channel is blocked"
    ],
    "This channel is available in High Definition.": [
        null,
        "This HD channel has not been subscribed to by you."
    ],
    "Timeshift & PVR feature will not work": [
        null,
        "Timeshift & PVR features will not work"
    ],
    "To RMN SMS DISHTV RMN {vcNum} to 57575": [
        null,
        "To Register your Mobile Number, SMS: \nDISHTV RMN {vcNum} to 57575"
    ],
    "To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "To Register your Mobile Number, SMS: DISHTV RMN {vcNum} to 57575."
    ],
    "To Register your Mobile Number, \nSMS: DISHTV RMN {vcNum} to 57575": [
        null,
        "To register your mobile number, SMS: DISHTV RMN {vcNum} to 57575."
    ],
    "To allow timely updation, after ordering a \nchannel, please switch-off & switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channnel 99 for 15 minutes.": [
        null,
        "To allow timely updation, after ordering a \nchannel, please switch-off & switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channel 96 for 15 minutes."
    ],
    "To order {EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}": [
        null,
        "Watch the latest blockbusters\nCurrently Showing: {EventName}\nPrice:(Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm})\nMovie Code: {PurchaseCode}"
    ],
    "To subscribe this channel, \nSMS: DISHTV GET {channelNum} to 57575 \nFrom your Registered Mobile Number (RMN)": [
        null,
        "To subscribe to this channel, \ncall 1860-258-3474 or SMS: DISHTV GET {channelNum} to 57575 from your Registered Mobile Number (RMN)."
    ],
    "Total services found": [
        null,
        "Total services found"
    ],
    "USB Device Not Inserted Properly": [
        null,
        "USB device has not been inserted properly."
    ],
    "USB disk size not compliant with PVR & TS requirements. Minimal free size to activate = 10Go": [
        null,
        "USB disk size not compliant with PVR & TS requirements. Minimal free size required to activate this functionality is 10GB."
    ],
    "Unable to play this file. Press BACK or OK key to return to Mediaplayer explorer.": [
        null,
        "Unable to play this file. Press BACK or OK key to return to media player explorer."
    ],
    "Unable to play this file. Press BACK or OK key to return to Recording.": [
        null,
        "Unable to play this file. Press BACK or OK key to return to recording."
    ],
    "Updates Ongoing....": [
        null,
        "Updates in progress..."
    ],
    "Upgrade your pack:": [
        null,
        "Upgrade pack:"
    ],
    "Usb key has been Unplugged": [
        null,
        "USB key has been unplugged."
    ],
    "VC No": [
        null,
        "VC No"
    ],
    "VC No:": [
        null,
        "VC No"
    ],
    "Vod catalog loading aborted by user.": [
        null,
        "VOD catalog loading aborted by user."
    ],
    "Vod initialization aborted.": [
        null,
        "[VOD] Initialization aborted."
    ],
    "Wrong pin code !": [
        null,
        "Wrong PIN Code"
    ],
    "You are now browsing you default channel list .\nPress FAV button to switch to your Favourite Channels list.": [
        null,
        "You are now browsing the default channel list .\nPress FAV button to switch to your Favourite Channels list."
    ],
    "You will launch a  Reset, All of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "You are going to launch a reset. All of your settings will be restored to the default value. If a recording is in progress, you will lose it."
    ],
    "You will launch a Channel Search that will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it.": [
        null,
        "You are going to launch a channel search. It will delete your current list of channels, Favourites list and any record in progress."
    ],
    "You will launch a Factory Reset, Some of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "You will launch a factory reset. Your settings will be restored to the default value and any recording in progress will be lost. "
    ],
    "Your Set-Top-Box is being updated, Please wait…": [
        null,
        "Your set-top-box is updating. Please wait."
    ],
    "Your TV will be switched off, today. Recharge immediately to avoid disruption in service.": [
        null,
        "YOUR TV WILL BE SWITCHED OFF, TODAY. RECHARGE IMMEDIATELY TO AVOID DISRUPTION IN SERVICE."
    ],
    "Your pin code has been successfully updated !": [
        null,
        "Your PIN code has been successfully updated !"
    ],
    "Your recharge date is near. Your TV will be switched off in {count} days. Please recharge immediately to avoid disruption in service.": [
        null,
        "YOUR RECHARGE DATE IS NEAR. YOUR TV WILL BE SWITCHED OFF IN {count} DAY(S). \nPLEASE RECHARGE IMMEDIATELY TO AVOID DISRUPTION IN SERVICE."
    ],
    "[vod]AssetVoucherCodeMessage": [
        null,
        "Please enter a valid voucher code to rent this asset"
    ],
    "[vod]AssetVoucherCodeTitle": [
        null,
        "Asset voucher code"
    ],
    "[vod]BuyPackError": [
        null,
        "Error when trying to play asset"
    ],
    "[vod]PackVoucherCodeMessage": [
        null,
        "Please enter a valid voucher code to buy this pack"
    ],
    "[vod]PackVoucherCodeTitle": [
        null,
        "Pack voucher code"
    ],
    "[vod]Play": [
        null,
        "Play"
    ],
    "[vod]PlayAssetError": [
        null,
        "Error when trying to play asset"
    ],
    "[vod]Rent": [
        null,
        "Rent"
    ],
    "[vod]RentAssetError": [
        null,
        "Error when trying to play asset"
    ],
    "[vod]VideoLoading": [
        null,
        "Video loading"
    ],
    "[vod]VoucherDigitError": [
        null,
        "Voucher code must contains {digitCount} digits"
    ],
    "[vod]anCurrency": [
        null,
        "[vod]Currency"
    ],
    "[vod]anLanguage": [
        null,
        "[vod]Language"
    ],
    "[vod]buyPack": [
        null,
        "Buy pack"
    ],
    "[vod]loadingTitle": [
        null,
        "[VOD] Loading title"
    ],
    "authentication status": [
        null,
        "Authentication Status"
    ],
    "conflicting with": [
        null,
        "is conflicting with"
    ],
    "dishtv.in": [
        null,
        "www.dishtv.in"
    ],
    "dns1": [
        null,
        "DNS 1"
    ],
    "dns2": [
        null,
        "DNS 2"
    ],
    "gateway": [
        null,
        "Gateway"
    ],
    "interface": [
        null,
        "Interface"
    ],
    "ip_address": [
        null,
        "IP Address"
    ],
    "mac_address": [
        null,
        "MAC Address"
    ],
    "malayalam": [
        null,
        "Malayalam"
    ],
    "manipuri": [
        null,
        "Manipuri"
    ],
    "nepali": [
        null,
        "Nepali"
    ],
    "netmask": [
        null,
        "Netmask"
    ],
    "no": [
        null,
        "No"
    ],
    "ok": [
        null,
        "OK"
    ],
    "yes": [
        null,
        "Yes"
    ],
    "{programName} - ({channelName}) has been started and is scheduled for recording.": [
        null,
        "{programName} - ({channelName}) has been started and is scheduled for recording."
    ]
}
,
"locale-hin_HIN":{ 
    "": {
        "Content-Transfer-Encoding": "8bit",
        "Content-Type": "text/plain; charset=UTF-8",
        "Generated-By": "Babel 1.3",
        "Language": "hin_HIN",
        "Language-Team": "none",
        "Last-Translator": "Automatically generated",
        "MIME-Version": "1.0",
        "PO-Revision-Date": "2017-05-03 18:56+0530",
        "POT-Creation-Date": "2018-06-19 11:08+0530",
        "Project-Id-Version": "PROJECT VERSION",
        "Report-Msgid-Bugs-To": "EMAIL@ADDRESS"
    },
    " 802 – Recording Alert": [
        null,
        "802 – रिकॉर्डिंग संबंधी सूचना "
    ],
    " Soon Recording Functions & Timeshift feature will be available. Retry later.": [
        null,
        "रिकॉर्डिंग और टाइमशिफ्ट संबंधी सुविधाएँ जल्द ही उपलब्ध होंगी। कृपया कुछ समय बाद पुन: प्रयास करें।"
    ],
    " You have run out of disk space on the connected USB device.Please delete existing recordings to record further.": [
        null,
        "आपके यूएसबी डिवाइस में पर्याप्त जगह नहीं है। कृपया नई रिकॉर्डिंग के लिए मौजूदा रिकॉर्डिंग्स को डिलीट करें।"
    ],
    " from live": [
        null,
        " लाइव"
    ],
    " on ": [
        null,
        " का "
    ],
    "101 - Unsubscribed Channel": [
        null,
        "101 - चैनल सब्सक्राइब नहीं किया गया है"
    ],
    "102 - Viewing Card (VC) Deactivated": [
        null,
        "102 - अकाउंट में बैलेंस नहीं है "
    ],
    "103 - HD Channel not subscribed": [
        null,
        "103 - एचडी पैक पर अपग्रेड करे"
    ],
    "106 Software Update": [
        null,
        "106 – सॉफ्टवेयर अपडेट"
    ],
    "1860-258-3474 (Local call charges apply)": [
        null,
        "1860-258-3474 (स्थानीय कॉल प्रभार लागू)"
    ],
    "301 – Signal not found": [
        null,
        "301 - सिग्नल प्राप्त नहीं हो रहा है"
    ],
    "302 - Signal Unavailable": [
        null,
        "302 - सिग्नल उपलब्ध नहीं है"
    ],
    "303 Re-Install Services": [
        null,
        "303 - चैनल स्कैन एरर"
    ],
    "5.1 OFF": [
        null,
        "5.1 ऑफ"
    ],
    "5.1 ON": [
        null,
        "5.1 ऑन"
    ],
    "5.1 Setting": [
        null,
        "5.1 ऑडियो सेटिंग"
    ],
    "501 - Conditional Access": [
        null,
        "501 - मूवी आर्डर करें"
    ],
    "601 - Upgrade to HD Set-Top-Box": [
        null,
        "601 - एचडी सेट-टॉप-बॉक्स अपनाएं"
    ],
    "701 – detecting External USB Device…": [
        null,
        "701 - यूएसबी डिवाइस को जोड़ा जा रहा है"
    ],
    "702 - Device Detected": [
        null,
        "702 – डिवाइस डिटेक्ट हुआ है "
    ],
    "702 – New USB Device": [
        null,
        "702 - नई यूएसबी डिवाइस"
    ],
    "704 – USB device Alert": [
        null,
        "704 – यूएसबी डिवाइस संबंधी सूचना"
    ],
    "706 – USB Device Full": [
        null,
        "706 - यूएसबी डिवाइस भर गयी है"
    ],
    "708 - Device Detected": [
        null,
        "708 – डिवाइस मिल गयी है "
    ],
    "709 - Device Detected": [
        null,
        "709 – डिवाइस मिल गयी है "
    ],
    "801 - Device Detected": [
        null,
        "801 – डिवाइस डिटेक्ट हुआ है "
    ],
    "803 – Recording Alert": [
        null,
        "804 – रिकार्डिंग संबंधी सूचना"
    ],
    "806 – Recording Alert": [
        null,
        "806 – रिकार्डिंग संबंधी सूचना"
    ],
    "808 – Content Alert": [
        null,
        "808 - कंटेंट संबंधी सूचना "
    ],
    "A Record or a Reminder is already scheduled \nfor this channel for the same hour. We can’t take into account your action.": [
        null,
        "एक रिकॉर्ड या एक रीमाइंडर इस चैनल पर एक ही समय पर पहले से ही अनुसूचित है।हम आपकी कार्रवाई को ध्यान में नहीं रख सकते।"
    ],
    "A Software version is available and the Client Software will force the Update.": [
        null,
        "एक नया सॉफ्टवेयर संस्करण उपलब्ध है और क्लांइट सॉफ्टवेयर अपडेट किया जाएगा।"
    ],
    "A TV recording is going to start on channel {channelName} which is not in the favorite list. Default list will be restored and the recorded channel will be displayed. Select 'Cancel' to stay on current service": [
        null,
        "एक टीवी रिकॉर्डिंग चैनल {channelName} पर शुरू हो रही है जो फेवरेट सूची में नहीं है।रिकॉर्ड किए गए चैनल दिखाया जाएगा और डिफ़ॉल्ट सूची को पुनर्स्थापित किया जाएगा। वर्तमान सेवा पर बने रहने के लिए 'रद्द करें' दबाएंं"
    ],
    "A TV recording is on-going on channel {channelName} which is not in the favorite list. Recording will be discontinued and Favourite List will be selected. Select 'Cancel' to stay on current service": [
        null,
        "एक टीवी रिकॉर्डिंग चैनल {channelName} पर चल रही है जो फेवरेट सूची में नहीं हैरिकॉर्डिंग बंद हो जाएगी और फेवरेट सूची का चयन हो जाएगा। वर्तमान सेवा पर बने रहने के लिए 'रद्द करें' दबाएंं"
    ],
    "A new USB Device has been detected. OK to start format. All data in the disk will be lost": [
        null,
        "एक नए डिवाइस को जोड़ा गया है। फार्मेट करने के लिए OK दबाएं \nचेतावनीः डिस्क में मौजूद संपूर्ण डॉटा समाप्त हो जाएगा"
    ],
    "A recording is going on, changing the channel shall discard the current recording.": [
        null,
        "रिकॉर्डिंग चालू है, चैनल बदलने से रिकार्डिंग बंद हो जाएगी।"
    ],
    "AM": [
        null,
        "अपराह्न"
    ],
    "Active Services": [
        null,
        "ऐक्टिव सर्विसेज़"
    ],
    "Add a manual recording": [
        null,
        "रिकॉर्डिंग शेड्यूल करें"
    ],
    "Advanced Setting Screen": [
        null,
        "एडवांस्ड सेटिंग "
    ],
    "All Channels": [
        null,
        "सभी चैनल"
    ],
    "Antenna settings": [
        null,
        "एंटेना सेटिंग्स"
    ],
    "App store": [
        null,
        "ऐप स्टोर"
    ],
    "Apps": [
        null,
        "ऍप्स "
    ],
    "Apr": [
        null,
        "अप्रैल"
    ],
    "April": [
        null,
        "अप्रैल"
    ],
    "Arts/Culture": [
        null,
        "कला/संस्कृति"
    ],
    "Assamese": [
        null,
        "असमिया"
    ],
    "Assamese/North East": [
        null,
        "पूर्वोत्तर"
    ],
    "Audio": [
        null,
        "ऑडियो"
    ],
    "Audio & Video": [
        null,
        "ऑडियो और वीडियो "
    ],
    "Audio & Video Outputs": [
        null,
        "ऑडियो और वीडियो आउटपुट"
    ],
    "Aug": [
        null,
        "अगस्त"
    ],
    "August": [
        null,
        "अगस्त"
    ],
    "BACK": [
        null,
        "वापस जाएं"
    ],
    "Back": [
        null,
        "वापस जाएं"
    ],
    "Bangla": [
        null,
        "बांग्ला"
    ],
    "Bengali": [
        null,
        "बंगाली"
    ],
    "Bhojpuri": [
        null,
        "भोजपुरी"
    ],
    "Bihar": [
        null,
        "बिहार"
    ],
    "Bihari": [
        null,
        "बिहारी"
    ],
    "CA Info Sheet": [
        null,
        "सीए (CA) संबंधी जानकारी "
    ],
    "CA Information": [
        null,
        "सीए (CA) संबंधी जानकारी "
    ],
    "CAM Menu": [
        null,
        "कैम (CAM) मेन्यू"
    ],
    "CAM Module": [
        null,
        "कैम (CAM) मॉड्यूल"
    ],
    "CAM Module not authorized action.": [
        null,
        "कैम मॉड्यूल अधिकृत कार्रवाई नहीं है।"
    ],
    "CAM Module was inserted, Press Ok to reboot STB.": [
        null,
        "कैम (CAM) मॉड्यूल लगाया गया है,एसटीबी को रिबूट करने के लिए OK दबाएं"
    ],
    "CAM Module was inserted, only the watching of channel will be available.": [
        null,
        "कैम मॉड्यूल लगाया गया था, केवल चैनल का निरीक्षण उपलब्ध होगा"
    ],
    "CAM Module was removed, Press Ok to reboot STB, in order to enjoy fully the possibility of your box.": [
        null,
        "कैम (CAM) मॉड्यूल निकाल दिया गया था ,पूरी तरह से आनंद लेने के लिए एसटीबी को रिबूट करने के लिए OK दबाएं. "
    ],
    "CA_SYS_ID:": [
        null,
        "सीएसिसआईडी (CA_SYS_ID:):"
    ],
    "CVBS": [
        null,
        "सीवीबीएस(CVBS)"
    ],
    "Call Center:": [
        null,
        "कॉल सेंटर:"
    ],
    "Call me to 57575 from your Registered Mobile Number.": [
        null,
        "अपने रजिस्टर्ड मोबाइल नम्बर से CALLME लिखकर 57575 पर भेजें।"
    ],
    "Cancel": [
        null,
        "रद्द करें"
    ],
    "Cancel & Exit": [
        null,
        "कैन्सल करें और बाहर जाएं"
    ],
    "Cancel Record": [
        null,
        "रिकॉर्डिंग रद्द करें"
    ],
    "Cancel Reminder": [
        null,
        "रीमाइंडर रद्द करें"
    ],
    "Change Freq:": [
        null,
        "फ्रीक्वेंसी परिवर्तन:"
    ],
    "Change Language": [
        null,
        "मेन्यू की भाषा बदलें"
    ],
    "Change Pin Code": [
        null,
        "पिन कोड बदलें"
    ],
    "Change UI Language": [
        null,
        "मेन्यू की भाषा बदलें"
    ],
    "Change pin code": [
        null,
        "पिन कोड बदलें"
    ],
    "Channel List": [
        null,
        "चैनल लिस्ट"
    ],
    "Channel No. {channelNum} is not subscribed by you.": [
        null,
        "आपने {channelNum} चैनल सब्सक्राइब नहीं किया है।"
    ],
    "Channel Search": [
        null,
        "चैनल खोज"
    ],
    "Channel Search Confirmation": [
        null,
        "चैनल खोज की पुष्टि"
    ],
    "Channel Settings": [
        null,
        "चैनल सेटिंग"
    ],
    "Channel block": [
        null,
        "चैनल ब्लॉक"
    ],
    "Channel search": [
        null,
        "चैनल खोजें "
    ],
    "Channel search completed": [
        null,
        "चैनल की खोज पूरी हुई"
    ],
    "Channel:": [
        null,
        "चैनल:"
    ],
    "Channels": [
        null,
        "चैनल"
    ],
    "Chip ID:": [
        null,
        "चिप आईडी:"
    ],
    "Choose your Network": [
        null,
        "भाषा का चयन करें "
    ],
    "Choose your language": [
        null,
        "भाषा का चयन करें "
    ],
    "Close": [
        null,
        "बंद करें"
    ],
    "Confirm new pin code": [
        null,
        "नए पिन कोड की पुष्टि करें"
    ],
    "Connected": [
        null,
        "कनेक्ट"
    ],
    "Connected USB device is not compatible to the STB.": [
        null,
        "जुड़ी हुई यूएसबी डिवाइस आपके सेट टॉप बॉक्स के अनुकूल नहीं है"
    ],
    "Contact Us": [
        null,
        "हमसे संपर्क करें"
    ],
    "Copyright & License Info": [
        null,
        "कॉपीराइट एवं लाइसेंस सूचना"
    ],
    "Currently no channels are available under this category.": [
        null,
        "अभी इस केटेगरी में कोई चैनल उपलब्ध नहीं है।"
    ],
    "Daily": [
        null,
        "रोज़ाना"
    ],
    "Date:": [
        null,
        "तारीख :"
    ],
    "Dec": [
        null,
        "दिसंबर"
    ],
    "December": [
        null,
        "दिसंबर"
    ],
    "Default List Mode": [
        null,
        "डिफ़ॉल्ट सूची मोड"
    ],
    "Delete": [
        null,
        "डिलीट करें"
    ],
    "Details": [
        null,
        "विवरण"
    ],
    "DiSEqC:": [
        null,
        "डाईसेक:"
    ],
    "DishTV RMN <11 digit VC No.> to 57575": [
        null,
        "DishTV RMN <11 digit VC No.> को 57575 पर भेज दें।"
    ],
    "DishTV add <a-la-carte code> <11 digit VC No.> to 57575": [
        null,
        "DishTV add <a-la-carte code> <11 digit VC No.> को 57575 पर भेज दें।"
    ],
    "DishTV refresh <11 digit VC No.> to 57575": [
        null,
        "DishTV refresh <11 digit VC No.> को 57575 पर भेज दें।"
    ],
    "DishTV up <Pack Price> <11 digit VC No.> to 57575": [
        null,
        "DishTV up <Pack Price> <11 digit VC No.> को 57575 पर भेज दें।"
    ],
    "Do you really want to Format HDD? All data in the disk will be lost": [
        null,
        "एक नए डिवाइस को जोड़ा गया है। फार्मेट करने के लिए OK दबाएं \nचेतावनीः डिस्क में मौजूद संपूर्ण डॉटा समाप्त हो जाएगा"
    ],
    "Do you want to activate PVR feature?": [
        null,
        "क्या आप पर्सनल वीडियो रिकॉर्डर (पीवीआर) फीचर ऐक्टिवेट करना चाहते हैं?"
    ],
    "Do you want to apply this HDMI resolution?": [
        null,
        "क्या आप इस एचडीएमआई (HDMI) रसोलूशन का प्रयोग करना चाहते हैं?"
    ],
    "Do you want to change IFtoIF mode and launch scan?  Launching scan will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it": [
        null,
        "क्या आप आईएफ2आईएफ (IF2IF) मोड में बदलाव कर स्कैन करना चाहते हैं? स्कैन करने से आपके मौजूदा चैनलों की लिस्ट व फेवरेट लिस्ट डिलीट हो जाएगी साथ ही यदि कुछ रिकॉर्ड हो रहा होगा तो आप वो भी खो देंगे"
    ],
    "Duration:": [
        null,
        "अवधि:"
    ],
    "EPG": [
        null,
        "ईपीजी"
    ],
    "EPG Error": [
        null,
        "ईपीजी एरर"
    ],
    "Easy Scan": [
        null,
        "ईज़ी स्कैन"
    ],
    "Education": [
        null,
        "शिक्षा"
    ],
    "End Freq: ": [
        null,
        "एंड फ्रीक्वेंसी"
    ],
    "English": [
        null,
        "अंग्रेज़ी"
    ],
    "Enhance your experience ": [
        null,
        "अपने अनुभव को और बेहतर बनायें। "
    ],
    "Enter current pin code": [
        null,
        "वर्तमान पिन कोड डालें"
    ],
    "Enter new pin code": [
        null,
        "नया पिन कोड डालें"
    ],
    "Enter pin code": [
        null,
        "पिन कोड डालें"
    ],
    "Entertainment": [
        null,
        "मनोरंजन"
    ],
    "Error": [
        null,
        "एरर"
    ],
    "Error when trying to connect to Alpha Networks backend.": [
        null,
        "अल्फा नेटवर्क बैकएंड से संपर्क स्थापित नहीं हो पा रहा है "
    ],
    "Exit": [
        null,
        "बाहर जाएं"
    ],
    "Factory Reset": [
        null,
        "फैक्ट्री रीसेट"
    ],
    "Factory Setting Confirmation": [
        null,
        "फैक्ट्री रिसेट की पुष्टि"
    ],
    "Family & Devotional": [
        null,
        "पारिवारिक व धार्मिक"
    ],
    "Fast Forward": [
        null,
        "फास्ट फ़ॉरवर्ड"
    ],
    "Fast Rewind": [
        null,
        "फास्ट रिवाइंड"
    ],
    "Favorite Add": [
        null,
        "फेवरेट में जोड़ें"
    ],
    "Favorite Remove": [
        null,
        "फेवरेट से हटाएँ"
    ],
    "Favorite channels": [
        null,
        "फेवरेट चैनल"
    ],
    "Favourite List Mode": [
        null,
        "फेवरेट सूची मोड"
    ],
    "Favourites": [
        null,
        "फेवरेट"
    ],
    "Feb": [
        null,
        "फरवरी"
    ],
    "February": [
        null,
        "फरवरी"
    ],
    "Finish": [
        null,
        "समाप्त"
    ],
    "First Install, Sw Update": [
        null,
        "पहली बार इंस्टॉल, सॉफ्टवेयर अपडेट"
    ],
    "For any assistance, call us on:": [
        null,
        "हमें किसी भी प्रकार की सहायता के लिए कॉल करें:"
    ],
    "For resolving no access/unsubscribed channel/card refresh errors:": [
        null,
        "चैनल लिस्ट रिफ्रेश करें:"
    ],
    "Force Software Update": [
        null,
        "प्रभावी सॉफ्टवेयर अपडेट"
    ],
    "Forgot to recharge! Give a Missed Call on \n1800 274 9050 to get your channels NOW. \nPay in next 3 days to enjoy NON STOP TV.": [
        null,
        "मदद के लिए रजिस्टर्ड मोबाइल नंबर से 57575 पर CALLME एसएमएस करें।"
    ],
    "Format HDD": [
        null,
        "हार्ड डिस्क फॉर्मेट"
    ],
    "Format Hard Disk": [
        null,
        "हार्ड डिस्क फॉर्मेट करें"
    ],
    "Formatting disk, please wait…": [
        null,
        "डिस्क फॉर्मेट हो रही है, कृपया प्रतीक्षा करें"
    ],
    "Free size: ": [
        null,
        "उपलब्ध क्षमता:"
    ],
    "French": [
        null,
        "फ्रेंच"
    ],
    "Fri": [
        null,
        "शुक्र"
    ],
    "Friday": [
        null,
        "शुक्रवार"
    ],
    "Give a missed call on 1800 274 9511 from your or SMS CALLME to 57575 from your Registered Mobile Number (RMN).": [
        null,
        "1800-274-9511 पर एक मिस्ड कॉल दें या अपने रजिस्टर्ड मोबाइल नंबर से 57575 पर CALLME एस.एम.एस करें।"
    ],
    "Guarani": [
        null,
        "गुआरानी"
    ],
    "Gujarati": [
        null,
        "गुजराती"
    ],
    "HD Channels": [
        null,
        "एचडी (HD) चैनल"
    ],
    "HDD size: ": [
        null,
        "एचडीडी की क्षमता:"
    ],
    "HDMI Settings": [
        null,
        "एचडीएमआई (HDMI) सेटिंग्स"
    ],
    "HDMI resolution": [
        null,
        "एचडीएमआई (HDMI)  रसोलूशन "
    ],
    "Hindi": [
        null,
        "हिन्दी"
    ],
    "Home Transponder:": [
        null,
        "होम ट्रांसपॉडर:"
    ],
    "Hours:": [
        null,
        "समय:"
    ],
    "IF2IF MODE": [
        null,
        "आईएफ2आईएफ (IF2IF) मोड"
    ],
    "IF2IF OFF": [
        null,
        "IF2IF ऑफ"
    ],
    "IF2IF ON": [
        null,
        "IF2IF ऑन"
    ],
    "IF2IF mode": [
        null,
        "आईएफ2आईएफ (IF2IF) मोड"
    ],
    "IN CASE OF HEAVY RAIN, WAIT TILL RAIN STOPS TO REGAIN SIGNAL": [
        null,
        "यदि मौसम साफ है लेकिन सिग्नल की समस्या जारी है, तो अपना सेट-टॉप-बॉक्स बंद करें, सभी केबल कनेक्शन जाँचें और फिर बॉक्स ऑन करें।"
    ],
    "If already recharged, please, switch-off & switch-on your Set-Top-Box from the mains and keep it ON for 15 minutes on channel 99": [
        null,
        "अपना अकाउंट अपडेट करने के लिए सेट-टॉप बॉक्स को मुख्य पावर से ऑफ/ऑन करें।"
    ],
    "If problem continues, SMS DISHTV 301 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "यदि समस्या बनी रहे तो 1860-258-3474 पर कॉल करें या अपने रजिस्टर्ड मोबाइल नम्बर से 57575 पर CALLME एसएमएस करें।"
    ],
    "If problem continues, SMS DISHTV 302 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "यदि समस्या बनी रहे तो 1860-258-3474 पर कॉल करें या अपने रजिस्टर्ड मोबाइल नम्बर से 57575 पर CALLME एसएमएस करें।"
    ],
    "Impossible to create a record, please set a valid date/time in the future.": [
        null,
        "रिकॉर्ड संभव नहीं है, कृपया भविष्य की एक सही तिथि और समय सेट करें।"
    ],
    "Impossible to remove a channel from favorite while currently browsing Favorite List": [
        null,
        "फेवरेट सूची ब्राउज़ करने के दौरान फेवरेट चैनल को डिलीट करना संभव नहीं है। "
    ],
    "In order to give you the state of the Transponder we need to stop the records.": [
        null,
        "ट्रांसपोंडर की जानकारी देने के लिए हमें आपकी रिकॉर्डिंग्स रोकनी होंगी। "
    ],
    "India (GMT +05:30)": [
        null,
        "भारत (GMT +05:30)"
    ],
    "Informations": [
        null,
        "जानकारियां"
    ],
    "Installation": [
        null,
        "इंस्टालेशन "
    ],
    "Instant Message": [
        null,
        "इंस्टेंट मैसेज "
    ],
    "Insufficient Disk Space": [
        null,
        "डिस्क में पर्याप्त जगह नहीं  है"
    ],
    "Interface Version:": [
        null,
        "इंटरफ़ेस संस्करण:"
    ],
    "Interface version:": [
        null,
        "इंटरफ़ेस संस्करण:"
    ],
    "Invalid date": [
        null,
        "अमान्य तिथि"
    ],
    "Jan": [
        null,
        "जनवरी"
    ],
    "January": [
        null,
        "जनवरी"
    ],
    "Jul": [
        null,
        "जुलाई"
    ],
    "July": [
        null,
        "जुलाई"
    ],
    "Jun": [
        null,
        "जून"
    ],
    "June": [
        null,
        "जून"
    ],
    "Kannada": [
        null,
        "कन्नड़"
    ],
    "Kids & Infotainment": [
        null,
        "किड्स व इंफोटेनमेंट"
    ],
    "LNB Hi Frequency:": [
        null,
        "एलएनबी (LNB) फ्रीक्वेंसी:"
    ],
    "LNB Low Frequency:": [
        null,
        "एलएनबी (LNB) फ्रीक्वेंसी:"
    ],
    "LNB Power:": [
        null,
        "एलएनबी (LNB) पॉवर:"
    ],
    "LNB settings": [
        null,
        "एलएनबी (LNB) सेटिंग्स"
    ],
    "Language": [
        null,
        "भाषा"
    ],
    "Language:": [
        null,
        "भाषा:"
    ],
    "Last Payment details:": [
        null,
        "अंतिम भुगतान विवरण:"
    ],
    "Latin": [
        null,
        "लैटिन"
    ],
    "Launch": [
        null,
        "लॉन्च"
    ],
    "Launch a scan": [
        null,
        "स्कैन शुरू करें"
    ],
    "Leisure hobbies": [
        null,
        "फुर्सत के पलों में"
    ],
    "Letter Box": [
        null,
        "लेटर बॉक्स"
    ],
    "MEDIACENTER": [
        null,
        "मीडिया सेंटर"
    ],
    "MOD": [
        null,
        "स्पेशल्स"
    ],
    "Mac adress isn't valid.": [
        null,
        "मैक एड्रेस मान्य नहीं है। "
    ],
    "Magahi": [
        null,
        "मगही"
    ],
    "Malayalam": [
        null,
        "मलयालम"
    ],
    "Manage favorites": [
        null,
        "फेवरेट चैनल मैनेज करें"
    ],
    "Mar": [
        null,
        "मार्च"
    ],
    "Marathi": [
        null,
        "मराठी"
    ],
    "March": [
        null,
        "मार्च"
    ],
    "Master Reset": [
        null,
        "मास्टर रीसेट"
    ],
    "May": [
        null,
        "मई"
    ],
    "Media center": [
        null,
        "मीडिया सेंटर"
    ],
    "Mediaplayer Error": [
        null,
        "मीडिया प्लेयर एरर"
    ],
    "Middleware Version:": [
        null,
        "मिडिलवेयर संस्करण:"
    ],
    "Mon": [
        null,
        "सोम"
    ],
    "Monday": [
        null,
        "सोमवार"
    ],
    "Movie": [
        null,
        "फिल्में"
    ],
    "Movies": [
        null,
        "फिल्में"
    ],
    "Music": [
        null,
        "संगीत "
    ],
    "Music & Lifestyle": [
        null,
        "म्यूज़िक व लाइफस्टाइल"
    ],
    "My Account": [
        null,
        "मेरा अकाउंट"
    ],
    "My DishTV": [
        null,
        "मेरा डिश टीवी"
    ],
    "My Recordings": [
        null,
        "मेरी रिकॉर्डिंग्स"
    ],
    "NO": [
        null,
        "वापस जाएं"
    ],
    "NO SIGNAL DETECTED": [
        null,
        "सिग्नल उपलब्ध नहीं है"
    ],
    "NTSC": [
        null,
        "एनटीएससी(NTSC)"
    ],
    "Network": [
        null,
        "नेटवर्क"
    ],
    "Network Selection": [
        null,
        "नेटवर्क की जानकारी"
    ],
    "Network information": [
        null,
        "नेटवर्क की जानकारी"
    ],
    "News": [
        null,
        "न्यूज़"
    ],
    "News & Business": [
        null,
        "न्यूज़ व बिज़नेस"
    ],
    "Next": [
        null,
        "आगे जाएं"
    ],
    "No": [
        null,
        "वापस जाएं"
    ],
    "No CAM Module": [
        null,
        "कैम मॉड्यूल नहीं है। "
    ],
    "No Channels": [
        null,
        "चैनल उपलब्ध नहीं"
    ],
    "No Channels Available": [
        null,
        "चैनल्स उपलब्ध नहीं"
    ],
    "No Services": [
        null,
        "कोई सर्विस उपलब्ध नहीं है"
    ],
    "No TV recordings available": [
        null,
        "कोई टीवी रिकॉर्डिंग उपलब्ध नहीं है"
    ],
    "No USB Device connected. Connect USB Device to use Recorder features": [
        null,
        "कोई भी यूएसबी डिवाइस कनेक्ट नहीं की गयी है। रिकार्डिंग करने के लिए कृपया यूएसबी डिवाइस लगाएं।"
    ],
    "No applications found.": [
        null,
        "कोई भी ऐप्लिकेशन नहीं मिली "
    ],
    "No channel": [
        null,
        "चैनल उपलब्ध नहीं"
    ],
    "No channels available, perform a scan, press back to exit": [
        null,
        "चैनल उपलब्ध नहीं, स्कैन करें,मेन्यू से बाहर निकलने के लिए BACK दबाएं"
    ],
    "No information": [
        null,
        "कोई जानकारी नहीं"
    ],
    "No internet connection.": [
        null,
        "इंटरनेट कनेक्शन उपलब्ध नहीं है। "
    ],
    "No services available. Perform a scan.": [
        null,
        "कोई सर्विस उपलब्ध नहीं है। कृपया स्कैन करें। "
    ],
    "None (default)": [
        null,
        "कोई भी नहीं (मूल सेटिंग)"
    ],
    "Not Connected": [
        null,
        "कनेक्ट नहीं की गयी है"
    ],
    "Not able to launch application/game": [
        null,
        "यह एप्लीकेशन अभी लांच नहीं की जा सकती। कृपया पुनः प्रयास करें।"
    ],
    "Nov": [
        null,
        "नवंबर"
    ],
    "November": [
        null,
        "नवंबर"
    ],
    "Number of sessions:": [
        null,
        "सेशन संख्या:"
    ],
    "OK": [
        null,
        "OK"
    ],
    "Oct": [
        null,
        "अक्टूबर"
    ],
    "October": [
        null,
        "अक्टूबर"
    ],
    "Ok": [
        null,
        "OK"
    ],
    "Ok ": [
        null,
        "ओके "
    ],
    "One Time": [
        null,
        "एकबार"
    ],
    "Order an A-La-Carte pack:": [
        null,
        "एड-ऑन पैक आर्डर करें:"
    ],
    "Order by Channel Name": [
        null,
        "चैनल के नाम के अनुसार"
    ],
    "Order by Channel Name - CAS Only": [
        null,
        "चैनल के नाम से आदेश - केवल सीएएस (CAS)"
    ],
    "Order by Channel Name - FTA Only": [
        null,
        "चैनल के नाम से क्रम में लगाएं - केवल एफटीए"
    ],
    "Order by LCN": [
        null,
        "चैनल नंबर के अनुसार"
    ],
    "Order now at a SPECIAL PRICE!": [
        null,
        "स्पेशल कीमत पर आर्डर करने के लिए "
    ],
    "Ordering": [
        null,
        "क्रम में लगाएं"
    ],
    "Oriya": [
        null,
        "उड़िया"
    ],
    "PAL": [
        null,
        "पीएएल(PAL)"
    ],
    "PINs do not match.": [
        null,
        "पिन मेल नहीं खा रहे हैं"
    ],
    "PM": [
        null,
        "पूर्वाहन"
    ],
    "PVR & TS": [
        null,
        "पर्सनल वीडियो रिकॉर्डर (पीवीआर)और ट्रांस्पोर्ट स्ट्रीम (टीएस)"
    ],
    "Panjabi": [
        null,
        "पंजाबी"
    ],
    "Parental Control": [
        null,
        "अभिभावकीय नियंत्रण"
    ],
    "Parental Control Settings": [
        null,
        "अभिभावकीय नियंत्रण सेटिंग"
    ],
    "Pause": [
        null,
        "पॉज़"
    ],
    "Pillar Box": [
        null,
        "पिल्लर बॉक्स"
    ],
    "Play": [
        null,
        "चलाएं"
    ],
    "Please Plug-in CAM to view CAM Menu.": [
        null,
        "कैम मेनू देखने के लिए कृपया कैम प्लग-इन करें"
    ],
    "Please Plugin USB Device Properly": [
        null,
        "कृपया यूएसबी डिवाइस को ठीक से प्लग-इन करें।"
    ],
    "Please RECHARGE YOUR DISHTV VC No {vcNum} \nLog on www.dishtv.in use Credit/Debit card walk into: Nearest Recharge Outlet": [
        null,
        "VC नंबर {vcNum} का रिचार्ज बकाया है\nकिसी भी डिश टीवी डीलर के पास जाकर रिचार्ज कराएं या dishtv.in पर जाएँ"
    ],
    "Please Select Network:": [
        null,
        "कृपया एफईसी (FEC) सेलेक्ट करे:"
    ],
    "Please Wait ...": [
        null,
        "कृपया प्रतीक्षा करें ..."
    ],
    "Please check your antenna cable": [
        null,
        "अपने एंटेना का केबल जाँच लें।"
    ],
    "Please check your subscription": [
        null,
        "कृपया अपना सब्सक्रिप्शन जाँच लें।"
    ],
    "Please choose a Filter": [
        null,
        "कृपया फिल्टर का चयन करें"
    ],
    "Please choose a language": [
        null,
        "कृपया भाषा का चयन करें"
    ],
    "Please ensure that your set-Top-Box is properly connected to the DISHTV antenna": [
        null,
        "यह भारी बारिश या खराब मौसम के कारण हो सकता है\nमौसम साफ होने तक प्रतीक्षा करें।"
    ],
    "Please enter PIN to select IF2IF mode, this will launch scan and it will delete your recording and favourite list.": [
        null,
        "IF2IF मोड का चयन करने के लिए कृपया पिन दर्ज करें। यह स्कैन लॉन्च करेगा और यह आपकी रिकॉर्डिंग और फेवरेट सूची को हटा देगा।"
    ],
    "Please enter Symbol rate:": [
        null,
        "कृपया सिंबल रेट एंटर करें:"
    ],
    "Please select FEC:": [
        null,
        "कृपया एफईसी (FEC) सेलेक्ट करे:"
    ],
    "Please select Polarization:": [
        null,
        "कृपया पोलराइज़ेशन सेलेक्ट करे:"
    ],
    "Please wait while the USB connection is being established": [
        null,
        "कनेक्शन स्थापित किया जा रहा है, कृपया प्रतीक्षा करें।"
    ],
    "Please, POWER OFF – POWER ON your Set-Top-Box from switch.": [
        null,
        "कृपया सेट-टॉप-बॉक्स को मुख्य पावर से बंद करके फिर से ऑन करें"
    ],
    "Press \"OK\" on your remote to re-install channels and services. \nIf problem continues, SMS DISHTV 303 to 57575 from your registered Mobile Number (RMN). To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "अपनी चैनल सूची को पुनःस्थापित करने के लिए कृपया अपने रिमोट पर स्थित OK बटन दबाएँ\nयदि समस्या बनी रहे तो, 1860-258-3474 पर कॉल करें या अपने रजिस्टर्ड मोबाइल नंबर से 57575 पर CALLME एसएमएस करें । "
    ],
    "Press BACK to save & exit or OK for details": [
        null,
        "वापस जाने के लिए BACK और विवरण के लिए OK दबाएं"
    ],
    "Press Back for STB InfoSheet": [
        null,
        "एसटीबी संबंधी जानकारी पर लौटने के लिए BACK दबाएं"
    ],
    "Press Back for Tools": [
        null,
        "एसटीबी संबंधी जानकारी पर लौटने के लिए BACK दबाएं"
    ],
    "Press Back to exit from active service": [
        null,
        "बाहर निकलने के लिए BACK दबाएं"
    ],
    "Press Menu to Exit": [
        null,
        "बाहर निकलने के लिए मेन्यू दबाएं"
    ],
    "Press OK for details": [
        null,
        "विवरण के लिए OK दबाएं"
    ],
    "Press OK to Save my schedule": [
        null,
        "अपना शेड्यूल सेव करने के लिए OK दबाएं"
    ],
    "Press OK to confirm": [
        null,
        "चुनने के लिए OK दबाएं"
    ],
    "Press OK to exit": [
        null,
        "बाहर निकलने के लिए OK दबाएं"
    ],
    "Press OK to launch EASY SCAN": [
        null,
        "ईज़ी स्कैन शुरु करने के लिए OK दबाएं"
    ],
    "Punjabi": [
        null,
        "पंजाबी"
    ],
    "RECORDS": [
        null,
        "रिकार्ड्स"
    ],
    "Radios": [
        null,
        "रेडियो"
    ],
    "Rajasthani": [
        null,
        "राजस्थानी"
    ],
    "Rec": [
        null,
        "रिकॉर्ड"
    ],
    "Recharge Reminder": [
        null,
        "रिचार्ज अलर्ट"
    ],
    "Record": [
        null,
        "रिकॉर्ड"
    ],
    "Recording  can't be done because The {channelTitle} doesn't have any program information": [
        null,
        "रिकॉर्डिंग संभव नहीं है क्योंकि {channelTitle} पर कार्यक्रम संबंधी सूचना नहीं है।"
    ],
    "Recording Alert": [
        null,
        "रिकार्डिंग संबंधी सूचना"
    ],
    "Recording Alert: Record Vs Reminder": [
        null,
        "रिकार्डिंग सूचना : रिकॉर्ड एंड रिमाइंडर "
    ],
    "Recording Conflict": [
        null,
        "रिकॉर्डिंग संबंधी समस्या"
    ],
    "Recording failed": [
        null,
        "रिकॉर्डिंग असफल"
    ],
    "Recording features are not authorized on this channel": [
        null,
        "इस चैनल पर रिकार्डिंग की सुविधा उपलब्ध नहीं है"
    ],
    "Recording in progress": [
        null,
        "रिकॉर्डिंग जारी है।"
    ],
    "Recording in progress. \nPress OK to stop record and continue. \n Press BACK to close the message and return to the live stream.": [
        null,
        "रिकॉर्डिंग जारी है। \nरिकॉर्ड को रोकने और जारी रखने के लिए OK दबाएं। \nसंदेश बंद करने और लाइव स्ट्रीम पर वापस लौटने के लिए BACK दबाएं।"
    ],
    "Recording in progress. If you continue you will lose your record.": [
        null,
        "रिकॉर्डिंग जारी है। चैनल बदलने से रिकॉर्डिंग बंद हो जाएगी। "
    ],
    "Recording is not possible on past event.": [
        null,
        "अतीत के कार्यक्रम की रिकॉर्डिंग संभव नहीं है। "
    ],
    "Recurrence:": [
        null,
        "पुनरावृत्ति"
    ],
    "Regional": [
        null,
        "क्षेत्रीय"
    ],
    "Regional Hindi": [
        null,
        "क्षेत्रीय हिंदी"
    ],
    "Register your Mobile No.:": [
        null,
        "अपना मोबाइल नंबर रजिस्टर करें:"
    ],
    "Reminder": [
        null,
        "रीमाइंडर"
    ],
    "Reminder Alert": [
        null,
        "रीमाइंडर अलर्ट"
    ],
    "Reminder Conflict": [
        null,
        "रिकॉर्डिंग संबंधी समस्या"
    ],
    "Reminder can't be applied as program has no information.": [
        null,
        "रीमाइंडर को लागू नहीं किया जा सकता क्योंकि कार्यक्रम में कोई जानकारी नहीं है"
    ],
    "Reminder or Recording is already set for this Program": [
        null,
        "इस प्रोग्राम के लिए रिमाइंडर या रिकॉर्डिंग पहले से ही सेट है"
    ],
    "Reset": [
        null,
        "रीसेट करें"
    ],
    "Reset Setting Confirmation": [
        null,
        "रीसेट सेटिंग कन्फर्मेशन"
    ],
    "Reset favorites": [
        null,
        "अपने फेवरेट्स रीसेट करें"
    ],
    "Resume playback": [
        null,
        "पुनः प्रारंभ करें"
    ],
    "Retrieving active service, please wait.": [
        null,
        "आपकी एक्टिव सर्विसेज लोड हो रहीं हैं। कृपया प्रतीक्षा करें।"
    ],
    "Return to STB InfoSheet": [
        null,
        "वापस एसटीबी संबंधी जानकारी पर लौटे"
    ],
    "SCRAMBLED CHANNEL": [
        null,
        "स्क्रैम्ब्लड चैनल"
    ],
    "SELECT GENRE": [
        null,
        "श्रेणी चुनें"
    ],
    "SMS DISHTV CALL ME to 57575 from your registered mobile number (RMN).": [
        null,
        "किसी भी समस्या के लिए 1860-258-3474 पर कॉल करें या अपने RMN से 57575 पर CALLME एसएमएस करें"
    ],
    "SMS MOD {vcNum} {PurchaseCode} to 57575. If you do not get the movie with in 10 minutes after sending ": [
        null,
        "ऑर्डर करने के लिए 57575 पर MOD {vcNum} {PurchaseCode} एसएमएस करें"
    ],
    "SMS Services": [
        null,
        "एसएमएस सेवाएं"
    ],
    "SMS: DISHTV ADD {channelNum} to 57575 \nfrom your Registered Mobile Number": [
        null,
        "चैनल/पैक के मूल्य की जानकारी के लिए dishtv.in पर जाएँ।"
    ],
    "STB Info Sheet": [
        null,
        "एसटीबी की जानकारी"
    ],
    "STB InfoSheet": [
        null,
        "एसटीबी की जानकारी"
    ],
    "STB Information": [
        null,
        "सेट-टॉप-बॉक्स संबंधी जानकारी"
    ],
    "STB No": [
        null,
        "एसटीबी नंबर:"
    ],
    "STB No:": [
        null,
        "एसटीबी नंबर:"
    ],
    "Sat": [
        null,
        "शनि"
    ],
    "Satellite": [
        null,
        "सेटेलाइट"
    ],
    "Saturday": [
        null,
        "शनिवार"
    ],
    "Save & Exit": [
        null,
        "सेव करें और बाहर जाएं"
    ],
    "Scan Ongoing": [
        null,
        "स्कैन चल रहा है "
    ],
    "Schedule Your Recording": [
        null,
        "रिकॉर्डिंग शेड्यूल करें"
    ],
    "Screen Adjustment": [
        null,
        "स्क्रीन समायोजन"
    ],
    "Security client ID:": [
        null,
        "सिक्योरिटी क्लाइंट आईडी:"
    ],
    "Security client version:": [
        null,
        "सिक्योरिटी क्लाइंट संस्करण:"
    ],
    "Self-help": [
        null,
        "मदद "
    ],
    "Sep": [
        null,
        "सितंबर"
    ],
    "September": [
        null,
        "सितंबर"
    ],
    "Serie": [
        null,
        "सीरीज़ (श्रृंखला)"
    ],
    "Set Reminder": [
        null,
        "रीमाइंडर सेट करें"
    ],
    "Settings": [
        null,
        "सेटिंग्स"
    ],
    "Should your services not restart in 15 minutes, \nSMS DISHTV REFRESH to 57575 \nfrom your registred Mobile Number": [
        null,
        "यदि 15 मिनट में सेवा शुरू नहीं हुई, तो अपने रजिस्टर्ड मोबाइल नंबर से 1800-270-2102 पर मिस्ड कॉल दें"
    ],
    "Show": [
        null,
        "कार्यक्रम"
    ],
    "Social/Politics": [
        null,
        "सामाजिक/राजनीतिक"
    ],
    "Sorry this action is not permitted with a CAM, remove it and switch off switch on your box in order to use this feature.": [
        null,
        "कैम मॉड्यूल के रहते इस कार्रवाई की अनुमती नहीं है। इस सुविधा का उपयोग करने के लिए कैम मॉड्यूल को हटाएँ तथा अपने सेट टॉप बॉक्स को ऑफ करके दोबारा ऑन करें। "
    ],
    "Sports": [
        null,
        "खेल"
    ],
    "SriLanka (GMT +05:30)": [
        null,
        "श्रीलंका (GMT +05:30)"
    ],
    "Start Freq: ": [
        null,
        "स्टार्ट फ्रीक्वेंसी "
    ],
    "Start Scan": [
        null,
        "स्कैन शुरू करें"
    ],
    "Stop": [
        null,
        "रोकें"
    ],
    "Stop & save": [
        null,
        "रोकें और सेव करें"
    ],
    "Stop Record": [
        null,
        "रिकॉर्डिंग रोकें"
    ],
    "Subscribe to this channel in HD picture \nquality along with {noOfHdChannels} more HD channels \nat  Rs. {priceTag} per month.": [
        null,
        "सब्सक्राइब करने लिए अपने रजिस्टर्ड मोबाइल नंबर से 57575 पर DISHTV GET {channelNum} SMS करें।"
    ],
    "Subscription Information": [
        null,
        "सब्सक्रिप्शन की जानकारी "
    ],
    "Subtitles": [
        null,
        "सबटाइटल्स"
    ],
    "Sun": [
        null,
        "रवि"
    ],
    "Sunday": [
        null,
        "रविवार"
    ],
    "Switch off date:": [
        null,
        "स्विच ऑफ तिथि:"
    ],
    "Switch to HD Now for ultra-clear picture quality and 5.1 surround sound": [
        null,
        "बेहतर पिक्चर व ऑडियो क्वालिटी के लिए HD बॉक्स अपनाएं।"
    ],
    "System Information": [
        null,
        "सिस्टम की जानकारी"
    ],
    "System information": [
        null,
        "सिस्टम की जानकारी"
    ],
    "TP Info": [
        null,
        "ट्रांसपॉन्डर संबंधी सूचना"
    ],
    "TP list screen": [
        null,
        "ट्रांसपॉडर लिस्ट "
    ],
    "TV": [
        null,
        "टीवी"
    ],
    "TV Channels": [
        null,
        "टीवी चैनल्स"
    ],
    "TV Guide": [
        null,
        "टीवी गाइड"
    ],
    "TV Type": [
        null,
        "टीवी के स्वरूप "
    ],
    "TV type": [
        null,
        "टीवी का प्रकार"
    ],
    "TV: {tvFound}     Radios: {radioFound}      Network: {networkFound}": [
        null,
        "टीवी चैनल्स: {tvFound}    रेडियो चैनल्स :  {radioFound}    नेटवर्क: {networkFound}"
    ],
    "Tamil": [
        null,
        "तमिल"
    ],
    "Telugu": [
        null,
        "तेलुगू"
    ],
    "The STB is not able to format the connected USB device. Use Another device": [
        null,
        "सेट-टॉप-बॉक्स यूएसबी डिवाइस को फॉर्मेट करने में सक्षम नहीं है। अन्य डिवाइस का प्रयोग करें"
    ],
    "The Sw version details are not provided, System can’t verify if a new Sw version is available": [
        null,
        "सॉफ्टवेयर संस्करण संबंधी जानकारी उपलब्ध नहीं है। सिस्टम नए सॉफ्टवेयर संस्करण की उपलब्धता सत्यापित करने में असमर्थ है। "
    ],
    "The program {scheduleTitle} can't be recorded because no compliant USB device connected.": [
        null,
        "यह कार्यक्रम {scheduleTitle} रिकॉर्ड नहीं किया जा सकता क्योंकि इस फीचर को सपोर्ट करने वाली यूएसबी डिवाइस कनेक्ट नहीं है।"
    ],
    "The signal to your Set-Top-Box is temporarily unavailable.": [
        null,
        "आपके सेट-टॉप-बॉक्स से कनेक्शन उपलब्ध नहीं है।"
    ],
    "The size of the connected USB Device is not enough to enable Recorder features. Please insert a USB Device with minimum 1GB capacity.": [
        null,
        "यूएसबी डिवाइस की क्षमता रिकॉर्डर सुविधाओं का उपयोग करने के लिए पर्याप्त नहीं है। कृपया न्यूनतम 1 जीबी क्षमता की यूएसबी डिवाइस कनेक्ट करें"
    ],
    "There is a TV recording in progress. You cannot access to radio universe": [
        null,
        "टीवी रिकॉर्डिंग जारी है। आप रेडियो यूनिवर्स ऐक्सेस नहीं कर सकते।"
    ],
    "This Channel Is Blocked": [
        null,
        "इस चैनल को ब्लॉक कर दिया गया है"
    ],
    "This channel is available in High Definition.": [
        null,
        "आपने यह एचडी चैनल सब्सक्राइब नहीं किया है।"
    ],
    "This program can't be recorded because another TV recording is planned at the same time on {channelName} starting at {startDate}.": [
        null,
        "इस कार्यक्रम को रिकॉर्ड नहीं किया जा सकता क्योंकि {startDate} को {channelName} पर समान समय पर एक अन्य रिकॉर्डिंग प्लान की गई है।"
    ],
    "Thu": [
        null,
        "गुरू"
    ],
    "Thursday": [
        null,
        "गुरूवार"
    ],
    "Time Format": [
        null,
        "समय प्रारूप"
    ],
    "Time Settings": [
        null,
        "टाइम सेटिंग्स"
    ],
    "Time Zone Format": [
        null,
        "टाइम ज़ोन का प्रारूप"
    ],
    "Timeshift & PVR feature will not work": [
        null,
        "टाइमशिफ्ट और पर्सनल वीडियो रिकॉर्डिंग (पीवीआर) की सुविधा काम नहीं करेगी।"
    ],
    "To RMN SMS DISHTV RMN {vcNum} to 57575": [
        null,
        "अपने मोबाइल नम्बर को रजिस्टर करने के लिए,\n57575 पर DISHTV RMN {vcNum} एसएमएस करें।"
    ],
    "To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "अपने मोबाइल नम्बर को रजिस्टर करने के लिए,\n57575 पर DISHTV RMN {vcNum} एसएमएस करें।"
    ],
    "To Register your Mobile Number, \nSMS: DISHTV RMN {vcNum} to 57575": [
        null,
        "अपने मोबाइल नम्बर को रजिस्टर करने के लिए,\n57575 पर DISHTV RMN {vcNum} एसएमएस करें।"
    ],
    "To Register your Mobile Number, SMS: \nDISHTV RMN {vcNum} to 57575": [
        null,
        "अपना मोबाइल नंबर रजिस्टर करने के लिए, एसएमएस करें\nDISHTV RMN {vcNum} और 57575 पर उसे भेज दें।"
    ],
    "To allow timely updation, after ordering a \nchannel, please switch-off & switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channnel 99 for 15 minutes.": [
        null,
        "चैनल को सब्सक्राइब करने के बाद समय से अपडेट करने के लिए कृपया मुख्य पॉवर स्विच से सेट टॉप बॉक्स को बंद करके इसे दोबारा चालू कर 15 मिनट तक चैनल 96 पर रखें।"
    ],
    "To get a call from us just SMS:": [
        null,
        "हमारी ओर से कॉल प्राप्त करने के लिए एसएमएस करें: "
    ],
    "To order {EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}": [
        null,
        "नवीनतम ब्लॉक-बस्टर फिल्में देखें\nअभी प्रसारित हो रही है: {EventName}\nकीमत: (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm})\nमूवी कोड: {PurchaseCode}"
    ],
    "To subscribe this channel, \nSMS: DISHTV GET {channelNum} to 57575 \nFrom your Registered Mobile Number (RMN)": [
        null,
        "इस चैनल को सब्सक्राइब करने के लिए अपने रजिस्टर्ड मोबाइल नम्बर (आरएमएन) से  1860-258-3474\nपर कॉल करें या 57575 पर DISHTV GET {channelNum} एसएमएस करें।"
    ],
    "To update My Account, give a MISSED CALL on 1800-274-4744 from your RMN": [
        null,
        "अपना अकाउन्ट अपडेट करने के लिए, अपने रजिस्टर्ड मोबाइल नम्बर से 1800-274-4744 पर एक मिस्ड कॉल दें "
    ],
    "Tools": [
        null,
        "टूल्स"
    ],
    "Total services found": [
        null,
        "कुल पाई गई सेवाएं"
    ],
    "Total services found: {serviceFound}.": [
        null,
        "कुल पाई गई सेवाएं: {serviceFound}"
    ],
    "Transponder Information": [
        null,
        "ट्रांसपोंडर की जानकारी "
    ],
    "Transponder List": [
        null,
        "ट्रांसपॉडर सूची"
    ],
    "Tue": [
        null,
        "मंगल"
    ],
    "Tuesday": [
        null,
        "मंगलवार"
    ],
    "Tuned channel will be changed if new recording started on this channel.": [
        null,
        "इस चैनल पर नयी रिकॉर्डिंग प्रारंभ करने से ट्यून किया गया चैनल बदल दिया जायेगा।"
    ],
    "USB Device Not Inserted Properly": [
        null,
        "यूएसबी डिवाइस को ठीक से कनेक्ट नहीं किया गया है। "
    ],
    "USB Device Unplugged": [
        null,
        "यूएसबी डिवाइस निकाल ली गयी है"
    ],
    "USB Formatted": [
        null,
        "यूएसबी फॉर्मैटिंग पूरी हो चुकी है"
    ],
    "USB Formatting...": [
        null,
        "यूएसबी फॉर्मैटिंग"
    ],
    "USB disk size not compliant with PVR & TS requirements. Minimal free size to activate = 10Go": [
        null,
        "यूएसबी डिस्क का साइज़ पर्सनल वीडियो रिकॉर्डर (पीवीआर)और ट्रांस्पोर्ट स्ट्रीम (टीएस) के अनुकूल नहीं है। ऐक्टिवेट करने के लिए न्यूनतम 10 GB क्षमता की आव्यशकता है। "
    ],
    "Unable to play this asset.": [
        null,
        "यह फाइल प्ले नहीं की जा सकती"
    ],
    "Unable to play this file. Press BACK or OK key to return to Mediaplayer explorer.": [
        null,
        "यह फाइल प्ले नहीं की जा सकती। मीडिया प्लेयर एक्सप्लोरर में वापस जाने के लिए BACK या OK दबाएं।"
    ],
    "Unable to play this file. Press BACK or OK key to return to Recording.": [
        null,
        "यह फाइल प्ले नहीं की जा सकती। रिकार्डिंग  में वापस जाने के लिए कृपया BACK या OK दबाएं।"
    ],
    "Updates Ongoing....": [
        null,
        "अपडेट चल रहा है...."
    ],
    "Upgrade your pack:": [
        null,
        "पैक अपग्रेड करें:"
    ],
    "Urdu": [
        null,
        "उर्दू"
    ],
    "Usb key has been Unplugged": [
        null,
        "यूएसबी (USB) निकाल ली गयी है"
    ],
    "Usb key successfully formatted": [
        null,
        "यूएसबी की (USB key) की फॉर्मैटिंग पूरी हो चुकी है"
    ],
    "Use Favourites List As Channel List": [
        null,
        "फेवरेट सूची"
    ],
    "Use default list": [
        null,
        "डिफ़ॉल्ट सूची"
    ],
    "Use favourite list": [
        null,
        "फेवरेट सूची"
    ],
    "VC No": [
        null,
        "वीसी नंबर:"
    ],
    "VC No:": [
        null,
        "वीसी नंबर:"
    ],
    "VC Number:": [
        null,
        "वीसी नम्बर:"
    ],
    "VOD Error": [
        null,
        "वीओडी एरर"
    ],
    "Vod catalog loading aborted by user.": [
        null,
        "वीओडी (VOD) को यूजर द्वारा निरस्त किया गया"
    ],
    "Vod initialization aborted.": [
        null,
        "वीओडी को निरस्त किया जाता है "
    ],
    "Watch": [
        null,
        "देखें"
    ],
    "Website:": [
        null,
        "वेबसाइट:"
    ],
    "Wed": [
        null,
        "बुध"
    ],
    "Wednesday": [
        null,
        "बुधवार"
    ],
    "Week Days": [
        null,
        "सोम से शुक्र"
    ],
    "Weekly": [
        null,
        "साप्ताहिक"
    ],
    "Wrong pin code !": [
        null,
        "गलत पिन कोड!"
    ],
    "YES": [
        null,
        "ओके(OK)"
    ],
    "Yes": [
        null,
        "ओके(OK)"
    ],
    "You are now browsing you default channel list .\nPress FAV button to switch to your Favourite Channels list.": [
        null,
        "अब आप अपनी डिफ़ॉल्ट चैनल्स की सूची में हैं। फेवरेट चैनल्स की सूची में जाने के लिए रिमोट पर FAV बटन दबाएं।"
    ],
    "You are now browsing your Favourite Channels list. \n Press Fav button to switch to Default channel list.": [
        null,
        "अब आप अपनी फेवरेट चैनल्स की सूची में हैं। डिफ़ॉल्ट सूची में वापस जाने के लिए रिमोट पर FAV बटन दबाएं।"
    ],
    "You have reached the end of this content.": [
        null,
        "आप इस कंटेंट के अंत तक पहुँच चुके है। "
    ],
    "You will launch a  Reset, All of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "आपके मास्टर रीसेट करने से सभी सेटिंग्स पुनः डीफॉल्ट (Default) मोड में चली जाएंगी। साथ ही यदि कुछ रिकॉर्ड हो रहा होगा तो आप वो भी खो देंगे।"
    ],
    "You will launch a Channel Search that will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it.": [
        null,
        "आप चैनलों की खोज करने जा रहे हैं जिससे आपके मौजूदा चैनलों की सूची और आपके फेवरेट चैनलों की सूची समाप्त हो जाएगी तथा यदि कोई रिकार्डिंग चल रही हो तो वह भी रद्द हो जाएगी।"
    ],
    "You will launch a Factory Reset, Some of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "आप फैक्ट्री रिसेट करने जा रहे हैं। इससे आपके बॉक्स की सेटिंग्स पुनः डीफॉल्ट मोड में चली जाएंगी। साथ ही यदि कुछ रिकॉर्ड हो रहा होगा तो आप वो भी खो देंगे।"
    ],
    "Your Set-Top-Box is being updated, Please wait…": [
        null,
        "आपका सेट-टॉप बॉक्स अपडेट हो रहा है, कृपया प्रतीक्षा कीजिए । "
    ],
    "Your TV will be switched off, today. Recharge immediately to avoid disruption in service.": [
        null,
        "आज आपका टीवी स्विच ऑफ हो जायेगा। सर्विस जारी रखने के लिए तुरंत रिचार्ज करें।"
    ],
    "Your current Set-Top-Box box doesn't support this HD channel": [
        null,
        "आपका सेट-टॉप-बॉक्स एक स्टैंडर्ड डेफिनिशन बॉक्स है और इस हाई-डेफिनिशन चैनल को सपोर्ट नहीं करता है।"
    ],
    "Your pin code has been successfully updated !": [
        null,
        "आपका पिन कोड सफलतापूर्वक अपडेट हो चुका है"
    ],
    "Your program {programName} on channel {channelNum} {channelName} will start at {startHour}. Do you want to tune the channel?": [
        null,
        "{channelNum} {channelName} पर आपका कार्यक्रम  {programName}  {startHour} पर शुरू होगा। क्या आप इस चैनल पर चैनल ट्यून करना चाहते "
    ],
    "Your recharge date is near. Your TV will be switched off in {count} days. Please recharge immediately to avoid disruption in service.": [
        null,
        "आपका रिचार्ज बकाया है। आपका टीवी {count} दिन में स्विच ऑफ हो जायेगा। सर्विस जारी रखने के लिए कृपया तुरंत रिचार्ज करें।"
    ],
    "Youth": [
        null,
        "युवा"
    ],
    "[vod]AssetVoucherCodeMessage": [
        null,
        "[वीओडी]  ऐसेट वाउचर कोड संदेश"
    ],
    "[vod]AssetVoucherCodeTitle": [
        null,
        "[वीओडी] ऐसेट वाउचर कोड टाइटल"
    ],
    "[vod]BuyPackError": [
        null,
        "बाय पैक एरर"
    ],
    "[vod]PackVoucherCodeMessage": [
        null,
        "[वीओडी]  पैक वाउचर कोड संदेश"
    ],
    "[vod]PackVoucherCodeTitle": [
        null,
        "[वीओडी]  पैक वाउचर कोड टाइटल"
    ],
    "[vod]Play": [
        null,
        "[वीओडी] प्ले करें"
    ],
    "[vod]PlayAssetError": [
        null,
        "[वीओडी] प्ले ऐसेट एरर"
    ],
    "[vod]Rent": [
        null,
        "[वीओडी]  रेंट करें"
    ],
    "[vod]RentAssetError": [
        null,
        "[वीओडी]  रेंट ऐसेट एरर"
    ],
    "[vod]VideoLoading": [
        null,
        "[वीओडी] वीडियो लोड हो रहा है"
    ],
    "[vod]VoucherDigitError": [
        null,
        "[वीओडी]  वाउचर डिजिट एरर"
    ],
    "[vod]anCurrency": [
        null,
        "[वीओडी] करेंसी"
    ],
    "[vod]anLanguage": [
        null,
        "[वीओडी] भाषा"
    ],
    "[vod]buyPack": [
        null,
        "[वीओडी] पैक खरीदें"
    ],
    "[vod]loadingTitle": [
        null,
        "[वीओडी] शीर्षक लोड हो रहा है"
    ],
    "authentication status": [
        null,
        "प्रमाणीकरण की स्थिति"
    ],
    "conflicting with": [
        null,
        "टकराव"
    ],
    "dishtv.in": [
        null,
        "www.dishtv.in"
    ],
    "dns1": [
        null,
        "डीएनएस 1"
    ],
    "dns2": [
        null,
        "डीएनएस 1"
    ],
    "failed": [
        null,
        "असफल"
    ],
    "gateway": [
        null,
        "गेटवे"
    ],
    "interface": [
        null,
        "इंटरफेस"
    ],
    "ip_address": [
        null,
        "आईपी एड्रेस"
    ],
    "mac_address": [
        null,
        "मैक_एड्रेस"
    ],
    "malayalam": [
        null,
        "मलयालम"
    ],
    "manipuri": [
        null,
        "मणिपुरी"
    ],
    "nepali": [
        null,
        "नेपाली"
    ],
    "netmask": [
        null,
        "नेटमास्क"
    ],
    "no": [
        null,
        "वापस जाएं"
    ],
    "ok": [
        null,
        "OK"
    ],
    "yes": [
        null,
        "ओके(OK)"
    ],
    "{dateNumber}{nth} {month}": [
        null,
        "{dateNumber}{nth} {month}"
    ],
    "{month} {dateNumber}{nth}": [
        null,
        "{month} {dateNumber}{nth}"
    ],
    "{programName} - ({channelName}) has been started and is scheduled for recording.": [
        null,
        "{programName} - ({channelName}) शुरू किया गया है और रिकॉर्डिंग के लिए तय किया गया है"
    ]
}
,
"locale-mar_MAR":{ 
    "": {
        "Content-Transfer-Encoding": "8bit",
        "Content-Type": "text/plain; charset=UTF-8",
        "Generated-By": "Babel 1.3",
        "Language": "en",
        "Language-Team": "none",
        "Last-Translator": "Automatically generated",
        "MIME-Version": "1.0",
        "PO-Revision-Date": "2018-01-12 19:59+0530",
        "POT-Creation-Date": "2018-06-19 11:08+0530",
        "Project-Id-Version": "PROJECT VERSION",
        "Report-Msgid-Bugs-To": "EMAIL@ADDRESS",
        "X-Generator": "Poedit 1.5.7"
    },
    " 802 – Recording Alert": [
        null,
        "802 - रेकॉर्डिंग अलर्ट"
    ],
    " Soon Recording Functions & Timeshift feature will be available. Retry later.": [
        null,
        "लवकरच रेकॉर्डिंग फंक्शन्स आणि टाइमशफ्ट वैशिष्ट्य उपलब्ध असतील. नंतर पुन्हा प्रयत्न करा."
    ],
    " You have run out of disk space on the connected USB device.Please delete existing recordings to record further.": [
        null,
        "कनेक्ट केलेल्या यूएसबी डिव्हाइसवरील तुमची डिस्क जागा संपली आहे. कृपया पुढील रेकॉर्डिंगसाठी विद्यमान रेकॉर्डिंग हटवा."
    ],
    " from live": [
        null,
        "लाइव्हकडून  "
    ],
    " on ": [
        null,
        "ऑन "
    ],
    " {msg} ": [
        null,
        "{msg}"
    ],
    "101 - Unsubscribed Channel": [
        null,
        "101- अनसबस्क्राईब्ड चॅनल"
    ],
    "102 - Viewing Card (VC) Deactivated": [
        null,
        "102 - व्यूविंग कार्ड (व्हीसी) निष्क्रिय केले"
    ],
    "103 - HD Channel not subscribed": [
        null,
        "103 - एचडी पॅक वर अपग्रेड करा"
    ],
    "106 Software Update": [
        null,
        "106 सॉफ्टवेअर अपडेट"
    ],
    "1860-258-3474 (Local call charges apply)": [
        null,
        "1860-258-3474 (स्थानिक कॉल चार्जेस लागू)"
    ],
    "301 – Signal not found": [
        null,
        "301 - सिग्नल आढळला नाही"
    ],
    "302 - Signal Unavailable": [
        null,
        "302 - सिग्नल अनुपलब्ध"
    ],
    "303 Re-Install Services": [
        null,
        " 303 सेवा रिइन्स्टॉल करा"
    ],
    "5.1 OFF": [
        null,
        "5.1 ऑफ"
    ],
    "5.1 ON": [
        null,
        "5.1 ऑन"
    ],
    "5.1 Setting": [
        null,
        "5.1 ऑडिओ सेटिंग्ज"
    ],
    "501 - Conditional Access": [
        null,
        "501 - सशर्त एक्सेस"
    ],
    "601 - Upgrade to HD Set-Top-Box": [
        null,
        "601 - एचडी सेट-टॉप-बॉक्स मिळवा"
    ],
    "701 – detecting External USB Device…": [
        null,
        "701 - बाह्य यूएसबी डिव्हाइस शोधत आहे ..."
    ],
    "702 - Device Detected": [
        null,
        "702 - डिवाईस शोधले"
    ],
    "702 – New USB Device": [
        null,
        "702 - नवीन यूएसबी डिव्हाइस"
    ],
    "704 – USB device Alert": [
        null,
        "704 - यूएसबी अलर्ट "
    ],
    "706 – USB Device Full": [
        null,
        "706 - यूएसबी डिव्हाइस पूर्ण भरले"
    ],
    "708 - Device Detected": [
        null,
        "708 - डिवाइस आढळले"
    ],
    "709 - Device Detected": [
        null,
        "709 - डिव्हाइस आढळले"
    ],
    "801 - Device Detected": [
        null,
        "801 - डिव्हाइस आढळले"
    ],
    "803 – Recording Alert": [
        null,
        "804 - रेकॉर्डिंग अलर्ट"
    ],
    "806 – Recording Alert": [
        null,
        "806 - रेकॉर्डिंग अलर्ट"
    ],
    "808 – Content Alert": [
        null,
        "808 - सामग्री चेतावणी "
    ],
    "A Record or a Reminder is already scheduled \nfor this channel for the same hour. We can’t take into account your action.": [
        null,
        "एक रेकॉर्ड किंवा रिमाइंडर आधीपासूनच निश्चित आहे\nयाच वेळेत या चॅनलसाठी. तुमची कृती आम्ही हिशेबात घेऊ शकत नाही."
    ],
    "A Software version is available and the Client Software will force the Update.": [
        null,
        "एक सॉफ्टवेअर आवृत्ती उपलब्ध आहे आणि क्लायंट सॉफ्टवेअर अपडेट करण्यास भाग पाडेल."
    ],
    "A TV recording is going to start on channel {channelName} which is not in the favorite list. Default list will be restored and the recorded channel will be displayed. Select 'Cancel' to stay on current service": [
        null,
        "चॅनल {channelName}वर एक टीव्ही रेकॉर्डिंग सुरू होणार आहे जी फेवरिट लिस्टमध्ये नाही. डिफॉल्ट लिस्ट रिस्टोर केली जाईल आणि रेकॉर्ड केलेले चॅनल प्रदर्शित केले जाईल. वर्तमान सेवेवर कायम राहण्यासाठी 'रद्द करा' निवडा"
    ],
    "A TV recording is on-going on channel {channelName} which is not in the favorite list. Recording will be discontinued and Favourite List will be selected. Select 'Cancel' to stay on current service": [
        null,
        "एक टीव्ही रेकॉर्डिंग {channelName} वर चालू आहे, जे फेवरिट लिस्टमध्ये नाही. रेकॉर्डिंग बंद केले जाईल आणि फेवरिट लिस्ट निवडली जाईल. वर्तमान सेवेवर कायम राहण्यासाठी 'रद्द करा' निवडा"
    ],
    "A new USB Device has been detected. OK to start format. All data in the disk will be lost": [
        null,
        "नवीन यूएसबी डिवाईस आढळले. फॉर्मॅट करण्यासाठी ओके करा. डिस्कमधील सर्व डेटा मिटेल"
    ],
    "A recording is going on, changing the channel shall discard the current recording.": [
        null,
        "एक रेकॉर्डिंग चालू आहे, चॅनल बदलल्यास सध्याचे रेकॉर्डिंग नाहीसे होईल."
    ],
    "AM": [
        null,
        "एएम "
    ],
    "Active Services": [
        null,
        "सक्रिय सेवा "
    ],
    "Add a manual recording": [
        null,
        "मॅन्युअल रेकॉर्डिंग जोडा   "
    ],
    "Advanced Setting Screen": [
        null,
        "प्रगत सेटिंग स्क्रीन"
    ],
    "All Channels": [
        null,
        "सर्व चॅनल्स"
    ],
    "Antenna settings": [
        null,
        "अँटेना सेटिंग्ज"
    ],
    "App store": [
        null,
        "एप स्टोअर"
    ],
    "Apps": [
        null,
        "एप्स "
    ],
    "Apr": [
        null,
        "एप्रि"
    ],
    "April": [
        null,
        "एप्रिल "
    ],
    "Arts/Culture": [
        null,
        "कला/संस्कृती"
    ],
    "Assamese": [
        null,
        "आसामी"
    ],
    "Assamese/North East": [
        null,
        "आसामी/उत्तर पूर्व"
    ],
    "Audio": [
        null,
        "ऑडियो"
    ],
    "Audio & Video": [
        null,
        "ऑडियो आणि व्हिडियो"
    ],
    "Audio & Video Outputs": [
        null,
        "ऑडियो आणि व्हिडियो"
    ],
    "Aug": [
        null,
        "ऑग "
    ],
    "August": [
        null,
        "ऑगस्ट "
    ],
    "BACK": [
        null,
        "मागे"
    ],
    "Back": [
        null,
        "मागे "
    ],
    "Bangla": [
        null,
        "बांगला"
    ],
    "Bengali": [
        null,
        "बंगाली "
    ],
    "Bhojpuri": [
        null,
        "भोजपुरी "
    ],
    "Bihar": [
        null,
        "बिहार"
    ],
    "Bihari": [
        null,
        "बिहारी "
    ],
    "CA Info Sheet": [
        null,
        "सीए माहिती शीट "
    ],
    "CA Information": [
        null,
        "सीए माहिती "
    ],
    "CAM Menu": [
        null,
        "कॅम मेनू "
    ],
    "CAM Module": [
        null,
        "कॅम मॉड्यूल"
    ],
    "CAM Module not authorized action.": [
        null,
        "कॅम मॉड्यूल अधिकृत क्रिया नाही"
    ],
    "CAM Module was inserted, Press Ok to reboot STB.": [
        null,
        "कॅम मॉड्यूल घातले होते, एसटीबी रिबूट करण्यासाठी ओके दाबा."
    ],
    "CAM Module was inserted, only the watching of channel will be available.": [
        null,
        "कॅम मॉड्यूल समाविष्ट केले गेले, केवळ चॅनल पाहणे उपलब्ध असेल."
    ],
    "CAM Module was removed, Press Ok to reboot STB, in order to enjoy fully the possibility of your box.": [
        null,
        "कॅम मॉड्यूल काढून टाकण्यात आले, आपल्या बॉक्सच्या पूर्ण क्षमतेचा आनंद घेण्यासाठी, एसटीबी रिबूट करण्यासाठी ओके दाबा."
    ],
    "CA_SYS_ID:": [
        null,
        "सीए_एसवायएस_आयडी:"
    ],
    "CVBS": [
        null,
        "सीव्हीबीएस"
    ],
    "Call Center:": [
        null,
        "कॉल सेंटर:"
    ],
    "Call me to 57575 from your Registered Mobile Number.": [
        null,
        "तुमच्या नोंदणीकृत मोबईल नंबरने मला 57575 वर कॉल करा"
    ],
    "Cancel": [
        null,
        "रद्द करा"
    ],
    "Cancel & Exit": [
        null,
        "रद्द करा आणि बाहेर पडा "
    ],
    "Cancel Record": [
        null,
        "रेकॉर्ड रद्द करा"
    ],
    "Cancel Reminder": [
        null,
        "रिमाइंडर रद्द करा  "
    ],
    "Change Freq:": [
        null,
        "फ्रिक्वेन्सी बदला:"
    ],
    "Change Language": [
        null,
        "भाषा बदला "
    ],
    "Change Pin Code": [
        null,
        "पिन कोड बदला"
    ],
    "Change UI Language": [
        null,
        "मेनू भाषा बदला "
    ],
    "Change pin code": [
        null,
        "पिन कोड बदला "
    ],
    "Channel List": [
        null,
        "चॅनल लिस्ट "
    ],
    "Channel No. {channelNum} is not subscribed by you.": [
        null,
        "चॅनल नंबर {channelNum} तुम्ही सबस्क्राईब केलेला नाही  "
    ],
    "Channel Search": [
        null,
        "चॅनल शोध  "
    ],
    "Channel Search Confirmation": [
        null,
        "चॅनल शोधची पुष्टी"
    ],
    "Channel Settings": [
        null,
        "सेटिंग्ज बदला "
    ],
    "Channel block": [
        null,
        "चॅनल ब्लॉक "
    ],
    "Channel search": [
        null,
        "चॅनल सर्च "
    ],
    "Channel search completed": [
        null,
        "चॅनेल शोधणे पूर्ण झाले"
    ],
    "Channel:": [
        null,
        "चॅनल:"
    ],
    "Channels": [
        null,
        "चॅनल्स "
    ],
    "Chip ID:": [
        null,
        "चीप आयडी:"
    ],
    "Choose your Network": [
        null,
        "तुमची भाषा निवडा "
    ],
    "Choose your language": [
        null,
        "तुमची भाषा निवडा "
    ],
    "Close": [
        null,
        "बंद "
    ],
    "Confirm new pin code": [
        null,
        "नव्या पिन कोडची पुष्टी करा "
    ],
    "Connected": [
        null,
        "जोडले"
    ],
    "Connected USB device is not compatible to the STB.": [
        null,
        "जोडलेले यूएसबी डिव्हाइस एसटीबीशी सुसंगत नाही."
    ],
    "Contact Us": [
        null,
        "आम्हाला संपर्क करा "
    ],
    "Copyright & License Info": [
        null,
        "कॉपीराईट आणि लायसन्स माहिती "
    ],
    "Currently no channels are available under this category.": [
        null,
        "सध्या या गटात कोणतेही चॅनल्स उपलब्ध नाहीत."
    ],
    "Daily": [
        null,
        "रोज "
    ],
    "Date:": [
        null,
        "तारीख:"
    ],
    "Dec": [
        null,
        "डिस  "
    ],
    "December": [
        null,
        "डिसेंबर "
    ],
    "Default List Mode": [
        null,
        "डिफॉल्ट लिस्ट मोड"
    ],
    "Delete": [
        null,
        "मिटवा "
    ],
    "Details": [
        null,
        "तपशील "
    ],
    "DiSEqC:": [
        null,
        "डीआयएसईक्यूसी: "
    ],
    "DishTV RMN <11 digit VC No.> to 57575": [
        null,
        "DishTV RMN <11 digit VC No.> to 57575"
    ],
    "DishTV add <a-la-carte code> <11 digit VC No.> to 57575": [
        null,
        "DishTV add <a-la-carte code> <11 digit VC No.> 57575 वर "
    ],
    "DishTV refresh <11 digit VC No.> to 57575": [
        null,
        "DishTV refresh <11 digit VC No.> 57575 वर  "
    ],
    "DishTV up <Pack Price> <11 digit VC No.> to 57575": [
        null,
        "DishTV UP <Pack Price> <11 digit VC No.> 57575 वर"
    ],
    "Do you really want to Format HDD? All data in the disk will be lost": [
        null,
        "तुम्हाला एचडीडी खरोखर फॉर्मॅट करायचे आहे काय? डिस्कमधील सर्व डेटा मिटेल"
    ],
    "Do you want to activate PVR feature?": [
        null,
        "तुम्हाला पीव्हीआरचे फिचर सक्रिय करायचे आहेत का?"
    ],
    "Do you want to apply this HDMI resolution?": [
        null,
        "तुम्ही हा एचडीएमआय रिझोल्यूशन लागू करू इच्छिता काय?"
    ],
    "Do you want to change IFtoIF mode and launch scan?  Launching scan will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it": [
        null,
        "तुम्ही आयएफटूआयएफ मोड बदलून स्कॅन लाँच करू इच्छिता काय? स्कॅन लाँच केल्याने तुमच्या वर्तमान चॅनेलची सूची, तुमची फेवरिट सूची आणि जर रेकॉर्ड चालू असेल तर तुम्ही गमवा."
    ],
    "Duration:": [
        null,
        "कालावधी: "
    ],
    "EPG": [
        null,
        "ईपीजी "
    ],
    "EPG Error": [
        null,
        "ईपीजी एरर"
    ],
    "Easy Scan": [
        null,
        "इझी स्कॅन "
    ],
    "Education": [
        null,
        "शिक्षण "
    ],
    "End Freq: ": [
        null,
        "एंड फ्रिक्वेन्सी:"
    ],
    "English": [
        null,
        "इंग्रजी"
    ],
    "Enhance your experience ": [
        null,
        "तुमचा अनुभव वाढवा"
    ],
    "Enter current pin code": [
        null,
        "सध्याचा पिन कोड एन्टर करा"
    ],
    "Enter new pin code": [
        null,
        "नवीन पिन कोड एन्टर करा "
    ],
    "Enter pin code": [
        null,
        "पिन कोड एन्टर करा."
    ],
    "Entertainment": [
        null,
        "मनोरंजन"
    ],
    "Error": [
        null,
        "एरर"
    ],
    "Error when trying to connect to Alpha Networks backend.": [
        null,
        "अल्फा नेटवर्कच्या बॅकएंडशी जोडण्याच्या प्रयत्नात त्रुटी झाली."
    ],
    "Exit": [
        null,
        "बाहेर पडा"
    ],
    "Factory Reset": [
        null,
        "फॅक्टरी रिसेट  "
    ],
    "Factory Setting Confirmation": [
        null,
        "फॅक्टरी सेटिंगची पुष्टी"
    ],
    "Family & Devotional": [
        null,
        "कौटुंबिक आणि भक्ती"
    ],
    "Fast Forward": [
        null,
        "फास्ट फॉरवर्ड  "
    ],
    "Fast Rewind": [
        null,
        "फास्ट रिवाईंड"
    ],
    "Favorite Add": [
        null,
        "फेवरिट जोडा"
    ],
    "Favorite Remove": [
        null,
        "फेवरिट मिटवा"
    ],
    "Favorite channels": [
        null,
        "फेवरिट चॅनल्स"
    ],
    "Favourite List Mode": [
        null,
        "फेवरिट लिस्ट मोड"
    ],
    "Favourites": [
        null,
        "फेवरिट्स"
    ],
    "Feb": [
        null,
        "फेब "
    ],
    "February": [
        null,
        "फेब्रुवारी "
    ],
    "Finish": [
        null,
        "समाप्त "
    ],
    "First Install, Sw Update": [
        null,
        "प्रथम इन्स्टॉल करा, Sw अपडेट"
    ],
    "For any assistance, call us on:": [
        null,
        "कोणत्याही मदतीसाठी, आम्हाला यावर कॉल करा:"
    ],
    "For resolving no access/unsubscribed channel/card refresh errors:": [
        null,
        "नो एक्सेस/अनसबस्क्राईब चेनल/कार्ड रेफ्रेशच्या एरर्स सोडवण्यासाठी: "
    ],
    "Force Software Update": [
        null,
        "सॉफ्टवेयर अपडेटला भाग पाडा"
    ],
    "Forgot to recharge! Give a Missed Call on \n1800 274 9050 to get your channels NOW. \nPay in next 3 days to enjoy NON STOP TV.": [
        null,
        "रिचार्ज करण्यासाठी विसरलात! एक मिस कॉल द्या\n1800 274 ​​9050 वर तुमच्या चॅनल्स मिळवण्यासाठी आत्ता"
    ],
    "Format HDD": [
        null,
        "एचडीडी फॉर्मॅट करा"
    ],
    "Format Hard Disk": [
        null,
        "हार्ड डिस्क फोर्मेट "
    ],
    "Formatting disk, please wait…": [
        null,
        "डिस्क फॉर्मॅट होत आहे, कृपया प्रतीक्षा करा ..."
    ],
    "Free size: ": [
        null,
        "फ्री साईझ:"
    ],
    "French": [
        null,
        "फ्रेंच "
    ],
    "Fri": [
        null,
        "शुक्र"
    ],
    "Friday": [
        null,
        "शुक्रवार "
    ],
    "Give a missed call on 1800 274 9511 from your or SMS CALLME to 57575 from your Registered Mobile Number (RMN).": [
        null,
        "सहाय्यासाठी, १८६०-२५८-३४७४ येथे कॉल करा किंवा तुमच्या नोंदणीकृत मोबाईल क्रमांकावरुन ५७५७५ लाCALLME हा एसएमएस करा."
    ],
    "Guarani": [
        null,
        "गुरानी"
    ],
    "Gujarati": [
        null,
        "गुजराती "
    ],
    "HD Channels": [
        null,
        "एचडी चॅनल्स"
    ],
    "HDD size: ": [
        null,
        "एचडीडी साईझ:"
    ],
    "HDMI Settings": [
        null,
        "एचडीएमआय सेटिंग्ज "
    ],
    "HDMI resolution": [
        null,
        "HDMI रिझोल्यूशन"
    ],
    "Hindi": [
        null,
        "हिंदी"
    ],
    "Home Transponder:": [
        null,
        "होम ट्रान्सपॉंडर: "
    ],
    "Hours:": [
        null,
        "तास:"
    ],
    "IF2IF MODE": [
        null,
        "आयएफ2आयएफ मोड"
    ],
    "IF2IF OFF": [
        null,
        "आयएफ2आयएफ ऑफ "
    ],
    "IF2IF ON": [
        null,
        "आयएफ2आयएफ ऑन "
    ],
    "IF2IF mode": [
        null,
        "आयएफ2आयएफ मोड"
    ],
    "IN CASE OF HEAVY RAIN, WAIT TILL RAIN STOPS TO REGAIN SIGNAL": [
        null,
        "मुसळधार पाऊस असेल, तर सिग्नल पुन्हा येण्यासाठी पाऊस थांबण्याची प्रतीक्षा करा"
    ],
    "If already recharged, please, switch-off & switch-on your Set-Top-Box from the mains and keep it ON for 15 minutes on channel 99": [
        null,
        "जर अगोदरच रिचार्ज केला असेल, तर कृपया तुमचा सेट-टॉप-बॉक्स मेन्सवरून स्विच-ऑफ आणि स्विच-ऑन करा आणि त्याला चॅनल 96 वर  मिनिटे चालू ठेवा."
    ],
    "If problem continues, SMS DISHTV 301 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "समस्या कायम राहिल्यास, 57575 वर एसएमएस करा DISHTV CALLME\nतुमच्या नोंदणीकृत मोबाईल नंबरवरून (आरएमएन)"
    ],
    "If problem continues, SMS DISHTV 302 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "समस्या चालू राहिल्यास, 57575 वर एसएमएस करा CALLME,\nतुमच्या नोंदणीकृत मोबाइल नंबरवरून (आरएमएन)."
    ],
    "Impossible to create a record, please set a valid date/time in the future.": [
        null,
        "रेकॉर्ड निर्माण करणे अशक्य, भविष्यात कृपया वैध तारीख/वेळ सेट करा."
    ],
    "Impossible to remove a channel from favorite while currently browsing Favorite List": [
        null,
        "सध्याची फेवरिट लिस्ट ब्राउझिंग करताना फेवरिटमधून एखादे चॅनल काढून टाकणे अशक्य आहे."
    ],
    "In order to give you the state of the Transponder we need to stop the records.": [
        null,
        "आपल्याला ट्रान्स्पापंडरची स्थिती देण्यासाठी आम्हाला नोंदी थांबवाव्या लागतील"
    ],
    "India (GMT +05:30)": [
        null,
        "भारत (जीएमटी +5.30 ) "
    ],
    "Informations": [
        null,
        "माहिती "
    ],
    "Installation": [
        null,
        "इनस्टॉलेशन"
    ],
    "Instant Message": [
        null,
        "त्वरित संदेश"
    ],
    "Insufficient Disk Space": [
        null,
        "अपर्याप्त डिस्क जागा"
    ],
    "Interface Version:": [
        null,
        "इंटरफेस आवृत्ती:"
    ],
    "Interface version:": [
        null,
        "इंटरफेस आवृत्ती:"
    ],
    "Invalid date": [
        null,
        "अमान्य तारीख"
    ],
    "Jan": [
        null,
        "जान "
    ],
    "January": [
        null,
        "जानेवारी "
    ],
    "Jul": [
        null,
        "जुल"
    ],
    "July": [
        null,
        "जुलै "
    ],
    "Jun": [
        null,
        "जून"
    ],
    "June": [
        null,
        "जून "
    ],
    "Kannada": [
        null,
        "कन्नड "
    ],
    "Kids & Infotainment": [
        null,
        "लहान मुले आणि मनोरंजन"
    ],
    "LNB Hi Frequency:": [
        null,
        "एलएनबी हाय फ्रिक्वेन्सी:"
    ],
    "LNB Low Frequency:": [
        null,
        "एलएनबी लो फ्रिक्वेन्सी:"
    ],
    "LNB Power:": [
        null,
        "एलएनबी पॉवर:"
    ],
    "LNB settings": [
        null,
        "एलएनबी सेटिंग "
    ],
    "Language": [
        null,
        "भाषा "
    ],
    "Language:": [
        null,
        "भाषा:"
    ],
    "Last Payment details:": [
        null,
        "अंतिम पेमेंटचे तपशील:"
    ],
    "Latin": [
        null,
        "लॅटिन  "
    ],
    "Launch": [
        null,
        "लाँच करा"
    ],
    "Launch a scan": [
        null,
        "एक स्कॅन सुरु करा"
    ],
    "Leisure hobbies": [
        null,
        "आरामाचे छंद "
    ],
    "Letter Box": [
        null,
        "लेटर बॉक्स"
    ],
    "MEDIACENTER": [
        null,
        "मीडियासेंटर "
    ],
    "MOD": [
        null,
        "स्पेसिअल"
    ],
    "Mac adress isn't valid.": [
        null,
        "मॅक अड्रेस मान्य नाही."
    ],
    "Magahi": [
        null,
        "मगाही "
    ],
    "Malayalam": [
        null,
        "मल्याळम"
    ],
    "Manage favorites": [
        null,
        "फेवरिट्स हाताळा "
    ],
    "Mar": [
        null,
        "मार "
    ],
    "Marathi": [
        null,
        "मराठी"
    ],
    "March": [
        null,
        "मार्च "
    ],
    "Master Reset": [
        null,
        "मास्टर रिसेट "
    ],
    "May": [
        null,
        "मे "
    ],
    "Media center": [
        null,
        "मीडिया सेंटर"
    ],
    "Mediaplayer Error": [
        null,
        "मीडियाप्लेयर त्रुटी"
    ],
    "Middleware Version:": [
        null,
        "मिडलवेअर आवृत्ती:"
    ],
    "Mon": [
        null,
        "सोम "
    ],
    "Monday": [
        null,
        "सोमवार "
    ],
    "Movie": [
        null,
        "सिनेमा"
    ],
    "Movies": [
        null,
        "चित्रपट"
    ],
    "Music": [
        null,
        "संगीत "
    ],
    "Music & Lifestyle": [
        null,
        "संगीत आणि जीवनशैली"
    ],
    "My Account": [
        null,
        "माय अकाऊंट "
    ],
    "My DishTV": [
        null,
        "माझा डिश टीव्ही "
    ],
    "My Recordings": [
        null,
        "माझ्या रेकॉर्डिंग्ज"
    ],
    "NO": [
        null,
        "नाही "
    ],
    "NO SIGNAL DETECTED": [
        null,
        "कोणताही सिग्नल आढळला नाही"
    ],
    "NTSC": [
        null,
        "एनटीएससी "
    ],
    "Network": [
        null,
        "नेटवर्क "
    ],
    "Network Selection": [
        null,
        "नेटवर्क इन्फोर्मेशन"
    ],
    "Network information": [
        null,
        "नेटवर्क इन्फोर्मेशन"
    ],
    "News": [
        null,
        "बातम्या"
    ],
    "News & Business": [
        null,
        "बातम्या आणि व्यवसाय"
    ],
    "Next": [
        null,
        "पुढे "
    ],
    "No": [
        null,
        "नाही"
    ],
    "No CAM Module": [
        null,
        "कॅम मॉड्यूल नाही"
    ],
    "No Channels": [
        null,
        "कोणतेही चॅनल्स नाहीत"
    ],
    "No Channels Available": [
        null,
        "कोणतेही चॅनल्स उपलब्ध नाहीत"
    ],
    "No Services": [
        null,
        "सेवा नाहीत"
    ],
    "No TV recordings available": [
        null,
        "टीव्ही रेकॉर्डिंग उपलब्ध नाही "
    ],
    "No USB Device connected. Connect USB Device to use Recorder features": [
        null,
        "कोणतेही यूएसबी डिवाईस जोडलेले नाही. रेकॉर्डरची वैशिष्ट्ये वापरण्यासाठी यूएसबी डिवाईस जोडा."
    ],
    "No applications found.": [
        null,
        "कोणतेही एप्लिकेशन आढळले नाहीत."
    ],
    "No channel": [
        null,
        "चॅनल नाही "
    ],
    "No channels available, perform a scan, press back to exit": [
        null,
        "कोणतेही चॅनल्स उपलब्ध नाहीत, एक स्कॅन करा, बाहेर पडण्यासाठी बॅक दाबा"
    ],
    "No information": [
        null,
        "माहिती नाही "
    ],
    "No internet connection.": [
        null,
        "कोणतेही इंटरनेट कनेक्शन नाही"
    ],
    "No services available. Perform a scan.": [
        null,
        "सेवा उपलब्ध नाहीत. एक स्कॅन करा."
    ],
    "None (default)": [
        null,
        "काही नाही (डिफॉल्ट)"
    ],
    "Not Connected": [
        null,
        "जोडलेले नाही "
    ],
    "Not able to launch application/game": [
        null,
        "यावेळी ऍप्लिकेशन प्रक्षेपित करता येणार नाही. कृपया नंतर पुन्हा प्रयत्न करा."
    ],
    "Nov": [
        null,
        "नोव "
    ],
    "November": [
        null,
        "नोव्हेंबर"
    ],
    "Number of sessions:": [
        null,
        "सत्रांची संख्या:"
    ],
    "OK": [
        null,
        "ओके "
    ],
    "Oct": [
        null,
        "ऑक्ट "
    ],
    "October": [
        null,
        "ऑक्टोबर "
    ],
    "Ok": [
        null,
        "ओके"
    ],
    "Ok ": [
        null,
        "ओके "
    ],
    "One Time": [
        null,
        "एक वेळ "
    ],
    "Order an A-La-Carte pack:": [
        null,
        "अ-ला-कार्ट पॅक मागवा."
    ],
    "Order by Channel Name": [
        null,
        "चॅनलच्या नावानुसार ऑर्डर "
    ],
    "Order by Channel Name - CAS Only": [
        null,
        "चॅनलच्या नावानुसार अनुक्रम - फक्त सीएएस "
    ],
    "Order by Channel Name - FTA Only": [
        null,
        "चॅनलच्या नावानुसार अनुक्रम - फक्त एफटीए"
    ],
    "Order by LCN": [
        null,
        "एलसीएननुसार अनुक्रम"
    ],
    "Order now at a SPECIAL PRICE!": [
        null,
        "विशेष दरासाठी तात्काळ मागणी नोंदवा!"
    ],
    "Ordering": [
        null,
        "ऑर्डरिंग"
    ],
    "Oriya": [
        null,
        "ओरिया "
    ],
    "PAL": [
        null,
        "पीएएल"
    ],
    "PINs do not match.": [
        null,
        "पिन्स जुळत नाहीत."
    ],
    "PM": [
        null,
        "पीएम "
    ],
    "PVR & TS": [
        null,
        "पीव्हीआर आणि टीएस"
    ],
    "Panjabi": [
        null,
        "पंजाबी "
    ],
    "Parental Control": [
        null,
        "पॅरेंटल कन्ट्रोल "
    ],
    "Parental Control Settings": [
        null,
        "पालक नियंत्रण सेटिंग्ज"
    ],
    "Pause": [
        null,
        "विराम"
    ],
    "Pillar Box": [
        null,
        "पिलर बॉक्स "
    ],
    "Play": [
        null,
        "प्ले "
    ],
    "Please Plug-in CAM to view CAM Menu.": [
        null,
        "कृपया कॅम मेनू पाहण्यासाठी कॅम प्लग-इन करा"
    ],
    "Please Plugin USB Device Properly": [
        null,
        "कृपया यूएसबी डिव्हाइस व्यवस्थित प्लगिन करा"
    ],
    "Please RECHARGE YOUR DISHTV VC No {vcNum} \nLog on www.dishtv.in use Credit/Debit card walk into: Nearest Recharge Outlet": [
        null,
        "कृपया तुमचा डिश टीव्ही व्हीसी नं. {vcNum} रिचार्ज करा.\nwww.dishtv.in वर लॉग इन करा क्रेडिट/डेबिट कार्डचा वापर करा: जवळच्या रिचार्ज आउटलेटमध्ये जा"
    ],
    "Please Select Network:": [
        null,
        "कृपया एफईसी निवडा: "
    ],
    "Please Wait ...": [
        null,
        "कृपया प्रतीक्षा करा..."
    ],
    "Please check your antenna cable": [
        null,
        "कृपया तुमचा अँटेना केबल तपासा"
    ],
    "Please check your subscription": [
        null,
        "कृपया तुमचे सबस्क्रिप्शन तपासा"
    ],
    "Please choose a Filter": [
        null,
        "कृपया एक फिल्टर निवडा "
    ],
    "Please choose a language": [
        null,
        "कृपया एक भाषा निवडा  "
    ],
    "Please ensure that your set-Top-Box is properly connected to the DISHTV antenna": [
        null,
        "कृपया तुमचा सेट-टॉप-बॉक्स DISHTV अन्टेनाशी योग्यरित्या जोडला असल्याची खात्री करा"
    ],
    "Please enter PIN to select IF2IF mode, this will launch scan and it will delete your recording and favourite list.": [
        null,
        "कृपया आयएफ2आयएफ मोड निवडण्यासाठी पिन एन्टर करा, यामुळे स्कॅन सुरु होईल आणि तुमचे रेकॉर्डिंग आणि फेवरिट लिस्ट हटविली जाईल."
    ],
    "Please enter Symbol rate:": [
        null,
        "सिम्बॉल रेट एन्टर करा: "
    ],
    "Please select FEC:": [
        null,
        "कृपया एफईसी निवडा: "
    ],
    "Please select Polarization:": [
        null,
        "कृपया पोलरायझेशन निवडा:"
    ],
    "Please wait while the USB connection is being established": [
        null,
        "कृपया यूएसबी जोडणीची स्थापना होईपर्यंत प्रतीक्षा करा"
    ],
    "Please, POWER OFF – POWER ON your Set-Top-Box from switch.": [
        null,
        "कृपया, स्विचमधून तुमचा सेट टॉप बॉक्स पॉवर ऑफ - पॉवर ऑन करा."
    ],
    "Press \"OK\" on your remote to re-install channels and services. \nIf problem continues, SMS DISHTV 303 to 57575 from your registered Mobile Number (RMN). To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "चॅनल आणि सेवा रिइन्स्टॉल करण्यासाठी आपल्या रिमोटवर \"OK\" दाबा.\nसमस्या चालू राहिल्यास, तुमच्या नोंदणीकृत मोबाईल क्रमांकावरून (आरएमएन) 57575 वर एसएमएस करा CALLME."
    ],
    "Press BACK to save & exit or OK for details": [
        null,
        "सेव्ह करण्यासाठी आणि बाहेर पडण्यासाठी बॅक दाबा किंवा तपशिलांसाठी ओके दाबा "
    ],
    "Press Back for STB InfoSheet": [
        null,
        "एसटीबी माहिती शीटसाठी बॅक दाबा"
    ],
    "Press Back for Tools": [
        null,
        "टूल्ससाठी बॅक दाबा "
    ],
    "Press Back to exit from active service": [
        null,
        "बाहेर पडण्यासाठी BACK दाबा"
    ],
    "Press Menu to Exit": [
        null,
        "बाहेर पडण्यासाठी मेनू दाबा"
    ],
    "Press OK for details": [
        null,
        "तपशिलांसाठी ओके दाबा "
    ],
    "Press OK to Save my schedule": [
        null,
        "माझे वेळापत्रक सेव्ह करण्यासाठी ओके दाबा "
    ],
    "Press OK to confirm": [
        null,
        "पुष्टी करण्यासाठी ओके दाबा."
    ],
    "Press OK to exit": [
        null,
        "बाहेर येण्यासाठी ओके दाबा "
    ],
    "Press OK to launch EASY SCAN": [
        null,
        "इझी स्कॅन सुरु करण्यासाठी ओके दाबा "
    ],
    "Punjabi": [
        null,
        "पंजाबी"
    ],
    "RECORDS": [
        null,
        "रेकॉर्ड्स "
    ],
    "Radios": [
        null,
        "रेडिओज"
    ],
    "Rajasthani": [
        null,
        "राजस्थानी "
    ],
    "Rec": [
        null,
        "रेक "
    ],
    "Recharge Reminder": [
        null,
        "रिचार्ज रिमाइंडर"
    ],
    "Record": [
        null,
        "रेकॉर्ड "
    ],
    "Recording  can't be done because The {channelTitle} doesn't have any program information": [
        null,
        "रेकॉर्डिंग केले जाऊ शकत नाही, कारण {channelTitle}कडे कोणतीही प्रोग्राम माहिती नाही"
    ],
    "Recording Alert": [
        null,
        "रेकॉर्डिंग अलर्ट"
    ],
    "Recording Alert: Record Vs Reminder": [
        null,
        "रेकॉर्डिंग अलर्ट: रेकॉर्ड विरुद्ध रिमाइंडर"
    ],
    "Recording Conflict": [
        null,
        "रेकॉर्डिंग विसंवाद"
    ],
    "Recording failed": [
        null,
        "रेकॉर्डिंग अयशस्वी झाले"
    ],
    "Recording features are not authorized on this channel": [
        null,
        "या चॅनलवर रेकॉर्डिंगची वैशिष्ट्ये अधिकृत नाहीत"
    ],
    "Recording in progress": [
        null,
        "रेकॉर्डिंग चालू आहे"
    ],
    "Recording in progress. \nPress OK to stop record and continue. \n Press BACK to close the message and return to the live stream.": [
        null,
        "रेकॉर्डिंग चालू आहे\nरेकॉर्ड थांबविण्यासाठी आणि चालू ठेवण्यासाठी ओके दाबा.\nमॅसेज बंद करण्यासाठी आणि लाइव्ह स्ट्रीमवर परतण्यासाठी बॅक दाबा."
    ],
    "Recording in progress. If you continue you will lose your record.": [
        null,
        "रेकॉर्डिंग चालू आहे. तुम्ही सुरू ठेवल्यास आपले रेकॉर्ड गमवाल."
    ],
    "Recording is not possible on past event.": [
        null,
        "मागील कार्यक्रमावर रेकॉर्ड करणे शक्य नाही"
    ],
    "Recurrence:": [
        null,
        "पुनरावृत्ती:"
    ],
    "Regional": [
        null,
        "प्रादेशिक"
    ],
    "Regional Hindi": [
        null,
        "प्रादेशिक हिंदी "
    ],
    "Register your Mobile No.:": [
        null,
        "तुमचा मोबईल नंबर रजिस्टर करा "
    ],
    "Reminder": [
        null,
        "रिमाइंडर"
    ],
    "Reminder Alert": [
        null,
        "रिमाइंडर अलर्ट"
    ],
    "Reminder Conflict": [
        null,
        "रिमाइंडर विसंगती"
    ],
    "Reminder can't be applied as program has no information.": [
        null,
        "प्रोग्राममध्ये कोणतीही माहिती नाही म्हणून रिमाइंडर लागू केले जाऊ शकणार नाही."
    ],
    "Reminder or Recording is already set for this Program": [
        null,
        "या प्रोग्रामसाठी रिमाइंडर किंवा रेकॉर्डिंग अगोदरपासून निश्चित आहे"
    ],
    "Reset": [
        null,
        "रिसेट करा"
    ],
    "Reset Setting Confirmation": [
        null,
        "सेटिंगच्या पुष्टीस रिसेट करा"
    ],
    "Reset favorites": [
        null,
        "फेवरिट्स रिसेट करा"
    ],
    "Resume playback": [
        null,
        "प्लेबॅक पुन्हा सुरु करा"
    ],
    "Retrieving active service, please wait.": [
        null,
        "सक्रिय सेवा पुन्हा मिळवत आहोत, कृपया वाट पहा."
    ],
    "Return to STB InfoSheet": [
        null,
        "एसटीबी माहिती शीटवर परत जा"
    ],
    "SCRAMBLED CHANNEL": [
        null,
        "अस्पष्ट चॅनल"
    ],
    "SELECT GENRE": [
        null,
        "श्रेणी निवडा."
    ],
    "SMS DISHTV CALL ME to 57575 from your registered mobile number (RMN).": [
        null,
        "तुमच्या नोंदणीकृत मोबाइल नंबर (आरएमएन) वरुन 57575 वर एसएमएस करा DISHTV CALLME"
    ],
    "SMS MOD {vcNum} {PurchaseCode} to 57575. If you do not get the movie with in 10 minutes after sending ": [
        null,
        "57575 वर एसएमएस करा {vcNum} {PurchaseCode}. जर तुम्हाला पाठविल्यानंतर 10 मिनिटांत मुव्ही मिळाली नाही तर"
    ],
    "SMS Services": [
        null,
        "एसएमएस सेवा "
    ],
    "SMS: DISHTV ADD {channelNum} to 57575 \nfrom your Registered Mobile Number": [
        null,
        " "
    ],
    "STB Info Sheet": [
        null,
        "एसटीबी माहिती शीट "
    ],
    "STB InfoSheet": [
        null,
        "एसटीबी माहिती शीट "
    ],
    "STB Information": [
        null,
        "एसटीबी माहिती "
    ],
    "STB No": [
        null,
        "एसटीबी नंबर "
    ],
    "STB No:": [
        null,
        "एसटीबी नं:"
    ],
    "Sat": [
        null,
        "शनी"
    ],
    "Satellite": [
        null,
        "सॅटेलाईट"
    ],
    "Saturday": [
        null,
        "शनिवार "
    ],
    "Save & Exit": [
        null,
        "सेव करा आणि बाहेर पडा "
    ],
    "Scan Ongoing": [
        null,
        "स्कॅन चालू आहे"
    ],
    "Schedule Your Recording": [
        null,
        "तुमच्या रेकॉर्डिंगचे निर्धारण करा"
    ],
    "Screen Adjustment": [
        null,
        "स्क्रीन अॅड्जस्टमेंट"
    ],
    "Security client ID:": [
        null,
        "सेक्युरिटी क्लायंट आयडी:"
    ],
    "Security client version:": [
        null,
        "सेक्युरिटी क्लायंट आवृत्ती:"
    ],
    "Select on your remote control the biggest number displayed": [
        null,
        "तुमच्या रिमोट कंट्रोलवर प्रदर्शित झालेली सर्वात मोठी संख्या निवडा"
    ],
    "Self-help": [
        null,
        "सेल्फ-हेल्प"
    ],
    "Sep": [
        null,
        "सप"
    ],
    "September": [
        null,
        "सप्टेंबर "
    ],
    "Serie": [
        null,
        "सिरी "
    ],
    "Set Reminder": [
        null,
        "रिमाइंडर सेट करा "
    ],
    "Settings": [
        null,
        "सेटिंग्ज "
    ],
    "Should your services not restart in 15 minutes, \nSMS DISHTV REFRESH to 57575 \nfrom your registred Mobile Number": [
        null,
        "तुमच्या सेवा 15 मिनिटांमध्ये पुन्हा चालू झाल्या नाहीत, तर 57575 वर एसएमएस करा DISHTV REFRESH तुमच्या नोंदणीकृत मोबाईल नंबरवरून"
    ],
    "Show": [
        null,
        "शो "
    ],
    "Social/Politics": [
        null,
        "सामाजिक/राजकारण"
    ],
    "Sorry this action is not permitted with a CAM, remove it and switch off switch on your box in order to use this feature.": [
        null,
        "माफ करा, कॅमसह ही कृती अनुमत नाही आहे, याला हटवा आणि हे वैशिष्ट्य वापरण्यासाठी तुमच्या बॉक्सवर स्विच बंद करा."
    ],
    "Sports": [
        null,
        "क्रीडा"
    ],
    "SriLanka (GMT +05:30)": [
        null,
        "श्रीलंका (जीएमटी +5.30 ) "
    ],
    "Start Freq: ": [
        null,
        "स्टार्ट फ्रिक्वेन्सी:"
    ],
    "Start Scan": [
        null,
        "स्कॅन सुरु करा"
    ],
    "Stop": [
        null,
        "थांबवा"
    ],
    "Stop & save": [
        null,
        "थांबवा आणि सेव्ह करा"
    ],
    "Stop Record": [
        null,
        "रेकॉर्ड थांबवा"
    ],
    "Subscribe to this channel in HD picture \nquality along with {noOfHdChannels} more HD channels \nat  Rs. {priceTag} per month.": [
        null,
        "सभासदत्व घेण्यासाठी DISHTV GET {channelNum} हा एसएमएस 57575 येथे आपल्या आरएमएनवरुन करा. \nप्राईसिंगच्या माहितीसाठी, कृपया dishtv.in येथे भेट द्या."
    ],
    "Subscription Information": [
        null,
        "सबस्क्रिप्शन माहिती "
    ],
    "Subtitles": [
        null,
        "सबटायटल "
    ],
    "Sun": [
        null,
        "रवि"
    ],
    "Sunday": [
        null,
        "रविवार "
    ],
    "Switch off date:": [
        null,
        "बंद करण्याची तारीख "
    ],
    "Switch to HD Now for ultra-clear picture quality and 5.1 surround sound": [
        null,
        "अल्ट्रा क्लिअर चित्र दर्जा आणि ५.१ सराऊंड साऊंडसाठी एचडि वापरणे सुरु करा."
    ],
    "System Information": [
        null,
        "सिस्टम इन्फोर्मेशन"
    ],
    "System information": [
        null,
        "सिस्टम इन्फोर्मेशन /माहिती "
    ],
    "TP Info": [
        null,
        "टीपी माहिती"
    ],
    "TP list screen": [
        null,
        "टीपी लिस्ट स्क्रीन "
    ],
    "TV": [
        null,
        "टीव्ही "
    ],
    "TV Channels": [
        null,
        "टीव्ही चॅनल्स"
    ],
    "TV Guide": [
        null,
        "टीव्ही गाईड "
    ],
    "TV Type": [
        null,
        "टीव्ही टाईप "
    ],
    "TV type": [
        null,
        "टीव्हीचा प्रकार"
    ],
    "TV: {tvFound}     Radios: {radioFound}      Network: {networkFound}": [
        null,
        "टीव्ही:{tvFound} रेडियोज:{radioFound}  नेटवर्क:{networkFound}"
    ],
    "Tamil": [
        null,
        "तामिळ "
    ],
    "Telugu": [
        null,
        "तेलुगु "
    ],
    "The STB is not able to format the connected USB device. Use Another device": [
        null,
        "एसटीबी जोडलेल्या यूएसबी उपकरणाचे फॉर्मॅट करण्यास सक्षम नाही. दुसरे डिव्हाइस वापरा"
    ],
    "The Sw version details are not provided, System can’t verify if a new Sw version is available": [
        null,
        "Sw आवृत्ती तपशील दिलेले नाहीत, सिस्टम नवीन Sw आवृत्ती उपलब्ध असल्यास पडताळणी करू शकत नाही"
    ],
    "The program {scheduleTitle} can't be recorded because no compliant USB device connected.": [
        null,
        "प्रोग्राम {scheduleTitle} रेकॉर्ड करणे शक्य नाही, कारण कोणतेही सुसंगत यूएसबी डिव्हाइस जोडलेले नाही."
    ],
    "The signal to your Set-Top-Box is temporarily unavailable.": [
        null,
        "तुमच्या सेट-टॉप-बॉक्सवर सिग्नल तात्पुरते अनुपलब्ध आहेत"
    ],
    "The size of the connected USB Device is not enough to enable Recorder features. Please insert a USB Device with minimum 1GB capacity.": [
        null,
        "जोडलेल्या यूएसबी डिव्हाइसचा आकार रेकॉर्डर वैशिष्ट्ये सक्षम करण्यासाठी पुरेसा नाही. कृपया किमान 1GB क्षमतेचे एक यूएसबी डिव्हाइस इन्सर्ट करा."
    ],
    "There is a TV recording in progress. You cannot access to radio universe": [
        null,
        "एक टीव्ही रेकॉर्डिंग चालू आहे. तुम्ही रेडिओ युनिव्हर्सला एक्सेस करू शकत नाही"
    ],
    "This Channel Is Blocked": [
        null,
        "हा चॅनेल ब्लॉक झालेला आहे"
    ],
    "This channel is available in High Definition.": [
        null,
        "आपल्याकडून या एचडि चॅनलचे सभासदत्व घेतले गेलेले नाहीये."
    ],
    "This program can't be recorded because another TV recording is planned at the same time on {channelName} starting at {startDate}.": [
        null,
        "हा प्रोग्राम रेकॉर्ड केला जाऊ शकत नाही, कारण त्याच वेळी {start_date} पासून {channelName} वर सुरू होणाऱ्या दुसरे टीव्ही रेकॉर्डिंग करण्याचे निश्चित केले आहे."
    ],
    "Thu": [
        null,
        "गुरु "
    ],
    "Thursday": [
        null,
        "गुरुवार "
    ],
    "Time Format": [
        null,
        "टाईम फोर्मेट "
    ],
    "Time Settings": [
        null,
        "टाईम सेटिंग्ज  "
    ],
    "Time Zone Format": [
        null,
        "टाइम झोन फोर्मेट "
    ],
    "Timeshift & PVR feature will not work": [
        null,
        "टाइमशिफ्ट आणि पीव्हीआर वैशिष्ट्य कार्य करणार नाहीत"
    ],
    "To RMN SMS DISHTV RMN {vcNum} to 57575": [
        null,
        "आरएमएनसाठी 57575 वर एसएमएस करा DISHTV RMN {vcNum}"
    ],
    "To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "आरएमएनवरून 57575 वर एसएमएस करा DISHTV RMN {vcNum} "
    ],
    "To Register your Mobile Number, \nSMS: DISHTV RMN {vcNum} to 57575": [
        null,
        "तुमचा मोबईल नंबर रजिस्टर करण्यासाठी, \n 57575 वर एसएमएस करा: DISHTV RMN {vcNum}"
    ],
    "To Register your Mobile Number, SMS: \nDISHTV RMN {vcNum} to 57575": [
        null,
        "तुमच्या मोबाईल नंबरची नोंदणी करण्यासाठी, एसएमएस करा:\n57575 वर DISHTV RMN {vcNum}"
    ],
    "To allow timely updation, after ordering a \nchannel, please switch-off & switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channnel 99 for 15 minutes.": [
        null,
        "एका चॅनलला ऑर्डर दिल्यानंतर वेळेवर अपडेट करण्याची परवानगी देण्यासाठी\nकृपया स्विच-ऑफ आणि स्विच-ऑन करा\nतुमचा मुख्य वीज पुरवठ्यापासून सेट टॉप बॉक्स\n15 मिनिटांसाठी हे चाळले 96 वर ठेवा"
    ],
    "To get a call from us just SMS:": [
        null,
        "आमच्याकडून कॉल मिळविण्यासाठी फक्त एसएमएसकरा:"
    ],
    "To order {EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}": [
        null,
        "{EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode} ऑर्डर करण्यासाठी"
    ],
    "To subscribe this channel, \nSMS: DISHTV GET {channelNum} to 57575 \nFrom your Registered Mobile Number (RMN)": [
        null,
        "हा चॅनल सबस्क्राईब करण्यासाठी, \n57575 वर एसएमएस करा: DISHTV GET {channelNum} \nतुमच्या नोंदणीकृत मोबाईल नंबरवरून (आरएमएन)"
    ],
    "To update My Account, give a MISSED CALL on 1800-274-4744 from your RMN": [
        null,
        "माय अकाऊंट अपडेट करण्यसाठी, तुमच्या आरएमएनवरून 1800-274-4744 वर एक मिस्ड कॉल द्या  "
    ],
    "Tools": [
        null,
        "साधने"
    ],
    "Total services found": [
        null,
        "सर्व सर्विसेस आढळल्या "
    ],
    "Total services found: {serviceFound}.": [
        null,
        "एकूण सेवा आढळल्या:{serviceFound}."
    ],
    "Transponder Information": [
        null,
        "ट्रान्सपाँडर माहिती "
    ],
    "Transponder List": [
        null,
        "ट्रान्स्पपॉंडर लिस्ट "
    ],
    "Tue": [
        null,
        "मंगळ "
    ],
    "Tuesday": [
        null,
        "मंगळवार "
    ],
    "Tuned channel will be changed if new recording started on this channel.": [
        null,
        "या चॅनलवर नवीन रेकॉर्डिंग चालू केले, तर ट्यून केलेले चॅनल बदलेल."
    ],
    "USB Device Not Inserted Properly": [
        null,
        "यूएसबी डिव्हाइस योग्यरित्या इन्सर्ट केलेले नाही"
    ],
    "USB Device Unplugged": [
        null,
        "यूएसबी डिव्हाइस अनप्लग केले"
    ],
    "USB Formatted": [
        null,
        "यूएसबी फॉर्मॅट केले आहे"
    ],
    "USB Formatting...": [
        null,
        "यूएसबी फॉर्मॅट होत आहे... "
    ],
    "USB disk size not compliant with PVR & TS requirements. Minimal free size to activate = 10Go": [
        null,
        "यूएसबी डिस्कचा आकार पीव्हीआर आणि टीएस आवश्यकतेनुसार अनुरूप नाही. सक्रिय करण्यासाठी किमान मुक्त आकार = 10Go"
    ],
    "Unable to play this asset.": [
        null,
        "ही असेट प्ले करण्यात अक्षम."
    ],
    "Unable to play this file. Press BACK or OK key to return to Mediaplayer explorer.": [
        null,
        "ही फाइल चालविण्यास असमर्थ. मीडियाप्लेयर एक्स्प्लोररवर परत येण्यासाठी बॅक दाबा किंवा ओके की दाबा."
    ],
    "Unable to play this file. Press BACK or OK key to return to Recording.": [
        null,
        "ही फाइल चालविण्यास असमर्थ. रेकॉर्डिंगवर परत येण्यासाठी बॅक दाबा किंवा ओके की दाबा."
    ],
    "Updates Ongoing....": [
        null,
        "अपडेट सुरु आहे... "
    ],
    "Upgrade your pack:": [
        null,
        "तुमचा पॅक अपग्रेड करा "
    ],
    "Urdu": [
        null,
        "उर्दू "
    ],
    "Usb key has been Unplugged": [
        null,
        "यूएसबी की अनप्लग करण्यात आले आहे"
    ],
    "Usb key successfully formatted": [
        null,
        "यूएसबी की यशस्वीरित्या फॉर्मॅट केले"
    ],
    "Use Favourites List As Channel List": [
        null,
        "फेवरिट्सची यादी चॅनलच्या यादीसारखी वापरा"
    ],
    "Use default list": [
        null,
        "डिफॉल्ट लिस्ट वापरा "
    ],
    "Use favourite list": [
        null,
        "फेवरिट लिस्ट वापरा"
    ],
    "VC No": [
        null,
        "व्हीसी नंबर "
    ],
    "VC No:": [
        null,
        "व्हीसी नं:"
    ],
    "VC Number:": [
        null,
        "व्हीसी नंबर "
    ],
    "VOD Error": [
        null,
        "व्हीओडी त्रुटी"
    ],
    "Vod catalog loading aborted by user.": [
        null,
        "व्होड कॅटलॉग लोडिंग युजरने रद्द केले."
    ],
    "Vod initialization aborted.": [
        null,
        "व्हॉड आरंभीकरण विफल केले."
    ],
    "Watch": [
        null,
        "बघा "
    ],
    "Website:": [
        null,
        "संकेतस्थळ"
    ],
    "Wed": [
        null,
        "बुध "
    ],
    "Wednesday": [
        null,
        "बुधवार "
    ],
    "Week Days": [
        null,
        "आठवड्याचे दिवस "
    ],
    "Weekly": [
        null,
        "साप्ताहिक"
    ],
    "Wrong pin code !": [
        null,
        "चुकीचा पिन कोड!"
    ],
    "YES": [
        null,
        "होय "
    ],
    "Yes": [
        null,
        "होय"
    ],
    "You are now browsing you default channel list .\nPress FAV button to switch to your Favourite Channels list.": [
        null,
        "तुम्ही आता डिफॉल्ट चॅनल लिस्ट ब्राउझ करीत आहात.\nतुमच्या आवडत्या चॅनल्स लिस्टकडे जाण्यासाठी FAV बटण दाबा."
    ],
    "You are now browsing your Favourite Channels list. \n Press Fav button to switch to Default channel list.": [
        null,
        "तुम्ही आता तुमच्या आवडत्या चॅनेलची सूची ब्राउझ करीत आहात.\nडिफॉल्ट चॅनल लिस्टकडे जाण्यासाठी Fav बटण दाबा."
    ],
    "You have reached the end of this content.": [
        null,
        "आपण या सामग्रीच्या समाप्तीपर्यंत पोहचला आहात"
    ],
    "You will launch a  Reset, All of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "तुम्ही रिसेट लाँच कराल, तुमची सर्व सेटिंग्ज डिफॉल्ट मूल्यावर रिस्टोर केली जातील. जर रेकॉर्ड चालू असेल तर तुम्ही ते गमवाल."
    ],
    "You will launch a Channel Search that will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it.": [
        null,
        "आपण एक चॅनल शोध लाँच कराल, जे तुमच्या चॅनलची वर्तमान यादी, आपली आवडती यादी हटवेल आणि जर रेकॉर्ड चालू असेल तर तुम्ही ते गमवाल."
    ],
    "You will launch a Factory Reset, Some of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "तुम्ही फॅक्टरी रिसेट लाँच कराल, तुमचे काही सेटिंग्ज डिफॉल्ट मूल्यावर रिस्टोर केली जातील. जर रेकॉर्ड चालू असेल तर तुम्ही ते गमवाल."
    ],
    "Your Set-Top-Box is being updated, Please wait…": [
        null,
        "तुमचे सेट-टॉप-बॉक्स अपडेट केले जात आहे, कृपया प्रतीक्षा करा..."
    ],
    "Your TV will be switched off, today. Recharge immediately to avoid disruption in service.": [
        null,
        "तुमचा टीव्ही आज बंद होईल. सेवेत अडथळा थांबवण्यासाठी लवकरच रिचार्ज करा  "
    ],
    "Your current Set-Top-Box box doesn't support this HD channel": [
        null,
        "तुमचा सध्याचा सेट-टॉप-बॉक्स या एचडि चॅनलला पाठिंबा देत नाही."
    ],
    "Your pin code has been successfully updated !": [
        null,
        "तुमचा पिन कोड यशस्वीपणे अपडेट झाला आहे!"
    ],
    "Your program {programName} on channel {channelNum} {channelName} will start at {startHour}. Do you want to tune the channel?": [
        null,
        "तुमचे कार्यक्रम {programName}  {channelNum} {channelName} चॅनलवर {startHour}मध्ये सुरु होईल. तुम्हाला चॅनल ट्यून करायचे आहे काय?"
    ],
    "Your recharge date is near. Your TV will be switched off in {count} days. Please recharge immediately to avoid disruption in service.": [
        null,
        "तुमची रिचार्ज तारीख जवळ आहे. तुमचा टीव्ही {count} दिवसात बंद होईल. सेवेत अडथळा थांबवण्यासाठी लवकरच रिचार्ज करा "
    ],
    "Youth": [
        null,
        "युवा"
    ],
    "[vod]AssetVoucherCodeMessage": [
        null,
        "[vod]असेटवाउचरकोडमेसेज"
    ],
    "[vod]AssetVoucherCodeTitle": [
        null,
        "[vod]असेटवाउचरकोडटायटल"
    ],
    "[vod]BuyPackError": [
        null,
        "[vod] बायपॅकएरर"
    ],
    "[vod]PackVoucherCodeMessage": [
        null,
        "[vod]पॅकवाउचरकोडमेसेज"
    ],
    "[vod]PackVoucherCodeTitle": [
        null,
        "[vod]पॅकवाउचरकोडटायटल "
    ],
    "[vod]Play": [
        null,
        "[vod]प्ले "
    ],
    "[vod]PlayAssetError": [
        null,
        "[vod]प्लेअसेटएरर"
    ],
    "[vod]Rent": [
        null,
        "[vod]भाडे"
    ],
    "[vod]RentAssetError": [
        null,
        "[vod]रेंटअसेटएरर"
    ],
    "[vod]VideoLoading": [
        null,
        "[vod]व्हिडियो लोडिंग "
    ],
    "[vod]VoucherDigitError": [
        null,
        "[vod]वाउचरडीजीटएरर    "
    ],
    "[vod]anCurrency": [
        null,
        "[vod]एकचलन"
    ],
    "[vod]anLanguage": [
        null,
        "[vod]एकभाषा"
    ],
    "[vod]buyPack": [
        null,
        "[vod]बायपॅक "
    ],
    "[vod]loadingTitle": [
        null,
        "[vod]लोडिंग टायटल "
    ],
    "authentication status": [
        null,
        "अधिप्रमाणन स्टेटस "
    ],
    "conflicting with": [
        null,
        "च्या सोबत संघर्ष चालू आहे."
    ],
    "dishtv.in": [
        null,
        "dishtv.in"
    ],
    "dns1": [
        null,
        "डीएनएस1 "
    ],
    "dns2": [
        null,
        "डीएनएस2 "
    ],
    "failed": [
        null,
        "अयशस्वी"
    ],
    "gateway": [
        null,
        "गेटवे "
    ],
    "interface": [
        null,
        "इंटरफेस "
    ],
    "ip_address": [
        null,
        "आयपी_अड्रेस "
    ],
    "mac_address": [
        null,
        "एमएसी_अड्रेस "
    ],
    "malayalam": [
        null,
        "मल्याळम"
    ],
    "manipuri": [
        null,
        "मणिपुरी "
    ],
    "nd": [
        null,
        "एनडी "
    ],
    "nepali": [
        null,
        "नेपाळी "
    ],
    "netmask": [
        null,
        "नेटमास्क "
    ],
    "no": [
        null,
        "नाही "
    ],
    "ok": [
        null,
        "ओके "
    ],
    "rd": [
        null,
        "आरडी "
    ],
    "st": [
        null,
        "एसटी "
    ],
    "th": [
        null,
        "द "
    ],
    "yes": [
        null,
        "होय"
    ],
    "{dateNumber}{nth} {month}": [
        null,
        "{dateNumber}{nth} {month}"
    ],
    "{day} {month} {dateNumber}{nth} {year}": [
        null,
        "{day} {month} {dateNumber}{nth} {year}"
    ],
    "{month} {dateNumber}{nth}": [
        null,
        "{month} {dateNumber}{nth}"
    ],
    "{programName} - ({channelName}) has been started and is scheduled for recording.": [
        null,
        "{programName} - ({channelName}) सुरू झाले आहे आणि रेकॉर्डिंगसाठी शेड्यूल केले आहे."
    ]
}
,
"locale-tel_TEL":{ 
    "": {
        "Content-Transfer-Encoding": "8bit",
        "Content-Type": "text/plain; charset=UTF-8",
        "Generated-By": "Babel 1.3",
        "Language": "te",
        "Language-Team": "none",
        "Last-Translator": "Automatically generated",
        "MIME-Version": "1.0",
        "PO-Revision-Date": "2018-01-12 17:36+0530",
        "POT-Creation-Date": "2018-06-19 11:08+0530",
        "Project-Id-Version": "PROJECT VERSION",
        "Report-Msgid-Bugs-To": "EMAIL@ADDRESS",
        "X-Generator": "Poedit 2.0.5"
    },
    " 802 – Recording Alert": [
        null,
        " 802 – రికార్డింగ్ హెచ్చరిక "
    ],
    " Soon Recording Functions & Timeshift feature will be available. Retry later.": [
        null,
        "త్వరలో రికార్డింగ్ ఫంక్షన్స్ మరియు టైం షిఫ్ట్ ఫీచర్ అందుబాటులోకి వస్తాయి. తరువాత మరల ప్రయత్నిచండి"
    ],
    " You have run out of disk space on the connected USB device.Please delete existing recordings to record further.": [
        null,
        "కనెక్ట్ చెయ్యబడిన USB డివైజ్ లో స్పేస్ అయిపోయింది. రికార్డింగ్ కొనసాగించడానికి, దయచేసి అందులో ఉన్న రికార్డింగ్స్ ని తొలగించండి."
    ],
    " from live": [
        null,
        "లైవ్ నుండి"
    ],
    " on ": [
        null,
        "ఆన్"
    ],
    " {msg} ": [
        null,
        " {msg}"
    ],
    "101 - Unsubscribed Channel": [
        null,
        "101 - సబ్స్క్రైబ్ చెయ్యని ఛానెల్"
    ],
    "102 - Viewing Card (VC) Deactivated": [
        null,
        "102 - VC డీయాక్టివేట్ చెయ్యబడినది"
    ],
    "103 - HD Channel not subscribed": [
        null,
        "103 - HD ప్యాక్కి అప్గ్రేడ్ చేయండి"
    ],
    "106 Software Update": [
        null,
        "106 సాఫ్ట్ వేర్ అప్ డేట్"
    ],
    "1860-258-3474 (Local call charges apply)": [
        null,
        "1860-258-3474 (లోకల్ కాల్ చార్జీలు వర్తిస్తాయి)"
    ],
    "301 – Signal not found": [
        null,
        "301 – సిగ్నల్ లభించలేదు"
    ],
    "302 - Signal Unavailable": [
        null,
        "302 - సిగ్నల్ అందుబాటులో లేదు "
    ],
    "303 Re-Install Services": [
        null,
        "303 రీ-ఇన్ స్టాల్ సేవలు"
    ],
    "5.1 OFF": [
        null,
        "5.1 ఆఫ్"
    ],
    "5.1 ON": [
        null,
        "5.1 ఆన్"
    ],
    "5.1 Setting": [
        null,
        "5.1 ఆడియో సెట్టింగ్"
    ],
    "501 - Conditional Access": [
        null,
        "501 - షరతులతో కూడిన యాక్సెస్"
    ],
    "601 - Upgrade to HD Set-Top-Box": [
        null,
        "601 - HD సెట్-టాప్ బాక్స్ పొందండి"
    ],
    "701 – detecting External USB Device…": [
        null,
        "701 – ఎక్స్టర్నల్ USB డివైజ్ గుర్తించబడుతుంది..."
    ],
    "702 - Device Detected": [
        null,
        "702 - డివైజ్ కనుగొనబడింది"
    ],
    "702 – New USB Device": [
        null,
        "702 - కొత్త USB డివైజ్"
    ],
    "704 – USB device Alert": [
        null,
        "704 - USB డివైజ్ హెచ్చరిక "
    ],
    "706 – USB Device Full": [
        null,
        "706 – USB డివైజ్ నిండినది"
    ],
    "708 - Device Detected": [
        null,
        "708 - డివైజ్ కనుగొనబడింది"
    ],
    "709 - Device Detected": [
        null,
        "709 - డివైజ్ కనుగొనబడినది "
    ],
    "801 - Device Detected": [
        null,
        "801 - డివైజ్ కనుగొనబడింది"
    ],
    "803 – Recording Alert": [
        null,
        "804 – రికార్డింగ్ హెచ్చరిక"
    ],
    "806 – Recording Alert": [
        null,
        "806 – రికార్డింగ్ హెచ్చరిక"
    ],
    "808 – Content Alert": [
        null,
        "808 – కంటెంట్ హెచ్చరిక "
    ],
    "A Record or a Reminder is already scheduled \nfor this channel for the same hour. We can’t take into account your action.": [
        null,
        "ఇదే సమయానికి ఈ ఛానెల్ కు \nఒక రికార్డ్ లేదా రిమైండర్ షెడ్యూల్ చేయబడింది. మేము మీ చర్యను పరిగణించలేము."
    ],
    "A Software version is available and the Client Software will force the Update.": [
        null,
        "ఒక సాఫ్ట్ వేర్ వెర్షన్ అందుబాటులో ఉన్నది మరియు క్లయింట్ సాఫ్ట్ వేర్, అప్ డేట్ చేస్తుంది."
    ],
    "A TV recording is going to start on channel {channelName} which is not in the favorite list. Default list will be restored and the recorded channel will be displayed. Select 'Cancel' to stay on current service": [
        null,
        "టీవీ ఛానెల్ {channelName} లో రికార్డింగ్ ప్రారంభమవుతుంది. అది ఫేవరేట్ జాబితాలో లేదు. డిఫాల్ట్ జాబితా రీస్టోర్ చెయ్యబడుతుంది మరియు రికార్డ్ చెయ్యబడిన ఛానెల్ చూపించబడుతుంది. ప్రస్తుత సేవలో కొనసాగడానికి 'Cancel' ని సెలక్ట్ చేసుకోండి."
    ],
    "A TV recording is on-going on channel {channelName} which is not in the favorite list. Recording will be discontinued and Favourite List will be selected. Select 'Cancel' to stay on current service": [
        null,
        "ఛానెల్ {channelName} లో TV రికార్డింగ్ జరుగుతోంది. అది మీ ఫెవరేట్ జాబితాలో లేదు. రికార్డింగ్ రద్దు చెయ్యబడుతుంది మరియు ఫెవరేట్ జాబితా ఎంపిక చెయ్యబడుతుంది. ప్రస్తుత సేవలో కొనసాగడానికి 'క్యాన్సిల్' ఎంచుకోండి"
    ],
    "A new USB Device has been detected. OK to start format. All data in the disk will be lost": [
        null,
        "ఒక కొత్త USB డివైజ్ కనుగొనబడినది. ఫార్మాట్ చెయ్యడం మొదలు పెట్టటానికి ఓకే నొక్కండి. డిస్క్ లో ఉన్న డాటా మొత్తం పోతుంది."
    ],
    "A recording is going on, changing the channel shall discard the current recording.": [
        null,
        "ఒక రికార్డింగ్ నడుస్తోంది, ఛానెల్ మార్చినట్లయితే ప్రస్తుత రికార్డింగ్ తొలగించబడుతుంది."
    ],
    "AM": [
        null,
        "ఎ ఎం"
    ],
    "Active Services": [
        null,
        "యాక్టివ్ సేవలు"
    ],
    "Add a manual recording": [
        null,
        "ఒక మాన్యువల్ రికార్డింగ్ ని జోడించండి "
    ],
    "Advanced Setting Screen": [
        null,
        "అడ్వాన్స్డ్  సెట్టింగ్ స్క్రీన్"
    ],
    "All Channels": [
        null,
        "అన్ని ఛానెల్స్ "
    ],
    "Antenna settings": [
        null,
        "యాంటేనా సెట్టింగ్స్ "
    ],
    "App store": [
        null,
        "యాప్ స్టోర్"
    ],
    "Apps": [
        null,
        "యాప్స్"
    ],
    "Apr": [
        null,
        "ఏప్రి"
    ],
    "April": [
        null,
        "ఏప్రిల్ "
    ],
    "Arts/Culture": [
        null,
        "ఆర్ట్స్/కల్చర్"
    ],
    "Assamese": [
        null,
        "అస్సామీస్ "
    ],
    "Assamese/North East": [
        null,
        "అస్సామీస్/ఈశాన్యం"
    ],
    "Audio": [
        null,
        "ఆడియో"
    ],
    "Audio & Video": [
        null,
        "ఆడియో & వీడియో"
    ],
    "Audio & Video Outputs": [
        null,
        "ఆడియో & వీడియో అవుట్ పుట్ "
    ],
    "Aug": [
        null,
        "ఆగ్"
    ],
    "August": [
        null,
        "అగస్ట్"
    ],
    "BACK": [
        null,
        "బ్యాక్"
    ],
    "Back": [
        null,
        "బ్యాక్"
    ],
    "Bangla": [
        null,
        "బంగ్లా "
    ],
    "Bengali": [
        null,
        "బెంగాలీ"
    ],
    "Bhojpuri": [
        null,
        "భోజ్ పురి"
    ],
    "Bihar": [
        null,
        "బీహార్ "
    ],
    "Bihari": [
        null,
        "బిహారీ"
    ],
    "CA Info Sheet": [
        null,
        "CA సమాచార షీట్"
    ],
    "CA Information": [
        null,
        "CA సమాచారం"
    ],
    "CAM Menu": [
        null,
        "CAM మెనూ\n "
    ],
    "CAM Module": [
        null,
        "CAM మాడ్యూల్"
    ],
    "CAM Module not authorized action.": [
        null,
        "CAM మాడ్యూల్ అధీకృత చర్య కాదు."
    ],
    "CAM Module was inserted, Press Ok to reboot STB.": [
        null,
        "CAM మాడ్యూల్ ఇన్సర్ట్ చెయ్యబడింది, STB ని రీబూట్ చెయ్యడం కోసం ఓకే నొక్కండి."
    ],
    "CAM Module was inserted, only the watching of channel will be available.": [
        null,
        "CAM మాడ్యూల్ ఇన్సర్ట్ చెయ్యబడింది, ఛానెల్ చూడటం మాత్రమే అందుబాటులో ఉంటుంది."
    ],
    "CAM Module was removed, Press Ok to reboot STB, in order to enjoy fully the possibility of your box.": [
        null,
        "CAM మాడ్యూల్ తొలగించబడింది, మీ బాక్సును సాధ్యమైనంత ఎక్కువగా ఆస్వాదించడానికి వీలుగా, STB ని రీబూట్ చెయ్యడం కోసం ఓకే నొక్కండి."
    ],
    "CA_SYS_ID:": [
        null,
        "CA_SYS_ID:"
    ],
    "CVBS": [
        null,
        "సీవీబీఎస్ "
    ],
    "Call Center:": [
        null,
        "కాల్ సెంటర్ "
    ],
    "Call me to 57575 from your Registered Mobile Number.": [
        null,
        "CALLME అని మీ నమోదిత మొబైల్ నంబర్ నుంచి 57575 కి ఎస్.ఎం.ఎస్. పంపండి. "
    ],
    "Cancel": [
        null,
        "రద్దు"
    ],
    "Cancel & Exit": [
        null,
        "రద్దు చేయి & నిష్క్రమించు\n "
    ],
    "Cancel Record": [
        null,
        "రికర్డింగ్ క్యాన్సిల్ చేయి"
    ],
    "Cancel Reminder": [
        null,
        "కాన్సల్ రిమైండర్"
    ],
    "Change Freq:": [
        null,
        "ఫ్రీక్వెన్సీ మార్చు :"
    ],
    "Change Language": [
        null,
        "భాషను మార్చండి"
    ],
    "Change Pin Code": [
        null,
        "పిన్ కోడ్ ను మార్చండి"
    ],
    "Change UI Language": [
        null,
        "భాషను మార్చండి"
    ],
    "Change pin code": [
        null,
        "పిన్ కోడ్ మార్చు"
    ],
    "Channel List": [
        null,
        "ఛానెల్ జాబితా"
    ],
    "Channel No. {channelNum} is not subscribed by you.": [
        null,
        "ఛానెల్ నం.{channelNum}కి మీరు సబ్‌స్క్రైబ్ చేసుకోలేదు."
    ],
    "Channel Search": [
        null,
        "చానెల్ సెర్చ్ "
    ],
    "Channel Search Confirmation": [
        null,
        "ఛానెల్ శోధన నిర్ధారణ"
    ],
    "Channel Settings": [
        null,
        "ఛానెల్ సెట్టింగ్స్"
    ],
    "Channel block": [
        null,
        "ఛానెల్ బ్లాక్ "
    ],
    "Channel search": [
        null,
        "ఛానెల్ శోధన"
    ],
    "Channel search completed": [
        null,
        "ఛానెల్ శోధన పూర్తయ్యింది"
    ],
    "Channel:": [
        null,
        "ఛానెల్:"
    ],
    "Channels": [
        null,
        "ఛానెల్స్ "
    ],
    "Chip ID:": [
        null,
        "చిప్ ఐడీ:"
    ],
    "Choose your Network": [
        null,
        "మీ భాషను ఎంచుకోండి"
    ],
    "Choose your language": [
        null,
        "మీ భాషను ఎంచుకోండి"
    ],
    "Close": [
        null,
        "మూసివేయి (క్లోజ్)"
    ],
    "Confirm new pin code": [
        null,
        "కొత్త పిన్ కోడ్ ను ధృవీకరించండి"
    ],
    "Connected": [
        null,
        "కనెక్ట్ అయి ఉన్నది"
    ],
    "Connected USB device is not compatible to the STB.": [
        null,
        "కనెక్ట్ చేయబడిన USB డివైజ్ STB కి కంపాటిబుల్ కాదు."
    ],
    "Contact Us": [
        null,
        "మమ్మల్ని సంప్రదించండి "
    ],
    "Copyright & License Info": [
        null,
        "కాపీ రైట్ & లైసెన్స్ సమాచారం "
    ],
    "Currently no channels are available under this category.": [
        null,
        "ఈ కేటగిరీలో ప్రస్తుతం ఏ ఛానెళ్ళు అందుబాటులో లేవు"
    ],
    "Daily": [
        null,
        "ప్రతి రోజు"
    ],
    "Date:": [
        null,
        "తేదీ:"
    ],
    "Dec": [
        null,
        "డిస్"
    ],
    "December": [
        null,
        "డిసెంబర్ "
    ],
    "Default List Mode": [
        null,
        "డిఫాల్ట్ జాబితా మోడ్ "
    ],
    "Delete": [
        null,
        "డిలీట్ "
    ],
    "Details": [
        null,
        "వివరాలు "
    ],
    "DiSEqC:": [
        null,
        "DiSEqC:"
    ],
    "DishTV add <a-la-carte code> <11 digit VC No.> to 57575": [
        null,
        "DishTV ADD <Add-On code> <11 digit VC No.> to 57575"
    ],
    "DishTV refresh <11 digit VC No.> to 57575": [
        null,
        "DishTV REFRESH <11 digit VC No.> to 57575"
    ],
    "DishTV up <Pack Price> <11 digit VC No.> to 57575": [
        null,
        "DishTV UP <Pack Price> <11 digit VC No.> to 57575"
    ],
    "Do you really want to Format HDD? All data in the disk will be lost": [
        null,
        "మీరు నిజంగా HDD ను ఫార్మాట్ చేయాలనుకుంటున్నారా? డిస్క్ లోని డేటా మొత్తం పోతుంది."
    ],
    "Do you want to activate PVR feature?": [
        null,
        "మీరు PVR ఫీచర్ ని యాక్టివేట్ చెయ్యాలనుకుంటున్నారా?"
    ],
    "Do you want to apply this HDMI resolution?": [
        null,
        "మీరు ఈ HDMI రిజల్యూషన్ ను వర్తింప చేయాలనుకుంటున్నారా?"
    ],
    "Do you want to change IFtoIF mode and launch scan?  Launching scan will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it": [
        null,
        "మీరు ఇఫ్2ఇఫ్ మోడ్ ను మార్చి, స్కాన్ ప్రారంభించాలనుకుంటున్నారా? స్కాన్‌ని ప్రారంభిస్తే, మీ ప్రస్తుత చానెల్స్ జాబితా, మీ ఫెవరేట్ జాబితా డిలీట్ అవుతుంది మరియు ఒకవేళ రికార్డ్ జరుగుతుంటే,వాటిని కోల్పోతారు."
    ],
    "Duration:": [
        null,
        "వ్యవధి:"
    ],
    "EPG": [
        null,
        "ఈపీజి "
    ],
    "EPG Error": [
        null,
        "EPG ఎర్రర్"
    ],
    "Easy Scan": [
        null,
        "ఈజీ స్కాన్ "
    ],
    "Education": [
        null,
        "విద్య"
    ],
    "End Freq: ": [
        null,
        "స్టాప్ ఫ్రీక్వెన్సీ:"
    ],
    "English": [
        null,
        "ఇంగ్లీష్ "
    ],
    "Enhance your experience ": [
        null,
        "మీ అనుభవాన్ని పెంపొందించుకోండి. "
    ],
    "Enter current pin code": [
        null,
        "ప్రస్తుత పిన్ కోడ్ ను ఎంటర్ చెయ్యండి"
    ],
    "Enter new pin code": [
        null,
        "కొత్త పిన్ కోడ్ ను ఎంటర్ చెయ్యండి"
    ],
    "Enter pin code": [
        null,
        "పిన్ కోడ్ ఎంటర్ చెయ్యండి"
    ],
    "Entertainment": [
        null,
        "వినోదం"
    ],
    "Error": [
        null,
        "ఎర్రర్"
    ],
    "Error when trying to connect to Alpha Networks backend.": [
        null,
        "ఆల్ఫా నెట్వర్క్ కు బ్యాకెండ్ నుండి కనెక్ట్ చేయడానికి ప్రయత్నిస్తున్నప్పుడుఎర్రర్ వస్తుంది."
    ],
    "Exit": [
        null,
        "నిష్క్రమణ"
    ],
    "Factory Reset": [
        null,
        "ఫాక్టరీ రీసెట్ "
    ],
    "Factory Setting Confirmation": [
        null,
        "ఫ్యాక్టరీ సెట్టింగు నిర్ధారణ"
    ],
    "Family & Devotional": [
        null,
        "కుటుంబం & భక్తి"
    ],
    "Fast Forward": [
        null,
        "ఫాస్ట్ ఫార్వార్డ్"
    ],
    "Fast Rewind": [
        null,
        "ఫాస్ట్ రివైండ్ "
    ],
    "Favorite Add": [
        null,
        "ఫేవరెట్ జత చేయి"
    ],
    "Favorite Remove": [
        null,
        "ఫేవరెట్ తొలగించు"
    ],
    "Favorite channels": [
        null,
        "ఇష్టమైన ఛానెల్స్"
    ],
    "Favourite List Mode": [
        null,
        "ఫేవరేట్ జాబితా మోడ్ "
    ],
    "Favourites": [
        null,
        "ఇష్టమైనవి"
    ],
    "Feb": [
        null,
        "ఫెబ్"
    ],
    "February": [
        null,
        "ఫిబ్రవరి"
    ],
    "Finish": [
        null,
        "ముగించు"
    ],
    "First Install, Sw Update": [
        null,
        "మొదటి ఇన్‌స్టాల్, Sw అప్డేట్"
    ],
    "For any assistance, call us on:": [
        null,
        "ఎటువంటి సహాయం కోసమైనా, మాకు కాల్ చెయ్యండి:\n "
    ],
    "For resolving no access/unsubscribed channel/card refresh errors:": [
        null,
        "నో యాక్సెస్ / అన్ సబ్‌స్క్రైబ్డ్ ఛానల్ / కార్డు రిఫ్రెష్ ఎర్రర్స్ పరిష్కరించడానికి:"
    ],
    "Force Software Update": [
        null,
        "ఫోర్స్ సాఫ్ట్ వేర్ అప్ డేట్"
    ],
    "Forgot to recharge! Give a Missed Call on \n1800 274 9050 to get your channels NOW. \nPay in next 3 days to enjoy NON STOP TV.": [
        null,
        "సహాయం కొరకు, CALLME అని 57575 కి ఎస్.ఎం.ఎస్. పంపండి."
    ],
    "Format HDD": [
        null,
        "HDD ఫార్మాట్ చేయి "
    ],
    "Format Hard Disk": [
        null,
        "హార్డ్ డిస్క్ ఫార్మాట్ చేయి"
    ],
    "Formatting disk, please wait…": [
        null,
        "డిస్క్ ఫార్మాట్ అవుతుంది, దయచేసి వేచి ఉండండి..."
    ],
    "Free size: ": [
        null,
        "ఫ్రీ సైజు:\n "
    ],
    "French": [
        null,
        "ఫ్రెంచ్ "
    ],
    "Fri": [
        null,
        "శుక్ర"
    ],
    "Friday": [
        null,
        "శుక్ర "
    ],
    "Give a missed call on 1800 274 9511 from your or SMS CALLME to 57575 from your Registered Mobile Number (RMN).": [
        null,
        "సహాయం కొరకు మీ రిజిస్టర్డ్ మొబైల్ నంబర్ నుండి 1860-258-3474 కు  కాల్ చెయ్యండి:, లేదా  CALLME అని టైప్ చేసే  57575 కు ఎస్ ఎం ఎస్ చెయ్యండి"
    ],
    "Guarani": [
        null,
        "గౌరాని"
    ],
    "Gujarati": [
        null,
        "గుజరాతి"
    ],
    "HD Channels": [
        null,
        "HD ఛానెల్స్ "
    ],
    "HDD size: ": [
        null,
        "HDD సైజు: "
    ],
    "HDMI Settings": [
        null,
        "HDMI సెట్టింగ్స్"
    ],
    "HDMI resolution": [
        null,
        "HDMI రిజల్యూషన్ "
    ],
    "Hindi": [
        null,
        "హిందీ"
    ],
    "Home Transponder:": [
        null,
        "హోమ్ ట్రాన్స్‌పాండర్:\n "
    ],
    "Hours:": [
        null,
        "గంటలు: "
    ],
    "IF2IF MODE": [
        null,
        "ఇఫ్2ఇఫ్  మోడ్"
    ],
    "IF2IF OFF": [
        null,
        "ఇఫ్2ఇఫ్ ఆఫ్"
    ],
    "IF2IF ON": [
        null,
        "ఇఫ్2ఇఫ్ ఆన్"
    ],
    "IF2IF mode": [
        null,
        "ఇఫ్2ఇఫ్ మోడ్"
    ],
    "IN CASE OF HEAVY RAIN, WAIT TILL RAIN STOPS TO REGAIN SIGNAL": [
        null,
        "భారీ వర్షం కురుస్తున్నట్లయితే, సిగ్నల్స్ తిగిరి పొందేందుకు వర్షం ఆగే వరకూ వేచి ఉండండి."
    ],
    "If already recharged, please, switch-off & switch-on your Set-Top-Box from the mains and keep it ON for 15 minutes on channel 99": [
        null,
        "రీఛార్జి చేసి ఉంటె, సెట్-టాప్-బాక్స్ ను స్విచ్ ఆఫ్ చేసి ఆన్ చేయండి, తరువాత ఛానల్ నెంబర్ 96 పై 15 నిముషాలు ఆన్ చేసి ఉంచండి "
    ],
    "If problem continues, SMS DISHTV 301 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "సమస్య కొనసాగుతున్నట్లయితే, మీ నమోదిత మొబైల్ నంబర్ నుంచి (RMN) నుండి\n1860-258-3474 కి కాల్ చేయగలరు లేదా CALLME అని 57575 కి ఎస్.ఎం.ఎస్. పంపండి.\n "
    ],
    "If problem continues, SMS DISHTV 302 to 57575,\nfrom your Registered Mobile Number (RMN).": [
        null,
        "ఒకవేళ సమస్య కొనసాగుతూ ఉంటే, మీ నమోదిత మొబైల్ నంబర్ నుంచి (RMN)\nDISHTV 302 అని 57575 కి ఎస్.ఎం.ఎస్. పంపండి, "
    ],
    "Impossible to create a record, please set a valid date/time in the future.": [
        null,
        "రికార్డును క్రియేట్ చెయ్యడం సాధ్యం కాదు, దయచేసి భవిష్యత్తులోని చెల్లుబాటయ్యే తేదీ/సమయం సెట్ చెయ్యండి."
    ],
    "Impossible to remove a channel from favorite while currently browsing Favorite List": [
        null,
        "ఫేవరేట్ జాబితాను బ్రౌజ్ చేస్తున్నప్పుడు, ఫేవరేట్ జాబితా నుండి ఛానెల్ ని తొలగించడం సాధ్యం కాదు"
    ],
    "In order to give you the state of the Transponder we need to stop the records.": [
        null,
        "ట్రాన్స్‌పాండర్ యొక్క స్థితిని మీకు తెలిపేందుకు, మేము రికార్డులు ఆపాస్లి ఉంటుంది."
    ],
    "India (GMT +05:30)": [
        null,
        "ఇండియా (GMT +05:30)"
    ],
    "Informations": [
        null,
        "సమాచారాలు"
    ],
    "Installation": [
        null,
        "ఇన్‌స్టాలేషన్\n "
    ],
    "Instant Message": [
        null,
        "తక్షణ సందేశం"
    ],
    "Insufficient Disk Space": [
        null,
        "చాలినంత డిస్క్ స్పేస్ లేదు"
    ],
    "Interface Version:": [
        null,
        "ఇంటర్ఫేస్ వెర్షన్ "
    ],
    "Interface version:": [
        null,
        "ఇంటర్ఫేస్ వెర్షన్: "
    ],
    "Invalid date": [
        null,
        "చెల్లుబాటు కాని తేదీ "
    ],
    "Jan": [
        null,
        "జాన్ "
    ],
    "January": [
        null,
        "జనవరి"
    ],
    "Jul": [
        null,
        "జూల్"
    ],
    "July": [
        null,
        "జులై"
    ],
    "Jun": [
        null,
        "జూన్"
    ],
    "June": [
        null,
        "జూన్"
    ],
    "Kannada": [
        null,
        "కన్నడ"
    ],
    "Kids & Infotainment": [
        null,
        "కిడ్స్ & ఇన్ఫోటైన్మెంట్ "
    ],
    "LNB Hi Frequency:": [
        null,
        "LNB హై ఫ్రీక్వెన్సీ:"
    ],
    "LNB Low Frequency:": [
        null,
        "LNB లో ఫ్రీక్వెన్సీ:"
    ],
    "LNB Power:": [
        null,
        "LNB పవర్:"
    ],
    "LNB settings": [
        null,
        "LNB సెట్టింగ్స్"
    ],
    "Language": [
        null,
        "భాష "
    ],
    "Language:": [
        null,
        "భాష:"
    ],
    "Last Payment details:": [
        null,
        "గత పేమెంట్ వివరాలు:"
    ],
    "Latin": [
        null,
        "లాటిన్"
    ],
    "Launch": [
        null,
        "లాంచ్"
    ],
    "Launch a scan": [
        null,
        "స్కాన్ ప్రారంభించు"
    ],
    "Leisure hobbies": [
        null,
        "లీజర్ హాబీలు"
    ],
    "Letter Box": [
        null,
        "లెటర్ బాక్స్"
    ],
    "MEDIACENTER": [
        null,
        "మీడియా సెంటర్ "
    ],
    "MOD": [
        null,
        "స్పెషల్స్"
    ],
    "Mac adress isn't valid.": [
        null,
        "Mac అడ్రస్ చెల్లుబాటు కాదు."
    ],
    "Magahi": [
        null,
        "మగాహి"
    ],
    "Malayalam": [
        null,
        "మలయాళం "
    ],
    "Manage favorites": [
        null,
        "ఫేవరేట్ నిర్వహించు (మేనేజ్)"
    ],
    "Mar": [
        null,
        "మార్"
    ],
    "Marathi": [
        null,
        "మరాఠీ"
    ],
    "March": [
        null,
        "మార్చ్"
    ],
    "Master Reset": [
        null,
        "మాస్టర్ రీసెట్"
    ],
    "May": [
        null,
        "మే"
    ],
    "Media center": [
        null,
        "మీడియా సెంటర్"
    ],
    "Mediaplayer Error": [
        null,
        "మీడియా ప్లేయర్ ఎర్రర్"
    ],
    "Middleware Version:": [
        null,
        "మిడిల్ వేర్ వెర్షన్:"
    ],
    "Mon": [
        null,
        "సోమ"
    ],
    "Monday": [
        null,
        "సోమ"
    ],
    "Movie": [
        null,
        "సినిమా"
    ],
    "Movies": [
        null,
        "సినిమాలు"
    ],
    "Music": [
        null,
        "మ్యూజిక్"
    ],
    "Music & Lifestyle": [
        null,
        "సంగీతం & లైఫ్ స్టైల్"
    ],
    "My Account": [
        null,
        "నా అకౌంట్"
    ],
    "My DishTV": [
        null,
        "మై డిష్ టీవీ"
    ],
    "My Recordings": [
        null,
        "నా రికార్డింగ్స్"
    ],
    "NO": [
        null,
        "కాదు"
    ],
    "NO SIGNAL DETECTED": [
        null,
        "ఏ సిగ్నల్ కనుగొనబడలేదు "
    ],
    "NTSC": [
        null,
        "ఎన్.టి.ఎస్.సి."
    ],
    "Network": [
        null,
        "నెట్వర్క్ "
    ],
    "Network Selection": [
        null,
        "నెట్వర్క్ సమాచారం "
    ],
    "Network information": [
        null,
        "నెట్వర్క్ సమాచారం "
    ],
    "News": [
        null,
        "వార్తలు"
    ],
    "News & Business": [
        null,
        "వార్తలు & బిజినెస్ "
    ],
    "Next": [
        null,
        "నెక్స్ట్"
    ],
    "No": [
        null,
        "కాదు"
    ],
    "No CAM Module": [
        null,
        "CAM మాడ్యూల్ లేదు."
    ],
    "No Channels": [
        null,
        "ఛానెల్స్ లేవు"
    ],
    "No Channels Available": [
        null,
        "ఏ ఛానెల్స్ అందుబాటులో లేవు."
    ],
    "No Services": [
        null,
        "సేవలు లేవు "
    ],
    "No TV recordings available": [
        null,
        "రికార్డింగ్స్ ఏవీ లభ్యం లేవు"
    ],
    "No USB Device connected. Connect USB Device to use Recorder features": [
        null,
        "ఏ USB డివైజ్ కనెక్ట్ అయ్యిలేదు. రికార్డర్ ఫీచర్లు వాడడానికి USB డివైజ్ కనెక్ట్ చేయండి"
    ],
    "No applications found.": [
        null,
        "అప్లికేషన్స్ ఏవీ కనుగొనబడలేదు"
    ],
    "No channel": [
        null,
        "ఏ ఛానెల్ లేదు"
    ],
    "No channels available, perform a scan, press back to exit": [
        null,
        "ఛానెల్స్ ఏవీ అందుబాటులో లేవు, స్కాన్ ను నిర్వహించండి, నిష్క్రమించడానికి బ్యాక్ నొక్కండి"
    ],
    "No information": [
        null,
        "సమాచారం లేదు"
    ],
    "No internet connection.": [
        null,
        "ఇంటర్నెట్ కనెక్షన్ లేదు."
    ],
    "No services available. Perform a scan.": [
        null,
        "సేవలు అందుబాటులో లేవు. స్కాన్ నిర్వహించండి. "
    ],
    "None (default)": [
        null,
        "నన్ (డిఫాల్ట్)"
    ],
    "Not Connected": [
        null,
        "కనెక్ట్ అయిలేదు"
    ],
    "Not able to launch application/game": [
        null,
        "ఈ అప్లికేషన్ ప్రస్తుతం లాంచ్ చెయ్యడానికి వీలు కావడంలేదు. కాసేపు ఆగి మళ్ళీ ప్రయత్నించండి"
    ],
    "Nov": [
        null,
        "నవ్"
    ],
    "November": [
        null,
        "నవంబర్"
    ],
    "Number of sessions:": [
        null,
        "సెషన్ల సంఖ్య:"
    ],
    "OK": [
        null,
        "ఓకే"
    ],
    "Oct": [
        null,
        "అక్టో"
    ],
    "October": [
        null,
        "అక్టోబర్"
    ],
    "Ok": [
        null,
        "ఓకే"
    ],
    "Ok ": [
        null,
        "ఓకే"
    ],
    "One Time": [
        null,
        "వన్ టైం\n "
    ],
    "Order an A-La-Carte pack:": [
        null,
        "ఒక ఆ-లా-కార్టే ప్యాక్ ను ఆర్డర్ చెయ్యండి: \n  "
    ],
    "Order by Channel Name": [
        null,
        "క్రమం - పేరు ఆధారంగా"
    ],
    "Order by Channel Name - CAS Only": [
        null,
        "ఛానెల్ పేరుతో ఆర్డర్ చెయ్యండి  - CAS మాత్రమే"
    ],
    "Order by Channel Name - FTA Only": [
        null,
        "ఛానెల్ పేరుతో ఆర్డర్ చెయ్యండి  - FTA మాత్రమే"
    ],
    "Order by LCN": [
        null,
        "LCN ద్వారా ఆర్డర్ చెయ్యండి"
    ],
    "Order now at a SPECIAL PRICE!": [
        null,
        "ఇప్పుడే ఆర్డర్ చేసి తగ్గింపు ధరకు పొందండి"
    ],
    "Ordering": [
        null,
        "ఆర్డరింగ్"
    ],
    "Oriya": [
        null,
        "ఒరియా"
    ],
    "PAL": [
        null,
        "పి.ఎ.ఎల్."
    ],
    "PINs do not match.": [
        null,
        "PINs సరిపోలడం లేదు."
    ],
    "PM": [
        null,
        "పి ఎం"
    ],
    "PVR & TS": [
        null,
        "పీవీఆర్ & టీఎస్ "
    ],
    "Panjabi": [
        null,
        "పంజాబీ"
    ],
    "Parental Control": [
        null,
        "పేరెంటల్ కంట్రోల్ "
    ],
    "Parental Control Settings": [
        null,
        "పేరెంటల్ కంట్రోల్ సెట్టింగ్స్"
    ],
    "Pause": [
        null,
        "పాజ్ "
    ],
    "Pillar Box": [
        null,
        "పిల్లర్ బాక్స్ "
    ],
    "Play": [
        null,
        "ప్లే"
    ],
    "Please Plug-in CAM to view CAM Menu.": [
        null,
        "CAM మెనూ ను వీక్షించడానికి దయచేసి CAM ని ప్లగ్-ఇన్ చెయ్యండి."
    ],
    "Please Plugin USB Device Properly": [
        null,
        "దయచేసి USB డివైజ్ ని సరిగ్గా ప్లగ్ ఇన్ చెయ్యండి "
    ],
    "Please RECHARGE YOUR DISHTV VC No {vcNum} \nLog on www.dishtv.in use Credit/Debit card walk into: Nearest Recharge Outlet": [
        null,
        "దయచేసి VC నంబర్ {vcNum} రీచార్జ్ చేసుకోండి.\nఅందుకొరకు www.dishtv.in పై లాగాన్ అయ్యి రరీఛార్జి చేసుకోవచ్చు"
    ],
    "Please Select Network:": [
        null,
        "దయచేసి FEC ని ఎంచుకోండి:"
    ],
    "Please Wait ...": [
        null,
        "దయచేసి వేచి ఉండండి..."
    ],
    "Please check your antenna cable": [
        null,
        "దయచేసి మీ యంటేనా కేబుల్ ను తనిఖీ చెయ్యండి "
    ],
    "Please check your subscription": [
        null,
        "దయచేసి మీ సబ్స్క్రిప్షన్ ను తనిఖీ చేసుకోండి."
    ],
    "Please choose a Filter": [
        null,
        "దయచేసి ఒక ఫిల్టర్ ను ఎంచుకోండి"
    ],
    "Please choose a language": [
        null,
        "దయచేసి ఒక భాషను ఎంచుకోండి"
    ],
    "Please ensure that your set-Top-Box is properly connected to the DISHTV antenna": [
        null,
        "దయచేసి మీ సెట్-టాప్-బాక్స్ డిష్ టివి యాంటెన్నాకి సరిగ్గా కనెక్ట్ చేయబడిందని నిర్ధారించుకోండి"
    ],
    "Please enter PIN to select IF2IF mode, this will launch scan and it will delete your recording and favourite list.": [
        null,
        "ఇఫ్2ఇఫ్ మోడ్ ఎంచుకోడానికి దయచేసి PIN ఎంటర్ చెయ్యండి, ఇది స్కాన్‌ని లాంచ్ చేసి, మీ రికార్డింగ్ మరియు ఫేవరేట్ జాబితాని తొలగిస్తుంది.\n  "
    ],
    "Please enter Symbol rate:": [
        null,
        "దయచేసి సింబల్ రేట్ ఎంటర్ చెయ్యండి:"
    ],
    "Please select FEC:": [
        null,
        "దయచేసి FEC ని ఎంచుకోండి:"
    ],
    "Please select Polarization:": [
        null,
        "దయచేసి పోలరైజేషన్ ని ఎంచుకోండి:"
    ],
    "Please wait while the USB connection is being established": [
        null,
        "USB కనెక్షన్ ఎస్టాబ్లిష్ అవుతోంది, దయచేసి వేచి ఉండండి"
    ],
    "Please, POWER OFF – POWER ON your Set-Top-Box from switch.": [
        null,
        "దయచేసి, స్విచ్ నుండి మీ సెట్-టాప్-బాక్స్ ని పవర్ ఆఫ్ - పవర్ ఆన్ చెయ్యండి"
    ],
    "Press \"OK\" on your remote to re-install channels and services. \nIf problem continues, SMS DISHTV 303 to 57575 from your registered Mobile Number (RMN). To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "దయచేసి మీ ఛానెల్లను పునరుద్ధరించడానికి మీ రిమోట్లో OK బటన్ నొక్కండి,\nసమస్య కొనసాగితే, Call: 1860-258-3474 లేదా SMS: CALLME to 57575 చేయగలరు మీ నమోదిత మొబైల్ నంబర్ నుండి"
    ],
    "Press BACK to save & exit or OK for details": [
        null,
        "సేవ్ చేసి నిష్క్రమించడానికి BACK నొక్కండి లేదా వివరాల కోసం OK నొక్కండి"
    ],
    "Press Back for STB InfoSheet": [
        null,
        "STB సమాచార షీట్ కోసం BACK నొక్కండి\n "
    ],
    "Press Back for Tools": [
        null,
        "టూల్స్ కోసం BACK నొక్కండి"
    ],
    "Press Back to exit from active service": [
        null,
        "నిష్క్రమించడానికి BACK ప్రెస్ చెయ్యండి"
    ],
    "Press Menu to Exit": [
        null,
        "నిష్క్రమించడం కోసం MENU నొక్కండి"
    ],
    "Press OK for details": [
        null,
        "వివరాల కోసం ఓకే నొక్కండి"
    ],
    "Press OK to Save my schedule": [
        null,
        "మై షెడ్యూల్ ను సేవ్ చెయ్యడానికి OK నొక్కండి"
    ],
    "Press OK to confirm": [
        null,
        "ధృవీకరించడానికి ఓకే నొక్కండి"
    ],
    "Press OK to exit": [
        null,
        "నిష్క్రమించడానికి OK నొక్కండి"
    ],
    "Press OK to launch EASY SCAN": [
        null,
        "ఈజీ స్కాన్ ను లాంచ్ చెయ్యడానికి ఓకే నొక్కండి"
    ],
    "Punjabi": [
        null,
        "పంజాబీ "
    ],
    "RECORDS": [
        null,
        "రికార్డ్స్ "
    ],
    "Radios": [
        null,
        "రేడియోలు"
    ],
    "Rajasthani": [
        null,
        "రాజస్థానీ"
    ],
    "Rec": [
        null,
        "రికార్డింగ్ "
    ],
    "Recharge Reminder": [
        null,
        "రీఛార్జి రిమైండర్ "
    ],
    "Record": [
        null,
        "రికార్డ్"
    ],
    "Recording  can't be done because The {channelTitle} doesn't have any program information": [
        null,
        "రికార్డింగ్ చేయడం సాధ్యం కాదు, ఎందుకంటే {channelTitle}కి ప్రోగ్రాంకి సంబంధించిన ఏ సమాచారం లేదు"
    ],
    "Recording Alert": [
        null,
        "రికార్డింగ్ హెచ్చరిక"
    ],
    "Recording Alert: Record Vs Reminder": [
        null,
        "రికార్డింగ్ హెచ్చరిక:  రికార్డ్ Vs రిమైండర్  "
    ],
    "Recording Conflict": [
        null,
        "రికార్డింగ్ వైరుధ్యం"
    ],
    "Recording failed": [
        null,
        "రికార్డింగ్ విఫలమైంది"
    ],
    "Recording features are not authorized on this channel": [
        null,
        "ఈ ఛానెల్లో రికార్డింగ్ ఫీచర్లు అధీకృతం కావు."
    ],
    "Recording in progress": [
        null,
        "రికార్డింగ్ జరుగుతుంది"
    ],
    "Recording in progress. \nPress OK to stop record and continue. \n Press BACK to close the message and return to the live stream.": [
        null,
        "రికార్డింగ్ జరుగుతుంది. \nరికార్డింగ్ నిలిపివేసి, కొనసాగించడానికి ఓకే నొక్కండి. \nసందేశాన్ని మూసివేసి, లైవ్ స్ట్రీం కి తిరిగి రావడానికి బ్యాక్ నొక్కండి "
    ],
    "Recording in progress. If you continue you will lose your record.": [
        null,
        "రికార్డింగ్ జరుగుతున్నది. మీరు కొనసాగితే మీ రికార్డ్ ను కోల్పోతారు."
    ],
    "Recording is not possible on past event.": [
        null,
        "గత ఈవెంట్ ను రికార్డ్ చేయడం సాధ్యం కాదు"
    ],
    "Recurrence:": [
        null,
        "పునరావృతం: "
    ],
    "Regional": [
        null,
        "ప్రాంతీయ "
    ],
    "Regional Hindi": [
        null,
        "ప్రాంతీయ హిందీ "
    ],
    "Register your Mobile No.:": [
        null,
        "మీ మొబైల్ నంబర్ ను నమోదు చేసుకోండి:"
    ],
    "Reminder": [
        null,
        "రిమైండర్ "
    ],
    "Reminder Alert": [
        null,
        "రిమైండర్ హెచ్చరిక "
    ],
    "Reminder Conflict": [
        null,
        "రిమైండర్ వైరుధ్యం"
    ],
    "Reminder can't be applied as program has no information.": [
        null,
        "ప్రోగ్రాంకు సమాచారం లేనందున రిమైండర్ వర్తింపచేయడం వీలు పడదు."
    ],
    "Reminder or Recording is already set for this Program": [
        null,
        "ఈ ప్రోగ్రామ్ కోసం రిమైండర్ లేదా రికార్డింగ్ ముందే సెట్ చేయబడింది"
    ],
    "Reset": [
        null,
        "రీసెట్"
    ],
    "Reset Setting Confirmation": [
        null,
        "రీసెట్ సెట్టింగు నిర్ధారణ"
    ],
    "Reset favorites": [
        null,
        "ఫేవరేట్స్ రీసెట్ చేయి"
    ],
    "Resume playback": [
        null,
        "రెస్యూమ్ ప్లేబాక్ "
    ],
    "Retrieving active service, please wait.": [
        null,
        "మీ యాక్టివ్ సర్వీసులను మేము పునరుద్ధరిస్తున్నాము, కాస్తా వేచి ఉండండి"
    ],
    "Return to STB InfoSheet": [
        null,
        "STB సమాచార షీట్ కి తిరిగి వెళ్ళు"
    ],
    "SCRAMBLED CHANNEL": [
        null,
        "స్క్రాంబిల్డ్ ఛానెల్ "
    ],
    "SELECT GENRE": [
        null,
        "శైలిని ఎంచుకోండి"
    ],
    "SMS DISHTV CALL ME to 57575 from your registered mobile number (RMN).": [
        null,
        "మీ నమోదిత మొబైల్ నంబర్ (RMN) నుండి DISHTV CALL ME అని 57575కి ఎస్.ఎం.ఎస్. చేయండి."
    ],
    "SMS MOD {vcNum} {PurchaseCode} to 57575. If you do not get the movie with in 10 minutes after sending ": [
        null,
        "MOD {vcNum} {PurchaseCode} అని 57575కి ఎస్.ఎం.ఎస్. పంపండి. ఒకవేళ పంపిన 10 నిమిషాల తర్వాత మీరు మూవీని పొందకపోతే "
    ],
    "SMS Services": [
        null,
        "ఎస్.ఎం.ఎస్. సర్వీస్"
    ],
    "SMS: DISHTV ADD {channelNum} to 57575 \nfrom your Registered Mobile Number": [
        null,
        "ధరల వివరాల కోసం,  dishtv.in లో చూడండి \n"
    ],
    "STB Info Sheet": [
        null,
        "STB సమాచార షీట్"
    ],
    "STB InfoSheet": [
        null,
        "STB సమాచార షీట్"
    ],
    "STB Information": [
        null,
        "STB సమాచారం "
    ],
    "STB No": [
        null,
        "STB నంబర్"
    ],
    "STB No:": [
        null,
        "STB నం:"
    ],
    "Sat": [
        null,
        "శని "
    ],
    "Satellite": [
        null,
        "శాటిలైట్ (ఉపగ్రహం)"
    ],
    "Saturday": [
        null,
        "శని "
    ],
    "Save & Exit": [
        null,
        "సేవ్ చేయి & నిష్క్రమించు\n "
    ],
    "Scan Ongoing": [
        null,
        "స్కాన్ జరుగుతుంది"
    ],
    "Schedule Your Recording": [
        null,
        "మీ రికార్డింగ్ ని షెడ్యూల్ చేయండి"
    ],
    "Screen Adjustment": [
        null,
        "స్క్రీన్ సర్దుబాటు"
    ],
    "Security client ID:": [
        null,
        "సెక్యూరిటీ క్లయింట్ ఐడీ:"
    ],
    "Security client version:": [
        null,
        "సెక్యూరిటీ క్లయింట్ వెర్షన్:"
    ],
    "Select on your remote control the biggest number displayed": [
        null,
        "మీ రిమోట్ కంట్రోల్లో ప్రదర్శించబడే అతిపెద్ద సంఖ్యను ఎంచుకోండి"
    ],
    "Self-help": [
        null,
        "ససహాయం"
    ],
    "Sep": [
        null,
        "సెప్"
    ],
    "September": [
        null,
        "సెప్టెంబర్"
    ],
    "Serie": [
        null,
        "సిరీ"
    ],
    "Set Reminder": [
        null,
        "సెట్ ిమైండర్"
    ],
    "Settings": [
        null,
        "సెట్టింగ్స్"
    ],
    "Should your services not restart in 15 minutes, \nSMS DISHTV REFRESH to 57575 \nfrom your registred Mobile Number": [
        null,
        "మీ సేవలు 15 నిమిషాలలో తిరిగి ప్రారంభం కాకపొతే, మీ నమోదిత మొబైల్ నంబర్ నుంచి,18002702102 కి మిస్డ్ కాల్ ఇవ్వగలరు"
    ],
    "Show": [
        null,
        "షో "
    ],
    "Social/Politics": [
        null,
        "సోషల్ / పాలిటిక్స్ "
    ],
    "Sorry this action is not permitted with a CAM, remove it and switch off switch on your box in order to use this feature.": [
        null,
        "క్షమించండి ఈ చర్య CAM తో అనుమతించబడదు, దీన్ని తొలగించండి. భవిష్యత్తులో ఈ ఫీచర్ ని ఉపయోగించడం కోసం మీ బాక్సును స్విచ్ ఆఫ్ స్విచ్ ఆన్ చెయ్యండి. "
    ],
    "Sports": [
        null,
        "క్రీడలు"
    ],
    "SriLanka (GMT +05:30)": [
        null,
        "శ్రీలంక (GMT +05:30)"
    ],
    "Start Freq: ": [
        null,
        "స్టార్ట్ ఫ్రీక్వెన్సీ:"
    ],
    "Start Scan": [
        null,
        "స్కాన్ మొదలుపెట్టు"
    ],
    "Stop": [
        null,
        "స్టాప్ "
    ],
    "Stop & save": [
        null,
        "స్టాప్ & సేవ్ "
    ],
    "Stop Record": [
        null,
        "రికార్డింగ్ ఆపు"
    ],
    "Subscribe to this channel in HD picture \nquality along with {noOfHdChannels} more HD channels \nat  Rs. {priceTag} per month.": [
        null,
        " సబ్స్ క్రైబ్ చెయ్యడానికి DISHTV GET {channelNum} అని టైప్ చేసి మీ ఆర్ఎంఎన్ నుండి 57575కు ఎస్ఎంఎస్ చెయ్యండి. \n"
    ],
    "Subscription Information": [
        null,
        "సబ్ స్క్రిప్షన్ సమాచారం"
    ],
    "Subtitles": [
        null,
        "సబ్ టైటిల్స్"
    ],
    "Sun": [
        null,
        "ఆది"
    ],
    "Sunday": [
        null,
        "ఆది "
    ],
    "Switch off date:": [
        null,
        "స్విచ్ ఆఫ్ తేదీ:"
    ],
    "Switch to HD Now for ultra-clear picture quality and 5.1 surround sound": [
        null,
        "చెయ్యదు. అందువల్ల స్పష్టమైన పిక్చర్ క్వాలిటీ మరియు 5.1. సరౌండ్ కోండ్ కోసం హెచ్ డి సెట్ – టాప్ – బాక్స్ తీసుకోండి"
    ],
    "System Information": [
        null,
        "సిస్టం సమాచారం "
    ],
    "System information": [
        null,
        "సిస్టం సమాచారం "
    ],
    "TP Info": [
        null,
        "TP సమాచారం"
    ],
    "TP list screen": [
        null,
        "TP జాబితా స్క్రీన్"
    ],
    "TV": [
        null,
        "టీవీ"
    ],
    "TV Channels": [
        null,
        "టివి ఛానెల్స్"
    ],
    "TV Guide": [
        null,
        "టీవీ గైడ్"
    ],
    "TV Type": [
        null,
        "టీవీ రకం\n "
    ],
    "TV type": [
        null,
        "TV రకం"
    ],
    "TV: {tvFound}     Radios: {radioFound}      Network: {networkFound}": [
        null,
        "టివి: {tvFound}    రేడియోలు: {radioFound}     నెట్వర్క్: {networkFound}"
    ],
    "Tamil": [
        null,
        "తమిళ్ "
    ],
    "Telugu": [
        null,
        "తెలుగు"
    ],
    "The STB is not able to format the connected USB device. Use Another device": [
        null,
        "కనెక్ట్ చేయబడిన USB డివైజ్ ని STB ఫార్మాట్ చేయలేకపోతుంది. దయచేసి మరొక డివైజ్ ఉపయోగించండి"
    ],
    "The Sw version details are not provided, System can’t verify if a new Sw version is available": [
        null,
        "Sw వెర్షన్ వివరాలు అందించబడలేదు, ఒకవేళ కొత్త Sw వెర్షన్ అందుబాటులో ఉంటే సిస్టం వెరిఫై చెయ్యలేదు."
    ],
    "The program {scheduleTitle} can't be recorded because no compliant USB device connected.": [
        null,
        "ఈ ప్రోగ్రాం {scheduleTitle} రికార్డ్ చెయ్యబడలేదు, ఎందుకంటే సరైన USB డివైజ్ కనెక్ట్ చేయబడలేదు."
    ],
    "The signal to your Set-Top-Box is temporarily unavailable.": [
        null,
        "మీ సెట్-టాప్-బాక్సు కి సిగ్నల్ తాత్కాలికంగా అందుబాటులో లేదు."
    ],
    "The size of the connected USB Device is not enough to enable Recorder features. Please insert a USB Device with minimum 1GB capacity.": [
        null,
        "రికార్డర్ ఫీచర్లను ప్రారంభించడానికి కనెక్ట్ చేయబడిన USB డివైజ్ యొక్క సైజు సరిపోదు. దయచేసి కనీసం 1GB సామర్ధ్యం కల ఒక USB డివైజ్ ఇన్సర్ట్ చెయ్యండి."
    ],
    "There is a TV recording in progress. You cannot access to radio universe": [
        null,
        "ఒక టీవీ రికార్డింగ్ జరుగుతూ ఉన్నది. మీరు రేడియో యూనివర్స్ ని యాక్సెస్ చెయ్యలేరు"
    ],
    "This Channel Is Blocked": [
        null,
        "ఈ ఛానెల్ బ్లాక్ చెయ్యబడింది"
    ],
    "This channel is available in High Definition.": [
        null,
        "ఈ ఛానెల్ హై-డెఫినిషన్ లో లభిస్తుంది."
    ],
    "This program can't be recorded because another TV recording is planned at the same time on {channelName} starting at {startDate}.": [
        null,
        "ఈ కార్యక్రమం రికార్డ్ చేయడానికి వీలవ్వదు, ఎందుకంటే ఇదే సమయంలో {channelName} పై {startDate} నుండి మరొక టీవీ రికార్డింగ్ ప్లాన్ చెయ్యబడింది."
    ],
    "Thu": [
        null,
        "గురు"
    ],
    "Thursday": [
        null,
        "గురు "
    ],
    "Time Format": [
        null,
        "టైం ఫార్మాట్ "
    ],
    "Time Settings": [
        null,
        "టైం సెట్టింగ్స్"
    ],
    "Time Zone Format": [
        null,
        "టైం జోన్ ఫార్మాట్ "
    ],
    "Timeshift & PVR feature will not work": [
        null,
        "టైం షిఫ్ట్ & PVR ఫీచర్ పనిచెయ్యదు "
    ],
    "To RMN SMS DISHTV RMN {vcNum} to 57575": [
        null,
        "RMN కొరకు DISHTV RMN {vcNum} అని 57575 కి ఎస్.ఎం.ఎస్. చేయండి."
    ],
    "To RMN, SMS DISHTV RMN {vcNum} to 57575.": [
        null,
        "RMN కొరకు, DISHTV RMN {vcNum} అని 57575 కి ఎస్.ఎం.ఎస్. పంపండి."
    ],
    "To Register your Mobile Number, \nSMS: DISHTV RMN {vcNum} to 57575": [
        null,
        "మీ మొబైల్ నంబర్ ను నమోదు చేసుకోడానికి,\nDISHTV RMN {vcNum} అని 57575కి ఎస్.ఎం.ఎస్. పంపండి"
    ],
    "To Register your Mobile Number, SMS: \nDISHTV RMN {vcNum} to 57575": [
        null,
        "మీ మొబైల్ నంబర్ ను నమోదు చేసుకోడానికి,\nDISHTV RMN {vcNum} అని 57575కి ఎస్.ఎం.ఎస్. పంపండి"
    ],
    "To allow timely updation, after ordering a \nchannel, please switch-off & switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channnel 99 for 15 minutes.": [
        null,
        "సకాలంలో అప్ డేట్ చేయడానికి వీలుగా, ఒక ఛానెల్‌ను ఆర్డర్ చేసిన\nతరువాత, దయచేసి మీ సెట్-టాప్-బాక్స్ ను ప్రధాన పవర్ సప్లై నుండి\nస్విచ్-ఆఫ్ చేసి మళ్ళీ స్విఛ్ ఆన్ చేయండి, తరువాత\nఛానెల్ 96 పై 15 నిమిషాలు ఉంచండి."
    ],
    "To get a call from us just SMS:": [
        null,
        "మా నుంచి కాల్ పొందడం కోసం ఎస్.ఎం.ఎస్. చెయ్యండి:"
    ],
    "To order {EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}": [
        null,
        "ఆర్డర్ చెయ్యడానికి  {EventName} (పెయిడ్ సినిమా {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}"
    ],
    "To subscribe this channel, \nSMS: DISHTV GET {channelNum} to 57575 \nFrom your Registered Mobile Number (RMN)": [
        null,
        "ఈ ఛానెల్ కి సబ్స్క్రైబ్ చెయ్యడం కోసం, \nమీ నమోదిత ఫోన్ నంబరు నుండి (RMN) నుండి \nDISHTV GET {channelNum} అని 57575కి ఎస్.ఎం.ఎస్. చేయండి"
    ],
    "To update My Account, give a MISSED CALL on 1800-274-4744 from your RMN": [
        null,
        "మై అకౌంట్ అప్ డేట్ చెయ్యడానికి, మీ నమోదిత మొబైల్ నంబర్ (RMN) నుంచి 1800-274-4744 కి మిస్డ్ కాల్ ఇవ్వండి"
    ],
    "Tools": [
        null,
        "టూల్స్ "
    ],
    "Total services found": [
        null,
        "కనుగొనబడిన మొత్తం సేవలు"
    ],
    "Total services found: {serviceFound}.": [
        null,
        "కనుగొనబడిన మొత్తం సేవలు : {serviceFound}."
    ],
    "Transponder Information": [
        null,
        "ట్రాన్స్ పాండర్ సమాచారం"
    ],
    "Transponder List": [
        null,
        "ట్రాన్స్‌పాండర్ జాబితా\n "
    ],
    "Tue": [
        null,
        "మంగళ "
    ],
    "Tuesday": [
        null,
        "మంగళ "
    ],
    "Tuned channel will be changed if new recording started on this channel.": [
        null,
        "ఈ ఛానెల్లో కొత్త రికార్డింగ్ ప్రారంభిస్తే ట్యూన్ చేసిన ఛానెల్ మార్చబడుతుంది."
    ],
    "USB Device Not Inserted Properly": [
        null,
        "USB డివైజ్ సరిగా ఇన్సర్ట్ చేయబడలేదు"
    ],
    "USB Device Unplugged": [
        null,
        "USB డివైజ్ అన్ ప్లగ్ చెయ్యబడినది"
    ],
    "USB Formatted": [
        null,
        "USB ఫార్మాట్ చెయ్యబడినది"
    ],
    "USB Formatting...": [
        null,
        "USB ఫార్మాట్ అవుతుంది... "
    ],
    "USB disk size not compliant with PVR & TS requirements. Minimal free size to activate = 10Go": [
        null,
        "PVR & TS అవసరాలకు USB డిస్క్ సైజ్ అనుకూలంగా లేదు. యాక్టివేట్ చెయ్యడానికి కనీస ఫ్రీ సైజ్ = 10Go"
    ],
    "Unable to play this asset.": [
        null,
        "ఈ అసెట్ ప్లే చేయడం సాధ్యపడడం లేదు."
    ],
    "Unable to play this file. Press BACK or OK key to return to Mediaplayer explorer.": [
        null,
        "ఈ ఫైలును ప్లే చేయడం సాధ్యపడడం లేదు. మీడియాప్లేయర్ ఎక్స్ ప్లోరర్ కు తిరిగి వెళ్లేందుకు బ్యాక్ లేదా ఓకే కీని నొక్కండి."
    ],
    "Unable to play this file. Press BACK or OK key to return to Recording.": [
        null,
        "ఈ ఫైలును ప్లే చేయడం సాధ్యపడడం లేదు. రికార్డింగ్ కు తిరిగి వెళ్లేందుకు బ్యాక్ లేదా ఓకే కీని నొక్కండి."
    ],
    "Updates Ongoing....": [
        null,
        "నవీకరణలు జరుగుతున్నవి...\n "
    ],
    "Upgrade your pack:": [
        null,
        "మీ ప్యాక్ ను అప్‌గ్రేడ్ చేసుకోండి:"
    ],
    "Urdu": [
        null,
        "ఉర్దూ"
    ],
    "Usb key has been Unplugged": [
        null,
        "USB కీ అన్ ప్లగ్ చెయ్యబడింది. "
    ],
    "Usb key successfully formatted": [
        null,
        "USB కీ విజయవంతంగా ఫార్మాట్ చెయ్యబడినది "
    ],
    "Use Favourites List As Channel List": [
        null,
        "ఫేవరేట్ జాబితాను ఛానెల్ జాబితాగా ఉపయోగించండి"
    ],
    "Use default list": [
        null,
        "డిఫాల్ట్ జాబితా ఉపయోగించు "
    ],
    "Use favourite list": [
        null,
        "ఫేవరేట్ లిస్టు వాడు"
    ],
    "VC No": [
        null,
        "VC నంబర్\n "
    ],
    "VC No:": [
        null,
        "VC నం:"
    ],
    "VC Number:": [
        null,
        "VC నంబర్:\n "
    ],
    "VOD Error": [
        null,
        "VOD ఎర్రర్ "
    ],
    "Vod catalog loading aborted by user.": [
        null,
        "యూజర్ ద్వారా Vod కాటలాగ్ లోడింగ్ నిలిపివేయబడింది."
    ],
    "Vod initialization aborted.": [
        null,
        "Vod ప్రారంభించడం నిలిపివేయబడినది."
    ],
    "Watch": [
        null,
        "వాచ్ "
    ],
    "Website:": [
        null,
        "వెబ్‌సైట్:"
    ],
    "Wed": [
        null,
        "బుధ"
    ],
    "Wednesday": [
        null,
        "బుధ "
    ],
    "Week Days": [
        null,
        "వీక్ రోజులు"
    ],
    "Weekly": [
        null,
        "ప్రతి వారం"
    ],
    "Wrong pin code !": [
        null,
        "తప్పు పిన్ కోడ్!"
    ],
    "YES": [
        null,
        "అవును"
    ],
    "Yes": [
        null,
        "అవును"
    ],
    "You are now browsing you default channel list .\nPress FAV button to switch to your Favourite Channels list.": [
        null,
        "ఇప్పుడు మీరు డిఫాల్ట్ ఛానల్ జాబితాను బ్రౌజ్ చేస్తున్నారు. \nమీ ఫేవరేట్ ఛానెల్స్ జాబితా కి వెళ్లేందుకు FAV బటన్ మీద క్లిక్ చెయ్యండి."
    ],
    "You are now browsing your Favourite Channels list. \n Press Fav button to switch to Default channel list.": [
        null,
        "మీరు ఇప్పుడు మీ ఇష్టమైన ఛానెళ్ళ జాబితాను బ్రౌజ్ చేస్తున్నారు.\nడిఫాల్ట్ ఛానెల్ జాబితాకు మారడానికి Fav బటన్ ను నొక్కండి."
    ],
    "You have reached the end of this content.": [
        null,
        "మీరు ఈ కంటెంట్ యొక్క ముగింపుకు చేరుకున్నారు."
    ],
    "You will launch a  Reset, All of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "మీరు ప్రారంభించే రీసెట్ వల్ల, మీ అన్ని సెట్టింగ్ లూ డిఫాల్ట్ విలువకు పునరుద్ధరించబడతాయి. ఏదైనా రికార్డింగు జరుగుతూ ఉంటే, మీరు దానిని కోల్పోతారు"
    ],
    "You will launch a Channel Search that will delete your current list of channels,  Your favorite list and if a record is in progress you will lose it.": [
        null,
        "మీ ప్ర్రస్తుత ఛానెళ్ళ జాబితా మరియు ఫెవరేట్ జాబితా డిలీట్ అయ్యే మరియు ప్రస్తుతం ఏదైనా రికార్డింగ్ జరుగుతుంటే దాన్ని కోల్పోయే చానెల్ శోధనను మీరు ప్రారంభిస్తున్నారు."
    ],
    "You will launch a Factory Reset, Some of your settings will be restored to the default value.If a record is in progress you will lose it.": [
        null,
        "మీరు ఫ్యాక్టరీ రీసెట్ ను ప్రారంభిస్తారు. మీ సెట్టింగులలో కొన్ని డిఫాల్ట్ విలువకు పునరుద్ధరించబడతాయి. ఏదైనా రికార్డు జరుగుతూ ఉంటే, మీరు దానిని కోల్పోతారు."
    ],
    "Your Set-Top-Box is being updated, Please wait…": [
        null,
        "మీ సెట్-టాప్-బాక్స్ అప్ డేట్ అవుతోంది, దయచేసి వేచి ఉండండి..."
    ],
    "Your TV will be switched off, today. Recharge immediately to avoid disruption in service.": [
        null,
        "ఈ రోజు మీ టీవీ స్విచ్ ఆఫ్ చేయబడుతుంది. సేవలో అంతరాయం నిరోధించడానికి వెంటనే రీఛార్జ్ చేయండి."
    ],
    "Your current Set-Top-Box box doesn't support this HD channel": [
        null,
        "ప్రప్స్తుతం ఉన్న మీ సెట్ – టాప్ – బాక్స్ హెచ్ డి చానల్స్ కు సపోర్ట్"
    ],
    "Your pin code has been successfully updated !": [
        null,
        "మీ పిన్ కోడ్ విజయవంతంగా అప్‌డేట్ చెయ్యబడింది!"
    ],
    "Your program {programName} on channel {channelNum} {channelName} will start at {startHour}. Do you want to tune the channel?": [
        null,
        "మీ ప్రోగ్రాం  {programName} {channelNum} {channelName} ఛానెల్ లో {startHour} కి ప్రారంభమవుతుంది. మీరీ ఛానెల్ కి ట్యూన్ కావాలనుకుంటున్నారా ?"
    ],
    "Your recharge date is near. Your TV will be switched off in {count} days. Please recharge immediately to avoid disruption in service.": [
        null,
        "మీ రీఛార్జ్ తేదీ సమీపంలో ఉంది. మీ టీవీ {count} రోజులలో స్విచ్ ఆఫ్ అవుతుంది. సేవలో అంతరాయం నిరోధించడానికి దయచేసి వెంటనే రీఛార్జ్ చేయండి."
    ],
    "Youth": [
        null,
        "యూత్ "
    ],
    "[vod]AssetVoucherCodeMessage": [
        null,
        "[vod]అసెట్ వోచర్ కోడ్ మెసేజ్"
    ],
    "[vod]AssetVoucherCodeTitle": [
        null,
        "[vod]అసెట్ వోచర్ కోడ్ టైటిల్ "
    ],
    "[vod]BuyPackError": [
        null,
        "[vod]బై ప్యాక్ ఎర్రర్ "
    ],
    "[vod]PackVoucherCodeMessage": [
        null,
        "[vod]ప్యాక్ వోచర్ కోడ్ మెసేజ్ "
    ],
    "[vod]PackVoucherCodeTitle": [
        null,
        "[vod]ప్యాక్ వోచర్ కోడ్ టైటిల్"
    ],
    "[vod]Play": [
        null,
        "[vod]ప్లే"
    ],
    "[vod]PlayAssetError": [
        null,
        "[vod]ప్లే అసెట్ ఎర్రర్ "
    ],
    "[vod]Rent": [
        null,
        "[vod]రెంట్"
    ],
    "[vod]RentAssetError": [
        null,
        "[vod]రెంట్ అసెట్ ఎర్రర్"
    ],
    "[vod]VideoLoading": [
        null,
        "[vod]వీడియో లోడింగ్"
    ],
    "[vod]VoucherDigitError": [
        null,
        "[vod]వోచర్ డిజిట్ ఎర్రర్"
    ],
    "[vod]anCurrency": [
        null,
        "[vod]ఒక కరెన్సీ "
    ],
    "[vod]anLanguage": [
        null,
        "[vod] ఒక భాష"
    ],
    "[vod]buyPack": [
        null,
        "[vod]ప్యాక్ కొనుగోలు "
    ],
    "[vod]loadingTitle": [
        null,
        "[vod] టైటిల్ లోడ్ అవుతుంది"
    ],
    "authentication status": [
        null,
        "ధృవీకరణ స్థితి"
    ],
    "conflicting with": [
        null,
        "సంఘర్షిస్తుంది"
    ],
    "dishtv.in": [
        null,
        "dishtv.in"
    ],
    "dns1": [
        null,
        "dns1"
    ],
    "dns2": [
        null,
        "dns2"
    ],
    "failed": [
        null,
        "విఫలమైంది (ఫెయిల్డ్)"
    ],
    "gateway": [
        null,
        "గేట్ వే"
    ],
    "interface": [
        null,
        "ఇంటర్ఫేస్"
    ],
    "ip_address": [
        null,
        "ip_address"
    ],
    "mac_address": [
        null,
        "mac_address"
    ],
    "malayalam": [
        null,
        "మలయాళం"
    ],
    "manipuri": [
        null,
        "మణిపురి"
    ],
    "nd": [
        null,
        "వ"
    ],
    "nepali": [
        null,
        "నేపాలి"
    ],
    "netmask": [
        null,
        "నెట్ మాస్క్ "
    ],
    "no": [
        null,
        "కాదు (లేదు)"
    ],
    "ok": [
        null,
        "ఓకే"
    ],
    "rd": [
        null,
        "వ"
    ],
    "st": [
        null,
        "వ"
    ],
    "th": [
        null,
        "వ"
    ],
    "yes": [
        null,
        "అవును"
    ],
    "{dateNumber}{nth} {month}": [
        null,
        "{dateNumber}{nth} {month}"
    ],
    "{day} {month} {dateNumber}{nth} {year}": [
        null,
        "{day} {month} {dateNumber}{nth} {year}"
    ],
    "{month} {dateNumber}{nth}": [
        null,
        "{month} {dateNumber}{nth}"
    ],
    "{programName} - ({channelName}) has been started and is scheduled for recording.": [
        null,
        "{programName} - ({channelName}) ప్రారంభమైంది మరియు రికార్డింగ్ కోసం షెడ్యూల్ చేయబడింది."
    ]
}
,
}
