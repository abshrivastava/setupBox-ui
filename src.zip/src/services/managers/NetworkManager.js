//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {sse, enableEvents} from "services/events"
import bus from "services/bus"
import * as networkApi from "services/api/network"

class NetworkManager {
  constructor() {
    enableEvents(this)
    this._connected = false
    this._authenticated = false
    this._current = "Ethernet"
    this.interfaces = {}
  }

  checkConnected() {
    return networkApi.status()
      .then(({status}) => {
        this._connected = status
        if (status === true) {
          return this.listInterfaces()
            .then(() => {
              return this.getAuthenticationStatus()
            })
        } else {
          this.authenticated = false
        }
      })
  }

  get authenticated() {
    return this._authenticated
  }

  set authenticated(value) {
    this._authenticated = (value === "auth_authenticated") ? "OK" : "FAILED"
  }

  get connected() {
    return this._connected
  }

  set current(value) {
    this._current = value
  }

  get current() {
    return this.interfaces[this._current]
  }

  listInterfaces() {
    return new Promise((resolve) => {
      return networkApi.getConfigs()
        .then(({configs}) => {
          const promises = []
          for (const config of configs) {
            promises.push(networkApi.getConfigDetails(config))
          }
          return Promise.all(promises)
        })
        .then((configs) => {
          const promises = []
          for (const config of configs) {
            const configName = Object.keys(config)[0]
            const interfaceName = Object.values(config)[0].interface
            Object.assign(this.interfaces, config)
            promises.push(this._fetchDetails(configName, interfaceName))
          }
          return Promise.all(promises)
            .then(() => {
              resolve()
            })
        })
    })
  }

  _fetchDetails(configName, interfaceName) {
    return networkApi.getDeviceDetails(interfaceName)
      .then((data) => {
        Object.assign(this.interfaces[configName], data)
        return Promise.resolve()
      })
  }

  @sse("network", {subtype: "DeviceConnected"})
  _onDeviceConnected() {
    this._connected = true
    return this.listInterfaces()
      .then(() => {
        bus.emit("network:connected", true)
      })
  }

  @sse("network", {subtype: "DeviceDisconnected"})
  _onDeviceDisConnected() {
    this._connected = false
    return this.listInterfaces()
      .then(() => {
        return this.getAuthenticationStatus()
      })
      .then(() => {
        bus.emit("network:disconnected", false)
      })
  }

  getAuthenticationStatus() {
    return networkApi.authenticated()
      .then(({status}) => {
        this.authenticated = status
        return this.authenticated
      })
  }
}

export default new NetworkManager()
