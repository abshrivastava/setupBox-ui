//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {putLedInfo} from "services/api/led"
import StorageManager from "services/managers/StorageManager"
import standby from "services/managers/PowerManager"
import PVRManager from "services/managers/PVRManager"
import {isDefined} from "utils"

class LedManager {

  constructor() {
    this._ledStandby = false
  }

  LedHitApi(ledNo,ledColor,ledRepeat) {
    const option = {
      "lednumber": parseInt(ledNo),
      "color": parseInt(ledColor),
      "repeat": parseInt(ledRepeat),
    }
    return putLedInfo(option)
  }

  LedNumZap() {
    if (StorageManager.storageled === 1 && !this._ledStandby) {
      if (PVRManager.pvrValue === false) {
        this.LedHitApi(1,2,1)
      }
    }
  }

  SetUsbOpen() {
    if (!standby.isStandbyState && !this._ledStandby) {
      this.LedHitApi(1,2,0)
    }
  }

  SetUsbClose() {
    if (!standby.isStandbyState && !this._ledStandby) {
      this.LedHitApi(1,2,-1)
    }
  }

  SetRecordOpen() {
    if (!standby.isStandbyState && !this._ledStandby) {
      this.LedHitApi(1,2,0)
    }
  }

  SetRecordStop() {
    if (!standby.isStandbyState) {
      this.LedHitApi(1,2,-1)
    }
  }

  LedUsbDisconnect() {
    if (!standby.isStandbyState) {
      this.LedHitApi(1,2,-1)
    }
  }

  SetStandOn() {
    this._ledStandby = true
    if (StorageManager.storageled === 0) {
      StorageManager.storageled=1
    }
    return this.LedHitApi(1,1,-1)
  }

  SetStandOff() {
    this._ledStandby = false
    if ((StorageManager.storageled===0) || (isDefined(PVRManager.ongoing)
      && PVRManager.ongoing.length > 0)) {
      return this.LedHitApi(1,2,0)
    }  else {
      return this.LedHitApi(1,2,-1)
    }
  }
}

export default new LedManager()
