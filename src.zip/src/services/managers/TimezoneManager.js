//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as TimezonesAPI from "services/api/timezone"
import TimezoneModel from "services/models/Timezone"
import {setTimeFormat} from "services/managers/config"
import {formatTime, transformTime} from "utils/date"

class TimezoneManager {
  constructor() {
    this._current = null
    this.timezoneList = []
    this._displayH24 = false
  }

  /* **********************************
   *        GETTER/SETTER             *
   ********************************** */
  get current() {
    return this._current
  }

  set current(value) {
    this._current = value
  }

  set displayH24(isH24="true") {
    this._displayH24 = isH24
    setTimeFormat(isH24)
  }

  get displayH24() {
    let bool
    if (this._displayH24 === "true") {
      bool = true
    } else if (this._displayH24 === "false") {
      bool = false
    } else {
      bool = this._displayH24
    }
    return bool
  }

  /* **********************************
   *        HELPERS METHODS           *
   ********************************** */
  getFormatTime(date) {
    return formatTime(date, this.displayH24)
  }

  getEpgFormatTime(time) {
    return transformTime(time, this.displayH24)
  }

  /* **********************************
   *            API METHODS           *
   ********************************** */
  getTimezones() {
    return TimezonesAPI.getTimezones()
      .then(({timezones}) => {
        this.timezoneList = []
        timezones.forEach((timezone) => {
          this.timezoneList.push(new TimezoneModel(timezone))
        })
        this.timezoneList.sort((a, b) => ((a.name.toLowerCase() <= b.name.toLowerCase())) ? -1 : 1)
        return this.getCurrentTimezone()
      })
  }

  getCurrentTimezone() {
    return TimezonesAPI.getTimezone().then(result => {
      this.current = new TimezoneModel(result)
    })
  }

  setCurrentTimezone(timezone) {
    return TimezonesAPI.setTimezone({timezone: timezone.name})
      .then(() => {
        this.current = timezone
      })
  }
}

export default new TimezoneManager()
