//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import bus  from "services/bus"
import {sse, enableEvents} from "services/events"
import * as popUpMsg from "app/utils/PopUpMsg"
import * as camApi from "services/api/cam"
import {getCamStatus, setCamStatus} from "services/managers/config"
import {setState} from "services/api/power"

const isInserted = Symbol("insertStatus")

const CAM_STATUS = {
  inserted: 1,
  removed: 2,
}

class CamManager {
  constructor() {
    this[isInserted] = false
    enableEvents(this)
  }

  get insertStatus() {
    return this[isInserted]
  }

  set insertStatus(value) {
    this[isInserted] = typeof value === "boolean" ? value : false
  }


  // Everytime Box boots up need to check whether CAM is there or not
  checkCamStatusAtBoot() {
    let camStatus = 0
    return camApi.getCamInsertStatus()
      .then((result) => {
        if (result && result.cam_insert_status) {
          camStatus = 1
          const buttons = [
            {
              label: "OK",
              action: () => {
                bus.stopEventEmit = false
                // bus.openUniverse("home")
              },
            },
          ]
          const closeCallback = () => {}
          popUpMsg.camInsertedAtBoot(buttons, closeCallback)
          this.insertStatus = true
          return setCamStatus(camStatus)
        } else if (result && !result.cam_insert_status) {
          return getCamStatus()
          .then((value)=>{
            if (value) {
              return setCamStatus(camStatus)
            }
          })
        }
      })
      .catch(() => {
        return setCamStatus(camStatus)
      })
  }


  @sse("content", {subtype: "ci_menu"})
  _onCIMenu(data) {
    bus.emit("Cam:MainMenu",data)
  }

  getCamSubMenu(params) {
    camApi.getCamSubMenu(params)
       .then((data)=>{
         console.log(data)
       })
  }

  getCamMenu() {
    camApi.getCamMainMenu()
  .then((data) => {
    console.log(data)
  })
  }


  @sse("content", {subtype: "cam_detect_status"})
  _onCamStatusChange(response) {
    const buttons = [
      {
        label: "OK",
        action: () => {
          setState({"state":"reboot"})
        },
      },
    ]
    if (response.cam_detect_status === CAM_STATUS.inserted) {
      popUpMsg.camInserted(buttons)
    } else {
      popUpMsg.camRemoved(buttons)
    }
  }
}

export default new CamManager()
