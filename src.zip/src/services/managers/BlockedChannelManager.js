//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import ChannelManager from "services/managers/ChannelManager"
import BlockedCh from "services/models/channels/BlockedCh"

class BlockedChannelManager {
  constructor() {
    this.blockedModel = new BlockedCh()
    this.running = false
  }

  updateChannelList(list) {
    this.blockedModel.updateBlockedChannels(list)
  }

  getBlockedChannels() {
    return new Promise((resolve) => {
      resolve(this.blockedModel.getBlockedChannelsList())
    })
  }

  getBlockedChannelsMap() {
    return this.blockedModel.getBlockedChannelsObj()
  }
  updatePin(pin) {
    this.blockedModel.updateBlockedPin(pin)
  }
  validateEnteredPin(enteredPin) {
    // let blockedPin = blockedModel.getBlockedPin();
    const blockedPin = this.blockedModel.getBlockedPin()
    if (blockedPin === enteredPin) {
      return true
    } else {
      return false
    }
  }

  getCurrentChannel() {
    return ChannelManager.current
  }

  updateLandingChannel(lcn) {
    if (lcn) {
      this.updateNoBlockList("LandingChannel", lcn)
    }
  }

  updateNoBlockList(type, lcn) {
    ChannelManager.getAbsoluteChannelFromLcn(lcn)
  .then((response) => {
    if (response) {
      const channel = response.resource.real || response.resource.fallback
      if (channel) {
        this.blockedModel.updateNoBlockList(type, channel)
      }
    }
  })
  }

  getNoBlockList() {
    return this.blockedModel.getNoBlockList()
  }

  isChannelBlocked(item,previouschannel,state) {
    if (this.getBlockedChannelsMap().hasOwnProperty(item.serviceId)) {
      if (item.serviceId === previouschannel.serviceId && (state !== "STOPPED" || !this.getCurrentChannelStatus())) {
      //  this.setCurrentChannelStatus(false)
        return false
      }
  //    this.setCurrentChannelStatus(false)
      return true
    } else {
  //    this.setCurrentChannelStatus(false)
      return false
    }
    // return this.getBlockedChannelsMap().hasOwnProperty(item.serviceId)
  }

  getCurrentChannelStatus() {
    return this.blockedModel.getCurrentChannelBlocked()
  }

  setCurrentChannelStatus(status) {
    this.blockedModel.setCurrentChannelBlocked(status)
  }

}

export default new BlockedChannelManager()
