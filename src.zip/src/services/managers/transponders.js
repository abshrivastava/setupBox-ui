//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {on, enableEvents} from "services/events"
import {getTranspondersList, getTranspondersInfo, getTransponderCompleteData} from "services/api/transponders"


class Transponders {
  constructor() {
    this.transpondersList = []
    this.isTPListScreen = false
    this.stbSerialNo = "N/A"
    enableEvents(this)
  }

  getTranspondersList() {
    const data = getTranspondersList()
    return data
  }

  getTransponderDetail() {
    const detail = getTranspondersInfo()
    return detail
  }

/** The updated call for diseqc as well as new transponder Api**/
@on("transponder:getlist")
  getTransponderDetailsList(obj) {
    if (obj.IF2IF === "IFTOIF_ON") this.diseqcRef = -1
    else if (obj.IF2IF === "IFTOIF_OFF") {
      switch (obj.diseqc) {
      case "DISEQC_AUTO":
        this.diseqcRef = "0"
        break
      case "DISEQC_PORT1":
        this.diseqcRef = "1"
        break
      case "DISEQC_PORT2":
        this.diseqcRef = "2"
        break
      case "DISEQC_PORT3":
        this.diseqcRef = "3"
        break
      case "DISEQC_PORT4":
        this.diseqcRef = "4"
        break
      default:
        this.diseqcRef = "0"
      }
    }
    getTransponderCompleteData(this.diseqcRef,obj.IF2IF).then(
      (data) => {
        this.transpondersList = data
      })
      .catch(() => {
        this.transpondersList = []
      })
  }

 }

export default new Transponders()
