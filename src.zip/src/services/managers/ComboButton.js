//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import bus from "services/bus"
import {on,enableEvents} from "services/events"
import PlayerManager from "services/managers/PlayerManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import PVRManager from "services/managers/PVRManager"
import ChannelManager from "services/managers/ChannelManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import transponders from "services/managers/transponders"

import Settings from "app/models/Settings"
import {locale} from "utils/locale"
import {setLocale, updateDefaultTrack, getLocale, updateAudiotracks} from "services/managers/config"
import {setEpgLanguage} from "services/api/program"

const MODEL = new Settings()

const ALL_UNIVERSE = ["home"]
let comboTickerStart = null

class ComboButton {
  constructor() {
    this.INITIAL_INTERVAL = 0
    this.SET_TIMEOUT = 3
    this.MAPPING_TIMEOUT = 2000
    this.LONG_PRESS_TIMEOUT = 10000
    this.longPressTimmer = null
    this._longPressInfoBanner = false
    this.comboBtnPress = false
    this.colorBtnCombination = []
    this.colorBtnCombinationFlag = false
    this.startTimmer = null
    this.coverSetting = false
    this.waitForOpenSettings = 200
    this.openSettingTimer = null
    this.greenBtnPress = false
    enableEvents(this)
  }

  @on("colorBtnPress")
  onColorBtnPress(colorBtn) {
    if (FtaBlockManager.onAdvancedScan) return
    if ((new Date() - comboTickerStart) > 800) {
      this.menuColorBtnForFta(colorBtn)
    }
    if (FtaBlockManager.isNavigationRestricted() === true) return
    this.colorBtnCombination.push(colorBtn)
    if (this.colorBtnCombination.length > 1) {
      const mapKeyColor = this.colorBtnCombination[0] + "_" + this.colorBtnCombination[1]
      this._menuShortcut(mapKeyColor)
      this.colorBtnCombination = []
    }
  }

  @on("colorBtnRelease")
  onColorBtnRelease(colorBtn) {
    if (FtaBlockManager.onAdvancedScan) return
    comboTickerStart = new Date()
    const isBlackUniverse = FtaBlockManager.isNavigationRestricted()
    if (isBlackUniverse) bus.universe = "blackuniverse"
    if (this.startTimmer) window.clearTimeout(this.startTimmer)
    if (colorBtn === "info") {
      this.startTimmer = window.setTimeout(() => {
        this.colorBtnCombination = []
      }, 5000) // More delay for info button
    } else {
      this.startTimmer = window.setTimeout(() => {
        this.colorBtnCombination = []
      }, this.MAPPING_TIMEOUT)
    }
  }

// ------- Locale Language Change --------

  @on("greenBtnPress")
  onGreenBtnRelease() {
    if (!this.greenBtnPress) {
      this.greenBtnPress = true
      let languages
      let nextLang
      let languagesLength
      return getLocale()
    .then((lang) => {
      if (MODEL.enableMultiLang) {
        languages = [
        {label: "English", value: "eng"},
        {label: "Hindi", value: "hin"},
        {label: "Marathi", value: "mar"},
        {label: "Telugu", value: "tel"},
        ]
      } else {
        languages = [{label: "English", value: "eng"},{label: "Hindi", value: "hin"}] // ["en", "fr","Hindi"]
      }
      languages.forEach((language, index) => {
        if (language.value === lang) {
          languagesLength = languages.length
          if ((index+1) === languagesLength)
            nextLang = languages[0]
          else
            nextLang = languages[index+1]
          locale.current = nextLang.value
          setLocale(locale.current).then(() => {
            let obj = {}
            if (!MODEL.enableMultiLang) {
              if (locale.current === "eng") {
                obj = {"audio_tracks": {"1": "hin", "2": "eng"}}
              } else if (locale.current === "hin") {
                obj = {"audio_tracks": {"2": "hin", "1": "eng"}}
              }
            } else {
              switch (locale.current) {
              case "eng":
                obj = {"audio_tracks":
                {
                  "1": "tel",
                  "2": "mar",
                  "3": "tam",
                  "4": "hin",
                  "5": "eng",
                },
                }
                break
              case "hin":
                obj = {"audio_tracks":
                {
                  "1": "tel",
                  "2": "mar",
                  "3": "tam",
                  "4": "eng",
                  "5": "hin",
                },
                }
                break
              case "tam":
                obj = {"audio_tracks":
                {
                  "1": "tel",
                  "2": "mar",
                  "3": "hin",
                  "4": "eng",
                  "5": "tam",
                },
                }
                break
              case "mar":
                obj = {"audio_tracks":
                {
                  "1": "tel",
                  "2": "tam",
                  "3": "hin",
                  "4": "eng",
                  "5": "mar",
                },
                }
                break
              case "tel":
                obj = {"audio_tracks":
                {
                  "1": "mar",
                  "2": "tam",
                  "3": "hin",
                  "4": "eng",
                  "5": "tel",
                },
                }
                break
              default:
                break
              }
            }
            updateDefaultTrack(locale.current)
            updateAudiotracks(obj)
            MODEL.loadUILanguages()
            .then((data) => {
              bus.emit("settings:setDefault", data)
            })
            MODEL.selectedLang = locale.current
            setEpgLanguage(locale.current)
            this.greenBtnPress = false
          })
        }
      })
    })
    }
  }

  menuColorBtnForFta(color) {
    const isNavigationRestricted = FtaBlockManager.isNavigationRestricted(color)
    if (isNavigationRestricted) {
      this.showShortCutMenu(color)
      comboTickerStart = new Date()
    }
  }


  showShortCutMenu(color) {
    const currentPage = FtaBlockManager.ftaPopupStatus.page
    const mapKeyColor = `${color}_${currentPage}`
    switch (mapKeyColor) {
    case "blue_error":
      this.updatePage("stb")
      break
    case "yellow_error":
      this.updatePage("tp")
      break
    case "blue_stb":
      this.updatePage("tp")
      break
    case "yellow_stb":
      this.updatePage("error")
      break
    case "blue_tp" :
      this.updatePage("error")
      break
    case "yellow_tp":
      this.updatePage("stb")
      break
    default:
      this.actDefault = true
    }
    if (color && currentPage) {
      FtaBlockManager.clearHomeTpTimer()
      this.closePage(color,currentPage)
      window.setTimeout(()=>{
        this.openPage(color,currentPage)
      },200)
    }
  }

  onBackFtaAdvanceScreen() {
    FtaBlockManager.clearHomeTpTimer()
    FtaBlockManager.ftaPopupStatus.page =  "error"
    this.showShortCutMenu("blue")
  }

  updatePage(openPage) {
    FtaBlockManager.ftaPopupStatus.page =  openPage
  }

  openPage(...option) {
    const [color,page] = option
    switch (page) {
    case "error":
      this.showFromErrorPage(color)
      break
    case "stb":
      this.showFromStbInfoSheet(color)
      break
    case "tp":
      this.showFromTplist(color)
      break
    default:
      console.log("default")
    }
  }

  closePage(...option) {
    const [color,page] = option
    switch (page) {
    case "error":
      this.closeErrorPage(color)
      break
    case "stb":
      this.closeStbInfoSheet(color)
      break
    case "tp":
      this.closeTplist(color)
      break
    default:
      console.log("default")
    }
  }

  showFromErrorPage(color) {
    if (color==="blue") {
      this.onOpenSTBinfoSheet()  // going to open stb
    }
    if (color === "yellow") {
      window.setTimeout(()=>{
        this.onOpenTransponderScreen()  // going to open tp/
      },0)
    }
  }

  showFromStbInfoSheet(color) {
    if (color==="blue") {
      bus.emit("STBInfoSheet:ok")  // going to open tp
    }
    if (color === "yellow") {
      FtaBlockManager.callForErrorPage()
    }
  }

  showFromTplist(color) {
    if (color==="blue") {
      FtaBlockManager.callForErrorPage()
    }
    if (color === "yellow") {
      bus.emit("blackuniverse:close:stbInfoSheet") // going to open stb
    }
  }

  closeErrorPage() {
    bus.emit("blackuniverse:hide") // going to hide Error page
  }

  closeStbInfoSheet(color) {
    if (color === "yellow") {
      bus.emit("STBInfoSheet:close")
      bus.emit("ftaBlockManager:close")
    }
  }

  closeTplist(color) {
    if (color === "blue") {
      bus.emit("STBInfoSheet:close")
      bus.emit("ftaBlockManager:close")
    }
  }

  _menuShortcut(mapKeyColor) {
    switch (mapKeyColor) {
    case "green_red":
      this.onOpenSTBinfoSheet()
      break
    case "red_yellow":
      this.onOpenTransponderScreen()
      break
    case "blue_yellow":
      this.onOpenUILanguage()
      break
    case "green_yellow":
      this.openEasyScan()
      break
    case "green_zero":
      this.colorBtnCombinationFlag = true
      this.openFactorySetting()
      break
    case "info_info":
      bus.emit("tv:ok:press")
      break
    default:
      console.log("default")
    }
  }

  @on("comboBtn:factorySetting")
  openFactorySetting() {
    bus.closeCurrentUniverse()
    this._resetAllUniverse()
    window.setTimeout(()=>{
      bus.openUniverse("settings")
      bus.emit("settings:setDefaultFocus","tools")
      bus.emit("scan:factoryReset")
    },100)
  }

  @on("comboBtn:easyScan")
  openEasyScan() {
    if (PVRManager.ongoing.length > 0) {
      this.RecordingScanConflict()
    } else {
      PlayerManager.stopCurrentChannel()
      this.openSettings("launchEasyScan")
    }
  }

  RecordingScanConflict() {
    const closeCallback = () => {
    }
    const buttons = [
      {
        label: "Ok",
        action: () => {
          ScanManager.scanTriggered = true
          PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
          PlayerManager.stopCurrentChannel()
          bus.closeCurrentUniverse()
          this._resetAllUniverse()
          if (bus.universe !== "settings") bus.openUniverse("settings")
          bus.emit("settings:setDefaultFocus","tools")
          bus.emit("scan:launchEasyScan",{"univ":null,"scanType":"EASY_SCAN"})
        },
      },
      {
        label: "Back",
        action: closeCallback,
      },
    ]
    return popUpMsg.confirmSCAN(buttons, closeCallback)
  }

  @on("colorBtnPress:open:appstore")
  openAppStore() {
    if (!ChannelManager.activeServices) {
      bus.closeCurrentUniverse()
      bus.emit("home:close")
      ChannelManager.activeServices = true
      bus.universe = "tv"
      bus.emit("tv:open")
    }
  }

  @on("openSTBinfoSheet")
  onOpenSTBinfoSheet() {
    this.openSettings("STBinfoSheet")
  }

  @on("openTransponderScreen")
  onOpenTransponderScreen() {
    if (!transponders.isTPListScreen) {
      this.openSettings("transponderScreen")
    }
  }

  @on("openUILanguage")
  onOpenUILanguage() {
    this.openSettings("UILanguage")
  }

  @on("comboBtn:home:press")
  onHomePress() {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    const isPage = FtaBlockManager.ftaPopupStatus.page
    if ((isFtaBlock && isPage !== "stb") || FtaBlockManager.onAdvancedScan) return

    if (!this.comboBtnPress) {
      if (!this.longPressTimmer) {
        this.longPressTimmer = window.setTimeout(() => {
          this.comboBtnPress = true
          this.openSettings("advancedScan")
        }, this.LONG_PRESS_TIMEOUT)
      }
    }
  }

  @on("comboBtn:home:release")
  onHomeRelease() {
    window.clearTimeout(this.openSettingTimer)
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    if (this.longPressTimmer)window.clearTimeout(this.longPressTimmer)
    if (!this.comboBtnPress && !isFtaBlock) {
      this.longPressTimmer = null
      if (bus.universe !== "home") {
        bus.closeCurrentUniverse()
        bus.openUniverse("home")
      }
    } else {
      this.longPressTimmer = null
      this.comboBtnPress = false
    }
  }

  _resetAllUniverse() {
    if (bus.universe === "home") return
    for (const value of ALL_UNIVERSE) {
      bus.emit(`${value}:close`)
    }
  }

  @on("openSettingsPage")
  openSettings(subSettings = "") {
    if (bus.universe !== "settings") {
      bus.closeCurrentUniverse()
      this._resetAllUniverse()
      window.clearTimeout(this.openSettingTimer)
      this.openSettingTimer = window.setTimeout(()=>{
        bus.openUniverse("settings")
        this.openSubSettings(subSettings)
      }, this.waitForOpenSettings)
    } else {
      bus.emit("settings:hideDelegate")
      this.openSubSettings(subSettings)
    }
  }

  openSubSettings(subSettings = "") {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    switch (subSettings) {
    case "launchEasyScan":
      bus.emit("settings:setDefaultFocus","tools")
      bus.emit("scan:launchEasyScan",{"univ":null,"scanType":"EASY_SCAN"})
      break
    case "STBinfoSheet":
      bus.emit("menuShortCut:STBInfo")
      if (!isFtaBlock) bus.emit("settings:setDefaultFocus","STBInfoSheet")
      break
    case "transponderScreen":
      // bus.emit("comboBtn:SettingsMenu:hide")
      bus.emit("menuShortCut:STBInfo", true)
      bus.emit("STBInfoSheet:ok")
      if (!isFtaBlock) bus.emit("settings:setDefaultFocus","STBInfoSheet")
      break
    case "UILanguage":
      bus.emit("settings:openpage","language")
      break
    case "advancedScan":
      if (!isFtaBlock) bus.emit("settings:setDefaultFocus","scan")
      bus.emit("settings:advanced_scan")
      break
    case "favorites":
      bus.emit("settings:Favorites","scan","favourite")
      break
    case "UIHelp":
      bus.emit("settings:openpage","selfHelp")
      break
    case "UITools":
      bus.emit("settings:openpage","tools")
      break
    default:
      console.log("default")
    }
    /**
     * check for FTA BLOCK ON EACH Commobo Btn...
     */
    if (isFtaBlock) bus.universe = "blackuniverse"
  }
}

export default new ComboButton()
