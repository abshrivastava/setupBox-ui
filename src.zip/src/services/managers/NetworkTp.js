//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

const Network = {
  "DISH" : "D2H_OFF",
  "D2H" : "D2H_ON",
  "HOME_TP1" : {
    IFTOIF_OFF: {frequency: "12688", code_rate:"Auto", symbol_rate: "27500", polarity:"V"},
    IFTOIF_ON: {frequency: "10730", code_rate:"Auto", symbol_rate:"27500", polarity:"V"},
  },
  "HOME_TP2" : {
    IFTOIF_OFF: {frequency: "11609", code_rate:"Auto", symbol_rate: "43978", polarity:"V"},
    IFTOIF_ON: {frequency: "10735", code_rate:"Auto", symbol_rate:"43978", polarity:"V"},
  },
  "TP" : {
    "DISH" : "TP1",
    "D2H" : "TP2",
    "DISH_Label" : "Home TP1 (SES8)",
    "D2H_Label" : "Home TP2 (ST2)",
  },
  "UriList" : {
    "DISH" : {
      OFF: {frequency: "12688000", code_rate:"Auto", symbol_rate: "27500000", polarity:"V", transmitter_id:"1"},
      ON: {frequency: "10730000", code_rate:"Auto", symbol_rate:"27500000", polarity:"V", transmitter_id:"-1"},
    },
    "D2H" : {
      OFF: {frequency: "11609000", code_rate:"Auto", symbol_rate: "43978000", polarity:"V", transmitter_id:"1"},
      ON: {frequency: "10735000", code_rate:"Auto", symbol_rate:"43978000", polarity:"V", transmitter_id:"-1"},
    },
  },
}

class NetworkTp {
  constructor() {
    this.currentHomeTp = null
    this.currentIFTOIF = null
    this.config = Network
  }

}
export default new NetworkTp()
