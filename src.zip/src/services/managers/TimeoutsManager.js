//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
//

class TimeoutsManager {
  constructor() {
    this.TIMEOUT_ACTION = 2000
    this._timer = null
  }

  setTimer(msec, func) {
    this.TIMEOUT_ACTION = msec
    this._timer = window.setTimeout(() => {
      this.clearTimeOut()
      func()
    }, this.TIMEOUT_ACTION)
  }

  clearTimeOut() {
    window.clearTimeout(this._timer)
  }

}

export default new TimeoutsManager()
