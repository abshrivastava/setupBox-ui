//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT, DELETE} from "../http"

export function getSections() {
  return GET("/config/")
}

export function createSections(sections) {
  return PUT("/config/", sections)
}

export function getSection(section) {
  return GET(`/config/${section}/`)
}

export function getEntry(section, entry) {
  return GET(`/config/${section}/${entry}/`)
}

export function updateEntry(section, entry, body) {
  return PUT(`/config/${section}/${entry}/`, body)
}

export function updateTimeZone(body) {
  return PUT("/time/timezone/", body)
}

export function updateAvio(body) {
  return PUT("/player/config/output/avio_output_hdmi0/", body)
}

export function getAvio() {
  return GET("/player/config/output/avio_output_hdmi0/")
}

export function updateAudiotracks(body) {
  return PUT("/player/config/audio_tracks/", body)
}

export function getPersistanceAudioLang() {
  return GET("/config/audio_lang/")
}

export function setTimeShiftDuration(option) {
  return PUT("/player/config/timeshiftduration/", option)
}

export function getPartitionIdVal(usbId) {
  return GET(`/storage/${usbId}/partitions/`)
}

export function getPartitionFreeSize(partitionId) {
  return GET(`/storage/partition/${partitionId}/`)
}
export function putRecordMedium(option) {
  return PUT("/player/config/record_storage_medium/", option)
}
export function getRecordMedium() {
  return GET("/player/config/record_storage_medium/")
}
export function getTimeShiftDuration() {
  return GET("/player/config/timeshiftduration/")
}
export function setSoftwareVersion(option) {
  return PUT("/softwareversion/", option)
}
export function updateDolby(body) {
  return PUT("/player/config/audio_codecs/", body)
}
export function updateDefaultTvType(armValue) {
  return PUT("/avio/player/WyPlayer/output/hdmi0/", armValue)
}

export function updateCVBS(format) {
  return PUT("/player/config/output/avio_output_videoanalog0/", format)
}

export function deleteEntry(section, entry) {
  return DELETE(`/config/${section}/${entry}/`)
}

export function deleteSection(section) {
  return DELETE(`/config/${section}/`)
}

export function getVCno() {
  return GET("/vsc/numstring/")
}

export default {
  getSections,
  createSections,
  getSection,
  getEntry,
  updateEntry,
  updateTimeZone,
  updateAvio,
  getAvio,
  updateAudiotracks,
  getPersistanceAudioLang,
  setTimeShiftDuration,
  getPartitionIdVal,
  getPartitionFreeSize,
  putRecordMedium,
  getTimeShiftDuration,
  setSoftwareVersion,
  updateDolby,
  updateDefaultTvType,
  updateCVBS,
  deleteEntry,
  getVCno,
  deleteSection,
}
