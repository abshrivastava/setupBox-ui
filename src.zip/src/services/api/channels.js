//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, POST, DELETE} from "../http"

export function createFavoriteList(params) {
  return POST("/channel_list/", params)
}

export function getChannels(params) {
  /*
   * This is an helper to get channels with the same fashion as we get
   * records/schedules/tasks. It also avoids to forget closing a datasource.
   */
  let source
  return POST("/channels/", params)     // Create a channels list datasource
    .then(({href}) => {
      source = href
      return GET(source)            // Get results (channels list)
    })
    .then((data) => {
      DELETE(source)                // Delete the datasource
      return Promise.resolve(data)  // Return results as is.
    })
}

export function getFavoriteChannels() {
  let source
  return POST("/channels/", {"criteria": "parent == '/channel_list/1/'"})
    .then(({href}) => {
      source = href
      return GET(source)
    })
    .then((data) => {
      DELETE(source)
      return Promise.resolve(data)
    })
}


export function create(params) {
  return POST("/channels/", params)
}

export function get(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return GET(`/channels/${id}/`)
}

export function count(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return GET(`/channels/${id}/count/`)
}

export function destroy(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return DELETE(`/channels/${id}/`)
}

export default {
  createFavoriteList,
  getChannels,
  getFavoriteChannels,
  create,
  get,
  count,
  destroy,
}
