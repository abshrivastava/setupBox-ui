//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT, POST, DELETE} from "../http"

export function getAll(playerId) {
  return GET(`/player/${playerId}/audiotracks/`)
}

export function search(value) {
  value = `criteria=name=="${value}"`
  return GET(`/alert/search/?start_index=0&max_count=0&${value}&order=id&metadata=*`)
}

export function set(option) {
  return POST("/alert/", option)
}

export function modify(id,option) {
  return PUT(`/alert/${id}/`, option)

}

export function remove(id) {
  return DELETE(`/alert/${id}/`)
}

export function getTaskConflict(id) {
  return GET(`/pvr/scheduled/tasks/${id}/conflicts/`)
}


export default {
  modify,
  search,
  set,
  remove,
  getTaskConflict,
}
