//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import {GET, POST, DELETE, PUT, createQueryString} from "../http"


// This is the maximal value for a Count arg as per the UPNP SRS spec
// 2^32-1, max unsigned int on 4 bytes
const UI4_MAX = 4294967295

/* ***** SCHEDULES ***** */
export function createSchedule(params) {
  return POST("/pvr/scheduled/", params)
}

export function getSchedules(params) {
  const criteriaTitle = "RechargeReminder"
  const queryString = createQueryString({
    requestedcount: UI4_MAX,
    sortcriteria: "active_period",
    searchcriteria: `title!="${criteriaTitle}"`,
    ...params,
  })
  return GET(`/pvr/scheduled/${queryString}`)
}

export function getSchedulesWithProperties(params) {
  return GET(`/pvr/scheduled/${params}/?propertylist=*`)
}

export function deleteSchedule(id) {

  return DELETE(`/pvr/scheduled/${id}/`)
}
/* *************************************** */

/* ***** TASKS ***** */
export function getTasks(params) {
  const queryString = createQueryString({
    criteria: params,
  })
  return GET(`/pvr/scheduled/tasks/${queryString}`)
}

export function deleteTask(id) {

  return DELETE(`/pvr/scheduled/tasks/${id}/`)
}

export function disableRecordTask(id) {
  return PUT(`/pvr/scheduled/tasks/${id}/disable`)
}

/* *************************************** */

/* ***** RECORDS ***** */
export function getRecords(params) {
  /*
   * This is an helper to get records with the same fashion as we get
   * schedules/tasks. It also avoids to forget closing a datasource.
   */
  let source
  return POST("/pvr/records/", params)     // Create a records list datasource
    .then(({href}) => {
      source = href
      return GET(source)
    })
    .then((data) => {
      DELETE(source)                // Delete the datasource
      return Promise.resolve(data)  // Return results as is.
    })
}

export function updateRecord(id, metadata) {
  return PUT(`/pvr/record/${id}/`, metadata)
}

export function deleteRecord(id) {

  return DELETE(`/pvr/record/${id}/`)
}

export function uiReady() {
  return PUT("/pvr/uiready/")
}
/* *************************************** */

export default {
  createSchedule,
  getSchedules,
  deleteSchedule,

  getTasks,
  deleteTask,

  getRecords,
  updateRecord,
  deleteRecord,

  uiReady,
}
