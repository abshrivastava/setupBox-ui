//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT} from "../http"

export function getVolume() {
  return GET("/player/config/volume/")
}

export function setVolume(volume) {
  return PUT("/player/config/volume/", {volume})
}

export function getMute() {
  return GET("/player/config/mute/")
}

export function setMute(value) {
  return PUT("/player/config/mute/", {value})
}

export function resizeVideo(outputId, left, top, right, bottom) {
  return PUT(`/avio/player/WyPlayer/output/${outputId}/`,
      {placement: [left, top, right, bottom]})
}

export function setAudioMode(outputId, mode) {
  /*
    'avio_audio_mode_stereo_downmix',
    'avio_audio_mode_bypass',
    'avio_audio_mode_ac3_transcode',
    'avio_audio_mode_max'
  */
  return PUT(`/player/config/output/avio_output_${outputId}/`,
    {audio_mode: `avio_audio_mode_${mode}`})
}

export function setTimeshiftDuration(timeshiftDuration) {
  return PUT("/player/config/timeshiftduration/", {timeshift_duration: timeshiftDuration})
}

export function setStorageMedium(medium) {
  return PUT("/player/config/record_storage_medium/", {medium})
}

export default {
  getVolume,
  setVolume,
  getMute,
  setMute,
  resizeVideo,
  setAudioMode,
  setTimeshiftDuration,
  setStorageMedium,
}
