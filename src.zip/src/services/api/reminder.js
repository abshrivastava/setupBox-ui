
//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {POST,GET,DELETE} from "../http"

export function createReminder(params) {
  return POST("/alert/", params)
}

export function checkConflict(taskId) {
  return GET(`/pvr/scheduled/tasks/${taskId}/conflicts/`)
}

export function getAlert(id) {
  return GET(`/alert/${id}/`)
}

export function deleteAlert(id) {
  return DELETE(`/alert/${id}/`)
}

export default {
  createReminder,
  checkConflict,
  getAlert,
  deleteAlert,
}
