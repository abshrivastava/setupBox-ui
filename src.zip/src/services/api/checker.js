//
// Copyright (C) 2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT, POST, DELETE} from "../http"

/** function:: getChecker()
 * Return a list of href.
 *
 *   200: Even if there is no tasks.
 *
 *   :returns Promise:
 */
export function getChecker() {
  return GET("/checker/")
}

/** function:: getCheckerTask()
 * Return the information of a Checker's task.
 *
 *   200: Even if there is no tasks.
 *
 *   :returns Promise:
 */
export function getCheckerTask(id) {
  return GET(`/checker/${id}/`)
}

/** function:: getCheckerEvents()
 * event: checker
 *
 *   :: Security Constraint
 *       MUST BE a static library in which will be linked to the daemon.
 *   :: Daemon
 *       MUST BE in a dedicated and isolated process.
 *       The configuration file MUST BE accessible only by the daemon.
 *       The checker zone MUST HAVE special permissions in order that only the daemon have access and all its content
 *          MUST BE accessible only to the checker daemon.
 *       The final install directory must have special permissions to allow checker and call to access to the data:
 *   :returns Promise:
 */
export function getCheckerEvents() {
  return GET(/events/)
}

/** function:: setChecker(option)
 * Create a checker task and return an identifier.
 *
 *   200: The task is created.
 *   400: The parameters are ill-formed.
 *   500: Something failed during the creation of the task:
 *       error_path if the path does not exist or ill-formed.
 *       error_access_denied if Checker has insufficient permissions.
 *       error_data if the files to be checked does not exist.
 *       error_signature if the signature file does not exist.
 *       error_strorage_mode_unsupported if storage mode not supported.
 *   :returns Promise:
 */
export function setChecker(option) {
  return POST("/checker/",option)
}

/** function:: startChecker(option)
 * Start the task.
 *
 *   200: The task is started.
 *   404: The identifier does not exist.
 *   500: Something failed during the start of the task:
 *       error_path if the path does not exist.
 *       error_access_denied if Checker has insufficient permissions.
 *       error_data if the files to be checked does not exist.
 *       error_signature if the signature file does not exist.
 *       error_bad_state when the current state is not state_created.
 *   :returns Promise:
 */
export function startChecker(id) {
  return PUT(`/checker/${id}/start`)
}

/** function:: cancelChecker(id)
 * Cancel a task.
 *
 *   200: The task is cancelled.
 *   404: The identifier does not exist.
 *   500: Something failed during the start of the task:
 *       error_bad_state when the current state is not state_started.
 *   :returns Promise:
 */
export function cancelChecker(id) {
  return PUT(`/checker/${id}/cancel`)
}

/** function:: installChecker(id)
 * Install the data to the install directory.
 *
 *   200: The data are installed from the destination directory.
 *   404: The identifier does not exist.
 *   500: Something failed during the install of the data:
 *       error_path if the path is not a relative path.
 *       error_access_denied if Checker has insufficient permissions to uninstall the data from the task's path.
 *       error_bad_state when the current state is not state_trusted
 *
 * Input
 * {
 * "path": "asset/",
 * }
 *   :returns Promise:
 */
export function installChecker(id,option) {
  return PUT(`/checker/${id}/data`,option)
}

/** function:: uninstallChecker(id)
 * Uninstall the data from the install directory.
 *
 *   200: The installed data are uninstalled from the destination directory
 *   404: The identifier does not exist.
 *   500: Something failed during the uninstall of the data:
 *       error_access_denied if Checker has insufficient permissions to uninstall the data from the task's path.
 *       error_bad_state when the current state is not state_installed.
 *
 *   :returns Promise:
 */
export function unInstallChecker(id) {
  return DELETE(`/checker/${id}/data`)
}

/** function:: deleteChecker(id)
 * Destroy the task and remove data from the Checker zone.
 *
 *   200: The task and its associated data from the Checker zone are removed.
 *   404: The identifier does not exist.
 *   500: Something failed during the remove of the data:
 *       error_bad_state when the current state is not state_created, state_untrusted, or state_trusted.
 *
 *   :returns Promise:
 */
export function deleteChecker(id) {
  return DELETE(`/checker/${id}/`)
}

export default {
  getChecker,
  getCheckerTask,
  getCheckerEvents,
  setChecker,
  startChecker,
  cancelChecker,
  installChecker,
  unInstallChecker,
  deleteChecker,
}
