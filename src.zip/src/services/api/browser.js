//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {POST, PUT, DELETE} from "../http"

export function openLayer(params) {
  return POST("/browser/layer/", params)
    .then(({href}) => {
      return href
    })
}

export function setLayerUrl(href, params) {
  return PUT(href, params)
}

export function closeLayer(href) {
  return DELETE(href)
}

export default {
  openLayer,
  setLayerUrl,
  closeLayer,
}
