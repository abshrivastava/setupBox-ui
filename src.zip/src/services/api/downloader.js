//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, POST, PUT, DELETE} from "../http"

export function listDowloaderTasks() {
  return GET("/downloader/tasks/")
}

export function createDowloaderTask(params) {
  return POST("/downloader/task/", params)
    .then(({href}) => {
      return Promise.resolve(href)
    })
}

export function taskWatcher(params) {
  return POST("/downloader/task_watcher/", params)
    .then(({href}) => {
      return Promise.resolve(href)
    })
}

export function getDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return GET(href)
}

export function updateDownloaderTask(href, params) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(href, params)
}

export function deleteDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return DELETE(href)
}

export function getDownloaderTaskProgress(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return GET(`${href}progress`)
}

export function startDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}start`)
}

export function pauseDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}pause`)
}

export function resumeDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}resume`)
}

export function stopDownloaderTask(href) {
  if (!href) {
    throw "Missing mandatory href"
  }

  return PUT(`${href}stop`)
}

// Returns the content of the download directory
export function getDownloaderDirectoryFiles() {
  return GET("/downloader/directory/")
}

// Returns a file stored in the download directory
export function getDownloaderFile(path) {
  return GET(`/downloader/directory/${path}`)
}

// Delete a file which is in the downloads directory
export function deleteDownloaderFile(path) {
  return DELETE(`${path}`)
}

export default {
  listDowloaderTasks,
  createDowloaderTask,
  taskWatcher,
  getDownloaderTask,
  updateDownloaderTask,
  deleteDownloaderTask,
  getDownloaderTaskProgress,
  startDownloaderTask,
  pauseDownloaderTask,
  resumeDownloaderTask,
  stopDownloaderTask,
  getDownloaderDirectoryFiles,
  getDownloaderFile,
  deleteDownloaderFile,
}
