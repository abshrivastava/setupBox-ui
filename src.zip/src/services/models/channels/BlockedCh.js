//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"


export default class BlockedCh extends Model {

  constructor(props = {}) {
    super(props)
    this.blockedChList = []
    this.serviceIdList = ""
    this.blockedPin = "0000"
    this.blockedCurrentChannel = false
    this.blockedChannelsObj = {}
    this.neverBlockedChannels = {}
  }

  updateBlockedChannels(list) {
    this.serviceIdList = list.toString()
    this.blockedChList = list.toString().split(",")
    const numBlockedChannels = this.blockedChList.length
    this.blockedChannelsObj = {}
    for (let i = 0; i < numBlockedChannels; i++) {
      this.blockedChannelsObj[this.blockedChList[i]] = true
    }
  }
  getBlockedChannelsList() {
    return this.blockedChList
  }
  getBlockedChannelsObj() {
    return this.blockedChannelsObj
  }
  updateBlockedPin(pin) {
    this.blockedPin = pin
  }

  getBlockedPin() {
    return this.blockedPin
  }
  setCurrentChannelBlocked(status) {
    this.blockedCurrentChannel = status
  }

  getCurrentChannelBlocked() {
    return this.blockedCurrentChannel
  }
  updateNoBlockList(type, channel) {
    this.neverBlockedChannels[type] = channel
  /*  if (this.neverBlockedChannels.indexOf(channel) < 0) {
      this.neverBlockedChannels.push(channel)
    } */
  }

  getNoBlockList() {
    return this.neverBlockedChannels
  }
}
