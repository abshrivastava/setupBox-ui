//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {convertFullDate} from "utils/date"

export default class Ads {
  constructor(programs) {
    this.programs = programs || []
  }

  getCurrentCampaignId() {
    let campaignId = null
    const currentDate = new Date()
    const currentFormattedDate = convertFullDate(currentDate)
    Object.keys(this.programs).forEach((programDate) => {
      if (programDate === currentFormattedDate) {
        campaignId = this.getCampaignFromDate(programDate, currentDate)
      }
    })
    return campaignId
  }

  getCampaignFromDate(programDate, currentDate) {
    let campaignId = null
    const currentHour = currentDate.getHours()
    if (this.programs.hasOwnProperty(programDate)) {
      const program = this.programs[programDate]
      Object.keys(program).forEach((hours) => {
        if (hours.startsWith(currentHour)) {
          campaignId = program[hours]
        }
      })
    }
    return campaignId
  }
}
