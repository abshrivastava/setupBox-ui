#!/bin/bash
COPYRIGHT='#
# Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
# This source code and any compilation or derivative thereof is the
# proprietary information of Wyplay and is confidential in nature.
# Under no circumstances is this software to be exposed to or placed under
# an Open Source License of any type without the expressed written permission
# of Wyplay.
#
'
COPYRIGHT_JS='//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
'
## locales/index.js generator
#    * for generating locales:
#        install (required by script/locale.sh):
#            (babel) to extract translatable content from js files
#                $> apt-get install babel
#            (python-babel) python module for Babel
#                $> apt-get install python-babel
#            (gettext) to use msginit tool to create (*.po) translation files
#                $> apt-get install gettext
#            (locale-po to json) Convert PO files to json https://pypi.python.org/pypi/pojson
#                $> apt-get -y install python-pip
#                $> pip install pojson
#        run:
#            (a first time)
#            $> [/path/to/frog-ui/]script/locale.sh
#                extract strings from js code Cf "_()"
#                translation updates can then be made on generated .po files (ex: locale-en_EN.po)
#                non auto-extracted can be added in individual .pot files (ex: menus.pot)
#            (a second time)
#            $> [/path/to/frog-ui/]script//locale.sh
#                merge all files (ex: english + menus.pot -> locales/index.js


#OCALES="eng_ENG hin_HIN"
#LOCALES="eng_ENG hin_HIN mar_MAR tam_TAM tel_TEL"
LOCALES="eng_ENG hin_HIN mar_MAR tel_TEL"

# PATH_BUILD="/opt/genbox/targets/current/work/media-gfx/frog-ui-1.1.16.18.4/work/frog-ui-1.1.16.18.4/script"
# echo $0 $(/opt/genbox/targets/current/work/media-gfx/frog-ui-1.1.16.18.4/work/frog-ui-1.1.16.18.4/script $0)
echo $(readlink -f $(dirname $0))
PATH_BUILD=$(readlink -f $(dirname $0))
#PATH_BUILD=$(realpath $(dirname $0))
PATH_ROOT=$(dirname ${PATH_BUILD})
PATH_LOCALE=${PATH_ROOT}/src/locales
PATH_CFG=${PATH_BUILD}/babel_extract.cfg
PATH_PO=${PATH_LOCALE}/po
PATH_MERGE=${PATH_LOCALE}/locale.tmp
PATH_AUTO=${PATH_LOCALE}/auto
PATH_MANUAL=${PATH_LOCALE}/manual
PATH_SRC=${PATH_ROOT}/src
PATH_DST=${PATH_ROOT}/src/locales/index.js

echo "PATH_ROOT= $PATH_ROOT"
echo "PATH_BUILD= $PATH_BUILD"
echo "PATH_LOCALE= $PATH_LOCALE"
echo "PATH_CFG= $PATH_CFG"
echo "PATH_PO= $PATH_PO"
echo "PATH_MERGE= $PATH_MERGE"
echo "PATH_AUTO= $PATH_AUTO"
echo "PATH_MANUAL= $PATH_MANUAL"
echo "PATH_SRC= $PATH_SRC"
echo "PATH_DST= $PATH_DST"


# CREATE POT FROM ${PATH_SRC} FILES
echo
pybabel extract -F ${PATH_CFG} ${PATH_SRC} -o ${PATH_MERGE}
echo

# ADD MANUAL CONTENT
 echo
for f in ${PATH_MANUAL}/*.pot; do
    echo "adding manual $f to ${PATH_MERGE}..."
    echo "#: $f" >> ${PATH_MERGE}
    msgcat ${PATH_MERGE} $f -o ${PATH_MERGE}
done
sed -i "s#${PATH_ROOT}/##g" ${PATH_MERGE}

# CREATE POs
echo
NEED_RELAUNCH=0
for loc in $LOCALES; do
    path_curr=${PATH_PO}/locale-$loc.po
    # If po file doesn't exist, create it
    if [ ! -f ${path_curr} ]; then
        NEED_RELAUNCH=1
        echo "msginit --no-translator -l $loc.UTF-8 -i ${PATH_MERGE} -o ${path_curr}"
        msginit --no-translator -l $loc.UTF-8 -i ${PATH_MERGE} -o ${path_curr}
        sed -i "s#${PATH_ROOT}/##g" ${path_curr}
        echo "${COPYRIGHT}" > ${path_curr}.copyrighted
        cat ${path_curr} >> ${path_curr}.copyrighted
        rm ${path_curr} && mv ${path_curr}.copyrighted ${path_curr}
        exit
    # Otherwise merge new modifications
    else
        echo -n -e "merging ${path_curr} to ${PATH_MERGE}"
        msgmerge -U ${path_curr} ${PATH_MERGE}
    fi
done

if [ $NEED_RELAUNCH -gt 0 ]; then
    echo "hereabove .po ready for manual changes"
    echo "when changes commited, launch again"
    echo $0
    echo "to finish process and generate ${PATH_DST}"
    exit
fi

# CREATE FINAL JS file in ${PATH_DST}
echo
echo "${COPYRIGHT_JS}" > ${PATH_DST}
echo -n -e "export const LOCALE_DATA = {\n" >> ${PATH_DST}
for loc in $LOCALES; do
    path_curr=${PATH_PO}/locale-$loc.po
    echo "\"locale-${loc}\":{ " >> ${PATH_DST}
    pojson -p ${path_curr} |sed '1d' >> ${PATH_DST}
    echo "," >> ${PATH_DST}
done
echo "}" >> ${PATH_DST}
echo "created ${PATH_DST}"

read -p "confirm delete ${PATH_MERGE} (Ctrl+C to cancel and finish) ?"
rm ${PATH_MERGE}
