#!/usr/bin/env bash
#
# Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
# This source code and any compilation or derivative thereof is the
# proprietary information of Wyplay and is confidential in nature.
# Under no circumstances is this software to be exposed to or placed under
# an Open Source License of any type without the expressed written permission
# of Wyplay.
#
set -euo pipefail
IFS=$'\n\t'

OUTPUT_FOLDER=./doc/framework/

TMPDIR=$(mktemp -d)
FILES=(
  src/core/bus.js
  src/core/Component.js
  src/core/Controller.js
  src/core/events.js
  src/core/http.js
  src/core/Model.js
  src/core/polyfill.js
  src/core/utils/CircularList.js
  src/core/utils/date.js
  src/core/utils/dom.js
  src/core/utils/dvb.js
  src/core/utils/index.js
  src/core/utils/List.js
  src/core/utils/Scrollable.js
  src/core/utils/string.js
)

for SOURCE in ${FILES[@]}; do
  # Convert "src/path/to/Foo.js" to "path-to-Foo"
  CLEAN_NAME=${SOURCE#src/core/}
  CLEAN_NAME=${CLEAN_NAME%%.js}
  TITLE="$CLEAN_NAME API"
  CLEAN_FILENAME=${CLEAN_NAME//\//-}
  TMPFILE="$TMPDIR/api-${CLEAN_FILENAME}.rst"
  OUTFILE="$OUTPUT_FOLDER/api-${CLEAN_FILENAME}.rst"
  echo "Extracting API docs from $SOURCE ($CLEAN_FILENAME)"
  sed -ne "/\/\*\*/,/\*\// w $TMPFILE" $SOURCE
  echo "  Wrote temp file"

  sed -i \
    -e "s/^ *//"\
    -e "/\/\*\*/a \\"\
    -e ""\
    -e "s/\/\*\*/.. /"\
    -e "s/^\*\( \|\/\|$\)/   /"\
    -e "s/^ *$//" $TMPFILE
  echo "  Did substitutions"

  echo $TITLE | sed 's/./#/g' > $OUTFILE
  echo $TITLE >> $OUTFILE
  echo $TITLE | sed 's/./#/g' >> $OUTFILE
  echo "" >> $OUTFILE
  echo "  Added heading substitutions"

  echo ".. default-domain:: js" >> $OUTFILE
  cat doc/framework/common.txt >> $OUTFILE
  echo "" >> $OUTFILE
  echo "  Added common declarations"

  cat $TMPFILE >> $OUTFILE
  echo "  Added API"
done

rm -rf $TMPDIR
