# Contributing Guide

## Git workflow

### Git configuration

Recommended git configuration :
```bash
$ git config --global pull.rebase true
$ git config --global rebase.autoStash true
$ git config --global rerere.enabled true
```

1. [pull.rebase][git-pullrebase]
2. [autoStash][git-autostash]
3. [rerere][git-rerere]

If you are not familiar with git you can try http://learngitbranching.js.org/

[git-pullrebase]: https://git-scm.com/docs/git-pull
[git-autostash]: https://git-scm.com/docs/git-rebase#_configuration
[git-rerere]: https://git-scm.com/blog/2010/03/08/rerere.html

### How to contribute

First, you need to clone the repository.
``$ git clone [repository url]``

Each time you have to develop a new feature, or fix an issue, you must create a branch starting from master branch and  following this naming convention
``wip-<bugtracker_ID>_<little_description_of_the_feature_or_fix>``

Please refer to [section 4 of the SCMP](https://docs.google.com/document/d/1nq5gIXG2t0QR7AecafY7oJxTHcopg09Mfc_A7Ug0oF0/edit#heading=h.dha1nbrd960b)

ie:
```
    $ git checkout master
    $ git pull
    $ git checkout -b wip-XX_my_awesome_feature
```

Then you can develop your functionnality/fix.
You can commit during this process, *the commits are local until you push the branches*
```
    $ git add .
    $ git commit -m "add a new file"
```
Syntax of commit message should respect at least those syntaxes:
```
    Version Bump 0.0.0
    [HOTFIX] My Hotfix
    [FIX][55555] My fix
    [FIX][55555|66666] My fixs
    [US][6] My US
    [US][6|5] My USs
    [TS][0|1] My TSs
    [TECHNICAL] My Technical
```

#### Review Process

When you consider it's ready for review.

##### 1. Prepare the merge request
  Don't forget: if possible one commit per User Story, Technical Story, Fix or Hotfix.
  We use the Merge Request feature of Gitlab to handle the code review process.
  We also use Gitlab's Labels feature to handle the code review process.

  You will need to work on a separate branch,
  and make a Merge Request from this branch to the master branch.

  You can prepare the MR in advance if you want to track your progress,
  just don't ask for a review on a branch that is not ready for integration in `master`.
  You can use the ~"review: not ready" label to clearly state that merge should not occur yet.

  Before asking for a review, make sure that your branch is rebased against the current `master` branch.

```
    $ git checkout master
    $ git pull
    $ git checkout wip-XX_my_awesome_feature
    $ git rebase master
```

##### 2. Resolve conflicts if any
  Don't hesitate to ask some help from your team if you aren't familiar with that.


##### 3. Then push your code.
```
  $ git push -u origin wip-XX_my_awesome_feature
```

##### 4. Go on the gitlab web interface and create the [merge request][mr].
Verify that the tests pass before create the merge request.
When you feel your branch is ready for review, simply add the ~"review: open for review" label to your MR and
assign it to one of approvers or to the technical leader.
Don't forget to check ``Remove source branch when merge request is accepted`` if needed to avoid leaving an useless branch.

##### 5. The technical leader or developer review the code
During this part of work he will set ~"review: ongoing" label.

##### 6. Fix your merge request (if needed)
If merge request is not ready to be integrated reviewer will set the label ~"review: changes needed" and reassign
the merge request to the developer.
In this case the developer will restart from step [1].

Otherwise the technical leader or experimented developer accept the produced code, and will merge the branch.

[mr]: https://gitlab.wyplay.com/common/apps_frog-ui/merge_requests/new

#### Bump Process

Each time technical leader has to bump the UI, he will take the code from common group and rebase it to the frogbywyplay group, then publish it.


