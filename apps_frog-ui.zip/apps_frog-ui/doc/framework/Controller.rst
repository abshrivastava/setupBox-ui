Controller
==========

Controllers are responsible for implementing the application logic and
navigation by interacting with the API through :js:class:`Model` and Services
classes and displaying information through :js:class:`Component`.

.. code:: text

    import {$, Component} from "widgets/Component"
    import Controller from "utils/Controller"

    class SimpleController extends Controller {
      constructor() {
        super()
        this.view = $("SimpleComponent")
      }
      actionName() {
       this.view.setValue("Hello world!")
      }
    }

    Controllers.SimpleController = new SimpleController()

    class SimpleComponent extends Component {
      static ref = "SimpleComponent"

      constructor(props) {
        super(props)
      }

      render() {
        return (
          <span prop="message">{this.props.message}</span>
        )
      }

      setValue(message) {
       this.setProp("message", message)
      }
    }


API
---

.. toctree::

   api-Controller
