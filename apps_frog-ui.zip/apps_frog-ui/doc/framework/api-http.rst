########
http API
########

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. class:: http.sse()


     :returns Object:

   .. code-block:: js

      import sse from "services/http"

      function callback(data) {
        console.log(data)
      }

      sse.connect()
      sse.addEventListener("player", callback, "playback"}
      sse.removeEventListener("player", callback)

.. function:: http.formUrlencoded(body)


     :returns Object:

   .. code-block:: js

      formUrlencoded() //=>

.. function:: http.createQueryString(parameters)


     :returns String:

   .. code-block:: js

      createQueryString() //=>

.. function:: http.GET(path, options)

   GET

     :returns Promise:

   .. code-block:: js

      GET("http://127.0.0.1/player/")

.. function:: http.PUT(path, body, options)

   PUT

     :returns Promise:

   .. code-block:: js

      PUT("http://127.0.0.1/player/", null, null)

.. function:: http.POST(path, body, options)

   POST

     :returns Promise:

   .. code-block:: js

      POST("http://127.0.0.1/player/", null, null)

.. function:: http.DELETE(path, options)

   DELETE

     :returns Promise:

   .. code-block:: js

      DELETE("http://127.0.0.1/player/")

