#############
Component API
#############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  Top level component references. To make a component top level, give it a

   `ref` property with the name you want.

   You can then use the :js:func:`$` helper function to retrieve the component
   in the controllers.

..  class:: Component([props, children])

   See :js:attr:`.props` for details about properties.

    :param Object<string, any> props: Properties.
    :param Array<> children: Children.

..  data:: static defaultProps

   Default properties of a component. To redefine in children classes.

     :type: Object<string, any>

..  attribute:: dom

   Root DOM Element of the Component.

     :type: ?Element

..  attribute:: className

   Shortcut to the className of the root DOM Element.

     :type: ?string

..  attribute:: props

   Component properties.

     :type: Object<string, any>

..  attribute:: children

   Children nodes or components.

     :type: Array<>

..  attribute:: _propRefs

   References to nodes that are bound to some properties.

     :type: Object<string, Array<Node>>
     :private:

..  function:: render()

   Renders the DOM Element of the Component.

   Derived components must implement this method and ensure it returns a DOM
   Element.

     :throws Error: Must be overriden by the subclass
     :returns Element: The root element of the component

..  function:: build()

   Renders the component.

   It will also automatically infer the base components `className` by using
   the first class found in the root node's `classList`.

     :returns Element: The root node created by #render()

..  function:: destroy()

   Destroys the DOM for this component and detach from parent.

   It will NOT recursively destroy children components.

..  function:: setProps(props = {})

   Changes the value of a set of properties and update all the nodes that
   are bound to them.

   See :js:func:`.setProp`.

     :param Object<string, any> props: Map of name/value for the new
       properties

..  function:: setProp(propName, propValue)

   Changes the value of a property and update all the nodes that are bound to
   it.

     :param String propName: Name of the property to change
     :param <*> propValue: New value for the property

..  function:: show()

   Removes the `hidden` BEM state on this component

..  function:: hide()

   Adds the `hidden` BEM state on this component

..  function:: pushState(state[, onTransitionEnd])

   Adds a BEM state on this component, optionally passing a callback to be
   executed on transition end.

   Be cautious that if you give a transition callback and do not define a CSS
   transition for this state,

     :param String state: Name of the state to add
     :param ?Function willTransition:
       Flag to set when state changes causes a transition

..  function:: pullState(state[, onTransitionEnd])

   Removes a BEM state on this component, optionally passing a callback to be
   executed on transition end.

   Be cautious that if you give a transition callback and do not define a CSS
   transition for this state,

     :param String state: Name of the state to remove
     :param ?Function willTransition:
       Flag to set when state changes causes a transition

..  function:: addTransitionListener(callback)

   Adds a transition listener on the root DOM node of the component.

     :param Function callback: Transition callback

..  function:: removeTransitionListener(callback)

   Removes a transition listener from the root DOM node of the component.

     :param Function callback: Transition callback

..  function:: _addPropRef(propName, node)

   Bind a node to be automatically updated whenever a given property changes.

     :param String propName: Name of the bound property
     :param Node node: The node to register
     :protected:

..  function:: $(ref)

   Returns a top level component by its reference.

     :param String ref: Reference name

