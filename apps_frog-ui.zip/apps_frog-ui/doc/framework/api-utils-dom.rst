#############
utils/dom API
#############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: utils.dom.pushState(domNode, bemState, willTransition, className)

   Adds a new class on specific Element

     :param Element domNode: DOM Element to push new class
     :param String bemState:
     :param Boolean willTransition:
     :param String className:
     :returns Promise:

   .. code-block:: js

      pushState(document.getElementById("body"), "selected", false, "item")

.. function:: utils.dom.pullState(domNode, bemState, willTransition, className)

   Removes a class on specific Element

     :param Element domNode: DOM Element to push new class
     :param String bemState:
     :param Boolean willTransition:
     :param String className:
     :returns Promise:

   .. code-block:: js

      pushState(document.getElementById("body"), "selected", false, "item")

.. function:: utils.dom.addTransitionListener(domNode, callback)

   Registers the specified callback on the Element it's called on.

     :param Element domNode: DOM Element
     :param Function callback: function

.. function:: utils.dom.removeTransitionListener(domNode, callback)

   Unregisters the specified callback on the Element it's called on.

     :param Element domNode: DOM Element
     :param Function callback: function

.. function:: utils.dom.disableTransitions(domNode)

   Adds a class u-noTransitions on Element

     :param Element domNode: DOM Element

.. function:: utils.dom.restoreTransitions(domNode, callback)

   Removes class u-noTransitions from Element

     :param Element domNode: DOM Element

.. function:: utils.dom.waitReflow(domNode)

   Force reset of any Element animation

     :param Element domNode: DOM Element

.. function:: utils.dom.clearNode(node)

   Remove all children of an Element

     :param Element node: DOM Element

