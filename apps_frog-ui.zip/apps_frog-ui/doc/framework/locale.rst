Locale
======

How to customize locales in Frog-ui

Prerequisites:
--------------

dependencies required by ``script/locale.sh``

- ``babel`` to extract translatable content from js files ::

  $ apt-get install babel

- ``python-babel`` python module for Babel ::

  $ apt-get install python-babel

- ``gettext`` to use ``msginit`` tool to create (\*.po) translation files ::

  $ apt-get install gettext

- ``locale-po to json`` `Convert PO files to json <https://pypi.python.org/pypi/pojson>`__ ::

  $ apt-get install python-pip
  $ pip install pojson

How to generate locales from \*.po files:
-----------------------------------------

Simply execute ``script/locale.sh`` file.
It will generate a json file stored in ``locales/index.js``
This file is then used by the Frog UI.


How to add a new language in Frog UI:
-------------------------------------

1. You have to add new Locales in the ``script/locale.sh file`` at line 42: 

::

  LOCALES="en_EN fr_FR de_DE"


2. Then, run the ``script/locale.sh`` file.
It will generate a new PO file in ``locales/po/`` directory and the filename will be: ``locale_de_DE.po``

3. Make your translation in this file using your favorite text editor or by using `poedit <https://poedit.net/>`__

4. Execute again the ``script/locale.sh`` file
It will generate the json file used by the Frog UI

5. finally, modify the settings model file ``src/app/models/Settings.js`` for enabling this new language. 

::

    #from
    const languages = ["en", "fr"]
    # to
    const languages = ["en", "fr", "de"]

6. that its, you have a new language available.

