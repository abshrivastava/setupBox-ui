################
utils/string API
################

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: utils.string.padLeft(string, padChar, size)

   Pads a string on its left using up to a given size

     :param String string: String to pad
     :param String padChar: Character to use for padding
     :param Number size: Size of the output string
     :returns String:

   .. code-block:: js

      padLeft("1", "0", 4") // => "0001"

.. function:: utils.string.capitalize(string)

   Capitalizes the first letter of a string.

     :param String string: The string to capitalize
     :returns String:

   .. code-block:: js

      capitalize("hello") //=> "Hello"

.. function:: utils.string.camelCase(string)

   Transforms a snake_case_string to a camelCaseString.

     :param String string: The string to camelcase
     :returns String:

   .. code-block:: js

      camelCase("record_task_created") //=> "recordTaskCreated"

.. function:: utils.string.isoToName(isoVersion, isoCode)

   Transforms a iso code to a language.

     :param String isoVersion: The iso Version
     :param String isoCode:
     :returns String:

   .. code-block:: js

      isoToName("3", "eng") //=> "English"

