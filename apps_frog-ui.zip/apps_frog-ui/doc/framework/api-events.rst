##########
events API
##########

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  function:: on(event)

   A decorator used for listen application events

     :implements: |-ext-js-decorators|_

   .. code-block:: js

      import {on} from "services/events"
      import bus from "services/bus"

      @on("event")
      function onEvent() {
        console.log("event catched")
      }

      bus.emit("event") //=> "event catched"

..  function:: @rcu(event)

   A decorator used for listen RCU key events

     :implements: |-ext-js-decorators|_

   .. code-block:: js

      import {rcu} from "services/events"

      @rcu("up:press")
      function onUp() {
        console.log("key Up pressed")
      }

..  function:: @sse(event, filter)

   A decorator used for listen SSE events

      :param string event: the event to listen
      :param ? filter:

     :implements: |-ext-js-decorators|_

   .. code-block:: js

      import {sse} from "services/events"

      @sse("player", {subtype: "epg_update"})
      function onEpgUpdate(data) {
        console.log("Epg updated", data)
      }

.. function:: enableEvents(o)




