Router
======

The Router is responsible for driving user- and UI-generated events to the
right code paths that will handle them.

It maintains an internal context and follows a set of rules (named *routes*) to
go from one to another while performing actions.

A route is an object of the following shape:

.. code-block:: js

    {
      "from": "sourceContext",
      "when": eventMatcher,
      "to": "targetContext",
      "action": () => doSomething(),
    }

Whenever an event is produced (see `Event matchers <#event-matchers>`__), the
Router will perform the following steps:

1. Get all routes where the ``from`` field is equals to the current context;
2. Select the first route where the ``when`` field matches the processed event;
3. Execute the function in the ``action`` field;
4. Switch context to the value in the ``to`` field.

If the third step returns a Promise, it will wait for its resolution before
switching to the target context.

Please note that only the ``when`` field is mandatory:

-  If you want your route to be a fallback, omit the ``from`` field;
-  If you don't want to change context, omit the ``to`` field;
-  If you don't want to perform any action, omit the ``action``.

Triggering events
-----------------

Events are triggered using the :js:func:`~router.trigger` method. It takes a
source and an event, plus some arbitrary arguments.

The router will check for routes that match this event, and it will take the
first that does. It then executes this route's action, waiting for it to finish
if it returns a Promise, and then change the context to the one specified by
the ``to`` field of the route, if present.

If no route matches for the current context, the router will then check for
routes without a ``from`` field and repeat the same process.

Any extra arguments to :js:func:`~router.trigger` will be passed to the route's
action function.

Event matchers
--------------

A matcher is simply an object that tells with source and wich events a route
responds to. The keys must be source names, and the values event values.

Example
-------

.. code-block:: js

    var router = new Router()
    router.addRoutes([
      {
        from: null,
        when: {keydown: 13}, // Enter
        to: "popup",
        action: (label) => showPopup(label),
      }
    ])

    document.body.addEventListener("keydown", (ev) => {
      router.trigger("keydown", ev.keyCode, "Hello world!")
      ev.preventDefault()
    }, true)

This example creates a router and bind keydown events to the triggering of a
``"keydown"`` event. Every time the user presses enter, ``showPopup`` is called
with ``"Hello world!"`` as argument.

After ``showPopup`` is called, the internal context changes to ``"popup"``.

API
---

.. toctree::

   api-Router

