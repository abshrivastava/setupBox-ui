#########
Model API
#########

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. class:: Model()


