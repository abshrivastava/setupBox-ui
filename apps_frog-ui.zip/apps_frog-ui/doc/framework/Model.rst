Model
=====

Models are responsible for representing data coming from the middleware's
REST API.

To interact with the API, please the the {@link GET}, {@link POST}, {@link PUT}
and {@link DELETE} functions from the {@link src/http.js} module.

API
---

.. toctree::

   api-Model

