##########
Router API
##########

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: router.addRoutes(routes)

   Add a list of routes to the Router.
     :param Array routes: The list of routes to add
     :shape routes: {from: string, to: string, when: Object, action: Function}

.. function:: router.trigger(source, event[, ...args])

   Checks if there is a route matching the given event source and value, and
   execute it if found.

   Any extra argument will be passed to the matching route's action function.
     :param string source: The event source name
     :param <*> event: The value of the event
     :returns Promise:

