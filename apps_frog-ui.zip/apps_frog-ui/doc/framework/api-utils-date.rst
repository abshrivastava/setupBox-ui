##############
utils/date API
##############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

.. function:: utils.date.addHours(d, h)

   Returns a new Date Object that adds the specified number of hours to the given Date Object..

     :param date d: Date Object or timestamp
     :param int h: hours to add
     :returns Date:

   .. code-block:: js

      addHours(new Date(0), 1) // => Thu Jan 01 1970 02:00:00 GMT+0100 (CET)

.. function:: utils.date.addMinutes(d, m)

   Returns a new Date Object that adds the specified number of minutes to the given Date Object..

     :param date d: Date Object or timestamp
     :param int m: minutes to add
     :returns Date:

   .. code-block:: js

      addHours(new Date(0), 17) // => Thu Jan 01 1970 01:17:00 GMT+0100 (CET)

.. function:: utils.date.unixToUpnp(unixTimestamp)

   Returns a UPNP Timestamp (in seconds) from given UNIX Timestamp (in seconds)

     :param int unixTimestamp: unix timestamp
     :returns Int:

   .. code-block:: js

      unixToUpnp(new Date(0).getTime()) // => 2208988800 (s)

.. function:: utils.date.upnpToUnix(unixTimestamp)

   Returns an Unix Timestamp (in ms) from given UPNP Timestamp (in ms)

     :param int upnpTimestamp: unix timestamp
     :returns Int:

   .. code-block:: js

      unixToUpnp(2208988800) //=> 0 (s)

.. function:: utils.date.dateToCdsTimestamp(unixTime)

   Returns the NTP timestamp of the given date in seconds

     :param Date unixTime: Unix Date object
     :returns Int:

   .. code-block:: js

      dateToCdsTimestamp(new Date(0)) //=> 2208988800 (s)

.. function:: utils.date.cdsTimestampToDate(upnpTimestamp)

   Returns a Date Obejct representing the given UPNP timestamp

     :param int unixTime: Unix Date object
     :returns Date:

   .. code-block:: js

      cdsTimestampToDate(2208988800) //=> Thu Jan 01 1970 01:00:00 GMT+0100 (CET)

.. function:: utils.date.formatDate(date)

   Returns a String 'Day Mon DayNumber Year' of given Date object

     :param Date date: Date object
     :returns String:

   .. code-block:: js

      formatDate(new Date(0)) //=> Thu January 1st 1970

.. function:: utils.date.formatTime(date)

   Returns a String "Hours:Minutes "of given Date object

     :param Date date: Date object
     :returns String:

   .. code-block:: js

      formatTime(new Date(0)) //=> 01:00

.. function:: utils.date.formatDuration(duration)

   Returns a String "Hours:Minutes "of given duration (in seconds)

     :param int duratin,: duration in seconds
     :returns String:

   .. code-block:: js

      formatDuration(3600) //=> 60min

.. function:: utils.date.toDayString(date)

   Returns a String "Day "of given date Object

     :param Date date,: Date object
     :returns String:

   .. code-block:: js

      toDayString(new Date(0)) //=> Thursday

.. function:: utils.date.toDateString(date)

   Returns a String "Day "of given date Object

     :param Date date,: Date object
     :returns String:

   .. code-block:: js

      toDateString(3600) //=> December 1st

