##############
utils/List API
##############

.. default-domain:: js
.. This file defines common substitutions that can be used in the framework
   docs.

.. _-ext-js-decorators: https://github.com/wycats/javascript-decorators
.. |-ext-js-decorators| replace:: Decorator

..  class:: List(items)


    :param Array<> items: Items.

..  attribute:: items

   Items to store in List Object

     :type: Array

..  attribute:: count

   Number of item

     :type: Int

..  attribute:: length

   Returns the length of the List

     :returns Int: Number of items in the list

   .. code-block:: js

      const list = new List(["a", "b", "c"])
      list.length //=> 3

..  function:: get(index)

   Returns item at specified index

     :param Int index: List Index
     :return Object: Item at the index

   .. code-block:: js

      const list = new List(["a", "b", "c"])
      list.get(1) //=> "b"

..  function:: set(index, value)

   Set item at specified index

     :param Int index: List Index
     :param Object value: Item to put in list

   .. code-block:: js

      const list = new List(["a", "b", "c"])
      list.set(2 "C") //=> ["a", "b", "C"]

..  function:: push(...items)

   Appends items at the end of the List

     :param ?Object items: Items to append

   .. code-block:: js

      const list = new List(["a", "b", "c"])
      list.push("d", "e") //=> ["a", "b", "c", "d", "e"]

..  function:: indexOf(item)

   Returns index of specified item

     :param ?Object item: Item

   .. code-block:: js

      const list = new List(["a", "b", "c"])
      list.indexOf("c") //=> 2

..  function:: update(items)

   Update items

     :param ?Object items: Items to put in the List

   .. code-block:: js

      const list = new List()
      list.update(["a", "b", "c"]) //=> ["a", "b", "c"]

..  function:: getRange(start, length)

   Return all items in the specified range

     :param Int start: Index
     :param Int length: Number of items to return
     :returns Array:

   .. code-block:: js

      const list = new List(["a", "b", "c", "d", "e", "f"])
      list.getRange(2, 2) //=> ["c", "d"]

