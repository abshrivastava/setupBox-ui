.. fragment: description of important compilation options
   expected by ./ref-configuration.rst

.. .....................................................................
   Change this line depending on your auto conf system.
   .....................................................................

To see all the compilation options, go to the source code and call `configure --help` from the command line.

.. .....................................................................
   Only document special or tricky options here, not the whole set.
   Use the object directive:

   .. object:: --stuff

      Compiles stuff.
   .....................................................................


