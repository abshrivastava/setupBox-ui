.. fragment: description of dependencies that are not automatically retrieved
   from the component's ebuild, or that require more information
   expected by ./overview.rst
