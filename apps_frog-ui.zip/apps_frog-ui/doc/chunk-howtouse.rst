.. fragment: introduction about how to use the component
   expected by the component overview

.. .....................................................................
   Contents: Short explanation (a few paragraphs) about how the component works and prerequisites about using it

   More content: add files to the TOC tree below, such as:
   * howitworks.rst (concepts and diagrams)
   * definitions.rst (concepts)
   * feature1.rst (guide)

   The TOC tree must be the last thing in the file.
   ......................................................................

Frog Turnkey UI `Video <https://www.youtube.com/watch?v=WH-iJZYgh4Q&feature=youtu.be>`_.

.. toctree::
   :maxdepth: 2

	
