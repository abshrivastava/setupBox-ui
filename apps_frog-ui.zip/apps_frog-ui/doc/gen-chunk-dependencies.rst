Here will go the auto-generated dependencies of your ebuild when ran from (e|x)merge
