.. fragment: describe main execution options
   expected by ref-configuration.rst

.. .....................................................................
   Contents:
   If n/a, "Not an executable."
   Otherwise, use the program, envvar, option directives as in the example:

   .. program:: packagename (usually)

   .. envvar:: BLAH

      Description of the environment variable

   .. option:: -v <value>, --velociraptor <value>

      Description of the command line option
   .....................................................................

Not an executable.
