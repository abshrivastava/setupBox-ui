Hello World
===========

Prerequisites
-------------

You have read the :ref:`guide-webapp-dev`.
It explains how to start the UI locally on your computer.
It also explains how to interact with the middleware of the STB.

Goal of this Lesson
-------------------

In this lesson, you first create a simple "universe" that displays a text.
Then, the text displayed in the universe page will display information from MiddleWare.
Finally, you will listen to middleware events and display messages on the UI.

Create a Component
------------------

Create a directory named HelloWorld in ``src/app/components/universes/``.
Then create an index.js file in it: ``src/app/components/universes/HelloWorld/index.js``.

.. code-block:: console

   mkdir src/app/components/universes/HelloWorld
   touch src/app/components/universes/HelloWorld/index.js


Open it using your favorite editor and create the Component.

.. code-block:: js

    import Component from "widgets/Component"

    export default class HelloWorld extends Component {
      constructor(props) {
        super(props)
      }

      render() {
        return (
          <div className="HelloWorld HelloWorld--hidden">
            <div className="HelloWorld-text" key="text"/>
          </div>
        )
      }

    }


Your component has been created, but there is no style on it.
You first need to create the index.css file in ``src/app/components/universes/HelloWorld/``.

.. code-block:: console

   touch src/app/components/universes/HelloWorld/index.css


And lets put some css code in it:

.. code-block:: css

   .HelloWorld{
     position: absolute;
     height: 720px;
     width: 1280px;
     background-color: black;
   }

   .HelloWorld--hidden{
     display: none;
   }

   .HelloWorld-text{
     position: relative;
     top: 100px;
     left: 100px;
     font-size: 47px;
     font-family: "Wyplay Sans ExtraLight";
     overflow: hidden;
     color: white;
   }


You now need to attach the css to your component.
Return to your ``src/app/components/universes/HelloWorld/index.js`` and import the css file at the beginning of the file, under the ``Component`` import.
Now, the result looks like this:

.. code-block:: js

    import Component from "widgets/Component"
    import "./index.css"

    export default class HelloWorld extends Component {
      constructor(props) {
        super(props)
      }

      render() {
        return (
          <div className="HelloWorld HelloWorld--hidden">
            <div className="HelloWorld-text" key="text"/>
          </div>
        )
      }

    }


Your Component has been created, you need to import it in order to be able to display it.
Open ``src/app/components/index.js`` file.
And add your Component in it by first importing it:

.. code-block:: js

   import HelloWorld from "app/components/universes/HelloWorld"


And then add the component to the DOM tree and give him a ``ref`` attribute:

.. code-block:: html

   <HelloWorld ref="helloWorld"/>


Now, the result looks like this:

.. code-block:: js

    import classNames from "classnames"

    import config from "utils/config"
    import Component from "widgets/Component"

    import Vod from "app/components/universes/Vod"
    import PVR from "app/components/universes/PVR"
    import Home from "app/components/universes/Home"
    import EpgGrid from "app/components/universes/EpgGrid"
    import Settings from "app/components/universes/Settings"
    import Television from "app/components/universes/Television"
    import AppWidgets from "app/components/universes/Application"
    import Mediacenter from "app/components/universes/Mediacenter"
    import Advertisement from "app/components/universes/Advertisement"
    import HelloWorld from "app/components/universes/HelloWorld"

    import "./index.css"

    export default class Application extends Component {
      static ref = "application"

      render() {
        const appStyles = classNames(
          "Application",
          config.IS_REMOTE && "Application--remote",
        )

        return (
          <div className={appStyles}>
            <Television ref="TelevisionUniverse"/>
            <EpgGrid ref="EpgGridUniverse"/>
            <PVR ref="PVRUniverse"/>
            <Mediacenter ref="MediacenterUniverse"/>
            <Settings ref="SettingsUniverse"/>
            <Home ref="homeMenu"/>
            <Vod ref="vodMenu"/>
            <Advertisement ref="AdvertisementUniverse"/>
            <AppWidgets ref="ApplicationUniverse"/>
            <HelloWorld ref="helloWorld"/>
          </div>
        )
      }
    }


Create a Controller
-------------------

Now that you have a Component that can display some text, let's add a controller for updating the text:

First, you will create a new directory named HelloWorld in ``src/app/controllers/`` and create an ``index.js`` file in it.

.. code-block:: console

   mkdir src/app/controllers/HelloWorld
   touch src/app/controllers/HelloWorld/index.js


Open the created file and let's put the minimal Controller code:

.. code-block:: js

    import Controller from "utils/Controller"

    export default class HelloWorldController extends Controller {
      constructor() {
        super()
      }
    }

And you need to import this new Controller in ``src/app/controllers/index.js``.


Now, the result looks like this:

.. code-block:: js

    export {default as Advertisement} from "./Advertisement"
    export {default as Application} from "./Application"
    export {default as EpgGrid} from "./EpgGrid"
    export {default as Home} from "./Home"
    export {default as PVR} from "./PVR"
    export {default as Mediacenter} from "./Mediacenter"
    export {default as Settings} from "./Settings"
    export {default as Television} from "./Television"
    export {default as Vod} from "./Vod"
    export {default as HelloWorld} from "./HelloWorld"


We said at the start of this lesson the ``HelloWorld`` is a new "universe" accessible from the Home Menu.
For that, we will add a new item on the Home Menu by modifying the ``src/app/models/Home.js`` file:

Add a new object in the ``ITEMS`` object defined at the beginning of the file.

.. code-block:: js

    ...
    import config from "utils/config"

    const ITEMS = {
      "hello": {
        label: "Hello World",
        icon: "",
        signal: "goto",
        args: "helloWorld",
      },
      "tv": {
        label: "Tv",
        icon: "tv",
    ...


Now, if you start the UI like this:

``http://localhost:8080/?homeItems=hello,tv,tv%20recordings,epg,vod,application%20store,media%20player,settings``

You will be able to see you new Item ``Hello World`` displayed on the main menu.


Enter in HelloWorld universe and display Hello World
----------------------------------------------------

Now that we have the Hello World universe accessible from the Home Menu, we want to display our new component when pressing ``OK`` from the remote/keyboard on this item.
For this, let's explain a little what happens when pressing OK on a Home Item.

When pressing an RCU key from the Home Menu, the keyboardEvent is catched by the Application and then a signal is emitted by ``Bus`` Class.
Code that catch events and emit the bus event is in the ``src/index.js`` file:

.. code-block:: js

    ...
    // Listen User Inputs
    document.body.addEventListener("keydown", utils.throttle((ev) => {
      bus.handleRcuEvent(ev.keyCode, "press", ev)
      ev.preventDefault()
    }, 100), true)

    document.body.addEventListener("keyup", utils.throttle((ev) => {
      bus.emit("window:keyPressed", ev.keyCode, ev.keyIdentifier)
      bus.handleRcuEvent(ev.keyCode, "release", ev)
      ev.preventDefault()
    }, 100), true)
    ...


And if you take a look at the ``Bus.handleRcuEvent()`` method defined in ``src/core/bus.js`` file, a message is emitted to the application:

   ``rcu#UNIVERSE_NAME:KEYNAME:TYPE``

with:

* ``UNIVERSE_NAME`` = the name of the active universe
* ``KEYNAME`` = the name of the key pressed or released
* ``TYPE`` = the type of event: ``pressed`` or ``released``

and for helping development, you can use the ``@rcu`` notation for decorating a function that will be fired when a rcu event is triggered (the decorators are defined in the ``src/core/events.js`` file.

So, if you take a look at the ``HomeController`` defined in ``src/app/controllers/Home.js``, there are some methods that listens to RCU events:

.. code-block:: js

    ...
      @rcu("home:ok:press")
      onOk() {
        super.trigger()
      }
    ...


So each time you are in Home universe, and each time OK key is pressed, the ``onOk```function will be called.
basically, it will call a function ``trigger`` defined in ``OptionMenuController``.
What you need to know on this function is:
It will emit a signal for the application.

.. code-block:: js

    ...
      if (item.signal && !item.default) {
        toNextLevel = false
        return bus.emit(item.signal, item)
      }
    ...


This signal can be catched using a decorator ``@on`` (defined in the ``src/core/events.js`` file).
It's basically the same mechanism as the ``@rcu`` decorator.
I mean, the decorated function will be triggered when the signal is emitted.

So, now, we have those concept in mind, we can return to our HelloWorld universe and display the HelloWorld page when pressing OK on Hello World item from Home Menu.

First, we can define show() and hide() functions in the ``HelloWorld`` component.
Those functions will push/pull a className ``HelloWorld--hidden`` using the special Component Methods: ``pullState`` / ``pushState``.

.. code-block:: js

    show() {
      this.pullState("hidden")
    }

    hide() {
      this.pushState("hidden")
    }


You can also create a method updateText that will update the text in the div with className: ``HelloWorld-text`` and key ``text``.

.. code-block:: js

    updateText(value) {
      this.text.textContent = value
    }


Our ``HelloWorld`` component looks like this now:

.. code-block:: js

    import Component from "widgets/Component"
    import "./index.css"

    export default class HelloWorld extends Component {
      constructor(props) {
        super(props)
      }

      render() {
        return (
          <div className="HelloWorld HelloWorld--hidden">
            <div className="HelloWorld-text" key="text"/>
          </div>
        )
      }

      show() {
        this.pullState("hidden")
      }

      hide() {
        this.pushState("hidden")
      }

      updateText(value) {
        this.text.textContent = value
      }
    }


Now, on Controller side you first need to define the view you will control by adding it in the constructor method.

.. code-block:: js

  constructor() {
    super()
    this.view = $("helloWorld") // "helloWorld" is the name you have put as a "ref" in the src/app/components/index.js file
  }


Don't forget to import the ``$`` symbol at the beginning of the file (used for accessing a view from a controller using its ``ref`` name).

.. code-block:: js

    import {$} from "widgets/Component"


We also need to import the decorators ``rcu`` and ``on``, still at the beginning of the file:


.. code-block:: js

    import {rcu, on} from "services/events"

And we can now define the methods that will display/hide the view when entering/exiting the HelloWorld universe by calling the show/hide method defined on view side.
Also, let's display "Hello World" when opening this universe.

.. code-block:: js

    @on("helloWorld:open")
    open() {
      this.view.show()
      this.view.show()
    }

    @rcu("helloWorld:back:press")
    close() {
      this.view.hide()
    }

If you test your code, when pressing OK on the HelloWorld, you enter your new Universe.
But, when pressing Back, you exit the menu, but it doesn't returns to HomeMenu.
We miss something.

You have to say to the bus that you want to open the ``home`` universe:

.. code-block:: js

    @rcu("helloWorld:back:press")
    close() {
      this.view.hide()
      bus.openUniverse("home")
    }

And don't forget to import the ``bus`` object at the beginning of your file:


.. code-block:: js

    import bus from "services/bus"


Now, our ``HelloWorldController`` code looks like this:

.. code-block:: js

    import Controller from "utils/Controller"
    import {$} from "widgets/Component"
    import {rcu, on} from "services/events"
    import bus from "services/bus"

    export default class HelloWorldController extends Controller {
      constructor() {
        super()
        this.view = $("helloWorld")
      }

      @on("helloWorld:open")
      open() {
        const text = "Hello World"
        this.view.updateText(text)
        this.view.show()
      }

      @rcu("helloWorld:back:press")
      close() {
        this.view.hide()
        bus.openUniverse("home")
      }
    }


That it, you have a new Universe ``Hello World`` accessible from the Home Menu where you can display a text.


Display data by calling REST Api
--------------------------------

You have now capabilities to display a text in a page coming from your controller.
Now, let's display a data coming from MW by calling a simple REST API.

Let's for example display the current volume level.
And update it each time we press ``volumeUp``/``volumeDown`` key.

We need for that to know the API:
By taking a look at the REST Api documentation:

``https://portalnightly.frogbywyplay.com/docs/wytv/featured/components/appframeworks-wyrest/wyrest/http/routes/#player``


.. code-block:: none

   GET /player/config/volume/

    Get the current volume of the player

  Sample response: {"volume":20}

So, now we know this, we can go back to our HelloWorldCntroller and start to write code.

First thing is to import the ``GET`` helper defined in ``src/core/https.js`` file.

.. code-block:: js

    import {GET} from "services/http"


And we want to display the current volume level when opening the Hello World universe:
For that, we will first create a new function that returns the value.
We need to change the ``open()`` method for that.
You will notice that ``GET`` returns a Promise, so you have to attach a chained function.


.. code-block:: js

    getCurrentVolumeLevel() {
      return GET("/player/config/volume/")
        .then((data) => {
          const volume = data.volume
          const text = "Current Volume Level is: " + volume
          this.view.updateText(text)
        })
    }


We can now display the current volume level when opening the Hello World universe.
By modifying the open method.

.. code-block:: js

  @on("helloWorld:open")
  open() {
    this.getCurrentVolumeLevel()
    this.view.show()
  }


And now, last step is to update the text each time we press volume up/down.


.. code-block:: js

  @rcu("helloWorld:volume_plus:press")
  @rcu("helloWorld:volume_minus:press")
  updateVolumeLevel() {
    this.getCurrentVolumeLevel()
  }

The HelloWorldController class looks like that now:

.. code-block:: js

  import Controller from "utils/Controller"
  import {$} from "widgets/Component"
  import {rcu, on} from "services/events"
  import bus from "services/bus"
  import {GET} from "services/http"

  export default class HelloWorldController extends Controller {
    constructor() {
      super()
      this.view = $("helloWorld")
    }

    @on("helloWorld:open")
    open() {
      this.getCurrentVolumeLevel()
      this.view.show()
    }

    @rcu("helloWorld:back:press")
    close() {
      this.view.hide()
      bus.openUniverse("home")
    }

    @rcu("helloWorld:volume_plus:press")
    @rcu("helloWorld:volume_minus:press")
    updateVolumeLevel() {
      this.getCurrentVolumeLevel()
    }

    getCurrentVolumeLevel() {
      return GET("/player/config/volume/")
        .then((data) => {
          const volume = data.volume
          const text = "Current Volume Level is: " + volume
          this.view.updateText(text)
        })
    }
  }


If you test it, you will notice that the current volume level is well displayed when entering the Hello World menu.
But nothing is refreshed when volume_plus/volume_minus are pressed.

What's wrong?
Actually, the update of volume level is already managed by another controller.
So, let's call the APIs already defined.
And let's update our code.

First, import the needed functions:

.. code-block:: js

    import {increaseVolume, decreaseVolume} from "services/managers/volume"


We also have to change our approach by creating 2 functions instead of ``updateVolumeLevel``.
One for increasing volume, and the other for decreasing volume.
Let's do it:

.. code-block:: js

  @rcu("helloWorld:volume_plus:press")
  volumeUp() {
    increaseVolume().then(() => {
      this.getCurrentVolumeLevel()
    })
  }

  @rcu("helloWorld:volume_minus:press")
  volumeDown() {
    decreaseVolume().then(() => {
      this.getCurrentVolumeLevel()
    })
  }

Our HelloWorldController class looks like this now:

.. code-block:: js

    import Controller from "utils/Controller"
    import {$} from "widgets/Component"
    import {rcu, on} from "services/events"
    import bus from "services/bus"
    import {GET} from "services/http"
    import {increaseVolume, decreaseVolume} from "services/managers/volume"

    export default class HelloWorldController extends Controller {
      constructor() {
        super()
        this.view = $("helloWorld")
      }

      @on("helloWorld:open")
      open() {
        this.getCurrentVolumeLevel()
        this.view.show()
      }

      @rcu("helloWorld:back:press")
      close() {
        this.view.hide()
        bus.openUniverse("home")
      }

      @rcu("helloWorld:volume_plus:press")
      volumeUp() {
        increaseVolume().then(() => {
          this.getCurrentVolumeLevel()
        })
      }

      @rcu("helloWorld:volume_minus:press")
      volumeDown() {
        decreaseVolume().then(() => {
          this.getCurrentVolumeLevel()
        })
      }

      getCurrentVolumeLevel() {
        return GET("/player/config/volume/")
          .then((data) => {
            const volume = data.volume
            const text = "Current Volume Level is: " + volume
            this.view.updateText(text)
          })
      }
    }

And if you test it, it works.
Challenge done.


Display data SENT by the MiddleWare
-----------------------------------

We have seen before how to display data by performing request to the MW.
What we will do now is to display data coming from MW by listening to events.

Let say that we want to display a text each time an usb key is plugged.

For that, we will use the SSE mechanism.
SSE means: Server Sent Event. for more information, take a look at this `Online Documentation <https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events>`_ .

For ease development, and in order to keep the same approach as RCU events using ``@rcu`` and Application events using ``@on``.
We have created an helper ``@sse`` defined in ``src/core/events.js`` file.
This decorator is able to filter the type of message we want to manage.

First thing to do is to update the ``HelloWorldComponent`` in order to add a ``<div>`` element where we will display a message indicating an USB key has been added/removed.

Open the file ``src/app/components/universes/HelloWorld/index.js`` and modify the ``render()`` method for adding the new div:

.. code-block:: html

  <div className="HelloWorld-storage" key="storageList"/>


Also, don't forget to add a method for adding div for each storage we want to display.

.. code-block:: js

  updateStorageList(value) {
    this.storageList.textContent = value
  }

Code of ``HelloWorldComponent`` is now:

.. code-block:: js

  import Component from "widgets/Component"
  import "./index.css"

  export default class HelloWorld extends Component {
    constructor(props) {
      super(props)
    }

    render() {
      return (
        <div className="HelloWorld HelloWorld--hidden">
          <div className="HelloWorld-text" key="text"/>
          <div className="HelloWorld-storage" key="storageList"/>
        </div>
      )
    }

    show() {
      this.pullState("hidden")
    }

    hide() {
      this.pushState("hidden")
    }

    updateText(value) {
      this.text.textContent = value
    }

    updateStorageList(value) {
      this.storageList.textContent = value
    }
  }


Now we have our component able to display storage name, it's time to manage the message from MW when a USB key is plugged.
We will use the ``@sse`` decorator for this.
The event broadcasted by the middleware when an USB key is plugged is:

.. code-block:: none

  Storage added event:

  Emitted whenever a new storage device is detected and inserted into device list :
  storage_name: [str] Unique id of the storage.
  {
      "content":{
          "storage_name":"c3RvcmFnZV9tb2RlbF9FeHRlcm5hbA=="
          },
      "subtype":"storage_added"
  }

you can retrieve this information in the documentation:
https://portalnightly.frogbywyplay.com/docs/wytv/featured/components/appframeworks-wyrest/wyrest/http/routes/#r-storage


In ``HelloWorldController`` we will create a method that listen to this event using the ``@sse`` decorator.
Edit the file ``src/app/controllers/HelloWorld/index.js`` and add the method ``onStoragePlugged``.
This method will listen to the ``storage`` event and refresh the view with ``storage_name``.

First, import the sse helper:

.. code-block:: js

  import {rcu, on, sse} from "services/events"

Then, code the method that will refresh the view.

.. code-block:: js

  @sse("storage", {subtype: "storage_added"})
  onStoragePlugged(data) {
    this.view.updateStorageList("Storage plugged is:  " + data.content.storage_name)
  }

Let's go further by managing the ``storage_removed`` event and clear the view.

.. code-block:: js

  @sse("storage", {subtype: "storage_removed"})
  onStorageUnPlugged(data) {
    this.view.updateStorageList("Storage unplugged")
  }


And because the name of the storage is hashed, maybe you want to display the real name of your USB key.
If you take a look at the REST Api documentation, you will find a route for getting info of a storage.
https://portalnightly.frogbywyplay.com/docs/wytv/featured/components/appframeworks-wyrest/wyrest/http/routes/#storage .

.. code-block:: none

  GET /storage/(unique_id)/
  Return details of specified storage device.

  Sample request

  GET /storage/c3RvcmFnZV9tb2RlbF9Wb3lhZ2VyX01pbmk=/ HTTP/1.1
  Accept: application/json, text/javascript

  Sample response

  HTTP/1.1 200 OK
  Vary: Accept
  Content-Type: text/javascript

  {"name":"Voyager Mini","location":"external","media_removable":true,
  "media_available":true,"type":"usb.key","size":8076132352}


Let's modified our ``onStoragePlugged`` method for displaying the name correctly:


.. code-block:: js

  @sse("storage", {subtype: "storage_added"})
  onStoragePlugged(data) {
    return GET("/storage/" + data.content.storage_name + "/")
      .then((storageData) => {
        const name = storageData.name
        this.view.updateStorageList("Storage plugged is:  " + name)
      })
  }

The ``HelloWorldContorller`` code looks like this now:

.. code-block:: js

  import Controller from "utils/Controller"
  import {$} from "widgets/Component"
  import {rcu, on, sse} from "services/events"
  import bus from "services/bus"
  import {GET} from "services/http"
  import {increaseVolume, decreaseVolume} from "services/managers/volume"

  export default class HelloWorldController extends Controller {
    constructor() {
      super()
      this.view = $("helloWorld")
    }

    @on("helloWorld:open")
    open() {
      this.getCurrentVolumeLevel()
      this.view.show()
    }

    @rcu("helloWorld:back:press")
    close() {
      this.view.hide()
      bus.openUniverse("home")
    }

    @rcu("helloWorld:volume_plus:press")
    volumeUp() {
      increaseVolume().then(() => {
        this.getCurrentVolumeLevel()
      })
    }

    @rcu("helloWorld:volume_minus:press")
    volumeDown() {
      decreaseVolume().then(() => {
        this.getCurrentVolumeLevel()
      })
    }

    getCurrentVolumeLevel() {
      return GET("/player/config/volume/")
        .then((data) => {
          const volume = data.volume
          const text = "Current Volume Level is: " + volume
          this.view.updateText(text)
        })
    }

    @sse("storage", {subtype: "storage_added"})
    onStoragePlugged(data) {
      return GET("/storage/" + data.content.storage_name + "/")
        .then((storageData) => {
          const name = storageData.name
          this.view.updateStorageList("Storage plugged is:  " + name)
        })
    }

    @sse("storage", {subtype: "storage_removed"})
    onStorageUnPlugged(data) {
      this.view.updateStorageList("Storage unplugged")
    }
  }


That's it, you are now able to display message coming from events.
If you want to display a ``popup`` instead of refreshing the HelloWorld universe view when a Usb key is plugged, mechanism is quite the same. Except you will trigger an Application event for displaying the popup.
Just change the ``onStoragePlugged`` and ``onStorageUnPlugged`` methods.


.. code-block:: js

    @sse("storage", {subtype: "storage_added"})
    onStoragePlugged(data) {
      return GET("/storage/" + data.content.storage_name + "/")
        .then((storageData) => {
          const name = storageData.name
          bus.emit("popup:alert", "USB plugged", "An usb key named " + name + " has been plugged", {})
          this.view.updateStorageList("Storage plugged is:  " + name)

        })
    }

    @sse("storage", {subtype: "storage_removed"})
    onStorageUnPlugged(data) {
      this.view.updateStorageList("Storage unplugged")
      bus.emit("popup:alert", "USB unPlugged", "Usb key has been plugged", {})
    }

For more informations regarding ``popup``, take a look at the file: ``src/app/controllers/Application/PopUp.js`` .
