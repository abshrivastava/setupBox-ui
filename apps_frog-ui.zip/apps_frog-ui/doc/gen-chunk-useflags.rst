Here will go the auto-generated useflag descriptions of your ebuild when ran from (e|x)merge
