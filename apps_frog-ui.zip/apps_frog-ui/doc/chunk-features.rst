.. fragment: functional description of the component
   expected by ./overview.rst

.. .....................................................................
   Contents: bullet list of functional specs ("cadre fonctionnel")
   .....................................................................

- Illustrates most of the functionalities of the Frog middleware.

For Supported formats and Limitations see :ref:`guide-webapp-dev`.



