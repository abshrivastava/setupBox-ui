//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"

import bus from "services/bus"
import {on} from "services/events"

import {$} from "widgets/Component"
import {updateBlockedChannelList} from "services/managers/config"
import BlockedChannelManager from "services/managers/BlockedChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import BlockedChannelList from "./BlockedChannelList"
import OptionsList from "./OptionsList"



export default class ChannelBlockController extends Controller {
  static delegates = [
    BlockedChannelList,
    OptionsList,
  ]

  constructor() {

    super()

    this.view = $("channelsBlock")
    this.activeDelegate = null
  }

  open() {

    this.view.show()
    this.OptionsList.setView(this.view)

    // this.view.loadItems(this.optionList)
    this.OptionsList.open(() => {
      console.log("optionlist opened")
    })
    this.BlockedChannelList.open(() => {
      console.log("blockedlist opened")
    })

    this.activeDelegate=this.BlockedChannelList
    BlockedChannelManager.running = true
    return Promise.resolve()
  }

  onOk() {
    if (this.activeDelegate === this.OptionsList) {

      if (this.OptionsList.selectedIndex === 0) {
        this.onChannelListSave()
      } else if (this.OptionsList.selectedIndex === 1) {
        this.onBlockedChannelListExit()
      }

    } else if (this.activeDelegate === this.BlockedChannelList) {
      this.BlockedChannelList.onOk()
    }
  }

  moveUp() {

    if (this.activeDelegate === this.OptionsList) {
      this.OptionsList.moveUp()
    } else if (this.activeDelegate === this.BlockedChannelList) {
      this.BlockedChannelList.moveUp()
    }

  }

  moveDown() {
    if (this.activeDelegate === this.OptionsList) {
      this.OptionsList.moveDown()
    } else if (this.activeDelegate === this.BlockedChannelList) {
      this.BlockedChannelList.moveDown()
    }
  }

  onLeft() {
    this.activeDelegate=this.BlockedChannelList
    this.OptionsList.onLeft()
    this.BlockedChannelList.onLeft()
  }

  onRight() {
    if (this.activeDelegate === this.BlockedChannelList) {
      this.BlockedChannelList.onRight()
    }

    this.activeDelegate=this.OptionsList
    this.OptionsList.onRight()
  }

  // @on("channelblock:save")
  onChannelListSave() {
    console.log("channel clock save")

    const blockedIds = Object.getOwnPropertyNames(this.BlockedChannelList.BlockServiceIds).join(",")
    updateBlockedChannelList(blockedIds)
      .then(() => {
        if (BlockedChannelManager.getCurrentChannelStatus()) {
          PlayerManager.stop()
        }
        BlockedChannelManager.updateChannelList(blockedIds)
        bus.emit("settings:subClose")
      })
  }

  // @on("channelblock:exit")
  onBlockedChannelListExit() {
    console.log("channel clock exit")
    bus.emit("settings:subClose")
  }

  @on("ChannelBlock:close")
  close() {
    this.activeDelegate=this.BlockedChannelList
    BlockedChannelManager.running = false
    this.BlockedChannelList.BlockServiceIds={}
    return this.view.hide()
  }

  onBack() {
    return this.close()
  }


}
