//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import {listTune} from "services/api/scan"
import transponders from "services/managers/transponders"
import ChannelManager from "services/managers/ChannelManager"
import PlayerManager from "services/managers/PlayerManager"
import {getCurrentTransponder,
getTransponderStatus} from "services/api/transponders"
import FtaBlockManager from "services/managers/FtaBlockManager"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"
import {_} from "utils/locale"
import AbstractSetting from "../AbstractSetting"

let TransSignal = ""
let transflag = false

const TransponderInfoConst = Object.freeze({
  ZERO_INDEX: 0,
  FIRST_INDEX:1,
  LAST_INDEX: 29,
  PAGE_SIZE:30,
})

export default class TransponderInfoController extends AbstractSetting {

  constructor() {
    super()
    this.view = $("transponderInfo")
    this.lastUniverse="settings"
    this.index = 0
    this.stopTransStatus = false
    this.currentTransponder = false
    this.pageNumber =1
    this.updateTPSattus= null
  }

  open() {
    this.view.onForeground()
    this.updateTPMenuTitle()
    this.resetTransponder()
    const heading = config.SD_ZAPPER?_("TP Info"): _("STB Info Sheet") + " - " + _("TP Info")
    bus.emit("settings:updateSettingsHeader", heading, true)
    return super.open()
  }

  updateTPMenuTitle() {
    this.view.updateTpTitleForFta()
  }

  @on("TransponderInfo:close")
  onBack() {
    this.view.onBackground()
    return Promise.resolve()
  }

  @on("setting:transponder:open")
  onTransponderOpen() {
    transponders.isTPListScreen = true
    const tpList = transponders.transpondersList
    this.stopTransStatus = false
    if (!tpList.length > 0) {
      this.updateTPMenuTitle()
      this.load()
      bus.emit("STBInfoSheet:unfold")
      this.view.show()
      this.view.onForeground()
    } else if ((tpList.length > 0) && (tpList.length <= 30)) {
      this.view.updateTransList(tpList)
      this.open().then(() => {
        bus.emit("STBInfoSheet:unfold")
      })
    } else {
      const newList = tpList.slice(0,30)
      this.view.updateTransList(newList)
      this.open().then(() => {
        bus.emit("STBInfoSheet:unfold")
      })
    }

// FTA Block Button Functionality
    const isFtaActive = FtaBlockManager.isNavigationRestricted()
    if (isFtaActive) {
      this.view.onBtnShow()
    }
    if (!isFtaActive) {
      this.view.onBtnClose()
    }
  }

  @on("TransponderInfo:TranponderStat")
  getEachTransStatus(transList) {
    if (this.updateTPSattus) clearTimeout(this.updateTPSattus)
    if (this.stopTransStatus === true) return
    bus.emit("TransTrigger",transList)
  }

  @on("TransTrigger")
  onTrigger(transList) {
    const TransLen = parseInt(transList.length)
    const countIndex = parseInt(this.index)

    let count = this.index
    if (!this.currentTransponder && (count === 0 || count === 1)) {
      this.currentTransponder = true
      const isFtaBlocked = FtaBlockManager.isNavigationRestricted()
      if (isFtaBlocked) {
        listTune()
         .then((rsp)=>{
           if (rsp.tunes.length >0) {
             const response = rsp.tunes[0].wydvb_uri
             this.getPropFromDvbUri(response)
             .then((Prop)=>{
               for (const trans in transList) {
                 const t1= transList[trans].properties
                 let testprop= ""
                 if (t1) testprop = t1.substring(0,21)
                 if (testprop === Prop) {
                   const currentTrans =  trans
                   this.view.updateCurrentTransponder(currentTrans)
                 }
               }
             })
           }
         })
         .catch((err)=>{
           console.log("err",err)
         })
      }
      if (!isFtaBlocked) {
        const serviceId = ChannelManager.current.serviceId
        if (serviceId) {
          getCurrentTransponder(serviceId)
            .then((rsp)=>{
              if (rsp) {
                const property= "S" + " " + rsp.frequency + " " + rsp.polarization + " " +
                    rsp.symbol_rate
                for (const trans in transList) {
                  const t1= transList[trans].properties
                  let testprop= ""
                  if (t1) testprop = t1.substring(0,21)
                  if (testprop === property) {
                    const currentTrans =  trans
                    this.view.updateCurrentTransponder(currentTrans)
                  }
                }
              }
            }).then(()=>{
              if (PlayerManager._state !== 10 || (PlayerManager._state === 10 && PlayerManager.speed === 1)) {
                PlayerManager.stop()
              }
            })
          count++
        }
      }
    }
    if (TransLen > countIndex) {
      if (PlayerManager._state !== 10) PlayerManager.stop()
      const uri = transList[this.index].wydvb_uri
      const wydvbUri = encodeURIComponent(uri)

      getTransponderStatus(wydvbUri)
          .then((rsp)=> {
            if (rsp.agc && parseInt(rsp.agc)>0) {
              TransSignal = ("(SS-") + (rsp.agc) + ("% SQ-") + (rsp.snr) + ("%)")
              transflag = true
            } else {
              TransSignal = "(SS-0% SQ-0%)"
              transflag = false
            }
            this.view.updateTransponderStatus(TransSignal, transflag, this.index)
            if (TransLen > this.index) {
              this.tpUpdateTimeout(transList)
            }
          })
    } else {
      this.index = 0
      this.getEachTransStatus(transList)
    }
  }

  tpUpdateTimeout(transList) {
    if (this.updateTPSattus) clearTimeout(this.updateTPSattus)
    this.updateTPSattus = setTimeout(() => {
      this.index++
      this.getEachTransStatus(transList)
    }, 1000)
  }

  getPropFromDvbUri(response) {
    return new Promise ((resolve)=>{
      const freq_sym_rate = ["S"]
      freq_sym_rate.push(response.substring(response.search("frequency=")+10, response.search("&modulation")))
      freq_sym_rate.push(response.substring(response.search("polarity=")+9, response.search("&transmitter_id")))
      freq_sym_rate.push(response.substring(response.search("symbol_rate=")+12, response.search("&iq_mode")))
      const currentTpProp = freq_sym_rate.join(" ")
      resolve(currentTpProp)
    })
  }

  moveUp() {
    if (this.pageNumber !== TransponderInfoConst.FIRST_INDEX) {
      /** for first element of any page other than 1st page**/
      this.index=0
      this.pageNumber--
      const pageupStartIndex =
      ((this.pageNumber - TransponderInfoConst.FIRST_INDEX) * TransponderInfoConst.LAST_INDEX)
      + (this.pageNumber - TransponderInfoConst.FIRST_INDEX)

      const pageupLastIndex =
      ((this.pageNumber - TransponderInfoConst.FIRST_INDEX) * TransponderInfoConst.LAST_INDEX) +
      TransponderInfoConst.PAGE_SIZE + (this.pageNumber - TransponderInfoConst.FIRST_INDEX)

      this.loadTranpondersPage(pageupStartIndex, pageupLastIndex)
    }
  }

  moveDown() {
    if (this.pageNumber !== (Math.ceil(transponders.transpondersList.length /TransponderInfoConst.PAGE_SIZE))) {
      this.index=0
      /** for any page except last page **/
      const pagedownStartIndex = (this.pageNumber * TransponderInfoConst.LAST_INDEX) + this.pageNumber
      const test = (this.pageNumber * TransponderInfoConst.LAST_INDEX) +
      TransponderInfoConst.PAGE_SIZE + this.pageNumber
      let pagedownLastIndex = null
      const test1 = transponders.transpondersList.length-(this.pageNumber * TransponderInfoConst.PAGE_SIZE)
      if (test >= test1) pagedownLastIndex = transponders.transpondersList.length
      else pagedownLastIndex = test
      this.pageNumber++
      this.loadTranpondersPage(pagedownStartIndex, pagedownLastIndex)
    }
  }

  loadTranpondersPage(startIndex, lastIndex) {
    if (transponders.transpondersList.length >0) {
      let TransponderListPage = []
      TransponderListPage = transponders.transpondersList.slice(startIndex, lastIndex)
      this.view.updateTransList(TransponderListPage, this.pageNumber)
      this.load()
    }
  }

  resetTransponder() {
    this.pageNumber = 1
    this.index = 0
    this.currentTransponder = false
  }
  load() {
    this.view.onLoad()
    // FTA active then don't show the lable Home to exit and back to STBInfosheet
    const isFtaActive = FtaBlockManager.isNavigationRestricted()
    if (isFtaActive) {
      this.view.updateTpTitleForFta()
    }
  }

  close() {
    this.view.onBackground
  }
}
