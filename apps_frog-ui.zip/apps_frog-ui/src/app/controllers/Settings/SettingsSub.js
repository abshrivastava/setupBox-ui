//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"

import AbstractSetting from "./AbstractSetting"

const OPTION_ITEMS = {
  fallback: [{
    name: "Close",
    action: "settings:subClose",
  }],
  "SysInfo": [{
    name: "Close",
    action: "settings:subClose",
  }, {
    name: "Reset",
    action: "settings:reset",
  }],
  "myAccount": [{
    name: "Back",
    action: "settings:subClose",
  }],
  "selfHelp": [{
    name: "Back",
    action: "settings:subClose",
  }],
  "ConnectionInfoDvb":[{
    name: "Close",
    action: "settings:subClose",
  },{
    name: "Update",
    action: "settings:dvbUpdate",
    wait: true,
  }],
}

export default class SettingsSubController extends AbstractSetting {
  constructor() {
    super()
    this.view = $("settingsSub")
  }

  open(sub) {
    this.sub = sub
    return super.open()
  }

  @on("SettingsSub:close")
  close() {
    bus.emit("settings:resetmyaccounttimer")
    this.selectedIndex = 0
    if (this.sub && this.sub.context === "selfHelp") {
      setTimeout(() => {
        bus.emit("settings:treeleft")
        setTimeout(() => {
          bus.emit("settings:setDefaultFocus","selfHelp")
        })
      })
    }
    this.view.hide()
    this.sub = null
  }

  load() {
    this.view.onLoad(this.sub)
    this.optionList = OPTION_ITEMS[this.sub.context] || OPTION_ITEMS.fallback
    this.view.loadItems(this.optionList)
    bus.emit("settings:subForeground")
  }

  moveUp() {
    const selectedMenu = super.moveUp()
    this.view.optionList.select(this.selectedIndex, selectedMenu)
  }

  moveDown() {
    const selectedMenu = super.moveDown()
    this.view.optionList.select(this.selectedIndex, selectedMenu)
  }
}
