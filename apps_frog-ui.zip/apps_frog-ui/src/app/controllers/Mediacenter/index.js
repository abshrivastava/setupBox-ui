//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {on, rcu} from "services/events"
import bus from "services/bus"
import {$} from "widgets/Component"
import * as popUpMsg from "app/utils/PopUpMsg"

import List from "utils/List"
import Scrollable, {DIRECTION as SCROLL_DIRECTION} from "utils/Scrollable"

import Volume from "services/models/mediacenter/Volume"
import Folder from "services/models/mediacenter/Folder"
import AudioFile from "services/models/mediacenter/AudioFile"
import VideoFile from "services/models/mediacenter/VideoFile"
import ImageFile from "services/models/mediacenter/ImageFile"

import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import MediaCenterManager from "services/managers/MediaCenterManager"

import Playback from "../Playback"
import VideoDetails from "./VideoDetails"
import AudioDetail from "./AudioDetail"

export default class MediacenterController extends Controller {

  static delegates = [
    Playback,
    VideoDetails,
    AudioDetail,
  ]

  constructor() {
    super()
    this.mediacenterList = new List([])
    Scrollable.ControllerMixin(this, {
      mode: "bounded",
      source: this.mediacenterList,
      onScrollStop: this._updateCurrentItem,
    })
    this.view = $("mediacenter")
    this.listview = this.view.itemList
    this.activeDelegate = null
    this.closing = false
  }

  _updateCurrentItem() {
    MediaCenterManager.setCurrent(this.getSelectedItem())
  }
  /* ************************************************************************ */

  /* ********* Open/Close functions ********* */
  @on("mediacenter:open")
  open() {
    this.closing = false
    PlayerManager.stop()
      .then(() => {
        if (this.closing) {
          this.closing = false
          return Promise.reject("MediaCenter: closing, so, reject opening")
        }
        MediaCenterManager.fetchVolumes()
          .then((volumes) => {
            if (this.closing) {
              this.closing = false
              return Promise.reject("MediaCenter closing, so, reject opening")
            }
            this.reLoadList(volumes)
            this.showCurrentView()
          })
      })
  }

  @on("mediacenter:close")
  close() {
    this.closing = true
    this.activeDelegate = null
    const promises = []
    bus.emit("clock:close")

    for (const delegate of this.delegates) {
      promises.push(delegate.close())
    }

    return Promise.all(promises)
      .then(() => {
        this.view.close()
        return PlayerManager.play(ChannelManager.current)
      })
      .then(() => {

      })
  }

  showCurrentView() {
    bus.emit("clock:open", "mediacenter")
    this.view.open()
  }

  hideCurrentView() {
    bus.emit("clock:close")
    this.view.hide()
  }

  /* ************************************************************************ */

  /* ********* Medias functions ********* */
  reLoadList(medias) {
    this.mediacenterList.update(medias)
    this.view.update(this.mediacenterList)
    this.jumpTo(0)
    this._updateCurrentItem()
  }

  backToParent() {
    MediaCenterManager.backToParent().then((medias) => {
      this.reLoadList(medias)
    })
  }

  showChildren() {
    MediaCenterManager.loadChildren().then((medias) => {
      this.reLoadList(medias)
    })
  }

  showVideoDetails() {
    switch (this.activeDelegate) {
    case this.VideoDetails:
      this._playVideo()
      break
    case this.AudioDetail:
    case this.Playback:
      break
    default:
      this.openVideoDetails()
      break
    }
  }

  openVideoDetails() {
    this.activeDelegate = this.VideoDetails
    this.VideoDetails.open(this.getSelectedItem())
  }

  closeVideoDetails() {
    this.activeDelegate = null
    this.VideoDetails.close()
  }

  _playVideo() {
    this.closeVideoDetails()
    this.hideCurrentView()

    PlayerManager.play(this.getSelectedItem(), "media", {}).then(() => {
      this.activeDelegate = this.Playback
      this.Playback.open(this.getSelectedItem())
    }).catch(() => {
      this.showCurrentView()
      popUpMsg.unsupportedVideoFile()
    })
  }

  _playAudio() {
    PlayerManager.play(this.getSelectedItem(), "media", {}).then(() => {
      this.activeDelegate = this.AudioDetail
      this.AudioDetail.open(this.getSelectedItem())
    })
  }

  /* ************************************************************************ */

  /* ********* Up/Down & Arrow Keys ********* */
  @rcu("mediacenter:up:press")
  onUp() {
    switch (this.activeDelegate) {
    case this.VideoDetails:
      this.VideoDetails.up()
      break
    case this.Playback:
      break
    case this.AudioDetail:
      this.AudioDetail.stop()
      this.activeDelegate = null
    default:
      this.scroll(SCROLL_DIRECTION.BACKWARD)
      break
    }
  }

  @rcu("mediacenter:down:press")
  onDown() {
    switch (this.activeDelegate) {
    case this.VideoDetails:
      this.VideoDetails.down()
      break
    case this.Playback:
      break
    case this.AudioDetail:
      this.AudioDetail.stop()
      this.activeDelegate = null
    default:
      this.scroll(SCROLL_DIRECTION.FORWARD)
      break
    }
  }

  @rcu("mediacenter:up:release")
  @rcu("mediacenter:down:release")
  onReleaseUpDown() {
    switch (this.activeDelegate) {
    case this.VideoDetails:
    case this.Playback:
      break
    case this.AudioDetail:
    default:
      this.stopScrolling()
      break
    }
  }

  /* ************************************************************************ */

  /* ********* Others RCU events ********* */
  @rcu("mediacenter:ok:press")
  onOk() {
    const currentItem = this.getSelectedItem()
    if (currentItem) {
      switch (currentItem.constructor) {
      case Volume:
      case Folder:
        this.showChildren()
        break
      case VideoFile:
        this.showVideoDetails()
        break
      case AudioFile:
        this._playAudio()
        break
      case ImageFile:
        break
      default:
        break
      }
    }
  }

  @rcu("mediacenter:back:press")
  onBack() {
    switch (this.activeDelegate) {
    case this.VideoDetails:
      this.closeVideoDetails()
      break
    case this.Playback:
      this.Playback.stop()
      break
    case this.AudioDetail:
      this.AudioDetail.stop()
      break
    default:
      this.backToParent()
      break
    }
  }

  @rcu("mediacenter:right:press")
  onRight() {
    if (!this.activeDelegate) {
      this.onOk()
    }
  }

  @rcu("mediacenter:left:press")
  onLeft() {
    if (!this.activeDelegate) {
      this.backToParent()
    }
  }

  @rcu("mediacenter:play:press")
  onPlay() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.resume()
      break
    case this.AudioDetail:
      this.AudioDetail.resume()
      break
    default:
      break
    }
  }

  @on("mediacenter:stopped")
  onStopped() {
    if (this.activeDelegate === this.Playback) {
      this.showCurrentView()
      this.activeDelegate = null
    }
  }

  @rcu("mediacenter:stop:press")
  onStop() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.stop()
      break
    case this.AudioDetail:
      this.AudioDetail.stop()
      this.activeDelegate = null
      break
    default:
      break
    }
  }

  @rcu("mediacenter:info:press")
  openInfoBanner() {
    switch (this.activeDelegate) {
    case this.Playback:
      this.Playback.infoView.open()
      break
    default:
      break
    }
  }

  // @rcu("mediacenter:pause:press")
  // onPause() {
  //   switch (this.activeDelegate) {
  //   case this.Playback:
  //     this.Playback.pause()
  //     break
  //   case this.AudioDetail:
  //     this.AudioDetail.pause()
  //     break
  //   default:
  //     break
  //   }
  // }
  //
  // @rcu("mediacenter:fast_rewind:press")
  // onFastRewind() {
  //   switch (this.activeDelegate) {
  //   case this.Playback:
  //     this.Playback.fastRewind()
  //     break
  //   case this.AudioDetail:
  //     this.AudioDetail.fastRewind()
  //     break
  //   default:
  //     break
  //   }
  // }
  //
  // @rcu("mediacenter:fast_forward:press")
  // onFastForward() {
  //   switch (this.activeDelegate) {
  //   case this.Playback:
  //     this.Playback.fastForward()
  //     break
  //   case this.AudioDetail:
  //     this.AudioDetail.fastForward()
  //     break
  //   default:
  //     break
  //   }
  // }
}
