//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"
import PlayerManager from "services/managers/PlayerManager"

export default class AudioDetailController extends Controller {
  constructor() {
    super()
    this.audioView = $("audioControl")
    this.currentSong = $("currentSong")
  }

  open(item) {
    this.pos = 0
    this.item = item
    this.audioView.update(item)
    this.audioView.open()
    this.currentSong.update(item)
    this._registerEndOfPlayback(item)
  }

  close() {
    return this.stop()
  }

  @on("AudioDetail:close")
  stop() {
    if (this.item) {
      this.flush()
      return PlayerManager.stop()
    }
  }

  pause() {
    return PlayerManager.pause()
      .then(() => {
        this.audioView.pause()
      })
  }

  resume() {
    return PlayerManager.resume()
      .then(() => {
        this.audioView.resume()
      })
  }

  fastForward() {
    return PlayerManager.fastForward()
      .then((speed) => {
        this.audioView.fastForward(speed)
      })
  }

  fastRewind() {
    return PlayerManager.fastRewind()
      .then((speed) => {
        this.audioView.fastRewind(speed)
        this._registerEndOfRewind()
      })
  }

  _registerEndOfRewind() {
    const _quit = () => {
      bus.off("player:speed:normal", _quit)
      return PlayerManager.getAbsolutePosition()
        .then((ppos) => {
          if (ppos.position <= 1) {
            this.audioView.resume()
          }
        })
    }
    bus.on("player:speed:normal", _quit)
  }

  _registerEndOfPlayback() {
    const _quit = () => {
      bus.off("player:state:stopped", _quit)
      this.flush()
      bus.emit(bus.universe + ":stopped")
    }
    bus.on("player:state:stopped", _quit)
  }

  flush() {
    this.pos = 0
    this.item = null
    this.currentSong.fold()
    this.audioView.fold()
  }
}
