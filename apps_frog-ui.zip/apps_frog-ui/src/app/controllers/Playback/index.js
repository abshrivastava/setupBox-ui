//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"

import PlayerManager from "services/managers/PlayerManager"
import PVRManager from "services/managers/PVRManager"
import CasManager from "services/managers/CasManager"
import Record from "services/models/pvr/Record"
import ChannelManager from "services/managers/ChannelManager"

export default class PlaybackController extends Controller {
  constructor() {
    super()
    this.infoView = $("playbackInfo")
    this.controlView = $("playerControl")
    this.operatorLogo = $("operatorLogo")
    this.recordList = $("recordList")
    this.timeshiftPlayback = false
    this.lastStateRewind = false
  }

  @on("player:speed:normal", {universe: "pvr"})
  _onPlayerSpeedNormal() {
    clearTimeout(this.infoView.foldDelayed)
    this.lastStateRewind = false
    this.timeshiftPlayback = false
    if (this.recordList.isOpened() === false)
      this.infoView.delayedFold()
    this.controlView.disableWithDelay()
  }

  open(item) {
    bus.emit("UnsubscribedErrorMsg:close")
    this.pos = 0
    this.item = item
    this.infoView.update(item)
    this.infoView.open()
    this.infoView.delayedFold()
    this.operatorLogo.unfold()
    this._registerEndOfPlayback()
    this._showAdBanner()
    this.lastStateRewind = false
    if (CasManager.isFingerprintActive === false) {
      bus.emit("fingerprint:timeshiftopen")
    }
  }

  close() {
    CasManager.closeFingerprint()
    this.operatorLogo.fold()
    this.timeshiftPlayback = false
    this.lastStateRewind = false
    return this.stop()
  }

  @on("Playback:close")
  stop() {
    if (ChannelManager.current) {
      CasManager.getPlayerSubscribeInfo(Number(ChannelManager.current.lcn))
    }
    return new Promise((resolve) => {
      if (this.item) {
        this.infoView.fold()
        this.controlView.disableImmediately()
        PlayerManager.getAbsolutePosition()
          .then((playerPos) => {
            this.pos = playerPos.position
            PVRManager.update(this.item, {position: `${this.pos}`})
            mute()
          })
          .catch(() => {
            resolve()
          })
          .then(() => {
            resolve()
          })
      } else {
        resolve()
      }
    })
  }

  pause() {
    this.timeshiftPlayback = true
    this.lastStateRewind = false
    return PlayerManager.pause()
      .then(() => {
        this._showAdBanner()
        this.infoView.unfold()
        this.controlView.showPaused(true)
      })
  }

  resume() {
    this.timeshiftPlayback = true
    this.lastStateRewind = false
    return PlayerManager.resume()
      .then(() => {
        this.infoView.delayedFold()
        this.controlView.disableWithDelay()
      })
  }

  fastForward() {
    clearTimeout(this.infoView.foldDelayed)
    this.timeshiftPlayback = true
    this.lastStateRewind = false
    return PlayerManager.fastForward()
      .then((speed) => {
        this._showAdBanner()
        this.infoView.unfold()
        this.controlView.fastForward(speed)
      })
  }

  fastRewind() {
    this.lastStateRewind = true
    clearTimeout(this.infoView.foldDelayed)
    this.timeshiftPlayback = false
    return PlayerManager.fastRewind()
      .then((speed) => {
        this._showAdBanner()
        this.infoView.unfold()
        this.controlView.fastRewind(speed)
        this._registerEndOfRewind()
      })
  }

  _registerEndOfRewind() {
    const _quit = () => {
      bus.off("player:speed:normal", _quit)
      return PlayerManager.getAbsolutePosition()
        .then((ppos) => {
          if (ppos.size && ppos.position <= 5) {
            this.infoView.delayedFold()
            this.controlView.disableWithDelay()
          }
        })
    }
    bus.on("player:speed:normal", _quit)
  }

  _registerEndOfPlayback() {
    const item = this.item
    const _quit = () => {
      bus.off("player:state:stopped", _quit)
      return this._getPlayerStoppedPromise().then(() => {
        CasManager.closeFingerprint()
        bus.emit(bus.universe + ":stopped", item.id || null)
        this.timeshiftPlayback = false
      })
    }
    bus.on("player:state:stopped", _quit)
  }

  _getPlayerStoppedPromise() {
    if (this.item && this.item.constructor === Record) {
      return PVRManager.update(this.item, {position: `${this.pos}`})
        .then(() => {
          this.flush()
        })
    }
    this.flush()
    return Promise.resolve()
  }

  _showAdBanner() {
    if (this.item && this.item.constructor === Record) {
      bus.emit("clock:open", "pvr")
    }
  }

  flush() {
    this.pos = 0
    this.item = null
    this.infoView.fold()
    this.controlView.disableImmediately()
  }
}
