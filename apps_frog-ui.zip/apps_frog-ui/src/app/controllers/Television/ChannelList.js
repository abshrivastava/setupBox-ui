//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {debounce} from "utils"
import List from "utils/List"
import CircularList from "utils/CircularList"
import Scrollable from "utils/Scrollable"
import {$} from "widgets/Component"

import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import PVRManager from "services/managers/PVRManager"

import * as epgService from "services/managers/epg"
import {getLastTunedLcn} from "services/managers/config"
import transponders from "services/managers/transponders"
import ScanManager from "services/managers/ScanManager"

export default class ChannelListController extends Controller {
  constructor() {
    super()
    this.nextOpened = false
    this.channelList = new CircularList([])
    Scrollable.ControllerMixin(this, {
      mode: "cyclic",
      source: this.channelList,
      onScrollStop: debounce(this._updateCurrentProgram, 500),
    })
    this.view = $("channelList")
    this.listview = this.view.itemList
  }

  open(channel) {
    this.nextOpened = false
    channel = channel || ChannelManager.current
    this.selectChannel(channel)
    bus.emit("clock:open", "tv")
    bus.emit("InfoBanner:showUsbAndUnsetBanner",true)
    return this.view.openFull()
  }

  close(closeFull = true) {
    bus.emit("InfoBanner:showUsbAndUnsetBanner",false)
    this.hideNextProgram()
    if (closeFull === false) {
      bus.emit("InfoBanner:showUsbBanner")
      return this.view.closeOnlyChannelList()
    }
    bus.emit("clock:close")
    return this.view.closeFull()
  }

  playSelectedChannel() {

    const selectedChannel = this.getSelectedItem()
    return this.master._play(selectedChannel)
  }

  selectChannel(newChannel = ChannelManager.current) {
    const channelIndex = this.channelList.indexOf(newChannel)
    this.jumpTo(channelIndex)
    this._updateCurrentProgram()
    return Promise.resolve()
  }

  selectPrev() {
    this.jumpTo(this.next(1))
  }

  selectNext() {
    this.jumpTo(this.next(-1))
  }

  @on("channels:updated")
  loadChannels() {
    this.stopScrolling()
    if (ChannelManager.channels.length <= 5) {
      this.channelList = new List([])
      Scrollable.ControllerMixin(this, {
        mode: "bounded",
        source: this.channelList,
        onScrollStop: debounce(this._updateCurrentProgram, 500),
      })
    } else {
      this.channelList = new CircularList([])
      Scrollable.ControllerMixin(this, {
        mode: "cyclic",
        source: this.channelList,
        onScrollStop: debounce(this._updateCurrentProgram, 500),
      })
    }
    this.channelList.update(ChannelManager.channels)
    this.view.update(this.channelList)
    let idx = this.channelList.indexOf(ChannelManager.current)
    /* Condition :: if :  ChannelManager.current is Null after Dvb table update
      than resetting the ChannelManager.current to lasttuned channel
     Condition :: Else :: jump to the current index
    */

    if (idx === -1) {
      getLastTunedLcn()
      .then((lcn) => {
        return lcn
      })
      .then((lcn) => {
        return ChannelManager.getChannelZapInformation(lcn)
      })
      .then((response) => {
        const channel = response.resource.real || response.resource.fallback
        ChannelManager.current = channel
        idx = this.channelList.indexOf(channel)
        this.jumpTo((idx === -1) ? 0 : idx)
        if (idx === 0 && (!transponders.isTPListScreen) && !ScanManager.isFirstInstall) {
          this.playSelectedChannel()
        }
      })
    } else {
      if (!transponders.isTPListScreen) {
        this.jumpTo(idx)
      }
    }
  }

  hideNextProgram() {
    this.nextOpened = false
    this.view.hideNextProgram()
    return Promise.resolve()
  }

  @on("channels:clearProgram")
  clearProgram() {
    this.view.clearCurrentProgram()
  }

  showNextProgram() {
    const selectedChannel = this.getSelectedItem()

    return this.master.getNextProgram(selectedChannel)
      .then((program) => {
        if (!program) {
          return false
        }
        this.view.showNextProgram(program)
        this.nextOpened = true
        return true
      })
      .catch(() => {
        // console.error(err)
        return false
      })
  }

  showDolbyLogo() {
    PlayerManager.getAudioTracks()
      .then((data) => {
        let isDolbyLogoEnableForCurrent=false

        for (let iCounter=0;iCounter < data.length ; iCounter++) {
          if (data[iCounter]._attributes["AudioCodec"] === "ac3" && data[iCounter].default === true) {
            isDolbyLogoEnableForCurrent = true
            break
          }
        }
        if (isDolbyLogoEnableForCurrent) {
          this.view.updateDolbyInfo(true)
        } else {
          this.view.hideDolbyInfo()
        }
      }).catch(() => {
        return false
      })
  }

  _updateCurrentProgram() {
    const selectedChannel = this.getSelectedItem()
    epgService.getCurrentProgram(selectedChannel)
    .then(program => {
      if (!program) return
      if (ChannelManager.current !== null) {
        this.clearProgram()
        this.view.updateProgram(program,ChannelManager.getGenreInfo(selectedChannel.genre))
        this.view.hideTSIndicator()
        if (program.serviceId === ChannelManager.current.serviceId) this.showDolbyLogo()
        if (this.isManualRecordOnGoing()) {
          this.view.showRecordIndicator()
          if (bus.universe === "tv" &&
          program.serviceId !== ChannelManager.current.serviceId) this.view.hideRecordIndicator()
        } else {
          this.view.hideRecordIndicator()
        }
      }
    })
  }

  isManualRecordOnGoing() {
    let isManualRecordOnGoing = false
    const schedules = PVRManager.getSchedulesFromServiceId(ChannelManager.current.serviceId)
    schedules.forEach(({schedule}) => {
      if (schedule.task.phase === "ACTIVE") {
        isManualRecordOnGoing = true
      }
    })
    return isManualRecordOnGoing
  }
}
