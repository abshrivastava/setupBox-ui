//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {$} from "widgets/Component"
import {on} from "services/events"
import {_} from "utils/locale"

import TimezoneManager from "services/managers/TimezoneManager"
import PlayerManager from "services/managers/PlayerManager"
import {formatDateOnly} from "utils/date"
import {TreeObj} from "app/utils/widgets/lists"

export default class PvrDetailsController extends Controller {
  constructor() {
    super()
    this.selected = 0
    this.actions = []
    this.view = $("pvrDetails")
    this.tree = new TreeObj(this.view.actionsTree)
    this.languageLabel = null
  }

  open(item, playingback) {
    item.changeTitle = item._title + " " + formatDateOnly(item.startDate) + " "
      + TimezoneManager.getFormatTime(item.startDate)
    this.selected = 0
    this.tree.view.moveExtendedTo(0)
    this.fromPlayback = playingback
    this.actions = this._actionsFactory(item)
    this.tree.setItems(0, this.actions)

    return this.view.open(item)
  }

  @on("PvrDetails:close")
  close() {
    this.view.close()
    this.tree.reset()
  }

  prev() {
    this.tree.up()
    this.tree.view.moveExtendedTo(this.tree.lists[0].selected)
  }

  next() {
    this.tree.down()
    this.tree.view.moveExtendedTo(this.tree.lists[0].selected)
  }

  right() {
    this.tree.right()
  }

  left() {
    this.tree.left()
  }

  trigger() {
    this.tree.trigger()
  }

  _actionsFactory(item) {
    if (this.fromPlayback) {
      return [{
        label: "Audio",
        onFocus: () => this.getAudioTracks(),
      }]
    } else {
      return this._listingActionsFactory(item)
    }
  }

  _listingActionsFactory(item) {
    let actions
    switch (item.constructor.name) {
    case "Schedule":
      actions = [
        {
          label: (item.startDate > new Date()) ? "Cancel Record" : "Stop Record",
          signal: "pvr:deleteCurrent",
        },
      ]
      break
    case "Record":
      actions = [
        {
          label: "Play",
          signal: "pvr:playCurrent",
        },
        {
          label: "Delete",
          signal: "pvr:deleteCurrent",
        },
      ]

      if (item.lastPosition) {
        actions.unshift({
          label: "Resume playback",
          signal: "pvr:resumeCurrent",
        })
      }
      break
    default:
      actions = []
      break
    }

    return actions
  }

  getAudioTracks() {
    return PlayerManager.getAudioTracks()
      .then((audios) => {
        return audios.map((t, i) => {
          this.languageLabel = t.lang
          if (t._attributes.AudioLang === "urd" || t._attributes.AudioLang === "guj"
          || t._attributes.AudioLang === "ben" || t._attributes.AudioLang === "kan"
          || t._attributes.AudioLang === "lat" || t._attributes.AudioLang === "mag"
          || t._attributes.AudioLang === "mni" || t._attributes.AudioLang === "nep"
          || t._attributes.AudioLang === "ori" || t._attributes.AudioLang === "pan"
          || t._attributes.AudioLang === "raj" || t._attributes.AudioLang === "asm"
          || t._attributes.AudioLang === "bho" || t._attributes.AudioLang === "bih"
          || t._attributes.AudioLang === "grn" || t._attributes.AudioLang === "mal") {
            switch (t._attributes.AudioLang) {
            case "urd":
              this.languageLabel = _("Urdu")
              break
            case "ben":
              this.languageLabel = _("Bengali")
              break
            case "guj":
              this.languageLabel = _("Gujarati")
              break
            case "kan":
              this.languageLabel = _("Kannada")
              break
            case "lat":
              this.languageLabel = _("Latin")
              break
            case "mag":
              this.languageLabel = _("Magahi")
              break
            case "mal":
              this.languageLabel = _("malayalam")
              break
            case "mni":
              this.languageLabel = _("manipuri")
              break
            case "nep":
              this.languageLabel = _("nepali")
              break
            case "ori":
              this.languageLabel = _("Oriya")
              break
            case "pan":
              this.languageLabel = _("Panjabi")
              break
            case "raj":
              this.languageLabel = _("Rajasthani")
              break
            case "asm":
              this.languageLabel = _("Assamese")
              break
            case "bho":
              this.languageLabel = _("Bhojpuri")
              break
            case "bih":
              this.languageLabel = _("Bihari")
              break
            case "grn":
              this.languageLabel = _("Guarani")
              break
            default:
              break
              // console.log("default")
            }
          }
          return {
            label: this.languageLabel,
            signal: "pvr:audio:set",
            default: t.default,
            track_id: i,
          }
        })
      })
  }

  @on("pvr:audio:set")
  _onAudioSet(data) {
    PlayerManager.setAudioTrack(data.track_id)
      .then(() => this.tree.lists[1].view.markAsDefault(data.track_id))
  }
 }
