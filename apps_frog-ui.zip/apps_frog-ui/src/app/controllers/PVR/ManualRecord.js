//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {on} from "services/events"
import {$} from "widgets/Component"
import {padLeft} from "utils/string"
import {findKey} from "utils"
import {addMinutes, MONTH, toDayString, exists} from "utils/date"
import {_} from "utils/locale"

import TimezoneManager from "services/managers/TimezoneManager"
import ChannelManager from "services/managers/ChannelManager"
import PVRManager from "services/managers/PVRManager"

import * as popUpMsg from "app/utils/PopUpMsg"
import {ListObj} from "app/utils/widgets/lists"
import ModManager from "services/managers/ModManager"

export default class ManualRecordController extends Controller {
  constructor() {
    super()
    this.view = $("manualRecord")
    this.spinners = {
      channel:    {view: this.view.channelSpinner,    list: null},
      day:        {view: this.view.daySpinner,        list: null},
      month:      {view: this.view.monthSpinner,      list: null},
      year:       {view: this.view.yearSpinner,       list: null},
      duration:   {view: this.view.durationSpinner,   list: null},
      recurrence: {view: this.view.recurrenceSpinner, list: null},
      hours:      {view: this.view.hoursSpinner,      list: null},
      minutes:    {view: this.view.minutesSpinner,    list: null},
      timeFormat: {view: this.view.tfSpinner,         list: null},
      // pin: {view: this.view.pinSpinner, list: null},
    }
    this.loadSpinners()
  }

  set currentSpinner(spinnerName) {
    if (this._current) {
      this._current.view.pullState("focused")
    }
    this._current = this.spinners[spinnerName]
    if (spinnerName === "day" || spinnerName === "month" || spinnerName === "year") {
      this.spinners["day"].view.pushState("hightlight")
    } else {
      this.spinners["day"].view.pullState("hightlight")
    }

    if (spinnerName === "hours" || spinnerName === "minutes") {
      this.spinners["hours"].view.pushState("hightlight")
    } else {
      this.spinners["hours"].view.pullState("hightlight")
    }
    this._current.view.pushState("focused")
  }

  get currentSpinner() {
    return this._current
  }

  get userContent() {
    const day = this.spinners.day.list.currentItem.value
    const month = this.spinners.month.list.currentItem.value
    const year = this.spinners.year.list.currentItem.value
    const duration = this.spinners.duration.list.currentItem.value
    const channel = this.spinners.channel.list.currentItem
    const recurrence = this.spinners.recurrence.list.currentItem.title
    let hours = this.spinners.hours.list.currentItem.value
    const minutes = this.spinners.minutes.list.currentItem.value
    const timeFormat = this.spinners.timeFormat.list.currentItem.value
    if (!TimezoneManager.displayH24) {
      if (hours === 12) {
        hours = 0
      }
      if (timeFormat === "pm") {
        hours += 12
      }
    }
    const startDate = new Date(year, month - 1, day, hours, minutes, 0, 0)
    const endDate = addMinutes(startDate, duration)
    // const pin = this.spinners.pin.list.currentItem.value
    return {
      channelTitle: channel.title,
      title: channel.title,// + " " + startDate.toLocaleDateString() + "  " + TimezoneManager.getFormatTime(startDate),
      description: "Manual record with '" + recurrence  +  "' recurrence, no description available",
      startDate: startDate,
      endDate: endDate,
      timeFormat: timeFormat,
      // pin: pin,
    }
  }

  open() {
    this._setDefaults()
    this.currentSpinner = "channel"
    this.view.show()
    this.view.updateHeaderFooter()
    if (TimezoneManager.displayH24) {
      // this.spinners.timeFormat.view.list.disable()
      this.spinners.timeFormat.view.hide()
    } else {
      this.spinners.timeFormat.view.show()
      // this.spinners.timeFormat.view.list.enable()
    }
    return Promise.resolve()
  }

  @on("ManualRecord:close")
  close() {
    this.view.hide()
    return Promise.resolve()
  }

  loadSpinners() {
    this._spinnersOrder = ["channel", "day", "month", "year", "duration", "recurrence","hours", "minutes","timeFormat"]
    this.spinners.day.list =        this._loadNumberSpinner(1,        31,           1,  this.spinners.day)
    this.spinners.month.list =      this._loadNumberSpinner(1,        12,           1,  this.spinners.month, (i) => {
      return MONTH[i-1]
    })
    this.spinners.duration.list =   this._loadNumberSpinner(15,       240,          15, this.spinners.duration, (i) => {
      return i + " Min"
    })
    this.spinners.recurrence.list = this._loadRecurrences()
    this.spinners.hours.list =      this._loadNumberSpinner(0,        12,           1,  this.spinners.hours)
    this.spinners.minutes.list =    this._loadNumberSpinner(0,        59,           1,  this.spinners.minutes)
    this.spinners.timeFormat.list = this._loadTimeFormat()
    // this.spinners.pin.list=this._loadPINOption()
  }

  _setDefaults() {
    const now = new Date()
    let hrs = now.getHours()
    let tf = 0
    const nowYear = now.getFullYear()
    if (!TimezoneManager.displayH24) {
      if (hrs === 0) {
        hrs = 11
      } else if (hrs < 12) {
        hrs = hrs - 1
      } else if (hrs === 12) {
        hrs = 11
        tf = 1
      } else {
        hrs = hrs - 13
        tf = 1
      }
    }
    this.spinners.year.list = this._loadNumberSpinner(nowYear,  nowYear + 10, 1,  this.spinners.year)
    this.spinners.channel.list.selectItem(ChannelManager.current)
    this.spinners.day.list.select(now.getDate() - 1)
    this.spinners.month.list.select(now.getMonth())
    this.spinners.year.list.select(0)
    this.spinners.duration.list.select(3) // 1H
    this.spinners.recurrence.list.select(0)
    this.spinners.hours.list.select(hrs)
    this.spinners.minutes.list.select(now.getMinutes())
    this.spinners.timeFormat.list.select(tf)

    // this.spinners.pin.list.select(0)
  }


  record() {
     // Checking If Channel is MOD(Movie on Demand) then recording is not allowed
    if (ModManager.isCurrentChannelMod(this.spinners.channel.list.currentItem)) return
    if (this._isDateValid()) {
      if (PVRManager._pvrReady) {
        const channel = this.spinners.channel.list.currentItem
        const userContent = this.userContent
        let recurrence = this.spinners.recurrence.list.currentItem.value

        if (recurrence === "week") {
          recurrence = toDayString(userContent.startDate).toLowerCase()
        }

        PVRManager.recordManual(userContent, channel, recurrence)
      } else {
        popUpMsg.pvrNotReady()
      }
    } else {
      popUpMsg.invalidDate()
      this.currentSpinner = "day"
    }
  }

  _loadTimeFormat() {
    return new ListObj([
        {title: _("AM"),      value: "am"},
        {title: _("PM"),      value: "pm"},
    ], this.spinners.timeFormat.view.list)
  }

  _loadPINOption() {
    /* return new ListObj([
        {title: _("No"),     value: "no"},
        {title: _("Yes"),  value: "yes"},
    ], this.spinners.pin.view.list)*/
  }

  _isDateValid() {
    const day = this.spinners.day.list.currentItem.value
    const month = this.spinners.month.list.currentItem.value
    const year = this.spinners.year.list.currentItem.value
    let hours = this.spinners.hours.list.currentItem.value
    const minutes = this.spinners.minutes.list.currentItem.value
    const timeFormat = this.spinners.timeFormat.list.currentItem.value
    if (!TimezoneManager.displayH24) {
      if (hours === 12) {
        hours = 0
      }
      if (timeFormat === "pm") {
        hours += 12
      }
    }
    if (exists(day, month, year)) {
      const startDate = new Date(year, month - 1, day, hours, minutes, 0, 0)
      if (startDate < new Date()) {
        this.currentSpinner = "day"
        return false
      }
    } else {
      return false
    }

    return true
  }

  @on("channels:updated")
  _loadChannels() {
    this.spinners.channel.list = new ListObj(ChannelManager.channels, this.spinners.channel.view.list)
    if (ChannelManager.current) {
      this.spinners.channel.list.selectItem(ChannelManager.current)
    }
  }

  @on("hours:update")
  updateSpinnerHour() {
    if (this.spinners) {
      if (!TimezoneManager.displayH24) {
        this.spinners.hours.list =      this._loadNumberSpinner(1,        12,           1,  this.spinners.hours)
      } else {
        this.spinners.hours.list =      this._loadNumberSpinner(0,        23,           1,  this.spinners.hours)
      }
    }
  }

  @on("locale:update")
  updateSpinnerLanguage() {
    if (this.spinners) {
      this.spinners.month.list =      this._loadNumberSpinner(1,        12,           1,  this.spinners.month, (i) => {
        return MONTH[i-1]
      })
      this.spinners.recurrence.list = this._loadRecurrences()
    }
  }

  _loadNumberSpinner(start, end, step, spinner, converter=null) {
    const values = []
    for (let i=start; i<=end; i += step) {
      values.push({
        title: converter ? converter(i) : padLeft("" + i, "0", "2"),
        value: i,
      })
    }
    return new ListObj(values, spinner.view.list)
  }

  _loadRecurrences() {
    return new ListObj([
      {title: _("One Time"),   value: null},
    ], this.spinners.recurrence.view.list)
  }

  up() {
    const currentSpinnerlist = this.currentSpinner.list
    if (!currentSpinnerlist.selected) {
      currentSpinnerlist.selected = currentSpinnerlist.items.length
    }
    currentSpinnerlist.up()
  }

  down() {
    const currentSpinnerlist = this.currentSpinner.list
    if (currentSpinnerlist.selected === currentSpinnerlist.items.length-1) {
      currentSpinnerlist.selected = -1
    }
    currentSpinnerlist.down()
  }

  left() {
    const currentName = findKey(this.spinners, this.currentSpinner)
    const nextName = Math.max(0, this._spinnersOrder.indexOf(currentName) - 1)
    this.currentSpinner = this._spinnersOrder[nextName]
  }

  right() {
    const currentName = findKey(this.spinners, this.currentSpinner)
    const nextName = Math.min(this._spinnersOrder.length - 1, this._spinnersOrder.indexOf(currentName) + 1)
    if (TimezoneManager.displayH24) {
      if (this._spinnersOrder[nextName] !== "timeFormat") {
        this.currentSpinner = this._spinnersOrder[nextName]
      }
    } else {
      this.currentSpinner = this._spinnersOrder[nextName]
    }
  }
}
