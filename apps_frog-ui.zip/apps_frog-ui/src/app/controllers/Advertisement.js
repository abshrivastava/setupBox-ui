//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import PlayerManager from "services/managers/PlayerManager"
import ChannelManager from "services/managers/ChannelManager"
import BrowserManager from "services/managers/BrowserManager"

import {$} from "widgets/Component"

import bus from "services/bus"
import {on, rcu} from "services/events"

export default class AdvertisementController extends Controller {
  constructor() {
    super()
    this.state = null
    this.view = $("adFrame")
    this.appView = $("application")
    this.legacyUniverse = null
  }

  @on("ad:website")
  openWebsite(params, universe) {
    this.legacyUniverse = universe
    PlayerManager.stop()
    this.state = "website"
    BrowserManager.openNewLayer(params, ["home", "backspace"])
  }

  @on("ad:video")
  openVideo(params, universe) {
    this.legacyUniverse = universe
    this.state = "video"
    return PlayerManager.play({playInfo: params}, "media")
      .then(() => this.appView.hide())
  }

  @on("ad:close")
  @rcu("ad:home:press")
  @rcu("ad:back:press")
  @rcu("ad:stop:press")
  close(params) {
    const goToHome = (params === "HOME")
    if (this.state === "website") {
      bus.emit("adbanner:deflate", goToHome)
      BrowserManager.closeLayer()
    } else if (this.state === "video") {
      bus.emit("adbanner:deflate", goToHome)
      this.appView.show()
    }
    if (this.legacyUniverse === "tv" || this.legacyUniverse === "home" || goToHome) {
      PlayerManager.play(ChannelManager.current, "channel")
    } else {
      PlayerManager.stop()
    }
    this.legacyUniverse = null
    this.state = null
  }

  @on("player:state:stopped", {universe: "ad"})
  onStop() {
    if (this.state === "video") {
      this.close()
    }
  }
}
