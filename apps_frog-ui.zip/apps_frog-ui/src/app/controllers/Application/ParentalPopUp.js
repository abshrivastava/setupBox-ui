//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import {createTicker} from "utils"
import {$} from "widgets/Component"

import bus from "services/bus"
import {on, rcu} from "services/events"
import BlockedChannelManager from "services/managers/BlockedChannelManager"
import {updatePinCode} from "services/managers/config"

/*
  =============
  Some snippets
  =============

  A simple alert pop up without actions
  -------------------------------------
 onAlert() {
  const title = "Title"
  const message = "A simple Message Pop Up, press back to exit"
  bus.emit("popup:alert", title, message, {})
  }

 An alert pop up with timeout
 ----------------------------
 onTimeOutAlert() {
  const title = "Title"
  const message = "A simple Message Pop Up, press back to exit, " +
    "or wait 5 seconds for auto hide"
  const timeout = 5000 // ms
  bus.emit("popup:alert", title, message, {timeout})
 }

 A confirm pop up with a callback triggered when pressing OK on YES button
 -------------------------------------------------------------------------
 openEpg() {
   const title = "EPG"
   const message = "Are you sure you want to enter the " +
    "Electronic Program Guide?"
   const callback = () => {
     bus.closeCurrentUniverse()
     bus.openUniverse("epg")
   }
   bus.emit("popup:confirm", title, message, {successCb: callback})
 }
 */
export default class ParentalPopUpController extends Controller {
  constructor(props) {
    super(props)
    this._reset()
    this.defaultButtons = ["yes", "no"]
    this.view = $("ParentalpopUp")
    this.currentPopup = ""
    this.newPin = "0000"
    this.If2IfPin = "3226"
    this.errorPopup = false
    this.callback
    this.settingTree
    this.baseUniverse
    this.lastUniverse = null
  }

  get selectedIdx() {
    return this._selectedIdx
  }

  set selectedIdx(value) {
    if (this.isConfirmPopUp) {
      this._selectedIdx = value
      this.view.selectButton(this._selectedIdx)
    }
  }

  _setLastUniverse(value) {
    if (value !== "parentalpopup" || value !== null || value !== "") {
      this.lastUniverse = value
    }
  }

  /* ********* Open/Close functions ********* */
  open() {
    this._setLastUniverse(bus.universe)
    this.legacyUniverse = bus.universe

    bus.universe = "parentalpopup"
    this.view.onOpen()
    if (this.autoHideTicker)
      this.autoHideTicker.start(this.close.bind(this, false), true)
  }
   @on("parentalpopup:close")
  close(confirm) {
    if (this.autoHideTicker)
      this.autoHideTicker.stop()
    if (this.errorPopup) {
      this.errorPopup = false
      this.view.hideError(this.currentPopup)
    }
    bus.universe = this.legacyUniverse
    if (bus.universe === null || bus.universe === "") {
      bus.universe = this.lastUniverse
    }
    this.view.onClose()
    if (this.isConfirmPopUp && confirm)
      this.successCallback()
    else
      this.cancelCallback()

    this._reset()
  }



  /* ********* Arrow Keys ********* */
  @rcu("parentalpopup:left:press")
  onLeft() {
    if (this.currentPopup !== "Success") {
      this.view.deleteText()
    }
  }
    /* ************************************************************************ */
    /* ********* Program Plus/Minus ********* */


  @rcu("parentalpopup:program_plus:press")
  nextChannel() {
    if (this.currentPopup === "BlockChannel") {
      this.close(true)
      bus.emit("tv:nextChannel")
    }
  }

  @rcu("parentalpopup:program_minus:press")
  previousChannel() {
    if (this.currentPopup === "BlockChannel") {
      this.close(true)
      bus.emit("tv:previousChannel")
    }
  }

/* ********* Special Buttons (OK, Back) ********* */
  @rcu("parentalpopup:back:press")
  onBack() {
    const confirm = false

    if (this.currentPopup === "BlockChannel") {

      bus.emit("tv:tunePrevious")


      this.close(confirm)
      this.view.hideError(this.currentPopup)
      this.view.hideSuccess(this.currentPopup)
      if (this.baseUniverse && this.baseUniverse !== "tv") {


        bus.openUniverse("home")
        this.baseUniverse = ""
      }
    //  bus.emit("tv:tunePrevious")
    //  this.callback && this.callback(false)
    }  else if (this.currentPopup === "Recording") {
      this.close(confirm)
        // this.view.hideError(this.currentPopup)
       // this.view.hideSuccess(this.currentPopup)
      bus.openUniverse("pvr")
    } else {
      this.close(confirm)
      bus.emit("setting:closeParent")
      this.view.hideError(this.currentPopup)
      this.view.hideSuccess(this.currentPopup)
    }
  }

  @rcu("parentalpopup:numeric:press")
  onInput(_) {
    if (this.errorPopup) {
      this.errorPopup = false
      this.view.hideError(this.currentPopup)
    }

    if (this.currentPopup !== "Success") {
      this.view.updateText(_)
    }
  }


  @rcu("parentalpopup:ok:press")
  onOk() {
    let enteredPin = ""
    let isPinCorrect
    switch (this.currentPopup) {
    case "IF2IF":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        if (this.If2IfPin !== enteredPin) {
          this.view.showError("error_msg")
          this.errorPopup = true
          return
        }
        this.callback && this.callback()
        this.close(true)
        bus.emit("setting:closeParent")
        this.settingTree &&  this.settingTree.right()
      }
      break
    case "EnterPin":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        isPinCorrect = BlockedChannelManager.validateEnteredPin(enteredPin)
        if (!isPinCorrect) {
          this.view.showError("error_msg")
          this.errorPopup = true
          return
        }
        this.callback && this.callback()
        this.close(true)
        bus.emit("setting:closeParent")
        this.settingTree &&  this.settingTree.right()
      }
      break
    case "BlockChannel":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        isPinCorrect = BlockedChannelManager.validateEnteredPin(enteredPin)
        if (!isPinCorrect) {
          this.view.showError("error_msg")
          this.errorPopup = true
          return
        }
        this.callback && this.callback(true)
        this.close(true)
        if (this.baseUniverse !== "tv") {
          bus.openUniverse("home")
          this.baseUniverse = ""
        }
      }
      break
    case "Recording":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        isPinCorrect = BlockedChannelManager.validateEnteredPin(enteredPin)
        if (!isPinCorrect) {
          this.view.showError("error_msg")
          this.errorPopup = true
          return
        }
        this.callback && this.callback(true)
        this.close(true)
        // if (this.baseUniverse != "tv") {
        //   bus.openUniverse("home")
        //   this.baseUniverse = ""
        // }
      }
      break
    case "ChangePin":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        isPinCorrect = BlockedChannelManager.validateEnteredPin(enteredPin)
        if (!isPinCorrect) {
          this.view.showError("error_msg")
          this.errorPopup = true
          return
        }
        this.currentPopup = "NewPin"
        this.view.updatePopup(this.currentPopup)
      }
      break
    case "NewPin":
      enteredPin = this.view.enteredPin
      if (enteredPin.length===4) {
        this.NewPin = enteredPin
        this.currentPopup = "ConfirmPin"
        this.view.updatePopup(this.currentPopup)
      }
      break
    case "ConfirmPin":
      enteredPin = this.view.enteredPin
      if (enteredPin.length === 4) {
        isPinCorrect = (this.NewPin === enteredPin)
        if (!isPinCorrect) {
          this.view.showError("mismatch")
          this.errorPopup = true
          return
        }
        updatePinCode(this.NewPin)
         .then(() => {
           BlockedChannelManager.updatePin(this.NewPin)
           this.currentPopup = "Success"
           this.view.updatePopup(this.currentPopup)
           this.view.showSuccess()
         })
      }
      break
    case "Success":
      this.close(true)
      bus.emit("setting:closeParent")
      this.view.hideSuccess(this.currentPopup)
      break
    default:
    }
  }

  /* ************************************************************************ */


  /* ************************************************************************ */

  @on("parentalpopup:parentAlert")
  _parentAlert(popupType, settingTree, callback, message, {timeout}) {
    if (!this.isConfirmPopUp)
      this.view.noButtons()
    this.currentPopup = popupType
    this.callback = callback

    this.baseUniverse = bus.universe
    // this.settingTree = settingTree
    if (timeout) {
      this.view.setCountDown(timeout / 1000)
      this.autoHideTicker = createTicker(timeout)
    }
    this.view.updatePopup(this.currentPopup)
    this.open()
  }

  @on("parentalpopup:pinAlert")
  _pinAlert(popupType, settingTree, callback, message, {timeout}) {

    if (!this.isConfirmPopUp)
      this.view.noButtons()
    this.currentPopup = popupType
    this.callback = callback

    this.baseUniverse = bus.universe
    // this.settingTree = settingTree
    if (timeout) {
      this.view.setCountDown(timeout / 1000)
      this.autoHideTicker = createTicker(timeout)
    }
    this.view.updateRecordingPopup(this.currentPopup)
    this.open()
  }
  _reset() {
    this.autoHideTicker = null
    this.successCallback = () => {}
    this.cancelCallback = () => {}
    this.isConfirmPopUp = false
    this.legacyUniverse = null
  }

}
