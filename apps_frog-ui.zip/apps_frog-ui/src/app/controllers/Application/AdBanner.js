//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"

import AdsManager from "services/managers/AdsManager"

export default class AdBannerController extends Controller {
  constructor() {
    super()
    this.ads = null
    this.legacyUniverse = null
    this.isChannelListOpen = false
    this.isClockOpen = false
    this.view = $("adBanner")
  }

  @on("adbanner:open")
  open(universe,isChannelList = false) {
    return AdsManager.fetchAd(universe,isChannelList)
      .then((response) => {
        if (response) {
          this.displayAd(universe)
        } else {
          this.view.fold()
        }
      })
  }

  @on("adbanner:openBelow")
  openBelow(universe) {
    return this.open(universe, true)
  }

  displayAd(universe) {
    const ad = AdsManager.getAd()
    if (ad) {
      this.legacyUniverse = universe
      this.isClockOpen && this.view.unfold(AdsManager.getMediaPath(), ad.type)
    }
  }

  @on("adbanner:close")
  close() {
    this.legacyUniverse = null
    return this.view.fold()
  }

  refresh() {
    if (bus.universe === this.legacyUniverse) {
      return AdsManager.fetchAd(this.legacyUniverse)
        .then(() => this.updateView(AdsManager.getAd()))
    }
  }

  updateView(ad) {
    if (ad) {
      return this.view.unfold(ad.mediaFile, ad.type)
    }
    return this.view.unfold()
  }

  @on("adbanner:inflate")
  inflate() {
    bus.universe = null
    const ad = AdsManager.getAd()
    switch (ad.type) {
    case "none":
      bus.universe = this.legacyUniverse
      break
    case "website":
      this.refreshTicker.stop()
      bus.openUniverse("ad")
      bus.emit("ad:website", ad.params, this.legacyUniverse)
      break
    case "video":
      this.refreshTicker.stop()
      bus.openUniverse("ad")
      bus.emit("ad:video", ad.params, this.legacyUniverse)
      break
    default:
      bus.universe = this.legacyUniverse
      return Promise.reject("AdBanner: Can't inflate because ads.type is not good")
    }
  }

  @on("adbanner:deflate")
  deflate(fromHome) {
    this.refreshTicker.start(this.refresh.bind(this, this.legacyUniverse), true)
    if (this.legacyUniverse !== null) {
      bus.universe = this.legacyUniverse
    }

    if (fromHome) {
      bus.closeCurrentUniverse()
      bus.openUniverse("home")
    }
  }

  @on("adbanner:onDownloadComplete")
  onDownloadComplete() {
    if (this.isClockOpen) {
      this.open(bus.universe, this.isChannelListOpen)
    }
  }

  @on("adBanner:channelListOpen")
  channelListOpen(isOpen) {
    this.isChannelListOpen = isOpen
  }

  @on("adBanner:clockOpen")
  clockOpen(isOpen) {
    this.isClockOpen = isOpen
  }
}
