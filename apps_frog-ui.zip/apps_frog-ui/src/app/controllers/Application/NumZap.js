//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Controller from "utils/Controller"
import bus from "services/bus"
import {on} from "services/events"
import {$} from "widgets/Component"
import config from "utils/config"

export const MAX_DIGITS = 4
export const KBD_TIMEOUT = 1500

export default class NumZapController extends Controller {
  constructor(props) {
    super(props)
    this.flush()
    this.view = $("numZap")
    this.KBD_TIMEOUT = KBD_TIMEOUT
    this.keyToNum = {}
    this.byPassOkButton = false
    for (const key in config.KEYMAP) {
      if (key.startsWith("KEY_")) {
        const keynum = Number(key.substring(4))
        this.keyToNum[config.KEYMAP[key]] = keynum.toString()
      }
    }
  }

  setTriggerFunction(triggerFunction) {
    this.triggerFunction = triggerFunction
  }

  /* ************************************************************************ */

  /* ********* Utilities function ********* */
  flush() {
    this.kbdInput = []
    this.isListeningNewEvent = true
    this.kbdTimer = null
  }

  _isValidKbdNum(kbdNum) {
    return kbdNum && (this.kbdInput.length > 0 || kbdNum > "0") && (this.kbdInput.length < this.maxDigits)
  }

  _isChannelReal(response) {
    return (response && response.lcn.real && !response.playing)
  }

  _getChannelFromResponse(response) {
    return (response.lcn.real) ? response.resource.real : response.resource.fallback
  }
  /* ************************************************************************ */

  open(kbd, doTriggerEach = false, doTriggerNew = true,
       maxDigits = MAX_DIGITS, doTimeout = true, from ="") {
    // handle ignoring if not listen new event
    this.active = true
    if (!this.isListeningNewEvent) {
      return Promise.reject("NumZap: handle ignored because timeout exceeded")
    }
    this.byPassOkButton = true
    this.doTriggerEach = doTriggerEach
    this.doTriggerNew = doTriggerNew
    this.maxDigits = maxDigits
    this.doTimeout = doTimeout

    this.view.onOpen(from)
    this.addKbdTimeout()
    this.update(kbd)
  }

  addKbdTimeout() {
    if (this.doTimeout || this.kbdInput.length === this.maxDigits) {
      clearTimeout(this.kbdTimer)
      clearTimeout(this.view.closeViewTimer)
      this.kbdTimer = setTimeout(() => {
        (this.kbdInput.length > 0) ? this.onZapFinish() : this.close()
      }, this.KBD_TIMEOUT)
    }
  }

  update(kbd) {
    switch (kbd.which) {
    case config.KEYMAP.STOP:
      return this.close()
    case config.KEYMAP.OK:
      return this.onZapFinish()
    case config.KEYMAP.LEFT:
      this.kbdInput.pop()
      break
    default:
      this.addKbdNum(this.keyToNum[kbd.which])
      break
    }
    this.view.onUpdate(this.kbdInput)
  }

  addKbdNum(kbdNum) {
    if (this._isValidKbdNum(kbdNum)) {
      this.kbdInput.push(kbdNum)
      this.triggerEach()
    }
  }

  triggerEach() {
    if (this.doTriggerEach) {
      this.triggerFunction(this.kbdInput.join(""))
        .then((response) => {
          bus.emit(`${bus.universe}:numzap_each`, this._getChannelFromResponse(response))
        })
    }
  }

  triggerNew(response) {
    if (this.doTriggerNew) {
      if (this._isChannelReal(response)) {
        bus.emit(`${bus.universe}:numzap_real`, response.resource.real)
      } else {
        if (response.playing) {
          bus.emit(`${bus.universe}:numzap_already`, response.resource.real)
        } else {
          bus.emit(`${bus.universe}:numzap_fallback`, response.resource.fallback)
        }
      }
    }
  }

  onZapFinish() {
    this.isListeningNewEvent = false
    this.triggerFunction(this.kbdInput.join(""))
      .then((response) => {
        this.triggerNew(response)
        this._isChannelReal(response) ? this.view.onSuccess() : this.view.onError()
        this.close()
      })
  }

  @on("NumZap:close")
  close() {
    this.byPassOkButton = false
    this.flush()
    this.view.onClose()
    this.active = false
    // if (bus.universe === "UnsubscribedErrorMsg") {
    //   bus.emit("UnsubscribedErrorMsg:close")
    //   bus.universe = "tv"
    // }
  }
}
