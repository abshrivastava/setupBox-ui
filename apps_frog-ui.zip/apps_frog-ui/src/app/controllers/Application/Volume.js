//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Controller from "utils/Controller"
import {$} from "widgets/Component"
import bus from "services/bus"

import {
  increaseVolume,
  decreaseVolume,
  mute,
  unmute,
  getMute,
  getVolume,
} from "services/managers/volume"
import {on} from "services/events"

export default class VolumeController extends Controller {
  constructor(props) {
    super(props)
    this.VIEW_TIMEOUT = 1500
    this.viewTimer = null
    this.muteViewTimer = null
    this.MUTE_TIMEOUT = 5000
    this.muteTimer = null
    this.pauseVolMinus = false
    this.view = $("volumeBar")
    this.isMute = false
  }

  clearViewTimer() {
    if (this.viewTimer) {
      clearTimeout(this.viewTimer)
    }
    if (this.muteViewTimer) {
      clearTimeout(this.muteViewTimer)
    }
  }

  clearMuteTimer() {
    if (this.muteTimer) {
      clearTimeout(this.muteTimer)
    }
    this.muteTimer = null
    this.pauseVolMinus = false
  }


  setMuteTimer() {
    this.muteTimer = setTimeout(() => {
      this.pauseVolMinus = true
      this.mute()
    }, this.MUTE_TIMEOUT)
  }


  setViewTimer() {
    this.clearViewTimer()
    this.viewTimer = setTimeout(() => {
      this.close()
    }, this.VIEW_TIMEOUT)
  }

  setMuteViewTimer() {
    if (this.muteViewTimer) {
      clearTimeout(this.muteViewTimer)
    }
    if (this.viewTimer) {
      clearTimeout(this.viewTimer)
    }

    this.muteViewTimer = setTimeout(() => {
      this.view.onClose()
    }, this.VIEW_TIMEOUT)
  }

  close() {
    getMute()
      .then((data) => {
        if (!data.value || bus.universe === "standby") {
          this.view.onClose()
        }
      })
  }

  mute() {
    mute()
      .then(() => {
        this.isMute = true
        this.view.onMute()
      })
  }

  @on("volume:setmute")
  setMuteView(volume) {
    mute().then(() => {
      this.isMute = true
      this.view.onOpen()
      this.view.onProgress(volume)
      this.view.onMute()
    })
  }

  @on("volume:hidebar")
  hideBar(volume) {
    this.view.onProgress(volume)
    this.view.onClose()
  }

  mutePressed() {
    if (this.muteViewTimer) clearTimeout(this.muteViewTimer)
    let muteStatus
    getMute()
      .then((data) => {
        muteStatus = data.value
        if (data.value) {
          this.isMute = false
          return unmute()
        } else {
          this.isMute = true
          return mute()
        }
      })
      .then(() => {
        return getVolume()
      })
      .then((progress) => {
        this.view.onOpen()
        this.view.onProgress(progress.volume)
        if (muteStatus) {
          this.view.onUnmute()
          this.setMuteViewTimer()
        } else {
          this.view.onMute()
        }
      })
  }

  @on("volume:unmute")
  onVolumeUnmute() {
    if (!this.isMute) {
      unmute()
      .then(() => {
        this.isMute = false
        this.view.onUnmute()
      })
    }
  }

  volumeUp() {
    return increaseVolume().then((progress) => {
      this.view.onOpen()
      this.view.onProgress(progress)
      this.isMute = false
      this.view.onUnmute()
      this.setViewTimer()
    })
  }

  volumeDown() {
    if (this.pauseVolMinus) return
    if (!this.muteTimer) this.setMuteTimer()
    decreaseVolume().then((progress) => {
      this.isMute = false
      this.view.onOpen()
      this.view.onProgress(progress)
      this.view.onUnmute()

      if (progress === 0) {
        this.isMute = true
        this.clearViewTimer()
        this.view.onMute()
      }
      if (!this.isMute) this.setViewTimer()
    })
  }

  volumeMinusOnUp() {
    this.clearMuteTimer()
  }
}
