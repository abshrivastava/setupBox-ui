//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import AbstractItem from "app/components/widgets/AbstractItem"
import RecordItem from "./RecordItem"
import EmptyItem from "./EmptyItem"
import ScheduleItem from "./ScheduleItem"
import ManualItem from "./ManualItem"

export default class RecordListItem extends AbstractItem {
  constructor() {
    super({
      map: {
        Record: "record",
        PvrEmpty: "empty",
        Schedule: "schedule",
        Manual: "manual",
      },
    })
  }

  render() {
    return (
      <div className="RecordListItem RecordListItemList-item">
        <ManualItem key="manual" />
        <EmptyItem key="empty" />
        <RecordItem key="record" />
        <ScheduleItem key="schedule" />
      </div>
    )
  }
}
