//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {waitReflow} from "utils/dom"

import MainBackground from "app/components/widgets/MainBackground"
import {default as hamsterWheelUrl} from "assets/loaders/wheel.png"

import Background from "./Background"
import Selection from "./Selection"
import ItemList from "./ItemList"

import "./index.css"

export default class RecordList extends Component {

  render() {
    return (
      <div className="RecordList RecordList--hidden">
        <MainBackground key="mainBackground" />
        <Background key="background" />
        <Selection key="selection" />
        <ItemList key="itemList" />
        <img className="RecordList-hamsterWheel RecordList-hamsterWheel--hidden"
         src={hamsterWheelUrl}
         key="hamsterWheel"/>
      </div>
    )
  }

  open() {
    this.show()
    this.mainBackground.show()
    waitReflow(this.dom)

    const promises = [
      this.selection.unfold(),
      this.itemList.unfold(),
      this.background.unfold(),
    ]

    return Promise.all(promises)
  }

  close() {
    this.itemList.fold()
    this.mainBackground.hide()
    this.selection.fold()
    this.background.fold()
    this.hide()
  }

  isOpened() {
    return this.itemList.dom.classList.contains("RecordListItemList--unfold")
  }

  update(data) {
    this.itemList.setScrollableSource(data)
  }

  showSpinner() {
    this.hamsterWheel.classList.remove("RecordList-hamsterWheel--hidden")
  }

  hideSpinner() {
    this.hamsterWheel.classList.add("RecordList-hamsterWheel--hidden")
  }
}
