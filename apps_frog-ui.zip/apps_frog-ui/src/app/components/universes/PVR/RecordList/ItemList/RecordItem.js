//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import * as date from "utils/date"
import config from "utils/config"
import {channelLogo as logoName} from "utils"
import {testImage} from "utils/image"

import recordPictoUrl from "assets/pictos/record.png"
import defaultLogoUrl from "assets/fallbacks/channel-logo.png"

export default class RecordItem extends Component {
  constructor() {
    super({
      title: "Untitled",
      category: "",
      channelTitle: "Unknown channel",
      startDate: new Date(),
      duration: "0h00",
      channelLogo: {defaultLogoUrl},
    })
  }

  render() {
    return (
      <div className="RecordItem RecordItem--hidden">
        <div className="RecordItem-summary">
          <img className="RecordItem-picto" src={recordPictoUrl} />
          <div className="RecordItem-title" prop="title" />
          <div className="RecordItem-category" prop="category" />
        </div>
        <div className="RecordItem-details">
          <div className="RecordItem-channel" prop="channelTitle" />
          <div className="RecordItem-date" prop="startDate" />
          <div className="RecordItem-duration" prop="duration" />
          <img
            className="RecordItem-channelLogo"
            src={defaultLogoUrl} key="logo"/>
        </div>
      </div>
    )
  }

  update(item) {
    if (!item) {
      this.hide()
      return
    }

    this.show()

    let duration
    try {
      duration = date.formatDuration(item.duration)
    } catch (err) {
      duration = "Unknown duration"
    }

    this.setProps({
      title: item.title,
      category: item.category,
      startDate: date.formatDate(item.startDate),
      channelTitle: item.channelTitle,
      duration: duration,
    })

    const channelLogo =
    `http://${config.STB_IP}${config.LOGO_BASE}${logoName(item.channelTitle)}.png`
    testImage(this.logo, channelLogo, defaultLogoUrl)
  }
}
