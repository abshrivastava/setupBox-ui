//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import PlayerManager from "services/managers/PlayerManager"
import Component from "widgets/Component"
import {waitReflow} from "utils/dom"
import {formatDuration} from "utils/date"
import {createTicker} from "utils"
import "./index.css"

import audioLogoUrl from "assets/pictos/music.png"

import pausePicto from "assets/pictos/trickmode-pause.png"
import playPicto from "assets/pictos/trickmode-classic-play.png"
import fastForwardPicto from "assets/pictos/trickmode-forward.png"
import fastRewindPicto from "assets/pictos/trickmode-rewind.png"


const PICTO = {
  play: playPicto,
  pause: pausePicto,
  fastForward: fastForwardPicto,
  fastRewind: fastRewindPicto,
}

export default class AudioControl extends Component {
  constructor(props) {
    super(Object.assign({}, {
      title: "",
      position: "",
      remaining: "",
      date: "",
      duration: "",
      mode: "play",
    }, props))

    this.refreshTicker = createTicker(1000)
    this.currentMode = "play"
  }

  render() {
    return (
      <div className="AudioControl">
        <div className="PlayerControl-icon">
          <div className="PlayerControl-speedinfo" key="speedInfo" />
          <img key="icon" src={playPicto} />
        </div>
        <div className="AudioControl-program" key="program">
          <img
            key="logoImg"
            className="AudioControl-logo"
            src={audioLogoUrl} />
          <div className="AudioControl-epgTitle" prop="title" />
          <div className="AudioControl-timeInfo" key="timeInfo">
            <div className="AudioControl-position" prop="position" />
            <div className="AudioControl-progressBar">
              <div className="AudioControl-progress" key="progress" />
            </div>
            <div className="AudioControl-remaining">
              -<span prop="remaining" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  open() {
    this.unfold()
  }

  stop() {
    this.fold()
  }

  update(item) {
    this.setProp("title", item.title)
    this._updateProgressRemaining()
  }

  pause() {
    waitReflow(this.dom)
    this.setMode("pause")
    this.speedInfo.textContent = ""
    this.unfold()
  }

  resume() {
    waitReflow(this.dom)
    this.setMode("play")
    this.speedInfo.textContent = ""
    this.unfold()
  }

  fastForward(speed) {
    this.setMode("fastForward")
    this.speedInfo.textContent = `x${~~(speed)}`
    this.unfold()
  }

  fastRewind(speed) {
    this.setMode("fastRewind")
    this.speedInfo.textContent = `x${~~(-speed)}`
    this.unfold()
  }

  fold() {
    return this.pullState("unfold", true)
      .then(() => this.refreshTicker.stop())
  }

  delayedFold() {
    this.foldDelayed = setTimeout(() => this.fold(), 3000)
  }

  unfold() {
    if (this.foldDelayed) {
      clearTimeout(this.foldDelayed)
    }
    return this.pushState("unfold", true)
      .then(() => {
        const update = () => this._updateProgressRemaining()
        return this.refreshTicker.start(update)
      })
  }

  setMode(mode) {
    this.currentMode = mode
    this.setSpeedInfo()
    this.icon.setAttribute("src", PICTO[mode])
  }

  setSpeedInfo() {
    this.speedInfo.classList.remove("AudioControl-speedinfo--hidden")
    if (this.currentMode === "fastRewind") {
      this.speedInfo.classList.add("AudioControl-speedinfo--rewind")
    } else if (this.currentMode === "fastForward") {
      this.speedInfo.classList.remove("AudioControl-speedinfo--rewind")
    } else {
      this.speedInfo.classList.add("AudioControl-speedinfo--hidden")
    }
  }

  _updateProgressRemaining() {
    PlayerManager.getAbsolutePosition()
      .then((ppos) => {
        const duration = ppos.size
        const position = ppos.position
        this.setProp("position", formatDuration(position))
        this.setProp("remaining", formatDuration(duration - position))
        this.progress.style.width = ~~(position / duration * 100) + "%"
      })
  }
}
