//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import "./index.css"
import {_} from "utils/locale"
import ActionsList from "../ActionList"


class FIlanguageSelector extends Component {
  render() {
    return (
      <div className = "FIlanguageSelector" key = "FIlanguageSelector">
        <div className = "FIlanguageSelector-bg" />
        <div className = "FIlanguageSelector-arrow" key = "arrow" />
      </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class FIlanguageItem extends Component {
  render() {
    return (
      <div className = "FIlanguageItem" prop = "label" />
    )
  }
}

export class FIlanguageList extends HybridListComponent {
  constructor() {
    super(FIlanguageSelector, FIlanguageItem)
    this.ITEM_HEIGHT = 50
    if (config.SD_ZAPPER) this.ITEM_HEIGHT = 40
    this.WINDOW_SIZE = 9
    this.EXTRA_VISIBLE_ITEMS = 1

  }


  render() {
    return (<div className = "FIlanguageList" />)
  }

  showSelector() {

  }

  addLock(iCounter) {
    this.dom.childNodes[1].childNodes[iCounter].classList.remove("lockChannel")
    this.dom.childNodes[1].childNodes[iCounter].classList.add("lockedChannel")
  }

  removeLock(iCounter) {
    this.dom.childNodes[1].childNodes[iCounter].classList.remove("lockedChannel")
    this.dom.childNodes[1].childNodes[iCounter].classList.add("lockChannel")
  }
}


export default class FIlanguageMenu extends Component {
  constructor() {
    const props = {channelHeading: _("Choose your language"), title: _("Installation")}
    super(props)
    this.selectedIndex = -1
  }

  render() {
    return (
      <div className="FIlanguageMenu FIlanguageMenu--hidden">
        <div className="FIlanguageMenu-inner">
          <div className = "FIlanguageMenu-container" >
            <div className = "FIlanguageMenu-heading" prop="channelHeading" />
            <FIlanguageList key="fIlanguageList"/>
          </div>
          <ActionsList ref="menuList" key="menuList"/>
        </div>
      </div>
    )
  }

  loadItems(itemList) {
    this.menuList.setActions(itemList)
    this.setProp("channelHeading", _("Choose your language"))
  }

  show() {
    this.pullState("onBackground")
    // this.channelsTree.show()
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    // this.channelsTree.reset()
    this.pushState("hidden")
  }

  highlightDefault(idx) {
    if (this.selectedIndex > -1) {
      this.fIlanguageList.actions[this.selectedIndex].pullState("default")
    }
    this.fIlanguageList.actions[idx].pushState("default")
    this.selectedIndex = idx
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

}
