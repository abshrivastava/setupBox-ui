//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {waitReflow}  from "utils/dom"
import {pick} from "utils"

import CurrentProgram from "app/components/universes/Television/ChannelList/CurrentProgram"
import MainBackground from "app/components/widgets/MainBackground"

import Background from "./Background"
import Selection from "./Selection"
import ItemList from "./ItemList"

import "./index.css"

export default class RadioList extends Component {
  constructor(props) {
    const {variant} = pick(props, "variant")
    super(props)
    this.variant = variant
  }

  render() {
    return (
      <div className={`RadioList RadioList--hidden RadioList--${this.variant}`}>
        <MainBackground key="mainBackground" />
        <Background key="background"/>
        <ItemList key="itemList" hasLogos={this.variant === "withLogos"}/>
        <CurrentProgram key="currentProgram" />
        <Selection key="selection" />
      </div>
    )
  }

  open() {
    this.show()
    this.mainBackground.show()
    waitReflow(this.dom)

    const promises = [
      this.selection.unfold(),
      this.itemList.unfold()
        .then(() => this.currentProgram.unfold()),
      this.background.unfold(),
    ]

    return Promise.all(promises)
  }

  close() {
    const promises = [
      this.mainBackground.hide(),
      this.selection.fold(),
      this.currentProgram.fold(),
      this.itemList.fold(),
      this.background.fold(),
    ]

    return Promise.all(promises)
      .then(() => this.hide())
  }

  update(data) {
    this.itemList.setScrollableSource(data)
  }

  updateProgram(program) {
    this.currentProgram.update(program)
  }
}
