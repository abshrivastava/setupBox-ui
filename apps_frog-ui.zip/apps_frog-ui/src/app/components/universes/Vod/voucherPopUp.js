//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import Component from "widgets/Component"
import {pushState, pullState} from "utils/dom"
import "./index.css"

class VoucherButton extends Component {
  render() {
    return (
      <div className="VoucherPopUp-button" prop="label" />
    )
  }

  update(value) {
    this.setProp("label", value)
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }
}

class VoucherInput extends Component {
  render() {
    return (
      <span className="voucherDigit" prop="label"/>
    )
  }

  update(value) {
    this.setProp("label", value.toString())
  }

  focus() {
    this.pushState("selected")
  }

  blur() {
    this.pullState("selected")
  }
}

export default class VoucherPopUp extends Component {
  constructor(props) {
    const defaultProps = {
      title: "",
      message: "",

    }
    super(Object.assign({}, defaultProps, props))
    this._flush()
  }

  render() {
    return (
      <div className="VoucherPopUp VoucherPopUp--hidden">
        <div className="VoucherPopUp-background" />
        <div className="VoucherPopUp-wrapper">
          <span className="VoucherPopUp-title" prop="title" />
          <div className="VoucherPopUp-message" prop="message" />
          <div className="VoucherPopUp-inner" key="digitWrapper" />
          <div className="VoucherPopUp-buttons-wrapper" key="buttonWrapper" />
          <div className="VoucherPopUp-error VoucherPopUp-error--hidden" key="errorWrapper">
            <div className="VoucherError-icon" key="error"/>
            <span className="VoucherError-message" prop="errorMessage"/>
          </div>
        </div>
      </div>
    )
  }

  onOpen(digitCount) {
    this.digitCount = digitCount
    this.setDigits()
    this.show()
  }

  onClose() {
    this.hide()
    this._flush()
    this.hideVoucherError()
  }

  updateTitle(title) {
    this.setProp("title", title)
  }

  updateMessage(message) {
    this.setProp("message", message)
  }

  setButtons(buttons) {
    if (buttons.length > 0) {
      for (const button of buttons) {
        const item = new VoucherButton(button)
        this.buttonWrapper.appendChild(item.build())
        this.buttons.push(item)
      }
      pushState(this.buttonWrapper, "hidden")
    }
  }

  setDigits() {
    for (let i = 0; i < this.digitCount; i++) {
      const item = new VoucherInput()
      this.digitWrapper.appendChild(item.build())
      this.digits.push(item)
    }
    this.selectDigit(0)
  }

  setDigit(value, index) {
    this.digits[index].update(value)
  }

  selectButton(index) {
    this.unSelectDigit()
    this.unSelectButton()
    this.focusedBtnIdx = index
    this.buttons[index].focus()
  }

  selectDigit(index) {
    this.unSelectButton()
    this.unSelectDigit()
    this.focusedDigitIdx = index
    this.digits[index].focus()
  }

  unSelectButton() {
    if (Number.isInteger(this.focusedBtnIdx)) {
      this.buttons[this.focusedBtnIdx].blur()
    }
  }

  unSelectDigit() {
    if (Number.isInteger(this.focusedDigitIdx)) {
      this.digits[this.focusedDigitIdx].blur()
    }
  }

  showVoucherError(message) {
    this.setProp("errorMessage", message)
    pullState(this.errorWrapper, "hidden")
  }

  hideVoucherError() {
    pushState(this.errorWrapper, "hidden")
  }

  clearButtons() {
    this.buttons = []
    if (this.buttonWrapper) {
      while (this.buttonWrapper.firstChild) {
        this.buttonWrapper.removeChild(this.buttonWrapper.firstChild)
      }
      pullState(this.buttonWrapper, "hidden")
    }
  }

  clearDigits() {
    this.digits = []
    if (this.digitWrapper) {
      while (this.digitWrapper.firstChild) {
        this.digitWrapper.removeChild(this.digitWrapper.firstChild)
      }
    }
  }

  _flush() {
    this.clearButtons()
    this.clearDigits()
  }
}
