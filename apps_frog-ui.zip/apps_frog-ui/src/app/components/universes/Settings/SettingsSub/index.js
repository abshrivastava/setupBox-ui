//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {on} from "services/events"

import bus from "services/bus"
import ActionsList from "./ActionList"

import "./index.css"

class Item extends Component {
  render() {
    return (
      <div className="SettingsSub-data">
        <span className="SettingsSub-label" prop="label" />&nbsp;
        <span className={"SettingsSub-value " + (this.props.value.startsWith("www.")  ? "inLowerCase" : "")}
        prop="value" />
      </div>
    )
  }
}

export default class SettingsSub extends Component {
  constructor(props) {
    super(props)
    this.subItems = []
    this.myAccountTimer = null
  }

  render() {
    return (
      <div className="SettingsSub SettingsSub--hidden">
        <div className="SettingsSub-inner">
          <div className="SettingsSub-main">
            <div className="SettingsSub-context" key="context" prop="title"/>
            <div className="SettingsSub-details">
              <div className="SettingsSub-item">
                <div className="SettingsSub-itemLabel">
                  <span key="itemLabel" prop="label"/>
                </div>
                <div className="SettingsSub-items" key ="SubItems" />
              </div>
            </div>
          </div>
          <ActionsList key="optionList"/>
        </div>
      </div>
    )
  }

  @on("settings:resetmyaccounttimer")
  resetmyAccountTimer() {
    if (this.myAccountTimer) {
      clearTimeout(this.myAccountTimer)
    }
  }

  onLoad(sub) {
    this.setProp("title", sub.title)
    this.setProp("label", sub.label)
    for (const item of this.subItems) {
      item.destroy()
    }
    this.subItems = []

    let data = {}
    if (!sub.filter) {
      data = sub.data
    } else {
      for (const key of sub.filter) {
        data[key] = sub.data[key] || ""
      }
    }
    let i = 0
    for (const [label, value] of Object.entries(data)) {
      const subItem = new Item({label: label, value: value})
      this.SubItems.appendChild(subItem.build())
      this.subItems[i] = subItem
      i++
    }
    if (sub.option === "Account") {
      this.myAccountTimer = setTimeout(()=>{
        bus.emit("settings:openmyaccount")
      }, 10000)
    }
  }

  loadItems(itemList) {
    this.optionList.setActions(itemList)
  }
}
