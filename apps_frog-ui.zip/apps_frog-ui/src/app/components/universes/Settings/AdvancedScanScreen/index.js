//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pullState, pushState} from "utils/dom"
// import ActionsList from "./ActionList"
import {_} from "utils/locale"

import {IFTOIF, Satellite, LNB} from "./OptionsList"
import "./index.css"

export default class AdvancedScanScreen extends Component {
  constructor() {
    const props = {title: _("Advanced Setting Screen"), footer: _("Press OK to launch EASY SCAN")}
    super(props)
  }

  render() {
    return (
      <div className="AdvancedScanScreen AdvancedScanScreen--hidden">
        <div className="AdvancedScanScreen-inner" key="inner">
          <IFTOIF ref="if2if"/>
          <Satellite ref="satellite"/>
          <LNB ref="lnbSettings"/>
        </div>
        <span className="AdvancedScanScreen-title" prop="title" key="title"/>
        <span className="AdvancedScanScreen-footer" prop="footer" key="footer"/>
      </div>
    )
  }

  show() {
    pullState(this.inner, "onBackground")
    pullState(this.title, "onBackground")
    pullState(this.footer, "onBackground")
    const properties = {title: _("Advanced Setting Screen"), footer: _("Press OK to launch EASY SCAN")}
    this.setProp("title", properties.title)
    this.setProp("footer", properties.footer)
    super.show()
  }

  onBackground() {
    pushState(this.inner, "onBackground")
    pushState(this.title, "onBackground")
    pushState(this.footer, "onBackground")
  }

  loadItems() {
  //  this.actionList.setActions(itemList)
  }
}
