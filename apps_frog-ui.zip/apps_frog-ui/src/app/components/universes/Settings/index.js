//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"

import SettingsMenu from "./SettingsMenu"
import SettingsSub from "./SettingsSub"
import ScanScreen from "./ScanScreen"
import AdvancedScanScreen from "./AdvancedScanScreen"
import ScanProgress from "./ScanProgress"
import ChannelsBlock from "./ChannelBlock"
import StbInfoSheet from "./STBInfoSheet/"
import TransponderInfo from "./STBInfoSheet/TransponderInfo"
import CasInfoSheet from "./STBInfoSheet/CasInfoSheet"
import TransponderList from "./TransponderList/"
// import ScaleScreen from "./ScaleScreen/" //Commented Screen adjustment code
import FavoriteScreen from "./FavoriteScreen"
import Cam from "./Cam"
import License from "./Tools"

//  <ScaleScreen ref= "scaleScreen"/>// Commented Screen adjustment code, add ScaleScreen tag after TransponderList

export default class SettingsUniverse extends Component {
  render() {
    return (
      <div className="Settings-universe">
        <SettingsMenu ref="settingsMenu"/>
        <SettingsSub ref="settingsSub"/>
        <ScanScreen ref="scanScreen"/>
        <AdvancedScanScreen ref="advancedScan"/>
        <ScanProgress ref="scanProgress"/>
        <FavoriteScreen ref="favoriteScreen"/>
        <ChannelsBlock ref="channelsBlock"/>
        <StbInfoSheet ref="stbInfoSheet"/>
        <TransponderInfo ref= "transponderInfo"/>
        <TransponderList ref= "transponderList"/>
        <CasInfoSheet ref= "CasInfoSheet"/>
        <Cam ref="cam"/>
        <License ref="license"/>
      </div>
    )
  }
}
