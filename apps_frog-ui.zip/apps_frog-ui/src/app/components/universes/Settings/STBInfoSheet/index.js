//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import {_} from "utils/locale"
import FtaBlockManager from "services/managers/FtaBlockManager"
import {pushState, pullState} from "utils/dom"
import SubscriptionList from "./SubscriptionList"
import "./index.css"

class Item extends Component {
  render() {
    return (
      <div className="STBInfoSheet-data">
        <span className="STBInfoSheet-label" prop="label" />&nbsp;
        <span className="STBInfoSheet-value" prop="value" />
      </div>
    )
  }
}

export default class STBInfoSheet extends Component {
  constructor(props) {
    super(props)
    this.subItems = []
  }
  render() {
    return (
      <div className="STBInfoSheet STBInfoSheet--hidden  STBInfoSheet--BtnHide">
          <div className="STBInfoSheet-inner"  key="STBparent">
            <div className="STBInfoSheet-main">
              <div className="STBInfoSheet-context" prop="title"/>
              <div className="STBInfoSheet-details">
                <div className="STBInfoSheet-item">
                  <div className="STBInfoSheet-items" key ="SubItems" />
                  {
                    !config.PVR_DISABLED ?
                    <div className="STBInfoSheet-items STBInfoSheet-hardDisk">
                      <div className="STBInfoSheet-data">
                        <span className="STBInfoSheet-label" prop="HddLabel" />
                        <span className="STBInfoSheet-value" prop="HddSize" />
                      </div>
                      <div className="STBInfoSheet-data">
                        <span className="STBInfoSheet-label" prop="freeSizeLabel" />&nbsp;
                        <span className="STBInfoSheet-value" prop="freeSize" />
                      </div>
                    </div>
                    : ""
                  }
                </div>
              </div>
              <div className="StbBtnList">
                <div className="StbBtnItem" key = "tranponderNameBtn">
                  <span className="StbBtnItem-name"  prop="tranponderName" key = "tranponderName" />
                </div>
                <div className="StbBtnItem" key = "casNameBtn">
                  <span className="StbBtnItem-name"  prop="casName" key = "casName" />
                </div>
              </div>
              <div className="Button-section">
                <div className="button blue" prop="TPlist" />
                <div className="button yellow" prop="Exit" />
              </div>
           </div>
           <SubscriptionList key="SubscriptionList"/>
           <div className="STBInfoSheet-horizontal" key="horizontalArrow"/>
           <div className="STBInfoSheet-exitLabel" prop= "ExitLabel"/>
        </div>
      </div>
    )
  }

  onLoad(sub) {
    this.setProp("title", sub.title)
    this.setProp("TransponderInfo", sub.label)
    this.setProp("tranponderName",  _("Transponder Information"))
    this.setProp("casName", _("CA Information"))
    this.setProp("HddLabel", _("HDD size: "))
    this.setProp("HddSize",sub.hddSize)
    this.setProp("freeSizeLabel", _("Free size: "))
    this.setProp("freeSize",sub.freeSize)
    this.setProp("TPlist", _("TP list screen"))
    this.setProp("Exit", _("Exit"))
    pushState(this.tranponderNameBtn,"selected")

    for (const item of this.subItems) {
      item.destroy()
    }
    this.subItems = []

    let data = {}
    if (!sub.filter) {
      data = sub.data
    } else {
      for (const key of sub.filter) {
        data[key] = sub.data[key] || ""
      }
    }
    let i = 0
    for (const [label, value] of Object.entries(data)) {
      const subItem = new Item({label: _(label), value: value})
      this.SubItems.appendChild(subItem.build())
      this.subItems[i] = subItem
      i++
    }
  }

  loadSubscriptions() {
    this.SubscriptionList.showSubscriptions()
  }

  CasBtnHide() {
    pushState(this.casNameBtn,"hide")
  }

  CasBtnShow() {
    pullState(this.casNameBtn,"hide")
  }

  showLeftArrow() {
    pushState(this.horizontalArrow, "showLeft")
  }

  showRightArrow() {
    pullState(this.horizontalArrow, "showLeft")
  }

  showHorizontalArrow() {
    pushState(this.horizontalArrow, "showArrow")
  }

  onMoveUp() {
    console.log("moveup")
    pullState(this.casNameBtn,"selected")
    pushState(this.tranponderNameBtn,"selected")
  }
  onMoveDown() {
    pullState(this.tranponderNameBtn,"selected")
    pushState(this.casNameBtn,"selected")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  onBtnShow() {
    this.pullState("BtnHide")
  }

  onBtnClose() {
    this.pushState("BtnHide")
  }

  updateHddDetails(hdd) {
    this.setProp("HddSize",hdd.hddSize)
    this.setProp("freeSize",hdd.freeSize)

  }

  updateTitleForFta() {
    if (!FtaBlockManager.isNavigationRestricted()) {
      this.setProp("ExitLabel", _("Press Menu to Exit"))
    } else {
      this.setProp("ExitLabel", "")
    }
  }

}
