//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "utils/config"
import Component from "widgets/Component"
import * as domUtils from "utils/dom"
import {HybridListComponent} from "app/utils/widgets/lists"
import "./index.css"

class CamSelector extends Component {
  render() {
    return (<div className = "CamSelector" key = "CamSelector"/>)
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {
    domUtils.pushState(this.arrow, "hidden")
  }

  showArrow() {
    domUtils.pullState(this.arrow, "hidden")
  }
}

class CamItem extends Component {
  render() {
    return (
      <div className = "CamItem"
      prop = "label" / >
    )
  }
}

export class CamList extends HybridListComponent {
  constructor() {
    super(CamSelector, CamItem)
    this.ITEM_HEIGHT = 45
    this.WINDOW_SIZE = 9
    this.EXTRA_VISIBLE_ITEMS = 1
    if (config.SD_ZAPPER) this.ITEM_HEIGHT = 36
  }


  render() {
    return (<div className = "CamList" />)
  }
}


export default class CamMenu extends Component {
  constructor() {
    const props = {CamHeading: "CAM Menu",CamsSubHeading:"Cam",CamFooter:"Press Back to Exit"}
    super(props)
  }

  render() {
    return (
      <div className="CamMenu CamMenu--hidden">
        <div className="CamMenu-inner">
          <div className = "CamMenu-container" >
          <div className = "CamMenu-heading" prop="CamHeading" />
          <div className="CamsMenu-Footer" prop="CamFooter"/>
          <CamList key="CamList"/>
          </div>
        </div>
      </div>
    )
  }

  loadItems(itemList) {
    this.optionList.setActions(itemList)
  }

  show() {
    this.pullState("onBackground")
    this.pullState("hidden")
    this.unfold()
  }

  hide() {
    this.fold()
    this.pushState("hidden")
  }

  onBackground() {
    this.pushState("onBackground")
  }

  onForeground() {
    this.pullState("onBackground")
  }

  fold() {
    return this.pullState("unfold", true)
  }

  unfold() {
    return this.pushState("unfold", true)
  }

}
