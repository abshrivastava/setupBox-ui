//
// Copyright (C) 2015 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import "./index.css"

export default class Ad extends Component {

  render() {
    return (
      <iframe className="AdFrame AdFrame--hidden"
        src=""
        key="iframe" />
    )
  }

  fold() {
    this.iframe.src = "about:blank"
    return this.hide()
  }

  unfold(url) {
    return new Promise((resolve, reject) => {
      this.iframe.onload = () => {
        this.show()
        resolve()
      }

      setTimeout(reject, 5000)

      this.iframe.src = url
    })
  }

  sendKeystroke(keystroke) {
    this.iframe.contentWindow.postMessage(keystroke, "*")
  }
}

