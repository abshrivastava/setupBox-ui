//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import classNames from "classnames"
import Component from "widgets/Component"
import {default as operatorLogo} from "assets/operator-logo.png"
import config from "utils/config"
import "./index.css"

const DEFAULT_POSITION = "topRight"
const IS_VERTICAL = config.HOME_ORIENTATION === "vertical"

export default class OperatorLogo extends Component {
  constructor() {
    super()
    this.homePosition = IS_VERTICAL ? "bottomLeft" : DEFAULT_POSITION
  }

  render() {
    const logoStyles = classNames(
      "OperatorLogo",
      this.homePosition,
    )

    return (
      <div className={logoStyles}>
        <img src={operatorLogo} class="OperatorLogoImg"  />
      </div>
    )
  }

  fold() {
    return this.pullState("unfold")
  }

  unfold(context) {
    let changePosition
    if (context === "homeMenu") {
      changePosition = this.pullState(DEFAULT_POSITION)
        .then(() => this.pushState(this.homePosition))
    } else {
      changePosition = this.pullState(this.homePosition)
        .then(() => this.pushState(DEFAULT_POSITION))
    }

    return changePosition
        .then(() => this.pushState("unfold"))
  }

}
