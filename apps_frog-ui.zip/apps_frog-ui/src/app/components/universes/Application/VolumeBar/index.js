//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//
import {tween, detectFlow} from "popmotion"
import Component from "widgets/Component"
import "./index.css"

const VOLUME_HEIGHT = 416

export default class VolumeBar extends Component {

  constructor() {
    super()
    this.currentVolume = 0
    this.firstProgress = true
    this.showVolumebarTween = tween({duration: 200})
    this.isMute = false
  }

  render() {
    return (
      <div class="VolumeBar" >
        <div class="Progress-wrapper">
          <div class="Progress" key="progress"/>
        </div>
        <div class="SoundIcon SoundIcon--unmute" key="soundIcon"/>
      </div>
    )
  }

  onOpen() {
    // this.showVolumebarTween.set({values: {x: -70}}).on(this.dom).start()
    return this.pushState("open")
  }

  onClose() {
    // this.showVolumebarTween.set({values: {x: 0}}).on(this.dom).start()
    return this.pullState("open")
  }

  onUnmute() {
    this.isMute = false
    this.soundIcon.className = "SoundIcon SoundIcon--unmute"
  }

  onMute() {
    this.isMute = true
    this.soundIcon.className = "SoundIcon SoundIcon--mute"
  }

  detectFlow() {
    return detectFlow(this.dom.querySelector(".Progress"))
  }

  onProgress(percentage) {

    if (this.detectFlow().isActive) {
      this.detectFlow().stop()
    }

    const transition = tween()

    if (this.firstProgress) {
      transition.set({duration: 0})
      this.firstProgress = false
    } else {
      transition.set({duration: 600})
    }

    this.currentVolume = percentage
    const newHeight = VOLUME_HEIGHT * percentage / 100
    transition.set({values: {height: newHeight}}).on(this.progress).start()
    // this.progress.css.height = newHeight
  }
}
