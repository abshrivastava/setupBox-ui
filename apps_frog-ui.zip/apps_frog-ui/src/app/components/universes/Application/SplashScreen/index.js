//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {waitReflow} from "utils/dom"

import {default as splashLogo} from "assets/loaders/splash.png"
import "./index.css"
import "app/components/universes/Home/index.css"

export default class SplashScreen extends Component {
  constructor(props) {
    super(props)
    this.timer = null
  }
  render() {
    return (
      <div className="SplashScreen">
        <div className="HomeList">
          <div className="HomeItem--selected">
            <div className="HomeItem-icon--tv" />
            <div className="HomeItem-icon--rec" />
            <div className="HomeItem-icon--epg" />
            <div className="HomeItem-icon--vod" />
            <div className="HomeItem-icon--apps" />
            <div className="HomeItem-icon--sets" />
            <div className="HomeItem-icon--radio" />
            <div className="HomeItem-icon--mplay" />
          </div>
        </div>
        <img src={splashLogo} className="SplashScreen-logo" />
        <div
          className="SplashScreen-bubble SplashScreen-bubble--first"
          collection="bubbles" />
        <div
          className="SplashScreen-bubble SplashScreen-bubble--second"
          collection="bubbles" />
        <div
          className="SplashScreen-bubble SplashScreen-bubble--last"
          collection="bubbles" />
      </div>
    )
  }

  enter() {
    this.show()
    waitReflow(this.dom)
    this.startPop()
  }

  startPop() {
    this.pushState("pop")
    this.timer = setTimeout(() => this.stopPop(), 600)
  }

  stopPop() {
    this.pullState("pop")
    this.timer = setTimeout(() => this.startPop(), 600)
  }

  exit() {
    this.pushState("hiding")
      .then(() => {
        clearTimeout(this.timer)
        this.hide()
        this.destroy()
      })
  }
}
