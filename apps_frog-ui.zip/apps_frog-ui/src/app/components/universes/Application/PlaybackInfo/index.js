//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import PlayerManager from "services/managers/PlayerManager"
import bus from "services/bus"
import Component from "widgets/Component"
import * as date from "utils/date"
import config from "utils/config"
import {testImage} from "utils/image"
import {createTicker, channelLogo as logoName} from "utils"
import "./index.css"

import defaultLogoUrl from "assets/fallbacks/channel-logo.png"

export default class PlaybackInfo extends Component {
  constructor(props) {
    super(Object.assign({}, {
      title: "",
      category: "",
      position: "",
      remaining: "",
      channel: "",
      date: "",
      duration: "",
    }, props))
    this.refreshTicker = createTicker(1000)
  }

  render() {
    return (
      <div className="PlaybackInfo">
        <div className="PlaybackInfo-program" key="program">
          <div className="PlaybackInfo-epgTitle" prop="title" />
          <div className="PlaybackInfo-epgGenre" prop="category" />
          <div className="PlaybackInfo-timeInfo" key="timeInfo">
            <div className="PlaybackInfo-position" prop="position" />
            <div className="PlaybackInfo-progressBar">
              <div className="PlaybackInfo-progress" key="progress" />
            </div>
            <div className="PlaybackInfo-remaining">
              -<span prop="remaining" />
            </div>
          </div>
        </div>
        <div className="PlaybackInfo-channel">
          <div className="PlaybackInfo-channelTitle" prop="channel" />
          <div className="PlaybackInfo-date" prop="date" />
          <div className="PlaybackInfo-duration" prop="duration" />
        </div>
        <img
          key="channelLogo"
          className="PlaybackInfo-channelLogo"
          src={defaultLogoUrl} />
      </div>
    )
  }

  update(item) {
    switch (item.constructor.name) {
    case "VideoFile":
      this.updateViewFromVideoFile(item)
      break
    case "Record":
      this.updateViewFromRecord(item)
      break
    default:
      this.updateViewFromItem(item)
      break
    }
  }

  updateViewFromVideoFile(video) {
    this.setProp("title", video.title)
    this.setProp("category", "")
    this.setProp("channel", "")
    this.setProp("date", "")
    this.setProp("duration", "")
    this.channelLogo.style.display = "none"
    this._updateProgressRemaining()
  }

  updateViewFromRecord(pvr) {
    let duration
    try {
      duration = date.formatDuration(pvr.duration)
    } catch (err) {
      duration = "Unknown duration"
    }
    this.setProp("title", pvr.title)
    this.setProp("category", pvr.category)
    this.setProp("channel", pvr.channelTitle)
    this.setProp("date", date.formatDate(pvr.startDate))
    this.setProp("duration", duration)
    this.channelLogo.style.display = "block"
    const channelLogo =
    `http://${config.STB_IP}${config.LOGO_BASE}${logoName(pvr.channelTitle)}.png`
    testImage(this.channelLogo, channelLogo, defaultLogoUrl)
    this._updateProgressRemaining()
  }

  updateViewFromItem(item) {
    let duration
    try {
      duration = date.formatDuration(item.duration)
    } catch (err) {
      duration = "Unknown duration"
    }
    this.setProp("title", item.title)
    this.setProp("category", "")
    this.setProp("channel", "")
    this.setProp("date", "")
    this.setProp("duration", duration)
    this.channelLogo.style.display = "none"
    this._updateProgressRemaining()
  }

  open() {
    return this.unfold()
  }

  fold() {
    return this.pullState("unfold", true)
      .then(() => {
        this.refreshTicker.stop()
      })
  }

  delayedFold() {
    clearTimeout(this.foldDelayed)
    this.foldDelayed = setTimeout(() => {
      if (bus.universe !== "epg") {
        this.fold()
        bus.emit("clock:close","pvr")
      }
    }, 3000)
  }

  unfold() {
    if (this.foldDelayed) {
      clearTimeout(this.foldDelayed)
    }
    return this.pushState("unfold", true)
      .then(() => {
        const update = () => this._updateProgressRemaining()
        return this.refreshTicker.start(update)
      })
  }

  _updateProgressRemaining() {
    PlayerManager.getAbsolutePosition()
      .then((ppos) => {
        const duration = ppos.size
        const position = ppos.position
        let formattedPosition
        try {
          formattedPosition = date.formatDuration(position)
        } catch (err) {
          formattedPosition = 0
        }
        let remaining
        try {
          remaining = date.formatDuration(duration - position)
        } catch (err) {
          remaining = 0
        }
        this.setProp("position", formattedPosition)
        this.setProp("remaining", remaining)
        this.progress.style.width = ~~(position / duration * 100) + "%"
      })
  }
}
