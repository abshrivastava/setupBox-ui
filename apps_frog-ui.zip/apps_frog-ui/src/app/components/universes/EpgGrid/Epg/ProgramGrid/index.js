//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {isDefined, pick} from "utils"
import {pushState, pullState} from "utils/dom"
import "./index.css"

import recPicto from "assets/pictos/record-small.png"
import schedulePicto from "assets/pictos/schedule.png"
import reminderPicto from "assets/pictos/reminder.png"
import scheduleSmallPicto from "assets/pictos/schedule_small.png"
import * as epgUtils from "app/utils/epg"

const PICTO = {
  schedule: schedulePicto,
  rec: recPicto,
  reminder: reminderPicto,
}

const LIST_SIZE = 5

class Cell extends Component {
  constructor(props) {
    const {program} = pick(props, "program")
    const defaultProps = {
      title: program.title || "",
      category: program.category || "",
    }
    super(Object.assign({}, defaultProps, props))
    this.program = program
    this.itemId = program.id
  }

  render() {
    return (
      <div className="ProgramItem">
        <div className="ProgramItem-title" prop="title" />
        <div className="ProgramItem-genre" prop="category" />
        <img className="ProgramItem-scheduleIndicator"
             src={schedulePicto}
             key="scheduleIndicator" />
      </div>
    )
  }

  onStyle() {
    this.setWidth(this.program.view.width)
    this.setPosition(this.program.view.x)
    if (this.program.view.ongoing) {
      this.pushState("ongoing")
    }
    if (this.program.isScheduled) {

      this.showScheduleIndicator("schedule")
    }
    if (this.program.isReminder) {

      this.showReminderIndicator("reminder")
    }
    if (this.program.isRecording) {
      this.showScheduleIndicator("rec")
    }
    if (this.program.view.ongoing) {
      this.hideReminderIndicator()
    }
    if (this.program.title === "No Information") {
      this.hideReminderIndicator()
    }
  }

  update(item) {
    this.itemId = item.id
    this.setProp("title", item.title)
    this.setProp("genre", item.category)
  }

  markAsRecording(program) {
    if (program.id === this.itemId) {
      return this.showScheduleIndicator("rec")
    }
  }

  markAsScheduled(program) {
    if (program.id === this.itemId) {
      if (program.isReminder) {
        return this.showReminderIndicator("reminder")
      }
      if (program.isScheduled) {
        return this.showScheduleIndicator("schedule")
      }
      if (program.isRecording || this.ongoing) {
        return this.showScheduleIndicator("rec")
      }
      if (program.isOngoing) {
        return this.showScheduleIndicator("rec")
      }
    }
  }

  unmarkScheduled(program) {
    if (program.id === this.itemId) {
      return this.hideScheduleIndicator()
    }
  }

  setWidth(width) {
    this.width = (width === -1) ? "100%" : width
    this.dom.style.width = this.width
  }

  setPosition(x) {
    this.x = x
    this.dom.style.left = x
  }

  focus() {
    return this.pushState("selected")
  }

  blur() {
    return this.pullState("selected")
  }

  showScheduleIndicator(type) {
    this.scheduleIndicator.src=PICTO[type]
    return Promise.all([
      pushState(this.scheduleIndicator, "visible", false),
      pullState(this.scheduleIndicator, "top", false),
    ])
  }

  hideScheduleIndicator() {
    return pullState(this.scheduleIndicator, "visible", false)
  }


  showReminderIndicator(type) {
    this.scheduleIndicator.src=PICTO[type]
    return Promise.all([
      pushState(this.scheduleIndicator, "top", false),
      pushState(this.scheduleIndicator, "visible", false),
    ])
  }

  hideReminderIndicator() {
    return Promise.all([
      pullState(this.scheduleIndicator, "visible", false),
      pullState(this.scheduleIndicator, "top", false),
    ]).then(() => {
      if (this.program.title === "No Information") {
        return Promise.resolve()
      }
      if (this.program.isRecording) {
        return this.showScheduleIndicator("rec")
      }
    })
  }
}

class RecordIndicator extends Component {
  constructor(props) {
    const {record} = pick(props, "record")
    const {startDate} = pick(props, "startDate")
    const defaultProps = {
      title: "Rec",
    }
    super(Object.assign({}, defaultProps, props))
    this.record = record
    this.recordStartDate = record.startDate
    this.timelineStart = startDate
  }

  render() {
    return (
      <div className="RecordIndicator">
        <span className="RecordIndicatorTitle" prop="title" />
        <img className="RecordIndicator-scheduleIndicator"
             src={scheduleSmallPicto}
             key="scheduleIndicator" />
      </div>
    )
  }

  onStyle() {
    this.getDeltaFromTimelineStart()
    this.setXPos()
    this.setWith()
    this.setRecordingState()
  }

  getDeltaFromTimelineStart() {
    this.delta = Math.max(Math.round((this.record.startDate.getTime() - this.timelineStart.getTime()) / 1000), 0)
  }

  getRecordDurationToDisplay() {
    return (this.delta > 0) ?
      this.record.duration : Math.round((this.record.endDate.getTime() - this.timelineStart.getTime()) / (1000))
  }

  setXPos() {
    return this.dom.style.left = epgUtils.minuteToPixel(this.delta) + "px"
  }

  setWith() {
    return this.dom.style.width = epgUtils.minuteToPixel(this.getRecordDurationToDisplay()) + "px"
  }

  setRecordingState() {
    const currentDate = new Date()
    if (currentDate <= this.record.startDate || currentDate >= this.record.endDate) {
      return this.pushState("ongoing")
    }
  }
}

class Row extends Component {

  constructor(props) {
    super(props)
    this.cells = []
    this.recordIndicators = []
    this.focusedIdx = 0
  }

  render() {
    return (
      <div className="Row" />
    )
  }

  flush() {
    return new Promise((resolve) => {
      this.cells = []
      this.recordIndicators = []
      this.focusedIdx = 0
      while (this.dom.firstChild) {
        this.dom.removeChild(this.dom.firstChild)
      }
      resolve()
    })
  }

  /* ************************************************************************ */

  /* ********* Cells build and state management ********* */
  buildCellsFromPrograms(programs) {
    programs.forEach((program) => {
      const cell = new Cell({
        program: program,
      })
      this.addCell(cell)
    })
  }

  addCell(cell) {
    this.dom.appendChild(cell.build())
    cell.onStyle()
    this.cells.push(cell)
  }

  selectCell(index) {
    const futureItem = this.cells[index]
    if (futureItem) {
      this.unSelectCell()
      this.focusedIdx = index
      futureItem.focus()
    }
  }

  unSelectCell() {
    const item = this.cells[this.focusedIdx]
    if (item) {
      item.blur()
    }
  }

  /* ************************************************************************ */

  /* ********* Manual record indicator build ********* */
  buildManualRecordIndicators(manualRecords, startDate) {
    manualRecords.forEach((record) => {
      const recordIndicator = new RecordIndicator({
        record: record,
        startDate: startDate,
      })
      this.addManualRecordIndicator(recordIndicator)
    })
  }

  addManualRecordIndicator(recordIndicator) {
    this.dom.appendChild(recordIndicator.build())
    recordIndicator.onStyle()
    this.recordIndicators.push(recordIndicator)
  }

  removeManualRec(startDate) {
    let idxToRemove = -1
    for (let i=0; i<this.recordIndicators.length; i++) {
      if (this.recordIndicators[i].recordStartDate.getTime() === startDate.getTime()) {
        idxToRemove = i
        break
      }
    }

    if (idxToRemove !== -1) {
      this.recordIndicators[idxToRemove].destroy()
      this.recordIndicators.splice(idxToRemove, 1)
    }
  }
}

export default class ProgramGrid extends Component {

  render() {
    return (
      <div className="ProgramGrid ProgramGrid--hidden">
        {Array.from({length: LIST_SIZE}, () =>
          <Row collection="children" />)}
      </div>
    )
  }

  flush() {
    return new Promise((resolve) => {
      this.children.forEach((child) => {
        child.flush()
      })
      resolve()
    })
  }

  load(programs, manualRecords, timeLine) {
    return this.flush()
      .then(() => {
        return Object.keys(programs).forEach((key, i) => {
          // TODO HACK
          if (programs[key][0]) {
            const serviceId = programs[key][0].serviceId
            this.buildRow(this.children[i], programs[key], manualRecords[serviceId], timeLine.start)
          }
        })
      })
  }

  buildRow(row, programs, manualRecords, startDate) {
    row.buildCellsFromPrograms(programs, startDate)
    if (manualRecords) {
      row.buildManualRecordIndicators(manualRecords, startDate)
    }
  }

  selectProgram(rowIndex, programIndex) {
    this.unSelectPreviousProgram()
    this.selectedRowIndex = rowIndex
    this.selectedProgIndex = programIndex
    this.children[rowIndex].selectCell(programIndex)
  }

  unSelectPreviousProgram() {
    const previouslySelectedRow = this.children[this.selectedRowIndex]
    if (isDefined(this.selectedRowIndex) && isDefined(previouslySelectedRow)) {
      previouslySelectedRow.unSelectCell()
    }
  }

  open() {
    return this.pullState("hidden")
  }

  close() {
    return Promise.all([
      this.flush(),
      this.pushState("hidden"),
    ])
  }

  markAsRecording(x, y, program) {
    this.children[y].cells[x] && this.children[y].cells[x].markAsRecording(program)
  }

  markAsScheduled(x, y, program) {
    this.children[y].cells[x] && this.children[y].cells[x].markAsScheduled(program)
  }

  unmarkScheduled(x, y, program) {
    this.children[y].cells[x] && this.children[y].cells[x].unmarkScheduled(program)
  }

  unmarkManualRecord(y, startDate) {
    this.children[y] && this.children[y].removeManualRec(startDate)
  }
}
