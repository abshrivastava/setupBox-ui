//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {default as blueIcon} from "assets/pictos/vod-bubble.png"

import ItemList from "./ItemList"
import ProgramInfos from "./ProgramInfos"
import TimeLine from "./TimeLine"
import ProgramGrid from "./ProgramGrid"
import "./index.css"

export default class Epg extends Component {

  render() {
    return (
      <div className="EpgGrid EpgGrid--hidden">
        <ProgramInfos key="programInfos" />
        <TimeLine key="timeLine" />
        <ItemList key="itemList" />
        <ProgramGrid key="programGrid" />
        <div className="GenreInfo" prop="genremain" />
          <img className="genre-icon" src={blueIcon} />
          <span className="genre-regional" prop="genreregional" />
          &nbsp;<span className="genre-title" prop="genrename" />
      </div>
    )
  }
  open() {
    return Promise.all([
      this.itemList.open(),
      this.programInfos.open(),
      this.timeLine.open(),
    ]).then(() => {
      return this.programGrid.open()
    }).then(() => {
      return this.pullState("hidden")
    })
  }

  close() {
    return this.pushState("hidden").then(() => {
      return Promise.all([
        this.programGrid.close(),
        this.itemList.close(),
        this.programInfos.close(),
        this.timeLine.close(),
      ])
    })
  }
  // open() {
  //   return this.show()
  //   // return new Promise((resolve) => {
  //   //   this.itemList.open()
  //   //   this.programGrid.open()
  //   //   this.programInfos.open()
  //   //   this.timeLine.open()
  //   //
  //   //   this.pullState("hidden")
  //   //   resolve()
  //   // })
  // }
  //
  // close() {
  //   return this.hide()
  //   // return new Promise((resolve) => {
  //   //   this.programGrid.close()
  //   //   this.itemList.close()
  //   //   this.programInfos.close()
  //   //   this.timeLine.close()
  //   //
  //   //   this.pushState("hidden")
  //   //   resolve()
  //   // })
  // }

  update(item) {
    return this.programInfos.update(item)
  }

  setChannels(channels, currentChannelIndex) {
    return this.itemList.setChannels(channels, currentChannelIndex)
  }

  selectChannel(idx) {
    return this.itemList.selectChannel(idx)
  }

  move(direction, idx) {
    return this.itemList.move(direction, idx)
  }

  loadPrograms(programs, manualRecords, timeLine) {
    return this.programGrid.load(programs, manualRecords, timeLine)
  }

  programChanged(rowIndex, idx) {
    return this.programGrid.selectProgram(rowIndex, idx)
  }

  flush() {
    return this.programGrid.flush()
  }

  loadTimeline(data) {
    return this.timeLine.loadTimeline(data)
  }

  setClock(clock) {
    return this.programInfos.setClock(clock)
  }

  markAsRecording(x, y, program) {
    return this.programGrid.markAsRecording(x, y, program)
  }

  markAsScheduled(x, y, program) {
    return this.programGrid.markAsScheduled(x, y, program)
  }

  unmarkScheduled(x, y, program) {
    return this.programGrid.unmarkScheduled(x, y, program)
  }

  unmarkManualRecord(y, startDate) {
    return this.programGrid.unmarkManualRecord(y, startDate)
  }

  setGenre(genre) {
    if (genre.selectedFilterId === 888) {
      this.setProp("genreregional", "Regional")
      this.setProp("genrename", genre.selectedSubGenre)
    } else {
      this.setProp("genreregional", "")
      this.setProp("genrename", genre.selectedGenre)
    }
    return Promise.resolve()
  }
}
