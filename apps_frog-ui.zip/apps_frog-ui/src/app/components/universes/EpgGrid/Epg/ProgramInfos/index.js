//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import {pushState, pullState} from "utils/dom"
import DateTime from "./DateTime"
import "./index.css"

const DEFAULT_PROPS = {
  title: "",
  genre: "",
  date: "",
  description: "",
}

export default class ProgramInfos extends Component {
  constructor(props) {
    super(Object.assign({}, DEFAULT_PROPS, props))
  }

  render() {
    return (
      <div className="ProgramInfos ProgramInfos--hidden">
        <div className="ProgramInfos-header">
          <span className="ProgramInfos-title" key="programTitle" prop="title" />
          <span className="ProgramInfos-genre" key="programGenre" prop="genre" />
          <span className="ProgramInfos-date" key="programTime" prop="date" />
        </div>
        <span
          className="ProgramInfos-description"
          key="programDescription"
          prop="description" />
        <DateTime key="dateTime" />
      </div>
    )
  }

  open() {
    return this.pullState("hidden")
  }

  close() {
    return this.pushState("hidden")
  }

  update(item) {
    if (item) {

      this.setProp("title", item.title)
      this.setProp("genre", item.genre)
      this.setProp("date", item.date)
      this.setProp("description", item.description)

      if (item.genre === "") {
        pushState(this.programGenre, "hidden")
      } else {
        pullState(this.programGenre, "hidden")
      }

    } else {
      this.setProps(DEFAULT_PROPS)
    }
  }

  setClock(clock) {
    return this.dateTime.setClock(clock)
  }
}
