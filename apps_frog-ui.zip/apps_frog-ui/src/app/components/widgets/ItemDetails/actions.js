import config from "utils/config"
import Component from "widgets/Component"
import {HybridListComponent} from "app/utils/widgets/lists"

import arrowDown from "assets/arrows/down.png"
import arrowUp from "assets/arrows/up.png"

class ActionSelector extends Component {
  render() {
    return (
      <div className="ActionSelector">
        <div className="ActionSelector-bg"/>
      </div>
    )
  }

  select(y) {
    this.dom.style.webkitTransform = `translate3d(0px, ${y}px, 0)`
  }

  hideArrow() {}
  showArrow() {}
}

class ActionItem extends Component {
  render() {
    return (
      <div className="ActionItem" prop="label" />
    )
  }
}

class ActionsList extends HybridListComponent {
  constructor() {
    super(ActionSelector, ActionItem)
    this.ITEM_HEIGHT = 65
    if (config.SD_ZAPPER) this.ITEM_HEIGHT = 52
    this.WINDOW_SIZE = 5
    this.EXTRA_VISIBLE_ITEMS= 1
  }

  render() {
    return (
      <div className="ActionsList" />
    )
  }
}

export default class ActionsTree extends Component {
  constructor() {
    super()
    this.focusedIdx = 0
  }

  render() {
    return (
      <div className="ActionsTree ">
        <ActionsList key="list0"/>
        <div className="rightCol" key="rightCol">
          <ActionsList key="list1"/>
          <img src={arrowDown} className="arrow-up"/>
          <img src={arrowUp} className="arrow-down"/>
        </div>
      </div>
    )
  }

  show() {
    this.focusedIdx = 0
    this.list0.pushState("focused")
    this.list1.pullState("focused")
  }

  reset() {
    for (let i=0; i< this.dom.children.length; i++) {
      const list = this["list" + i]
      list.reset()
    }
    this.focusedIdx = 0
  }

  left(idx) {
    this["list" + this.focusedIdx].pullState("focused")
    this.focusedIdx = idx
    this["list" + this.focusedIdx].pushState("focused")
  }

  right(idx) {
    this["list" + this.focusedIdx].pullState("focused")
    this.focusedIdx = idx
    this["list" + this.focusedIdx].pushState("focused")
  }

  moveExtendedTo(idx) {
    this.rightCol.style.top = idx * this.list1.ITEM_HEIGHT + "px"
  }
}
