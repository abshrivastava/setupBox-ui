//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import classNames from "classnames"

import config from "utils/config"
import Component from "widgets/Component"
import PVR from "app/components/universes/PVR"
import Home from "app/components/universes/Home"
import EpgGrid from "app/components/universes/EpgGrid"
import Settings from "app/components/universes/Settings"
import Television from "app/components/universes/Television"
import AppWidgets from "app/components/universes/Application"
import Advertisement from "app/components/universes/Advertisement"
import Apps from "app/components/universes/Apps"
import FirstInstall from "app/components/universes/FirstInstall"

import "./index.css"

export default class Application extends Component {
  static ref = "application"

  render() {
    const appStyles = classNames(
      "Application",
      config.IS_REMOTE && "Application--remote",
      config.SD_ZAPPER && "Application--SD",
    )

    return (
      <div className={appStyles}>
        <Television ref="TelevisionUniverse"/>
        <EpgGrid ref="EpgGridUniverse"/>
        <PVR ref="PVRUniverse"/>
        <Settings ref="SettingsUniverse"/>
        <Home ref="homeMenu"/>
        <Advertisement ref="AdvertisementUniverse"/>
        <AppWidgets ref="ApplicationUniverse"/>
        <Apps ref="AppsUniverse" />
		<FirstInstall ref="FirstInstallUniverse"/>
      </div>
    )
  }

  show() {
    this.pullState("hidden")
  }

  hide() {
    this.pushState("hidden")
  }

  setAnalog(value) {
    if (value) this.pushState("analog")
    else this.pullState("analog")
  }

  setScale(value) {
    this.resetScale()
    this.scale = value
    this.pushState(`scale-${this.scale}`)
  }

  resetScale() {
    if (this.scale) {
      this.pullState(`scale-${this.scale}`)
    }
  }
}
