//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import Component from "widgets/Component"
import {isFunction, isDefined, mod, findKeyInArrayByValue} from "utils"
import bus from "services/bus"

/* ************************************************************************ */
export class ListObj {
  constructor(data, view) {
    this.selected = 0
    this.items = data
    this.view = view
    if (isDefined(this.view))
      this.view.setActions(this.items)
  }

  get currentItem() {
    return this.items[this.selected]
  }

  up() {
    this.selected = Math.max(--this.selected, 0)
    if (isDefined(this.view)) {
      return this.view.select(this.selected)
        .then((idx) => {
          this.selected = idx
          return idx
        })
    } else {
      return Promise.resolve()
    }
  }

  down() {
    this.selected = Math.min(++this.selected, this.items.length - 1)
    if (isDefined(this.view)) {
      return this.view.select(this.selected)
        .then((idx) => {
          this.selected = idx
          return idx
        })
    } else {
      return Promise.resolve()
    }
  }

  select(idx) {
    this.selected = mod(idx, this.items.length)
    if (isDefined(this.view)) {
      return this.view.select(this.selected)
        .then((idx) => {
          this.selected = idx
          return idx
        })
    } else {
      return Promise.resolve()
    }
  }

  selectItem(item) {
    let idx = this.items.indexOf(item,this.items)
    if (idx !== -1) {
      this.select(idx)
    } else {
      idx = findKeyInArrayByValue(this.items, item.serviceId)
      this.select(idx)
    }
  }

  trigger() {
    const data = this.currentItem
    if (data.wait) {
      this.view.showSpinner(this.selected)
    }
    if (isFunction(data.action)) {
      data.action()
      return Promise.resolve()
    } else if (isDefined(data.signal)) {
      bus.emit(data.signal, data)
      return Promise.resolve()
    } else {
      return Promise.reject(`ListObj: no trigger can't be called on this item: ${data}`)
    }
  }

  markAsDefault(data) {
    for (let i=0; i<data.length; i++) {
      if (data[i].default === true) {
        this.view.markAsDefault(i)
      }
    }
  }

  hideSpinner() {
    this.view.hideSpinner(this.items.indexOf(this.currentItem))
  }

  withArrows(bool) {
    this.view.withArrows(bool)
  }
}
/* ************************************************************************ */

/* ************************************************************************ */
export class TreeObj {
  constructor(view) {
    this.selected = 0
    this.lists = []
    this.view = view
  }

  up() {
    this.lists[this.selected] && this.lists[this.selected].up()
    this._fillChildren()
  }

  down() {
    this.lists[this.selected] && this.lists[this.selected].down()
    this._fillChildren()
  }

  left() {
    this.selected = Math.max(--this.selected, 0)
    this.view.left(this.selected)
    if (this.selected + 2 < this.lists.length) {
      this.setItems(this.selected + 2, [])
    }
  }

  right() {
    this.selected = Math.min(++this.selected, this.lists.length - 1)
    this.view.right(this.selected)
    this._fillChildren()
  }

  back() {
    if (this.selected > 0) {
      this.left()
      return Promise.resolve()
    } else {
      return Promise.reject(`TreeObj: back can't be called because this.selected > 0: ${this.selected}`)
    }
  }

  trigger() {
    this.lists[this.selected].trigger()
      .catch(() => {
        this.right()
      })
  }

  getSelectedIndex() {
    return this.lists[this.selected].selected
  }

  select(index) {
    this.lists[this.selected].select(index)
  }

  setItems(index, items) {
    const listView = this.view["list" + index]
    if (!isDefined(listView))
      return
    this.lists.splice(index, 1, new ListObj(items, listView))
    if (items.length === 0)
      this.lists.splice(index, 1)
  }

  getChildren() {
    let data = null
    if (this.lists && this.lists[this.selected] && this.lists[this.selected].currentItem)
      data = this.lists[this.selected].currentItem

    if (data && isFunction(data.onFocus)) {
      return data.onFocus()
    } else if (data && isDefined(data.items)) {
      return Promise.resolve(data.items)
    } else {
      return Promise.reject(`TreeObj: ${data} has no children`)
    }
  }

  reset() {
    for (const i in this.lists) {
      this.setItems(i, [])
    }
    this.selected = 0
    this.lists = []
  }

  markAsDefault(data) {
    if (isDefined(this.lists[this.lists.length - 1]))
      this.lists[this.lists.length - 1].markAsDefault(data)
  }

  hideSpinner(data) {
    if (isDefined(this.lists[this.lists.length - 1]))
      this.lists[this.lists.length - 1].hideSpinner(data)
  }

  _fillChildren() {
    return this.getChildren()
      .then((items) => {
        this.lists[this.selected].withArrows(true)
        this.setItems(this.selected + 1, items)
      })
      .catch(() => {
        this.lists[this.selected].withArrows(false)
        this.setItems(this.selected + 1, [])
      })
  }
}

/* ************************************************************************ */
export class ListComponent extends Component {
  constructor(selectorClass, itemClass) {
    super()
    this.selectorClass = selectorClass
    this.itemClass = itemClass
    this._flush()
  }

  _flush() {
    this.actions = []
    this.focusedIdx = 0
    this.default = null
    this.selector = null
    this.hybrid = false
    this.windowPos = 0
    if (this.dom) {
      while (this.dom.firstChild) {
        this.dom.removeChild(this.dom.firstChild)
      }
    }
  }

  setActions(actions) {
    this._flush()
    this.selector = new this.selectorClass()
    this.dom.appendChild(this.selector.build())

    this.wrapper = document.createElement("DIV")
    this.wrapper.classList.add("ListWrapper")
    this.dom.appendChild(this.wrapper)

    for (const action of actions) {
      const item = new this.itemClass(action)
      this.wrapper.appendChild(item.build())
      this.actions.push(item)
      if (action.default) {
        this.markAsDefault(actions.indexOf(action))
      }
    }
    this.hybrid = actions.length > this.WINDOW_SIZE
    if (this.actions.length > 0) {
      this.select(0)
    } else {
      this.selector.pushState("hidden")
    }
  }

  select() {
    console.error("Do not implement ListComponent!")
    return Promise.resolve()
  }

  _setMoreStates() {
    const listLength = this.actions.length
    if (this.windowPos > 0) {
      this.pushState("more-above")
    } else {
      this.pullState("more-above")
    }
    if (this.windowPos < listLength - this.WINDOW_SIZE) {
      this.pushState("more-under")
    } else {
      this.pullState("more-under")
    }
  }

  markAsDefault(idx) {
    if (this.default !== null) {
      this.actions[this.default].pullState("default")
    }
    this.default = idx
    this.actions[this.default].pushState("default")
  }

  showSpinner(idx) {
    this.actions[idx].showSpinner()
  }

  hideSpinner(idx) {
    this.actions[idx].hideSpinner()
  }

  withArrows(bool) {
    if (bool)
      this.selector.showArrow()
    else
      this.selector.hideArrow()
  }

  reset() {
    this._flush()
    this.pullState("focused")
    this.pullState("leaved")
  }
}


export class LimitedListComponent extends ListComponent {

  _flush() {
    this.buildedItems = []
    super._flush()
  }

  setActions(actions) {
    this._flush()
    this.selector = new this.selectorClass()
    this.dom.appendChild(this.selector.build())
    this.wrapper = document.createElement("DIV")
    this.wrapper.classList.add("ListWrapper")
    this.dom.appendChild(this.wrapper)

    for (const action of actions) {
      const item = new this.itemClass(action)
      const buildedItem = item.build()
      this.buildedItems.push(buildedItem)
      this.actions.push(item)
    }
  }
}
/* ************************************************************************ */

/* ************************************************************************ */
export class MenuListComponent extends ListComponent {
  select(idx) {
    const verticalOrientation = (!this.ORIENTATION || this.ORIENTATION !== "horizontal")
    const distance = (verticalOrientation) ? this.ITEM_HEIGHT : this.ITEM_WIDTH
    let selectorMove = 0
    selectorMove = idx * distance
    this.focusedIdx = idx
    return this.selector.select(selectorMove)
  }
}


export class HybridListComponent extends ListComponent {
  select(idx) {
    return new Promise((resolve) => {
      const self = this
      function _onSelect() {
        resolve(idx)
        self.focusedIdx = idx
        self.removeTransitionListener(_onSelect)
      }
      this.addTransitionListener(_onSelect)

      const verticalOrientation = (!this.ORIENTATION || this.ORIENTATION !== "horizontal")
      const distance = (verticalOrientation) ? this.ITEM_HEIGHT : this.ITEM_WIDTH
      if (this.hybrid) {
        this.updateWindowPos(idx)

        const listMove = -(distance * (this.windowPos))
        const translation = (verticalOrientation) ? `(0, ${listMove}px, 0)` : `(${listMove}px, 0, 0)`
        const selectorMove = (idx - this.windowPos) * distance

        this.wrapper.style.webkitTransform = "translate3d" + translation
        this._setMoreStates()
        this.focusedIdx = idx
        this.selector.select(selectorMove)
      } else {
        this.focusedIdx = idx
        this.pullState("more-above")
        this.pullState("more-under")
        this.selector.select(idx * distance)
      }
    })
  }

  updateWindowPos(idx) {
    const windowPosMax = this.actions.length - this.WINDOW_SIZE
    const delta = this.WINDOW_SIZE - this.EXTRA_VISIBLE_ITEMS - idx
    const neededChanges = Math.abs(idx - this.windowPos) >= this.WINDOW_SIZE - this.EXTRA_VISIBLE_ITEMS
    if (idx === 0) {
      return this.windowPos = 0
    }
    if (delta < 0 && this.focusedIdx < idx && neededChanges) {
      this.windowPos = Math.min(Math.abs(delta), windowPosMax)
    }
    if (delta > idx - this.windowPos && this.windowPos === idx) {
      this.windowPos = Math.abs(idx - 1)
    }
  }
}
/* ************************************************************************ */

/* ************************************************************************ */
export class FixedListComponent extends ListComponent {
  select(idx) {
    let listMove = 0
    let selectorMove = 0
    this.windowPos = idx - this.EXTRA_VISIBLE_ITEMS
    listMove = -(this.ITEM_HEIGHT * (this.windowPos))
    selectorMove = this.EXTRA_VISIBLE_ITEMS * this.ITEM_HEIGHT
    this.wrapper.style.webkitTransform = `translate3d(0px, ${listMove}px, 0)`
    this.selector.select(selectorMove)
    this._setMoreStates()
    this.focusedIdx = idx
    return Promise.resolve()
  }
}

export class FixedLimitedListComponent extends LimitedListComponent {

  translateListItems(y) {
    const nbItems = this.wrapper.childNodes.length
    for (let i = 0; i < nbItems; i++) {
      this.wrapper.childNodes[i].style.webkitTransform = `translate3d(0, ${y}px, 0)`
    }
  }


  redrawList(idx) {
    while (this.wrapper.firstChild) {
      this.wrapper.removeChild(this.wrapper.firstChild)
    }

    for (let i = -this.EXTRA_VISIBLE_ITEMS; i <= this.EXTRA_VISIBLE_ITEMS; i++) {
      if (idx+i >= 0 && idx+i < this.buildedItems.length) {
        this.wrapper.appendChild(this.buildedItems[idx+i])
      }
    }

    // Nothing above
    if (idx <= this.EXTRA_VISIBLE_ITEMS) {
      this.translateListItems(this.ITEM_HEIGHT * (this.EXTRA_VISIBLE_ITEMS - idx))
    } else if (idx <= (2*this.EXTRA_VISIBLE_ITEMS + 1)) {
      this.translateListItems(0)
    }

    this.windowPos = idx <= this.EXTRA_VISIBLE_ITEMS ? 0 :
      idx - this.EXTRA_VISIBLE_ITEMS
    this.selector.select(this.EXTRA_VISIBLE_ITEMS * this.ITEM_HEIGHT)
    this._setMoreStates()
    this.focusedIdx = idx
    return Promise.resolve()
  }

  select(idx) {
    const moveIdx = idx - this.focusedIdx

    // No movement
    if (moveIdx === 0 && this.wrapper.childNodes.length) {
      return
    }

    if (idx < 0 && idx >= this.buildedItems.length) {
      return
    }
    return this.redrawList(idx)

  }
}
/* ************************************************************************ */

export default {
  ListObj,
  TreeObj,
}
