//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "services/bus"
import {_} from "utils/locale"

// ----------------------------------------------------------------
// -------------------------- PVR Popups --------------------------
// ----------------------------------------------------------------

// Message indicating PVR is not active
export function pvrNotReady() {
  const title = _("704 – USB device Alert")
  const message = _("No USB Device connected. Connect USB Device to use Recorder features")
  return bus.emit("popup:alert", title, message, {closeOnOk: true})
}

// Message asking for activating PVR functionality
export function confirmPvrReady(buttons) {
  const title = _("PVR & TS")
  const message = _("Do you want to activate PVR feature?")
  bus.emit("popup:confirm", title, message, {buttons})
}

// Message indicating a schedule is overlapping the new one, MonoTuner strategy, so Warn the user
export function scheduleConflict(channelName, startDate) {
  const title = _("Recording Conflict")
  let message = _("This program can't be recorded because another TV recording is planned at " +
    "the same time on {channelName} starting at {startDate}.")
  message = message.replace("{channelName}", channelName)
  message = message.replace("{startDate}", startDate)
  bus.emit("popup:alert", title, message, {closeOnOk: true})
}

// Message indicating a schedule is overlapping the new one, MonoTuner strategy, so Warn the user
export function scheduleFailed(schedule) {
  const title = _("Recording failed")
  let message = _("The program {scheduleTitle} can't be recorded because no compliant USB device connected.")
  message = message.replace("{scheduleTitle}", schedule._title)
  bus.emit("popup:alert", title, message, {closeOnOk: true})
}

/** as per newPRD Message indicating a record is ongoing and zap impossible, MonoTuner strategy, so Warn the user
•	<OK> Zap & cancel the record
•	<BACK> Keep the record
•	If no choice is made by the EndUser, the record will have the priority
**/
export function zapConflict(buttons, closeCallback) {
  const title = _("803 – Recording Alert")
  const message = _("Recording in progress. If you continue you will lose your record.")
  const timeout = -1
  bus.emit("popup:confirm", title, message, {buttons, timeout, closeCallback})
}
// Message indicating a record is going to start
export function tunerConflict(programName,channelName, buttons, closeCallback) {
  // const title = _("Recording Conflict")
  // let message =  _("A TV recording is going to start on {channelName}. " +
  //   "You will automatically zap in 10sec to launch the TV recording. Or select CANCEL to stay on current service.")
  // message = message.replace("{channelName}", channelName)
  // const timeout = 10000
  const title = _("806 – Recording Alert")
  let message =  _("{programName} - ({channelName}) has been started and is scheduled for recording.")
  message = message.replace("{channelName}", channelName)
  message = message.replace("{programName}", programName)
  const timeout = 10000
  bus.emit("popup:confirm", title, message, {timeout, buttons, closeCallback})
}

// Message indicating a record is going & it's impossible to reach RADIO universe
export function onGoingRecordConflict(closeCallback) {
  const title = _("Recording Conflict")
  const message =  _("There is a TV recording in progress. You cannot access to radio universe")
  bus.emit("popup:alert", title, message, {closeCallback,closeOnOk: true})
}

// Message indicating a record is going & user tries to access any screen that can interrupt the record
export function RecordingConflict(buttons) {
  const title = _("803 – Recording Alert")
  const message =  _("Recording in progress")
  bus.emit("popup:alert", title, message, {buttons})
}

export function RecordingConflictAppStore(buttons, closeCallback) {
  const title = _("803 – Recording Alert")
  const message = _("Recording in progress. \n" +
        "Press OK to stop record and continue. \n " +
        "Press BACK to close the message and return to the live stream.")
  const timeout = 10000
  bus.emit("popup:confirm", title, message, {timeout, buttons, closeCallback})
}

export function _askForFlickRecording(buttons) {
  const title = _("Recording Alert")
  const message = _("A recording is going on, changing the channel shall discard the current recording.")
  const timeout = -1
  bus.emit("popup:confirm", title, message, {buttons, timeout})
}

export function _askForConflictRecording(buttons) {
  const title = _("Recording Alert")
  const message = _("Tuned channel will be changed if new recording started on this channel.")
  const timeout = -1
  bus.emit("popup:confirm", title, message, {buttons, timeout})
}

export function recordingFailed(content) {
  const title = _("Recording failed")
  let message = _("Recording  can't be done because The {channelTitle} doesn't have any program information")
  message = message.replace("{channelTitle}", content.channelTitle)
  bus.emit("popup:alert", title, message,  {closeOnOk: true})
}

// Message when TP List is viewed while record in process updated as per new PRD
export function recordTPListConflict(buttons) {
  const title = _("STB Info Sheet")
  const message = _("In order to give you the state of the Transponder we need to stop the records.")
  bus.emit("popup:alert", title, message, {buttons})
}

export function RecordingEnded() {
  const title = _("808 – Content Alert")
  const msg =  _("You have reached the end of this content.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function PVRDisabled() {
  const title = _("Enhance your experience ")
  const msg =  _(" Soon Recording Functions & Timeshift feature will be available. Retry later.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function RecordBlockOnMOD() {
  const title = _(" 802 – Recording Alert")
  const msg =  _("Recording features are not authorized on this channel")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function currentConflictWithScheduled(param) {
  const title = _("803 – Recording Alert")
  const message = "" + param.conflictTaskStr
  const timeout = 20000
  const buttons = param.buttons
  const closeCallback = param.closeCallback
  bus.emit("popup:confirm", title, message, {timeout,buttons,closeCallback},"","",true)
}

export function recordVSReminderConflictSameTime(buttons,closeCallback) {
  const title = _("Recording Alert: Record Vs Reminder")
  const message = _("A Record or a Reminder is already scheduled \n" +
  "for this channel for the same hour. We can’t take into account your action.")
  const timeout = 20000
  bus.emit("popup:confirm", title, message, {buttons,timeout,closeCallback},"","",true)
}

// Message indicating the date is not valid for manual records
export function invalidDate() {
  const title = _("Invalid date")
  const msg = _("Impossible to create a record, please set a valid date/time in the future.")
  bus.emit("popup:alert", title, msg,  {closeOnOk: true})
}

export function epgRecordEnded() {
  const title = _("EPG Error")
  const msg = _("Recording is not possible on past event.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

// ----------------------------------------------------------------
// ------------------------ STORAGE Popups ------------------------
// ----------------------------------------------------------------

export function formatUsb(buttons, disableBack) {
  const title = _("702 - Device Detected")
  const message = _("A new USB Device has been detected. OK to start format. All data in the disk will be lost")
  const timeout = -1
  bus.emit("popup:confirm", title, message, {buttons, timeout}, "", "", disableBack)
}

export function hardFormatUsb(buttons, disableBack) {
  const title = _("Format HDD")
  const message = _("Do you really want to Format HDD? All data in the disk will be lost")
  const timeout = -1
  bus.emit("popup:confirm", title, message, {buttons, timeout}, "", "", disableBack)
}

// End changes for US85852
export function unsupportedUsb() {
  const title = _("801 - Device Detected")
  const message = _("The size of the connected USB Device is not enough to enable Recorder features."+
      " Please insert a USB Device with minimum 1GB capacity.")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}
export function ErrorUsb() {
  const title = _("USB Device Not Inserted Properly")
  const message = _("Please Plugin USB Device Properly")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}
export function smallStorageRemoved() {
  const title = _("USB Device Unplugged")
  const message = _("Usb key has been Unplugged")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}
/** During the format phase a message will be displayed in order to inform
the EndUser that he needs to wait the end of the format **/
export function formattingInProcess() {
  const title = _("702 – New USB Device")
  const message = _("Formatting disk, please wait…")
  const timeout = 50000
  bus.emit("popup:confirm", title, message, {timeout,closeOnOk: true})
}

export function UsbFormatted() {
  const title = _("USB Formatted")
  const message = _("Usb key successfully formatted")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}
export function UsbFormatError() {
  const title = _("709 - Device Detected")
  const message = _("The STB is not able to format the connected USB device. Use Another device")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

export function UsbEstablished() {
  const title = _("701 – detecting External USB Device…")
  const message = _("Please wait while the USB connection is being established")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

/* Message indicating the Storage used for timeshift has been removed, so PVR is not active anymore
1) At recording time if no device are detected
2)during the playback the device is disconnected a
3)if the device is disconnected during the navigation on PVR list
4)if the USB HDD is disconnected during the playback of timeshift
*/
export function storageRemoved() {
  const title = _("704 – USB device Alert")
  const message = _("No USB Device connected. Connect USB Device to use Recorder features")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

/** updated as per new PRD**/
export function incompatibleUSB() {
  const title = _("708 - Device Detected")
  const message = _("Connected USB device is not compatible to the STB.")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

// Message indicating the Storage plugged is not valid for PVR/TS because of not enough Free Space
export function storageNotEnoughFreeSpace() {
  const title = _("PVR & TS")
  const message = _("USB disk size not compliant with PVR & TS requirements. Minimal free size to activate = 10Go")
  bus.emit("popup:alert", title, message, {closeOnOk: true})
}

// Message indicating the Storage plugged is not valid Buffering Free Space
export function storageFreeSpace() {
  const title = _("Insufficient Disk Space")
  const message = _("Timeshift & PVR feature will not work")
  const timeout = 50000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

// Message indicating that there is no disk space to schedule a record
export function DiskSpaceConflict() {
  const title = _("706 – USB Device Full")
  const message =  _(" You have run out of disk space on the connected USB device." +
    "Please delete existing recordings to record further.")
  bus.emit("popup:alert", title, message, {closeOnOk: true})
}

// ----------------------------------------------------------------
// --------------------- CHANNEL ACCESS Popups --------------------
// ----------------------------------------------------------------

// Message asking for SD 101 Unsubscribed channel functionality
export function UnsubscribeChannel(channelNum, vcNum) {
  const title = _("101 - Unsubscribed Channel")
  let message = _("Channel No. {channelNum} is not subscribed by you.")
  message = message.replace("{channelNum}", channelNum)
  let message2 = _("To subscribe this channel, \nSMS: DISHTV GET {channelNum} to " +
  "57575 \nFrom your Registered Mobile Number (RMN)")
  message2 = message2.replace("{channelNum}", channelNum)
  let message3 = _("To Register your Mobile Number, \nSMS: DISHTV RMN {vcNum} to 57575")
  message3 = message3.replace("{vcNum}", vcNum)
  const message4 = _("To allow timely updation, after ordering a \nchannel, please switch-off & " +
  "switch-on your \nSet-Top-Box from the main power supply and \nkeep it on channnel 99 for 15 minutes.")
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

// Message asking for HD 103 Unsubscribed channel functionality
export function UnsubscribeHDChannelPromotion() {
  const title = _("601 - Upgrade to HD Set-Top-Box")
  const msg1 = _("Your current Set-Top-Box box doesn't support this HD channel")
  const msg2 = _("Switch to HD Now for ultra-clear picture quality and 5.1 surround sound")
  const msg3 = _("Order now at a SPECIAL PRICE!")
  const msg4 = _("Give a missed call on 1800 274 9511 from your or SMS CALLME to 57575 "
  + "from your Registered Mobile Number (RMN).")
  bus.emit("UnsubscribedErrorMsg:alert", title, msg1, msg2, msg3, msg4, {})
}

// Message asking for HD 103 Unsubscribed channel functionality
export function UnsubscribeHDChannel(priceTag,noOfHdChannels,channelNum,vcNum) {
  const title = _("103 - HD Channel not subscribed")
  const message = _("This channel is available in High Definition.")
  let message2 = _("Subscribe to this channel in HD picture \nquality along " +
  "with {noOfHdChannels} more HD channels \nat  Rs. {priceTag} per month.")
  message2 = message2.replace("{priceTag}", priceTag)
  message2 = message2.replace("{noOfHdChannels}",noOfHdChannels)
  message2 = message2.replace("{channelNum}",channelNum)

  let message3 = _("SMS: DISHTV ADD {channelNum} to 57575 \nfrom your Registered Mobile Number")
  message3 = message3.replace("{channelNum}",channelNum)
  let message4 = _("To Register your Mobile Number, SMS: \nDISHTV RMN {vcNum} to 57575")
  message4 = message4.replace("{vcNum}", vcNum)
  message4 = message4.replace("{channelNum}",channelNum)
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

// Message asking for MOD 501 Conditional Access functionality
export function ModChannelAccess(Currency, PriceInUnit, PurchaseCode, PriceDecimalForm, EventName, vcNum) {
  const title = _("501 - Conditional Access")
  let message = _("To order {EventName} (Paid movie {Currency} {PriceInUnit}.{PriceDecimalForm}) {PurchaseCode}")
  message = message.replace("{EventName}", EventName)
  message = message.replace("{Currency}", "Rs")
  message = message.replace("{PriceInUnit}", PriceInUnit)
  message = message.replace("{PriceDecimalForm}", PriceDecimalForm)
  message = message.replace("{PurchaseCode}", PurchaseCode)

  let message2 = _(
    "SMS MOD {vcNum} {PurchaseCode} to 57575. If you do not get the movie with in 10 minutes after sending ")
  message2 = message2.replace("{vcNum}", vcNum)
  message2 = message2.replace("{PurchaseCode}", PurchaseCode)
  const message3 = _("SMS DISHTV CALL ME to 57575 from your registered mobile number (RMN).")
  let message4 = _("To RMN SMS DISHTV RMN {vcNum} to 57575")
  message4 = message4.replace("{vcNum}", vcNum)
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

// ----------------------------------------------------------------
// ------------------------ REMINDERS Popups ----------------------
// ----------------------------------------------------------------

// Message asking for rechargeReminder alert
export function RechargeReminderAlert(count) {
  const title = _("Recharge Reminder")
  let message = _("Your recharge date is near. Your TV will be switched off in {count} days. "
                  + "Please recharge immediately to avoid disruption in service.")
  message = message.replace("{count}", count)
  const timeout = 30000
  const disablePopupMessage=true
  bus.emit("popup:alert", title, message, {timeout, closeOnOk: true},undefined,undefined, disablePopupMessage)
}

// Message asking for rechargeReminder alert for today
export function RechargeReminderLastAlert() {
  const title = _("Recharge Reminder")
  const message = _("Your TV will be switched off, today. Recharge immediately to avoid disruption in service.")
  const timeout = -1
  const disablePopupMessage=true
  bus.emit("popup:alert", title, message, {timeout, closeOnOk: true},undefined,undefined, disablePopupMessage)
}

export function showReminderMessage(programName, channelName, channelNum, startHour, timeout, buttons, closeCallback) {
  const title = _("Reminder")
  let  message = _("Your program {programName} on channel {channelNum} {channelName} will start at {startHour}." +
                " Do you want to tune the channel?")
  message = message.replace("{programName}", programName)
  message = message.replace("{channelNum}", channelNum)
  message = message.replace("{channelName}", channelName)
  message = message.replace("{startHour}", startHour)
  bus.emit("popup:confirm", title, message, {timeout, buttons, closeCallback})
}

export function reminderNotPossible() {
  const title = _("Reminder Alert")
  const msg =  _("Reminder can't be applied as program has no information.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function ReminderAlreadySet() {
  const title = _("Reminder Conflict")
  const message =  _("Reminder or Recording is already set for this Program")
  const timeout = 20000
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: true})
}

// ----------------------------------------------------------------
// ------------------------ SIGNALS Popups ------------------------
// ----------------------------------------------------------------

export function ftaSignalNotFound(vcNum) {
  const title = _("301 – Signal not found")
  const message = _("Please ensure that your set-Top-Box is properly connected to the DISHTV antenna")
  const message2 = _("IN CASE OF HEAVY RAIN, WAIT TILL RAIN STOPS TO REGAIN SIGNAL")
  const message3 = _("If problem continues, SMS DISHTV 301 to 57575," +
  "\nfrom your Registered Mobile Number (RMN).")
  let message4 = _("To RMN, SMS DISHTV RMN {vcNum} to 57575.")
  message4 = message4.replace("{vcNum}", vcNum)
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

export function signalUnavailable(vcNum) {
  const title = _("302 - Signal Unavailable")
  const message = _("The signal to your Set-Top-Box is temporarily unavailable.")
  const message2 = _("Please, POWER OFF – POWER ON your Set-Top-Box from switch.")
  const message3 = _("If problem continues, SMS DISHTV 302 to 57575," +
  "\nfrom your Registered Mobile Number (RMN).")
  let message4 = _("To RMN, SMS DISHTV RMN {vcNum} to 57575.")
  message4 = message4.replace("{vcNum}", vcNum)
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

// ----------------------------------------------------------------
// -------------------------- SCAN Popups -------------------------
// ----------------------------------------------------------------

/** Updation for the Launch of the TPState Screen from the Scan PopUP **/
export function scanComplete(tvFound, radioFound, networkFound, serviceFound, onOpenCall, disableBack) {
  let IsPictoDisplay = true
  const title = _("Channel search completed")
  let  message = _("TV: {tvFound}     Radios: {radioFound}      Network: {networkFound}")
  message = message.replace("{tvFound}", tvFound)
  message = message.replace("{radioFound}", radioFound)
  message = message.replace("{networkFound}", networkFound)
  let  message2 = _("Total services found: {serviceFound}.")
  message2 = message2.replace("{serviceFound}", serviceFound)
  const  message3 = _("Press BACK to save & exit or OK for details")
  if (serviceFound === 0) {
    IsPictoDisplay = false
  }
  bus.emit("popup:alert", title, message, {openTPList: true,displayPicto: IsPictoDisplay,onOpenCall},
   message2, message3, disableBack)
}

// Message asking user to confirm the scan
export function confirmSCAN(buttons, closeCallback) {
  const title = _("Channel Search Confirmation")

  const msg =  _("You will launch a Channel Search that will delete your current list of channels, " +
       " Your favorite list and if a record is in progress you will lose it.")
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

// ----------------------------------------------------------------
// ----------------------- FAVOURITE LIST Popups ------------------
// ----------------------------------------------------------------

export function favoriteIsInUse(closeCallback) {
  const title = _("Error")
  const message = _("Impossible to remove a channel from favorite while currently browsing Favorite List")
  bus.emit("popup:alert", title, message, {closeCallback})
}

export function FavListConflictRecording(channelName, buttons, closeCallback) {
  const title = _("Recording Conflict")
  let msg = _("A TV recording is on-going on channel {channelName} which is not in the favorite list."+
  " Recording will be discontinued and Favourite List will be selected. Select 'Cancel' to stay on current service")
  msg = msg.replace("{channelName}", channelName)
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

export function defaultChannelList() {
  const title = _("Default List Mode")
  const msg =  _("You are now browsing you default channel list .\n"+
   "Press FAV button to switch to your Favourite Channels list.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function favChannelList() {
  const title = _("Favourite List Mode")
  const msg =  _("You are now browsing your Favourite Channels list. \n"+
  " Press Fav button to switch to Default channel list.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function switchOnDefaultChannelList(channelName, buttons, closeCallback) {
  const title = _("Recording Conflict")
  let msg = _("A TV recording is going to start on channel {channelName} which is not in the favorite list. Default"+
  " list will be restored and the recorded channel will be displayed. Select 'Cancel' to stay on current service")
  msg = msg.replace("{channelName}", channelName)

  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

// ----------------------------------------------------------------
// --------------------------- CAM Popups -------------------------
// ----------------------------------------------------------------

export function camInsertedAtBoot(buttons, closeCallback) {
  const title = _("CAM Module")
  const message =  _("CAM Module was inserted, only the watching of channel will be available.")
  bus.emit("popup:confirm", title, message, {buttons, closeCallback})
  bus.stopEventEmit = true
}

export function camInserted(buttons) {
  const title = _("CAM Module")
  // TODO : This text needs to be changes after final discussion with PO
  const message = _("CAM Module was inserted, Press Ok to reboot STB.")
  bus.emit("popup:confirm", title, message, {buttons},"","",true,true)
  bus.stopEventEmit = true
}

export function camRemoved(buttons) {
  const title = _("CAM Module")
  // TODO : This text needs to be changes after final discussion with PO
  const message = _("CAM Module was removed, Press Ok to reboot STB,"+
  " in order to enjoy fully the possibility of your box.")
  bus.emit("popup:confirm", title, message, {buttons},"","",true,true)
  bus.stopEventEmit = true
}

// Message indicating there is no channels/radios
export function insertCAM() {
  const title = _("No CAM Module")
  const message = _("Please Plug-in CAM to view CAM Menu.")
  bus.emit("popup:alert", title, message, {closeOnOk: true})
}

export function ConaxDisabled() {
  const title = _("CAM Module not authorized action.")
  const msg =  _("Sorry this action is not permitted with a CAM, remove it and" +
  " switch off switch on your box in order to use this feature.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

// ----------------------------------------------------------------
// ------------------------- APPS Popups --------------------------
// ----------------------------------------------------------------

export function appLaunched(closeCallback) {
  const title = _("Active Services")
  const message =  _("Retrieving active service, please wait.")
  const message2 = _("Press Back to exit from active service")
  const timeout = -1
  bus.emit("popup:alert", title, message, {timeout,closeCallback}, undefined, message2, false, undefined, true)
}


export function errorAppLaunched() {
  const title = _("Active Services")
  const message = _("Not able to launch application/game")
  const timeout = 20000
  const disablePopupMessage = false
  bus.emit("popup:alert", title, message, {timeout, closeOnOk: true},undefined,undefined, disablePopupMessage)
}

export function appFileDownloadFailed() {
  const title = _("Active Services")
  const message = _("Not able to launch application/game")
  const timeout = 20000
  const disablePopupMessage=true
  bus.emit("popup:alert", title, message, {timeout, closeOnOk: true},undefined,undefined, disablePopupMessage)
}

export function appFileDownloadLoading(closeCallback) {
  const title = _("Active Services")
  const message = _("Retrieving active service, please wait.")
  const timeout = -1
  bus.emit("popup:alert", title, message, {timeout,closeCallback},undefined,undefined, false, undefined, true)
}

export function appsDownloadFail() {
  const title = _("Active Services")
  const message = _("Not able to launch application/game")
  const timeout = 20000
  const disablePopupMessage=true
  bus.emit("popup:alert", title, message, {timeout, closeOnOk: true},undefined,undefined, disablePopupMessage)
}

export function dvbAppsNoJSonAvailable() {
  const title = _("App store")
  const msg = _("No applications found.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

// ----------------------------------------------------------------
// ------------------------- PLAYER Popups ------------------------
// ----------------------------------------------------------------

// Message indicating there is no channels/radios
export function noServices(closeCallback) {
  const title = _("No Services")
  const message = _("No services available. Perform a scan.")
  bus.emit("popup:alert", title, message, {closeCallback,closeOnOk: true})
}

export function unsupportedVideoFile() {
  const title = _("Mediaplayer Error")
  const msg = _("Unable to play this file. Press BACK or OK key to return to Mediaplayer explorer.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function playbackError() {
  const title = _("Mediaplayer Error")
  const msg = _("Unable to play this file. Press BACK or OK key to return to Recording.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

export function vodLoadErrorPopUp(msg, closeCallback) {
  const title = _("VOD Error")
  bus.emit("popup:alert", title, msg, {closeOnOk: true, closeCallback: closeCallback})
}
export function vodPlayErrorPopUp() {
  const title = _("VOD Error")
  const msg = _("Unable to play this asset.")
  bus.emit("popup:alert", title, msg, {closeOnOk: true})
}

// ----------------------------------------------------------------
// ------------------------- FACTORY Popups -----------------------
// ----------------------------------------------------------------

// Message asking user to confirm the scan
export function confirmFactoryReset(buttons, closeCallback) {
  const title = _("Factory Setting Confirmation")

  const msg =  _("You will launch a Factory Reset, Some of your settings will be restored to the default value." +
  "If a record is in progress you will lose it.")
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

// Message asking user to confirm the scan
export function confirmReset(buttons, closeCallback) {
  const title = _("Reset Setting Confirmation")

  const msg =  _("You will launch a  Reset, All of your settings will be restored to the default value." +
  "If a record is in progress you will lose it.")
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

// Message when Factory Reset In Progress
export function FactorySettingInProgress() {
  const title = _("Scan Ongoing")
  const msg = _("Your Set-Top-Box is being updated, Please wait…")
  const disablePopupMessage=true
  bus.emit("popup:alert", title, msg, {closeOnOk: false, hideScanBar:true},undefined,undefined,disablePopupMessage)
}

// ----------------------------------------------------------------
// ------------------------- SERVICES Popups ----------------------
// ----------------------------------------------------------------

export function epgNoChannels() {
  const title = _("No Channels Available")
  const message = _("Currently no channels are available under this category.")
  bus.emit("popup:alert", title, message,  {closeOnOk: true})
}

export function reInstallServices(buttons, vcNum, closeCallback) {
  const title = _("303 Re-Install Services")

  let msg =  _("Press \"OK\" on your remote to re-install channels and services. \n" +
       "If problem continues, SMS DISHTV 303 to 57575 from your registered Mobile " +
       "Number (RMN). To RMN, SMS DISHTV RMN {vcNum} to 57575.")
  const disablePopupMessage=true
  msg = msg.replace("{vcNum}", vcNum)
  bus.emit("popup:confirm", title, msg, {buttons, closeCallback},undefined,undefined,disablePopupMessage)
}

// ----------------------------------------------------------------
// ------------------------- MISC Popups --------------------------
// ----------------------------------------------------------------

// Start changes for US85852
export function vcDeactivated(vcNum) {
  const title = _("102 - Viewing Card (VC) Deactivated")
  let message = _("Please RECHARGE YOUR DISHTV VC No {vcNum} \nLog on www.dishtv.in " +
  "use Credit/Debit card walk into: Nearest Recharge Outlet")
  message = message.replace("{vcNum}", vcNum)
  const message2 = _("If already recharged, please, switch-off & switch-on your Set-Top-Box " +
  "from the mains and keep it ON for 15 minutes on channel 99")
  const message3 = _("Should your services not restart in 15 minutes, " +
  "\nSMS DISHTV REFRESH to 57575 \nfrom your registred Mobile Number")
  const message4 = _("Forgot to recharge! Give a Missed Call on \n1800 274 9050 to get " +
  "your channels NOW. \nPay in next 3 days to enjoy NON STOP TV.")
  bus.emit("UnsubscribedErrorMsg:alert", title, message, message2, message3, message4, {})
}

// Message asking user to confirm the wanted resolution
export function confirmResolution(buttons, closeCallback) {
  const title = _("HDMI resolution")
  const msg = _("Do you want to apply this HDMI resolution?")
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

// Message asking user to confirm IF2IF mode change
export function confirmIF2IFmode(buttons, closeCallback) {
  const title = _("IF2IF mode")
  const msg = _("Do you want to change IFtoIF mode and launch scan? " +
      " Launching scan will delete your current list of channels, " +
       " Your favorite list and if a record is in progress you will lose it")
  const timeout = 10000
  bus.emit("popup:confirm", title, msg, {timeout, buttons, closeCallback})
}

export function confirmSoftwareUpdate(buttons) {
  const title = _("106 Software Update")
  const msg = _("A Software version is available and the Client Software will force the Update.")

  bus.emit("popup:confirm", title, msg, {buttons},"","",true,true)
  bus.stopEventEmit = true
}

// updated PRD action:button:return to first easy scan
export function firstInstallSoftwareUpdate(buttons) {
  const title = _("First Install, Sw Update")
  const msg = _("The Sw version details are not provided, System can’t verify if a new Sw version is available")
  bus.emit("popup:confirm", title, msg, {buttons},"","",true,true)
  bus.stopEventEmit = true
}

export function instantMessage(msg, duration) {
  const title = _("Instant Message")
  let message = _(" {msg} ")
  message = message.replace("{msg}", msg)
  const timeout = duration
  bus.emit("popup:alert", title, message, {timeout,closeOnOk: false})
}

export default {
  ConaxDisabled,
  RecordBlockOnMOD,
  pvrNotReady,
  confirmPvrReady,
  unsupportedUsb,
  UsbFormatted,
  UsbFormatError,
  storageRemoved,
  storageNotEnoughFreeSpace,
  incompatibleUSB,
  scheduleConflict,
  scheduleFailed,
  zapConflict,
  tunerConflict,
  onGoingRecordConflict,
  RecordingConflictAppStore,
  favoriteIsInUse,
  DiskSpaceConflict,
  noServices,
  insertCAM,
  confirmResolution,
  invalidDate,
  scanComplete,
  unsupportedVideoFile,
  showReminderMessage,
  epgNoChannels,
  _askForFlickRecording,
  _askForConflictRecording,
  recordingFailed,
  ErrorUsb,
  epgRecordEnded,
  reInstallServices,
  storageFreeSpace,
  vodPlayErrorPopUp,
  vodLoadErrorPopUp,
  dvbAppsNoJSonAvailable,
  recordTPListConflict,
  UnsubscribeChannel,
  UnsubscribeHDChannel,
  PVRDisabled,
  formattingInProcess,
  firstInstallSoftwareUpdate,
  RecordingEnded,
  vcDeactivated,
  ftaSignalNotFound,
  signalUnavailable,
  camInsertedAtBoot,
  camInserted,
  camRemoved,
  ModChannelAccess,
  instantMessage,
  switchOnDefaultChannelList,
  FavListConflictRecording,
  RechargeReminderAlert,
  RechargeReminderLastAlert,
  defaultChannelList,
  favChannelList,
  hardFormatUsb,
  reminderNotPossible,
  ReminderAlreadySet,
  recordVSReminderConflictSameTime,
  appLaunched,
  errorAppLaunched,
  appFileDownloadFailed,
  appFileDownloadLoading,
  appsDownloadFail,
}
