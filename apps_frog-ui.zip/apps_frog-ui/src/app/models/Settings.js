//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import bus from "services/bus"
import {on, enableEvents} from "services/events"
import {setLocale,
  updateAudiotracks,
  updateDefaultTrack,
  updateTimeZone,
} from "services/managers/config"
import {_, locale} from "utils/locale"
import {GET, PUT} from "services/http"
import TimezoneManager from "services/managers/TimezoneManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import CasManager from "services/managers/CasManager"
import config from "utils/config"
import {myAccountTimestampToDate, formatDateOnly} from "utils/date"
import ScanManager from "services/managers/ScanManager"
import {getMyAccountDetails} from "services/api/cas"
import InstantMessageManager from "services/managers/InstantMessageManager"
import PVRManager from "services/managers/PVRManager"
import PlayerManager from "services/managers/PlayerManager"
import Transponder from "services/managers/transponders"

import {setEpgLanguage} from "services/api/program"

import * as packages from "../../../package.json"

/** @ignore */
export default class Settings extends Model {
  constructor(props) {
    super(props)
    this.currentTimezone = null
    this.defaultTimeZone = null
    this.selectedAudio = null
    this.currentRatio = null
    this.openFavInProgress = false
    this.enableMultiLang = true
    enableEvents(this)

    this.RESET_VALUES = Object.freeze({
      AVIO: {"format": "1280x720@50p"},
      AUDIO: {"audio_codecs": {"1": "ac3", "2": "mp2"}},
      TIME_FORMAT: "12h",
      LAST_TUNED_CHANNEL: 99,
      TIMEZONE: "Asia/Kolkata",
      TRACK: "eng",
      ARM: {"arm": "avio_video_arm_full"},
      ASPECT_ARM: "avio_aspect_ratio_16_9_avio_video_arm_full",
      CVBS: {format: "720x576@50i"},
      DEFAULT_AUDIO_TRACK: {"audio_tracks": {"1": "hin","2": "eng"}},
    })

    this.LNBParams = [
      {
        "antenna_satellite_lnb_control_mode": "lnb_control_13_v_18_v_22_k",
        "antenna_transmitter_id": -1,
        "antenna_satellite_message_repetition": 0,
        "antenna_satellite_committed_switch_position": -1,
        "antenna_satellite_switch_freq": 11725000,
        "antenna_satellite_lnb_type": "lnb_type_2_bands",
        "antenna_satellite_switch_position": -1,
        "antenna_satellite_toneburst_switch_position": -1,
        "antenna_satellite_tone_22_khz_mode": "tone_22_khz_auto",
        "antenna_satellite_freq_oscillator1": 9750000,
        "antenna_satellite_freq_oscillator2": 10600000,
        "antenna_type": "antenna_type_satellite",
        "antenna_satellite_uncommitted_switch_position": -1,
      },
      {
        "antenna_satellite_lnb_control_mode": "lnb_control_13_v_18_v_22_k",
        "antenna_transmitter_id": 1,
        "antenna_satellite_message_repetition": 0,
        "antenna_satellite_committed_switch_position": 0,
        "antenna_satellite_switch_freq": 11725000,
        "antenna_satellite_lnb_type": "lnb_type_2_bands",
        "antenna_satellite_switch_position": 0,
        "antenna_satellite_toneburst_switch_position": -1,
        "antenna_satellite_tone_22_khz_mode": "tone_22_khz_auto",
        "antenna_satellite_freq_oscillator1": 9750000,
        "antenna_satellite_freq_oscillator2": 10600000,
        "antenna_type": "antenna_type_satellite",
        "antenna_satellite_uncommitted_switch_position": -1,
      },
      {
        "antenna_satellite_lnb_control_mode": "lnb_control_13_v_18_v_22_k",
        "antenna_transmitter_id": 2,
        "antenna_satellite_message_repetition": 0,
        "antenna_satellite_committed_switch_position": 1,
        "antenna_satellite_switch_freq": 11725000,
        "antenna_satellite_lnb_type": "lnb_type_2_bands",
        "antenna_satellite_switch_position": 1,
        "antenna_satellite_toneburst_switch_position": -1,
        "antenna_satellite_tone_22_khz_mode": "tone_22_khz_auto",
        "antenna_satellite_freq_oscillator1": 9750000,
        "antenna_satellite_freq_oscillator2": 10600000,
        "antenna_type": "antenna_type_satellite",
        "antenna_satellite_uncommitted_switch_position": -1,
      },
      {
        "antenna_satellite_lnb_control_mode": "lnb_control_13_v_18_v_22_k",
        "antenna_transmitter_id": 3,
        "antenna_satellite_message_repetition": 0,
        "antenna_satellite_committed_switch_position": 2,
        "antenna_satellite_switch_freq": 11725000,
        "antenna_satellite_lnb_type": "lnb_type_2_bands",
        "antenna_satellite_switch_position": 2,
        "antenna_satellite_toneburst_switch_position": -1,
        "antenna_satellite_tone_22_khz_mode": "tone_22_khz_auto",
        "antenna_satellite_freq_oscillator1": 9750000,
        "antenna_satellite_freq_oscillator2": 10600000,
        "antenna_type": "antenna_type_satellite",
        "antenna_satellite_uncommitted_switch_position": -1,
      },
      {
        "antenna_satellite_lnb_control_mode": "lnb_control_13_v_18_v_22_k",
        "antenna_transmitter_id": 4,
        "antenna_satellite_message_repetition": 0,
        "antenna_satellite_committed_switch_position": 3,
        "antenna_satellite_switch_freq": 11725000,
        "antenna_satellite_lnb_type": "lnb_type_2_bands",
        "antenna_satellite_switch_position": 3,
        "antenna_satellite_toneburst_switch_position": -1,
        "antenna_satellite_tone_22_khz_mode": "tone_22_khz_auto",
        "antenna_satellite_freq_oscillator1": 9750000,
        "antenna_satellite_freq_oscillator2": 10600000,
        "antenna_type": "antenna_type_satellite",
        "antenna_satellite_uncommitted_switch_position": -1,
      },
    ]


    // array order is determining menu order
    this.items = [
      {
        label: "My Account",
        onFocus: () => this.emptyCall(),
        action: () => this.loadMyAccount(),
      },

      {
        label: _("Change Language"), // Language
        name:"language",
        items: [
          {
            label: "Change UI Language",
            onFocus: () => this.loadUILanguages(),
          },
        ],
      },

      {
        label: _("Channel Settings"),
        name:"scan",
        onFocus: () => this.loadScanSections(),
      },

      {
        label: "Time Settings",
        items: [
          {
            label: "Time Zone Format",
            onFocus: () => this.loadUITimeZoneFormat(),
          },
          {
            label: "Time Format",
            onFocus: () => this.loadUITimeFormat(),
          },
        ],
      },

      {
        label: _("Audio & Video"), // Audio/Video Outputs
        items: [
          {
            label: "HDMI Settings",
            onFocus: () => this.loadHdmi({reload: false}),
          },
          {
            label: _("TV Type"),
            onFocus: () => this.loadAspectRatio({reload: false}),
          },
          {
            label: "CVBS",
            onFocus: () => this.loadCVBSConfig({reload: false}),
          },
          {
            label: "5.1 Setting",
            onFocus: () => this.loadDolbyOption(),
          },
        ],
      },

      {
        label: "STB Info Sheet",
        name:"STBInfoSheet",
        action: () => this.loadStbInfo(),
      },
      {
        label: "Tools",
        name:"tools",
        onFocus: () => this.loadToolsOption(),
      },
      {
        label: _("Self-help"),
        name:"selfHelp",
        onFocus: () => this.loadSelfHelp(),
      },
    ]

    if (config.PVR_DISABLED) {
      // array order is determining menu order
      this.items = [
        {
          label: "My Account",
          onFocus: () => this.emptyCall(),
          action: () => this.loadMyAccount(),
        },

        {
          label: _("Change Language"), // Language
          name:"language",
          items: [
            {
              label: "Change UI Language",
              onFocus: () => this.loadUILanguages(),
            },
          ],
        },

        {
          label: _("Channel Settings"),
          name:"scan",
          onFocus: () => this.loadScanSections(),
        },

        {
          label: "Time Settings",
          items: [
            {
              label: "Time Zone Format",
              onFocus: () => this.loadUITimeZoneFormat(),
            },
            {
              label: "Time Format",
              onFocus: () => this.loadUITimeFormat(),
            },
          ],
        },

        {
          label: _("Audio & Video"), // Audio/Video Outputs
          items: [
            {
              label: "CVBS",
              onFocus: () => this.loadCVBSConfig({reload: false}),
            },
          ],
        },

        {
          label: "STB Info Sheet",
          name:"STBInfoSheet",
          action: () => this.loadStbInfo(),
        },
        {
          label: "Tools",
          name:"tools",
          onFocus: () => this.loadToolsOption(),
        },
        {
          label: _("Self-help"),
          name:"selfHelp",
          onFocus: () => this.loadSelfHelp(),
        },
      ]
    }
  }

  @on("setting:tvtype")
  getTvType() {
    const API = "/player/config/output/avio_output_hdmi0/"
    const armApi = "/avio/player/WyPlayer/output/hdmi0/"
    const letter = "avio_aspect_ratio_4_3_avio_video_arm_box"
    const pillar = "avio_aspect_ratio_16_9_avio_video_arm_box"
    Promise.all([
      GET(API), GET(armApi),
    ])
    .then(([first, second]) => {
      const type = first.aspect_ratio +"_"+second.arm
      if (type === pillar) {
        PlayerManager.tvType = "Pillar"
      } else if (type === letter) {
        PlayerManager.tvType = "Letter"
      } else {
        PlayerManager.tvType = "Auto"
      }
    })
  }

  @on("setting:stb-serialNo")
  getStbSerialNo() {
    const API = "/software/stbserialnum/"
    GET(API).then((data) => {
      const serialNo = data ? data.stbserialnum : ""
      if (serialNo && serialNo.length > 0) {
        Transponder.stbSerialNo =  serialNo
      }
    })
  }

  // time zone and time format
  loadDolbyOption() {
    const API = "/player/config/audio_codecs/"
    return GET(API)
        .then((currentDolby) => {
          const current = currentDolby
          const itemsObj = {items: []}
          const dolbyOption = [
            {label: "5.1 ON", value:{"audio_codecs": {"2": "ac3", "1": "mp2"}}},
            {label: "5.1 OFF", value:{"audio_codecs": {"1": "ac3", "2": "mp2"}}},
          ]

          if (!this.selectedAudio) {
            this.selectedAudio = current.audio_codecs[1]
          }

          dolbyOption.forEach((data) => {
            itemsObj.items.push({
              label: data.label,
              action: () => {
                this.selectedAudio = data.value.audio_codecs[1]

                this.loadDolbyOption()
                    .then((data) => {
                      bus.emit("settings:setDefault", data)
                    })
                const data_api = {"preferred_audio_codecs": {"1": data.value.audio_codecs[1],
                  "2": data.value.audio_codecs[2]}}
                this._setDolbyValue(data.value)
                this._setDolbyValue_preferred(data_api)

              },
              default: this.selectedAudio === data.value.audio_codecs[1],
            })
          })
          return Promise.resolve(itemsObj.items)
        })
  }

  loadParentalLockSections() {
    const items= [
      {
        label: "Change pin code",
        signal: "settings:parentalLock",
        type: "ChangePin",
      },
      {
        label: _("Channel block"),
        signal: "settings:parentalLock",
        foreground: true,
        type: "BlockChannelList",
      },
    ]
    return Promise.resolve(items)
  }

  loadToolsOption() {
    let items= [
      {
        label: "Factory Reset",
        signal: "scan:factoryReset",
      },
      {
        label: "Force Software Update",
        signal: "settings:softwareUpdateForcely",
      },
      {
        label: _("Format Hard Disk"),
        signal: "storage:hardformat",
      },
      {
        label: _("CAM Menu"),
        signal: "settings:onSettingCam",
      },
      {
        label: _("Master Reset"),
        signal: "settings:reset",
      },
      {
        label: _("Copyright & License Info"),
        signal: "settings:license",
      },
    ]
    if (config.PVR_DISABLED) {
      items= [
        {
          label: "Factory Reset",
          signal: "scan:factoryReset",
        },
        {
          label: "Force Software Update",
          signal: "settings:softwareUpdateForcely",
        },
        {
          label: _("CAM Menu"),
          signal: "settings:onSettingCam",
        },
        {
          label: _("Master Reset"),
          signal: "settings:reset",
        },
        {
          label: _("Copyright & License Info"),
          signal: "settings:license",
        },
      ]
    }
    return Promise.resolve(items)
  }

  loadSelfHelp() {
    const items= [
      {
        label: _("SMS Services"),
        signal: "settings:smsServices",
      },
      {
        label: "Contact Us",
        signal: "settings:contactUs",
      },
    ]
    return Promise.resolve(items)
  }

  loadScanSections() {
    const items = [
      {
        label: _("Channel Search"),
        name:"chSearch",
        signal: "settings:scan",
        foreground: true,
      },
      {
        label: _("Transponder List"),
        name:"tpList",
        action: () => this.loadTransponderList(),
      },
      {
        label: "Favorite channels",
        name:"favourite",
        action: () => this.loadFavorites(),
      },
    ]
    if (config.BROADCAST === "dvbs") {
      items.push({
        label: "Advanced Scan",
        signal: "settings:advanced_scan",
        foreground: true,
      })
    }

    return Promise.resolve(items)
  }

  @on("transponderList:show")
  _onTransponderListShow(isfromPopUp) {
    if (ScanManager.isFirstInstall) {
      bus.emit("settings:closeScanProgress")
    }
    bus.emit("transponderList:open",isfromPopUp)
  }

@on("transponderList:open")
  loadTransponderList(option = false) {
    const item = {
      title: _("Transponder List"),
      context: "TPList",
      label: _("Transponder List"),
      isfromPopUp : option,
    }
// opening TPLIst while reconding in progress
    if (PVRManager.ongoing.length > 0) {
      this.RecordingTransponderListConflict(item)
    } else {
      bus.emit("settings:transponderList",item)
    }
  }

  RecordingTransponderListConflict(item) {
    const closeCallback = () => {
    }
    const buttons = [
      {
        label: "Ok",
        action: () => {
          PVRManager.cancel(PVRManager.ongoing[0].programId ,(PVRManager.ongoing[0]))
          bus.emit("settings:transponderList",item)
        },
      },
      {
        label: "Back",
        action: closeCallback,
      },
    ]
    return popUpMsg.recordTPListConflict(buttons, closeCallback)
  }




  loadUILanguages() {
    const API = "/player/config/audio_tracks/"
    return GET(API)
      .then((currentLanguage) => {
        const current = currentLanguage
        const itemsObj = {items: []}
        let languages

        if (this.enableMultiLang) {
          languages = [
            {label: "English", value: "eng"},
            {label: "Hindi", value: "hin"},
            {label: "Marathi", value: "mar"},
            /* {label: "Tamil", value: "tam"}, */
            {label: "Telugu", value: "tel"},
          ]
        } else {
          languages = [{label: "English", value: "eng"},{label: "Hindi", value: "hin"}] // ["en", "fr","Hindi"]
        }

        if (!this.selectedLang) {
          this.selectedLang = Object.keys(current.audio_tracks).length === 2 ? current.audio_tracks[2] :
          current.audio_tracks[Object.keys(current.audio_tracks).length]
        }

        languages.forEach((lang) => {
          itemsObj.items.push({
            label: lang.label,
            action: () => {
              locale.current = lang.value
              this.selectedLang = lang.value
              setLocale(lang.value).then(() => {
                let obj = {}

                if (!this.enableMultiLang) {
                  if (lang.value === "eng") {
                    obj = {"audio_tracks": {"1": "hin", "2": "eng"}}
                  } else if (lang.value === "hin") {
                    obj = {"audio_tracks": {"2": "hin", "1": "eng"}}
                  }
                } else {
                  switch (lang.value) {
                  case "eng":
                    obj = {"audio_tracks":
                    {
                      "1": "tel",
                      "2": "mar",
                      "3": "tam",
                      "4": "hin",
                      "5": "eng",
                    },
                    }
                    break
                  case "hin":
                    obj = {"audio_tracks":
                    {
                      "1": "tel",
                      "2": "mar",
                      "3": "tam",
                      "4": "eng",
                      "5": "hin",
                    },
                    }
                    break
                  case "tam":
                    obj = {"audio_tracks":
                    {
                      "1": "tel",
                      "2": "mar",
                      "3": "hin",
                      "4": "eng",
                      "5": "tam",
                    },
                    }
                    break
                  case "mar":
                    obj = {"audio_tracks":
                    {
                      "1": "tel",
                      "2": "tam",
                      "3": "hin",
                      "4": "eng",
                      "5": "mar",
                    },
                    }
                    break
                  case "tel":
                    obj = {"audio_tracks":
                    {
                      "1": "mar",
                      "2": "tam",
                      "3": "hin",
                      "4": "eng",
                      "5": "tel",
                    },
                    }
                    break
                  default:
                    break
                  }
                }
                updateDefaultTrack(this.selectedLang)
                updateAudiotracks(obj)
                setEpgLanguage(this.selectedLang)
              })
              this.loadUILanguages()
                .then((data) => {
                  bus.emit("settings:setDefault", data)
                })
            },
            default: this.selectedLang === lang.value,
          })
        })
        return Promise.resolve(itemsObj.items)
      })
  }

  loadNetwork() {
    const interfaces = Object.keys(NetworkManager.interfaces)
    const items = []
    interfaces.forEach((interfaceName) => {
      items.push({
        label: interfaceName,
        action: () => this.loadNetworkIface(interfaceName),
      })
    })
  }

  loadNetworkIface(interfaceName) {
    const filter = [
      "interface",
      "ip_address",
      "netmask",
      "gateway",
      "dns1",
      "dns2",
      "mac_address",
      "authentication status",
    ]
    NetworkManager.interfaces[interfaceName]["authentication status"] = NetworkManager.authenticated
    const item = {
      title: "Network information",
      context: "NetworkInfo",
      label: interfaceName,
      data: NetworkManager.interfaces[interfaceName],
      filter: filter,
    }
    bus.emit("settings:subOpen", item)
  }

  loadHdmi({reload}) {
    return this.loadAvio("format")
      .then((data) => {
        if (reload)
          bus.emit("settings:setDefault", data)
        else
          return data
      })
  }

  loadAspectRatio({reload}) {
    return this.loadAvio("aspect_ratio")
      .then((data) => {
        if (reload)
          bus.emit("settings:setDefault", data)
        else
          return data
      })
  }

  loadCVBSAvio() {
    const API = "/player/config/output/avio_output_videoanalog0/"
    const itemsObj = {items: []}
    return GET(API)
    .then((configsList) => {
      const cvbsList = [
          {label: "PAL", value: "720x576@50i"},
          {label: "NTSC", value: "720x480@60i"},
      ]
      const currentCVBS = configsList.format
      cvbsList.forEach((cvbs) => {
        itemsObj.items.push({
          label: cvbs.label,
          action: () => {
            const item = {format: cvbs.value}
            return PUT(API, item)
                .then(() => {
                  return this.loadCVBSConfig({reload: true})
                })
          },
          default: cvbs.value === currentCVBS,
        })
      })
      return Promise.resolve(itemsObj.items)
    })
  }

  loadCVBSConfig({reload}) {
    return this.loadCVBSAvio()
      .then((data) => {
        if (reload)
          bus.emit("settings:setDefault", data)
        else
          return data
      })
  }
  loadAvio(type) {
    const API = "/player/config/output/avio_output_hdmi0/"
    const armApi = "/avio/player/WyPlayer/output/hdmi0/"
    const itemsObj = {items: []}
    return GET(API)
    .then((configsList) => {
      if (type === "format") {
        const currentFormat = {}
        currentFormat.val = configsList.format
        this._sortAvio(this.removeCvbsRes(configsList.hdmi_supported_formats)).forEach((format) => {
          itemsObj.items.push({
            label: format.label,
            action: () => {
              if (format && format.value !== currentFormat.val) {
                this._setAvio({[type]: format.value}, currentFormat)
              }
            },
            default: format.value === currentFormat.val,
          })
        })

      }

      if (type === "aspect_ratio") {
        const aspectRatios = [
          {label: "None (default)", value: "avio_aspect_ratio_16_9",action:"16_19_auto", active:"avio_video_arm_full"},
          {label: "Letter Box", value: "avio_aspect_ratio_4_3",action:"16_19_letter", active:"avio_video_arm_box"},
          {label: "Pillar Box", value: "avio_aspect_ratio_16_9",action:"16_19_pillar", active:"avio_video_arm_box"},
        ]
        const currentRatio = configsList.aspect_ratio

        return GET(armApi)
        .then((defaultArm) => {
          const defaultSection = currentRatio + "_" + defaultArm.arm

          aspectRatios.forEach((ratio) => {
            itemsObj.items.push({
              label: ratio.label,
              action: () => this._setAvio({active:ratio.active,action:ratio.action,[type]: ratio.value}),
              default: ratio.value + "_" + ratio.active  === defaultSection,
            })
          })
          return Promise.resolve(itemsObj.items)
        })
      }

      return Promise.resolve(itemsObj.items)
    })
  }

  _setDolbyValue(item) {
    const API = "/player/config/audio_codecs/"
    return PUT(API, item)
  }


  _setDolbyValue_preferred(item) {
    return GET("/player/")
    .then((playerID) => {
      return PUT(playerID[0].href, item)
    })
  }

  removeCvbsRes(raw) {
    const analogRes = ["720x576@50i", "720x480@60i"]
    analogRes.forEach(function(res) {
      const ind = raw.indexOf(res)
      if (ind > -1) {
        raw.splice(ind, 1)
      }
    })
    return raw
  }
  _sortAvio(raw) {
    /**
     * 1920x1080@60p => 1080p / 60Hz
     * + sorted
     */
    const index = []
    const forged = []
    const sorted = []
    raw.forEach((format) => {
      const mixed = format.replace(
        /([0-9]*)x([0-9]*)@([0-9]*)([A-z]*)/,
        "$1.$2.$3.$4").split(".")
      let digits
      if (mixed[1].toString().length < 4) {
        digits = `${mixed[2]}${"0"}${mixed[1]}`
      } else {
        digits = `${mixed[2]}${mixed[1]}`
      }
      const alpha = mixed[3].charCodeAt(0)
      let key = parseInt(digits + alpha, 10)
      key = `${key}${mixed[0]}`
      index.push(key)
      forged[key] = {
        label: `${mixed[1]}${mixed[3]} / ${mixed[2]}Hz`,
        value: format,
      }
    })
    index.sort((a, b) => {
      return (a - b)
    })
    index.forEach((key) => {
      sorted.push({
        label: forged[key].label,
        value: forged[key].value,
      })
    })
    return sorted
  }

  _setAvio(item, current) {
    const API = "/player/config/output/avio_output_hdmi0/"
    const armAPI = "/avio/player/WyPlayer/output/hdmi0/"
    const type = Object.keys(item).pop()
    const armRequest = {
      "16_19_auto": "avio_video_arm_full",
      "4_3_auto": "avio_video_arm_full",
      "16_19_pillar": "avio_video_arm_box",
      "16_19_letter": "avio_video_arm_box",
    }
    return PUT(API, item)
      .then(() => {
        if (type === "aspect_ratio") {
          const armtype = item.action
          const armValue = {"arm": armRequest[armtype]}

          if (armtype === "16_19_letter") {
            PlayerManager.tvType = "Letter"
          } else if (armtype === "16_19_pillar") {
            PlayerManager.tvType = "Pillar"
          } else {
            PlayerManager.tvType = "Auto"
          }

          return PUT(armAPI,armValue).then(() => {
            return this.loadAspectRatio({reload: true})
          })
        } else if (type === "cvbs_config") {
          return this.loadCVBSConfig({reload: true})
        } else {
          const currentRes = current.val
          const closeCallback = () => {
            if (currentRes) {
              const item = {format: currentRes}
              return PUT(API, item)
                 .then(() => {
                   current.val = item.format
                   this.loadHdmi({reload: true})
                 })
            }
          }
          current.val = item.format
          const buttons = [
            {
              label: "Yes",
              action: () => {
                this.loadHdmi({reload: true})
              },
            },
            {
              label: "No",
              action: closeCallback,
            },
          ]
          popUpMsg.confirmResolution(buttons, closeCallback)
        }
      })
  }


  loadChannelBlockList() {
    const item = {
      context: "ChannelBlock",
      label: "Details",
    }
    bus.emit("settings:openChannel", item)
  }

  loadSysInfo() {
    const data = {
      "target": "rainette",
      "architecture": "remote",
      "version": "x.y.z.r",
    }

    const wyplayStb = navigator.userAgent.split(/WyplayStb/i)

    if (wyplayStb.length > 1) {
      const itemElts = wyplayStb[1]
        .split(/QtWebkit/i)[0]
        .replace(/\//g, " ")
        .replace(/^\ +/, "")
        .replace(/ $/,"")
        .split(" ")
      Object.keys(data).forEach((key, i) => {
        data[key] = itemElts[i] || "N/A"
      })
    }
    const item = {
      title: "System information",
      context: "SysInfo",
      label: "Details",
      data: data,
    }
    bus.emit("settings:subOpen", item)
  }

  loadFavorites() {
    bus.emit("settings:favorites:open")
  }

  @on("settings:openmyaccount")
  loadMyAccount() {
    const properties = {
      prop1: _("VC Number:"),
      prop2: _("Switch off date:"),
      prop3: _("Last Payment details:"),
      prop4: _("To update My Account, give a MISSED CALL on 1800-274-4744 from your RMN"),
    }

    getMyAccountDetails()
    .then((response) => {
      const values = {
        prop1: response.acntInfo_str.VSCNumber.toString(),
        prop2: formatDateOnly(myAccountTimestampToDate(response.acntInfo_str.ActualEndDate,"a")),
        prop3: " Rs. " + response.acntInfo_str.RechargeAmountInINR + _(" on ")
        + formatDateOnly(myAccountTimestampToDate(response.acntInfo_str.RechargeDate,"a")),
        prop4: "",
      }
      this._fillMyAccount(values,properties)
    })
    .catch(() => {
      const errorMsg = _("No information")
      const values = {
        prop1: errorMsg,
        prop2: errorMsg,
        prop3: errorMsg,
        prop4: "",
      }
      this._fillMyAccount(values,properties)
    })
  }

  _fillMyAccount(values,properties) {
    const data = {}
    for (const prop in properties) {
      if (properties.hasOwnProperty(prop)) {
        data[properties[prop]] = values[prop]
      }
    }
    const item = {
      title: _("My Account"),
      context: "myAccount",
      label: "",
      option:"Account",
      data: data,
    }
    bus.emit("settings:subOpen", item)
  }

  @on("settings:smsServices")
  loadSmsServices() {
    const properties = {
      prop1: _("Upgrade your pack:"),
      prop2: _("Order an A-La-Carte pack:"),
      prop3: _("For resolving no access/unsubscribed channel/card refresh errors:"),
      prop4: _("Register your Mobile No.:"),
    }

    const values = {
      prop1: _("DishTV up <Pack Price> <11 digit VC No.> to 57575"),
      prop2: _("DishTV add <a-la-carte code> <11 digit VC No.> to 57575"),
      prop3: _("DishTV refresh <11 digit VC No.> to 57575"),
      prop4: _("DishTV RMN <11 digit VC No.> to 57575"),
    }

    this._fillSmsServices(values,properties)
  }

  _fillSmsServices(values, properties) {
    const data = {}
    for (const prop in properties) {
      if (properties.hasOwnProperty(prop)) {
        data[properties[prop]] = values[prop]
      }
    }
    const item = {
      title: _("SMS Services"),
      context: "selfHelp",
      label: "",
      data: data,
    }
    bus.emit("settings:subOpen", item)
  }

  @on("settings:contactUs")
  loadContactUs() {
    const properties = {
      prop1: _("For any assistance, call us on:"),
      prop2: _("To get a call from us just SMS:"),
      prop3: _("Website:"),
    }

    const values = {
      prop1: _("1860-258-3474 (Local call charges apply)"),
      prop2: _("Call me to 57575 from your Registered Mobile Number."),
      prop3: _("dishtv.in"),
    }

    this._fillContactUs(values,properties)
  }

  _fillContactUs(values, properties) {
    const data = {}
    for (const prop in properties) {
      if (properties.hasOwnProperty(prop)) {
        data[properties[prop]] = values[prop]
      }
    }
    const item = {
      title: _("Contact Us"),
      context: "selfHelp",
      label: "",
      data: data,
    }
    bus.emit("settings:subOpen", item)
  }

  // time zone and time format
  loadUITimeFormat() {
    const itemsObj = {items: []}
    const timeformat = ["24h", "12h"]
    timeformat.forEach((timeFormat) => {
      itemsObj.items.push({
        label: timeFormat,
        action: () => {
          TimezoneManager.displayH24 = timeFormat === "24h"
          this.loadUITimeFormat()
            .then((data) => {
              bus.emit("hours:update")
              bus.emit("settings:setDefault", data)
            })
        },
        default: TimezoneManager.displayH24 === (timeFormat === "24h"),
      })
    })
    return Promise.resolve(itemsObj.items)
  }

  loadUITimeZoneFormat() {
    const itemsObj = {items: []}
    const ApiTimezones = "/time/timezones/"
    const ApiDefaultTimezones = "/time/timezone/"
    const timezoneLevel = {
      "Asia/Colombo": "SriLanka (GMT +05:30)",
      "Asia/Kolkata": "India (GMT +05:30)",
    }
    const timezoneSort = ["Asia/Kolkata", "Asia/Colombo"]
    return Promise.all([
      GET(ApiTimezones),
      GET(ApiDefaultTimezones),
    ])
    .then(([_, defaultTimezone]) => {
      this.defaultTimeZone = defaultTimezone.name
      if (!this.currentTimezone) {
        this.currentTimezone = defaultTimezone.name
      }

      timezoneSort.forEach((value) => {
        itemsObj.items.push({
          label: timezoneLevel[value],
          action: () => {
            this.currentTimezone = value
            updateTimeZone(value)
            this.loadUITimeZoneFormat()
             .then((data) => {
               bus.emit("settings:setDefault", data)
             })
          },
          default: this.currentTimezone.indexOf(value)  >= 0,
        })
      })
      return Promise.resolve(itemsObj.items)
    })
  }

  emptyCall() {
    return Promise.resolve(false)
  }

  @on("menuShortCut:STBInfo")
  loadStbInfo(option) {
    const vcno = CasManager.vscNumber
    const data = {
      "VC No:": vcno,
      "STB No:": Transponder.stbSerialNo,
      "Middleware Version:": "1.3",
      "Interface Version:": packages.version,
      "Call Center:": "1860-258-3474",
    }
    const wyplayStb = navigator.userAgent.split("/")
    if (wyplayStb.length > 1) {
      const itemElts = wyplayStb[wyplayStb.length-2].split(" ")
      data["Middleware Version:"] = itemElts[0]
    }
    if (option) this.option = option
    else this.option = false

    const item = {
      title: _("STB Information"),
      context: "StbInfo",
      label: _("Transponder Information"),
      data: data,
      hideStbInfo : this.option,
    }
    InstantMessageManager.isCAmenuOpen = true
    bus.emit("settings:stbInfoSheet", item)
  }

  loadScaleScreen() {
    bus.emit("settings:zoom")
  }
}
