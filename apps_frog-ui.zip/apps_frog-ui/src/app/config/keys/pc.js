//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import config from "../../../../config.json"

let rucMapping = null

const liberty = {
  UP: 38,            // Up Arrow
  DOWN: 40,          // Down Arrow
  LEFT: 37,          // Left Arrow
  RIGHT: 39,         // Right Arrow
  OK: 13,            // Enter
  BACK: 8,           // Backspace
  INFO: 73,          // i
  HOME: 72,          // h
  PROGRAM_PLUS: 33,  // PageUp
  PROGRAM_MINUS: 34, // PageDown
  VOLUME_PLUS: 43,   // +
  VOLUME_MINUS: 45,  // -
  FAST_REWIND: 74,   // j
  FAST_FORWARD: 75,  // k
  MUTE: 77,          // m
  REC: 69,           // e
  PLAY: 32,          // Space
  PAUSE: 80,         // p
  STOP: 83,          // s
  POWER: 27,         // Escape
  KEY_0: 48,         // KP 0
  KEY_1: 49,         // KP 1
  KEY_2: 50,         // KP 2
  KEY_3: 51,         // KP 3
  KEY_4: 52,         // KP 4
  KEY_5: 53,         // KP 5
  KEY_6: 54,         // KP 6
  KEY_7: 55,         // KP 7
  KEY_8: 56,         // KP 8
  KEY_9: 57,         // KP 9
  KEY_FAV: 113,      // F2
  AD: 114,           // F3
  MYFILES: 115,      // F4
  LANG: 116,         // F5
  MYACC: 117,        // F6
  MOD: 118,          // F7
  EPG: 119,          // F8
  KEY_RED: 120,      // F9
  KEY_GREEN: 121,    // F10
  KEY_YELLOW: 122,   // F11
  KEY_BLUE: 123,     // F12
}

const sdZapper = {
  UP: 38,            // Up Arrow
  DOWN: 40,          // Down Arrow
  LEFT: 37,          // Left Arrow
  RIGHT: 39,         // Right Arrow
  OK: 13,            // Enter
  BACK: 8,           // Backspace
  INFO: 73,          // i
  HOME: 72,          // h
  PROGRAM_PLUS: 33,  // PageUp
  PROGRAM_MINUS: 34, // PageDown
  VOLUME_PLUS: 43,   // +
  VOLUME_MINUS: 45,  // -
  MUTE: 77,          // m
  POWER: 27,         // Escape
  KEY_0: 48,         // KP 0
  KEY_1: 49,         // KP 1
  KEY_2: 50,         // KP 2
  KEY_3: 51,         // KP 3
  KEY_4: 52,         // KP 4
  KEY_5: 53,         // KP 5
  KEY_6: 54,         // KP 6
  KEY_7: 55,         // KP 7
  KEY_8: 56,         // KP 8
  KEY_9: 57,         // KP 9
  KEY_FAV: 113,      // F2
  AD: 114,           // F3
  LANG: 116,         // F5
  MYACC: 117,        // F6
  MOD: 118,          // F7
  EPG: 119,          // F8
  KEY_RED: 120,      // F9
  KEY_GREEN: 121,    // F10
  KEY_YELLOW: 122,   // F11
  KEY_BLUE: 123,     // F12
  EXIT : 81,         // q
  PREVIOUS_CHANNEL : 88, // x
  HELP : 90,          // j
  TOOLS : 84,         // t
  MAIL : 67,          // c
  REMINDER : 66,      // b
}


if (config.sdzapper) {
  rucMapping = Object.assign({},sdZapper)
} else {
  rucMapping = Object.assign({},liberty)
}

const keys = rucMapping

keys.ANY = Object.keys(keys).map((key) => {
  return keys[key]
})

keys.ANY_NUMERIC = [
  keys.KEY_0,
  keys.KEY_1,
  keys.KEY_2,
  keys.KEY_3,
  keys.KEY_4,
  keys.KEY_5,
  keys.KEY_6,
  keys.KEY_7,
  keys.KEY_8,
  keys.KEY_9,
]

export {keys as pc}
