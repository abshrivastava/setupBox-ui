//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

/**class:: Controller()
 */
export default class Controller {
  static delegates = []

  constructor() {
    /** attribute:: controller.activeDelegate
     * Child controller to delegate actions to, or null.
     *
     *   :type: Controller
     */
    this.activeDelegate = null

    /** attribute:: controller.delagates
     * List of delegate controller instances.
     *
     *   :type: Array<Controller>
     *   :private:
     */
    this.delegates = []

    /** attribute:: controller.displayName
     * Name of the controller without "Controller"
     *
     *   :type: String
     */
    this.displayName = this.constructor.name.replace("Controller", "")

    // Instantiate delegate controllers and register them as children
    for (const delegate of this.constructor.delegates.values()) {
      const instance = new delegate()
      this[instance.displayName] = instance
      instance.master = this
      this.delegates.push(instance)
    }
  }
}
