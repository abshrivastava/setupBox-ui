//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {_, locale} from "utils/locale"
import {padLeft} from "./string"

export const UPNP_DELTA = 2208988800

const IST_TIME_530 = 19800000

const DAY = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
]
export const MONTH = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

/**function:: utils.date.addHours(d, h)
 * Returns a new Date Object that adds the specified number of hours to the given Date Object..
 *
 *   :param date d: Date Object or timestamp
 *   :param int h: hours to add
 *   :returns Date:
 *
 * .. code-block:: js
 *
 *    addHours(new Date(0), 1) // => Thu Jan 01 1970 02:00:00 GMT+0100 (CET)
 */
export function addHours(d, h) {
  const date = new Date(d)
  date.setHours(date.getHours() + h)
  return date
}

/**function:: utils.date.addMinutes(d, m)
 * Returns a new Date Object that adds the specified number of minutes to the given Date Object..
 *
 *   :param date d: Date Object or timestamp
 *   :param int m: minutes to add
 *   :returns Date:
 *
 * .. code-block:: js
 *
 *    addHours(new Date(0), 17) // => Thu Jan 01 1970 01:17:00 GMT+0100 (CET)
 */
export function addMinutes(d, m) {
  const date = new Date(d)
  date.setMinutes(date.getMinutes() + m)
  return date
}

export function subtractMinutes(d, m) {
  const date = new Date(d)
  date.setMinutes(date.getMinutes() - m)
  return date
}

/**function:: utils.date.unixToUpnp(unixTimestamp)
 * Returns a UPNP Timestamp (in seconds) from given UNIX Timestamp (in seconds)
 *
 *   :param int unixTimestamp: unix timestamp
 *   :returns Int:
 *
 * .. code-block:: js
 *
 *    unixToUpnp(new Date(0).getTime()) // => 2208988800 (s)
 */
export function unixToUpnp(unixTimestamp) {
  return unixTimestamp + UPNP_DELTA
}

/**function:: utils.date.upnpToUnix(unixTimestamp)
 * Returns an Unix Timestamp (in ms) from given UPNP Timestamp (in ms)
 *
 *   :param int upnpTimestamp: unix timestamp
 *   :returns Int:
 *
 * .. code-block:: js
 *
 *    unixToUpnp(2208988800) //=> 0 (s)
 */
export function upnpToUnix(upnpTimestamp) {
  return upnpTimestamp - UPNP_DELTA
}

/**function:: utils.date.dateToCdsTimestamp(unixTime)
 * Returns the NTP timestamp of the given date in seconds
 *
 *   :param Date unixTime: Unix Date object
 *   :returns Int:
 *
 * .. code-block:: js
 *
 *    dateToCdsTimestamp(new Date(0)) //=> 2208988800 (s)
 */
export function dateToCdsTimestamp(unixTime) {
  return unixToUpnp(~~(unixTime / 1000))
}

/**function:: utils.date.cdsTimestampToDate(upnpTimestamp)
 * Returns a Date Obejct representing the given UPNP timestamp
 *
 *   :param int unixTime: Unix Date object
 *   :returns Date:
 *
 * .. code-block:: js
 *
 *    cdsTimestampToDate(2208988800) //=> Thu Jan 01 1970 01:00:00 GMT+0100 (CET)
 */
export function cdsTimestampToDate(upnpTimestamp) {
  const t = 1000 * upnpToUnix(upnpTimestamp)
  return new Date(t)
}

/**function:: utils.date.myAccountTimestampToDate(upnpTimestamp)
 * Returns a Date Obejct representing the given UPNP timestamp
 *
 *   :param int unixTime: Unix Date object
 *   :returns Date:
 *
 * .. code-block:: js
 *
 *    myAccountTimestampToDate(2208988800) //=> Thu Jan 01 1970 01:00:00 GMT+0100 (CET)
 */
export function myAccountTimestampToDate(upnpTimestamp,type) {
  if (type === "a") {
    return new Date((upnpTimestamp*1000)-IST_TIME_530)
  } else {
    return new Date((upnpTimestamp*1000))
  }
}

/**function:: utils.date.formatDateOnly(date)
 * Returns a String 'DayNumber Mon Year' of given Date object
 *
 *   :param Date date: Date object
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    formatDate(new Date(0)) //=> 01/01/1970
 */
export function formatDateOnly(date) {
  if (!isValidDate(date)) {
    return
  }
  function pad(s) {
    return (s < 10) ? "0" + s : s
  }
  const d = new Date(date)
  return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join("/")
}


/**function:: utils.date.formatDate(date)
 * Returns a String 'Day Mon DayNumber Year' of given Date object
 *
 *   :param Date date: Date object
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    formatDate(new Date(0)) //=> Thu January 1st 1970
 */
export function formatDate(date) {
  if (!isValidDate(date)) {
    return
  }
  const day = date.toString().substr(0,3)
  const dateNumber = date.getDate()
  const month = MONTH[date.getMonth()]
  const year = date.getFullYear()

  let string = _("{day} {month} {dateNumber}{nth} {year}")
  string = string.replace("{day}", _(day))
  string = string.replace("{month}", _(month))
  string = string.replace("{dateNumber}", dateNumber)
  string = string.replace("{nth}", nth(dateNumber))
  string = string.replace("{year}", year)
  return string
}

/**function:: utils.date.formatTime(date)
 * Returns a String "Hours:Minutes "of given Date object
 *
 *   :param Date date: Date object
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    formatTime(new Date(0)) //=> 01:00
 */
export function formatTime(date, isH24=false) {
  if (!isValidDate(date)) {
    return ""
  }

  const hours = padLeft(String(date.getHours()), "0", 2)
  const minutes = padLeft(String(date.getMinutes()), "0", 2)

  return transformTime(`${hours}:${minutes}`, isH24)
}

export function transformTime(time, isH24=false) {
  const hours = time.split(":")[0]
  const minutes = time.split(":")[1]
  if (isH24) {
    return `${hours}:${minutes}`
  } else {
    switch (true) {
    case (hours.toString() === "0"):
    case (hours.toString() === "00"):
      return `12:${minutes} am`
    case (hours.toString() === "12"):
      return `${hours}:${minutes} pm`
    case (hours > 12):
      return `${hours-12}:${minutes} pm`
    case (hours < 12):
      return `${hours}:${minutes} am`
    }
  }
}

/**function:: utils.date.formatDuration(duration)
 * Returns a String "Hours:Minutes "of given duration (in seconds)
 *
 *   :param int duratin,: duration in seconds
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    formatDuration(3600) //=> 60min
 */
export function formatDuration(duration) {
  if (typeof duration !== "number" || duration < 0) {
    throw new Error("invalid duration")
  }

  const seconds = duration
  const minutes = ~~(seconds / 60)

  if (minutes) {
    return `${minutes}min`
  }
  return `${seconds}s`
}

/**function:: utils.date.toDayString(date)
 * Returns a String "Day "of given date Object
 *
 *   :param Date date,: Date object
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    toDayString(new Date(0)) //=> Thursday
 */
export function toDayString(d) {
  if (!isValidDate(d)) {
    throw new Error("invalid date")
  }
  const date = new Date(d)
  const day = DAY.slice(date.getDay() - 1)[0]
  return _(day)
}

/**function:: utils.date.toDateString(date)
 * Returns a String "Day "of given date Object
 *
 *   :param Date date,: Date object
 *   :returns String:
 *
 * .. code-block:: js
 *
 *    toDateString(3600) //=> December 1st
 */
export function toDateString(d) {
  if (!isValidDate(d)) {
    throw new Error("invalid date")
  }
  const date = new Date(d)
  const dateNumber = date.getDate()
  const month = MONTH[date.getMonth()]

  let string = _("{month} {dateNumber}{nth}")
  string = string.replace("{month}", _(month))
  string = string.replace("{dateNumber}", dateNumber)
  string = string.replace("{nth}", nth(dateNumber))
  return string
}

export function toClockDateString(d) {
  if (!isValidDate(d)) {
    throw new Error("invalid date")
  }
  const date = new Date(d)
  const dateNumber = date.getDate()
  const month = MONTH[date.getMonth()]

  let string = _("{dateNumber}{nth} {month}")
  string = string.replace("{dateNumber}", dateNumber)
  string = string.replace("{nth}", nth(dateNumber))
  string = string.replace("{month}", _(month))
  return string
}

export function toString(d) {
  let day
  let date
  try {
    day = toDayString(d)
    date = toDateString(d)
  } catch (err) {
    return ""
  }
  return day + ", " + date
}

export function nth(d) {
  if (locale._currentLocale !== "eng") return ""
  if (d > 3 && d < 21) {
    return "th"
  }
  switch (d % 10) {
  case 1:
    return "st"
  case 2:
    return "nd"
  case 3:
    return "rd"
  default:
    return "th"
  }
}

export function exists(d, m, y) {
  const date = new Date(y, m - 1, d, 0, 0, 0, 0)
  return !isNaN(date) &&
    (date.getDate() === d) &&
    (date.getMonth() === (m - 1)) &&
    (date.getFullYear() === y) && (y > 0)
}

export function convertFullDate(date) {
  let dt = date.getDate()
  if (dt < 10) dt = `0${dt}`
  let dm = date.getMonth()
  dm++
  if (dm < 10) dm = `0${dm}`
  return date.getFullYear() + "" + dm + "" + dt
}

function isValidDate(date) {
  return (date instanceof Date && !isNaN(date.getTime()))
}
