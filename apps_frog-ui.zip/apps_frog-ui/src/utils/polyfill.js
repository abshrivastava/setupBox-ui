//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

/** Object.assign()
 * Based on MDN's `Object.assign Polyfill https://mdn.io/assign#Polyfill`__ (Public Domain)
 *
 * The Object.assign() method is used to copy the values of all enumerable own properties from one or more source
 * objects to a target object. It will return the target object.
 *
 *  :param Object target: The target object.
 *  :returns Object: The target object gets returned.
 *
 * Cloning an object
 *
 * .. code-block:: js
 *
 *    var obj = {a: 1}
 *    var copy = Object.assign({}, obj);
 *    console.log(copy); //=> { a: 1 }
 *
 * Merging objects
 *
 * .. code-block:: js
 *
 *    var o1 = { a: 1 };
 *    var o2 = { b: 2 };
 *    var o3 = { c: 3 };
 *
 *    var obj = Object.assign(o1, o2, o3);
 *    console.log(obj); //=> { a: 1, b: 2, c: 3 }
 *    console.log(o1);  //=> { a: 1, b: 2, c: 3 }, target object itself is changed.
 *
 * Copying symbol-typed properties
 *
 * .. code-block:: js
 *
 *    var o1 = { a: 1 };
 *    var o2 = { [Symbol('foo')]: 2 };
 *
 *    var obj = Object.assign({}, o1, o2);
 *    console.log(obj); // { a: 1, [Symbol("foo")]: 2 }
 */
Object.assign = function(target) {
  "use strict"
  if (target === undefined || target === null) {
    throw new TypeError("Cannot convert undefined or null to object")
  }

  const output = Object(target)
  for (let index = 1; index < arguments.length; index++) {
    const source = arguments[index]
    if (source !== undefined && source !== null) {
      for (const nextKey in source) {
        if (source.hasOwnProperty(nextKey)) {
          output[nextKey] = source[nextKey]
        }
      }
    }
  }
  return output
}

Array.prototype.equals = function(a) {
  // If the array to compare is falsy, not an array or not same size
  if (!a || !(a instanceof Array) || this.length !== a.length) {
    return false
  }

  return this.every(function(v, i) {
    return v === a[i]
  })
}
Object.defineProperty(Array.prototype, "equals", {enumerable: false})
