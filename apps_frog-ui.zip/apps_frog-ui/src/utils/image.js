//
// Copyright (C) 20062016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

export function testImage(dom, src, fallback = null) {
  return new Promise((resolve) => {
    testImageUrl(src, fallback).then((imgResult) => {
      dom.src = imgResult
      resolve()
    })
  })
}

export function testImageUrl(src, fallback) {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => resolve(src)
    img.onerror = () => resolve(fallback)
    img.src = src
  })
}