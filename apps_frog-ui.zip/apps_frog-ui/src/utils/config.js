//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

const searchString = typeof window !== "undefined" ? window.location.search : ""
const QS = new Map(searchString
  .slice(1)
  .split("&")
  .map(pairs => {
    const [key, value] = pairs.split("=", 2)
    const stringToBoolean = {
      "0": false,
      "false": false,
      "no": false,
      "1": true,
      "true": true,
      "yes": true,
    }

    if (value in stringToBoolean) {
      return [key, stringToBoolean[value]]
    }

    return [key, decodeURIComponent(value) || true]
  })
)

const config = {
  _defaults: {},

  setDefaults(defaults) {
    this._defaults = defaults
  },

  defineFlag(name, urlFlag, separator = null) {
    const value = this._getConfigFlag(urlFlag)

    this[name] = (separator !== null) ? value.split(separator) : value
  },

  _getConfigFlag(flag) {
    const qsFlag = QS.get(flag)

    if (qsFlag !== undefined) {
      return qsFlag
    }

    return this._defaults[flag]
  },
}

export default config

