//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import CircularListController from "./controllers/CircularListController"

/**
 * @typedef {Object} ListViewOptions
 * @example
 * // By default will create DOM like This
 * // <div className="List">
 * //  <div className="SelectorList"></div>
 * //   <div className="ItemsList">
 * //     <div className="Item">
 * //       <div className="Item-title" prop="title" />
 * //       ...
 * //       ...
 * //       <div className="Item-title" prop="title" />
 * //     </div>
 * //   </div>
 * // </div>
 *
 * // Default options:
 * {
*   "selectorView" : SelectorListView,
*   "itemView" : ItemView,
*   "wrapperName" : "List",
*   },
 * }
 *
 * @property {Component}} [selectorView] - Options to set the view used
 * for the SelectorList
 * @property {Component}} [listView] - Options
 * to set the view used for the List and the classname
 * @property {Component} [ItemView] - Option to set the view used
 * for one Item
 * @property {{view: Component}} [wrapper] - Option to set the className for
 * the wrapper div
 *
 */

/**
 * Widget for Circular Lists
 */
export default class CircularList extends CircularListController {
   /**
   * ListWidget constructor
   *
   * @name constructor
   * @public
   * @param {!Array<Object>} [items] - Non empty Array of Object
   * @param {!Node} [parentNode] - Parent Node, this widget will insert himself
   * inside this Node
   * @param {!ListView} [viewClass] - ListView class to use
   * @param {?ListControllerOptions} [optionsctrl=null] - ListController
   * options
   * @param {?ListViewOptions} [optionsview=null] - ListView options
   * @param {!Object} [defaultItem] - item selected by default
   */
  constructor(items, parentNode, viewClass, optionsctrl, optionsview, defaultItem) {
    super(items, optionsctrl)
    /**
     * @type {ListView} [view] - ListView class to use
     */

    this.view = new viewClass(optionsview)
    parentNode.appendChild(this.view.build())
    this.select(0)
    if (defaultItem) {
      this.selectItem(defaultItem)
    }
  }
}
