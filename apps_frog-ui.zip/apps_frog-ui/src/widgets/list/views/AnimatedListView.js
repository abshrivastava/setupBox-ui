//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//


import Component from "widgets/Component"
import ListView from "./ListView"

export default class AnimatedListView extends ListView {
  static defaultOptions = {
    "ITEM_HEIGHT": 36,
    "ITEM_SELECTED_HEIGHT": 50,
  }

  constructor(options) {
    super(options)

    this.options = Object.assign(this.options, this.constructor.defaultOptions,
      options)
    this.rangeItem = []
    this.selectedNode = null

  }

  _buildItems(range, idx) {
    for (let i = 0; i < range.length; i++) {
      const node = new this.itemView()
      this.rangeItem.push(node)
      this.itemsList.dom.appendChild(node.build())
    }
    range.forEach(itm => {
      const node = new this.itemView(itm)
      this.rangeItem.push(node)
      this.itemsList.dom.appendChild(node.build())
    })
    for (let i = 0; i < range.length; i++) {
      const node = new this.itemView()
      this.rangeItem.push(node)
      this.itemsList.dom.appendChild(node.build())
    }
    this.selectedNode = this.rangeItem[range.length+idx]
    this.updatePositions()
    this.selectedNode.pushState("selected")
  }

  update(range, idx, moveIdx) {
    if (!this.rangeItem.length && range.length > 0) {
      this._buildItems(range, idx)
    }

    if (moveIdx === 0) {
      return
    }
    if (moveIdx > 0) {
      const nb = moveIdx >= range.length ? range.length : moveIdx
      for (let i = 0 ; i < nb ; i++) {
        this.rangeItem[range.length*2].update(range[range.length-nb+i])
        this.rangeItem[0].flush()
        this.rangeItem.push(this.rangeItem.shift())
      }
    } else {
      const nb = -moveIdx >= range.length ? range.length : -moveIdx
      for (let i = 0; i < nb ; i++) {
        this.rangeItem[range.length-1].update(range[nb-1-i])
        this.rangeItem[this.rangeItem.length - 1].flush()
        this.rangeItem.unshift(this.rangeItem.pop())
      }
    }
    this.selectedNode.pullState("selected")
    this.selectedNode = this.rangeItem[range.length+idx]
    this.updatePositions()
  }

  _setSelectedNode() {
    this.selectedNode.pushState("selected")
    this.selectedNode.removeTransitionListener(this._setSelectedNode)
  }

  updatePositions() {
    const start = this.rangeItem.length / 3
    const selectedIdx = this.rangeItem.indexOf(this.selectedNode)

    let y = -(start * this.options.ITEM_HEIGHT)

    for (let i = 0 ; i < this.rangeItem.length; i++) {
      this.rangeItem[i].dom.style.webkitTransform = `translate3d(0, ${y}px, 0)`
      if (i === selectedIdx) {
        this.rangeItem[i].removeTransitionListener(
          this._setSelectedNode.bind(this))
        this.rangeItem[i].addTransitionListener(
          this._setSelectedNode.bind(this))
      }
      y += (i === selectedIdx) ? this.options.ITEM_SELECTED_HEIGHT :
        this.options.ITEM_HEIGHT
    }
  }
}
