//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Component from "widgets/Component"
import SelectorList from "./SelectorListView"
import ItemsList from "./ItemsListView"
import Item from "./ItemView"

export default class ListView extends Component {
  static defaultListViewOptions = {
    "selectorView" : SelectorList,
    "listView" : ItemsList,
    "itemView" : Item,
    "wrapperName": "List",
  }

  constructor(options) {
    super(options)
    this.options = Object.assign({}, this.constructor.defaultListViewOptions,
      options)

    this.selector = new this.options.selectorView()
    this.itemsList = new this.options.listView()
    this.itemView = this.options.itemView
    this.classname = this.options.wrapperName
  }

  build() {
    super.build()
    this.dom.appendChild(this.selector.build())
    this.dom.appendChild(this.itemsList.build())
    return this.dom
  }

  onFocus() {
    this.pushState("selected")
    this.selector.pushState("selected")
  }

  onBlur() {
    this.pullState("selected")
    this.selector.pullState("selected")
  }

  getSelector() {
    return this.selector.dom
  }

  getItemList() {
    return this.itemsList.dom
  }

  update() {
    throw new Error("Don't instanciate ListView!")
  }

  render() {
    return (
      <div className={`${this.classname}`}/>
    )
  }
}
