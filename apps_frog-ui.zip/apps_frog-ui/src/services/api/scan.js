//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT, DELETE} from "../http"

/** function:: start(options)
 * Start a scan session on a device.
 *
 *   :param Object options: {"device_id":"1","transponder_set_id":"1","scan_type":"1","scan_param":["49156","279"]}
 *   :returns Promise:
 */
export function start(options) {
  return PUT("/scan/start", options)
}

/** function:: stop(options)
 * Stop the scan process that is currently running on a given device.
 *
 *   :param Object options: {"device_id":"1"}
 *   :returns Promise:
 */
export function stop(options) {
  return PUT("/scan/stop", options)
}

/** function:: commit(options)
 * Commit Scanned services: stores services found in database
 *
 *   :param Object options: {"device_id":"1"}
 *   :returns Promise:
 */
export function commit(options) {
  return PUT("/scan/commit", options)
}

/** function:: rollback(options)
 * Rollback scanned services, ignore services found.
 *
 *   :param Object options: {"device_id":"1"}
 *   :returns Promise:
 */
export function rollback(options) {
  return PUT("/scan/rollback", options)
}

/** function:: removeAllServices(options)
 * Remove all services in the database.
 *
 *   :returns Promise:
 */
export function removeAllServices() {
  return PUT("/scan/remove_all_services")
}

/** function:: removeAllServicesWithoutFav(options)
 * Remove all services in the database except Favorites.
 *
 *   :returns Promise:
 */
export function removeAllServicesWithoutFav() {
  return PUT("/scan/remove_all_services_without_favorites")
}

/** function:: removeAllTransponders(transponderSetId)
 * Deletes all the transponders of the specified transponder set and all the services associated to these transponder.
 *
 *   :param Int transponderSetId: Transponder Set Identifier from wyscan
 *   :returns Promise:
 */
export function removeAllTransponders(transponderSetId) {
  return DELETE(`/scan/transponder_set/${transponderSetId}/`)
}

/** function:: getAllTransponderSet()
 * Get list of available set of transponders.
 *
 *   :returns Promise:
 */
export function getAllTransponderSet() {
  return GET("/scan/transponder_set/")
}

/** function:: getTransponderSet(transponderSetId)
 * Get transponder set properties.
 *
 *   :param Int transponderSetId: Transponder Set Identifier from wyscan
 *   :returns Promise:
 */
export function getTransponderSet(transponderSetId) {
  return GET(`/scan/transponder_set/${transponderSetId}/`)
}

/** function:: getAllTransponders(transponderSetId)
 * Get list of available transponders from a specific transponder set.
 *
 *   :param Int transponderSetId: Transponder Set Identifier from wyscan
 *   :returns Promise:
 */
export function getAllTransponders(transponderSetId) {
  return GET(`/scan/transponder_set/${transponderSetId}/transponder/`)
}

/** function:: getTransponder(transponderSetId, transponderId)
 * Get transponder properties from a specific transponder set.
 *
 *   :param Int transponderSetId: Transponder Set Identifier from wyscan
 *   :param Int transponderId: Transponder Identifier from wyscan
 *   :returns Promise:
 */
export function getTransponder(transponderSetId, transponderId) {
  return GET(`/scan/transponder_set/${transponderSetId}/transponder/${transponderId}/`)
}

export function softwareUpdate(options) {
  return PUT("/software/update/", options)
}
export function getSoftwareVersion() {
  return GET("/software/version/")
}

export function getAntennas() {
  return GET("/antennas/")
}

export function getAntenna(id) {
  return GET(`/antennas/${id}/`)
}

export function setAntenna(id, options) {
  return PUT(`/antennas/${id}/`, options)
}

/** function:: listTune()
 * Returns a list of all the existing tune requests on all the tuner devices.
 *
 *   :returns Promise:
 */
export function listTune() {
  return GET("/scan/tune/")
}

/** function:: addTune(options)
 * Creates a tune request for a transponder, based on a wydvb URI.
 * The tune request is asynchronous: you receive the TuneStateUpdate signal when tuner state is updated.
 * You can make several tune requests: their completion depends on on-going requests and their priorities.
 *
 *   :param Object options: {"wydvb_uri":
 *                    "wydvb://dvbs/?frequency=12551500&modulation=Auto&code_rate=5/6&symbol_rate=22000000&polarity=V"}
 *   :returns Promise:
 */
export function addTune(options) {
  return POST("/scan/tune/", options)
}

/** function:: updateTune(id, options)
 * Updates the parameters of an existing tune request by providing a new wydvb URI.
 *
 *   :param Int id: Tune request identifier, returned by addTune
 *   :param Int options: {"wydvb_uri":
 *                    "wydvb://dvbs/?frequency=12551500&modulation=Auto&code_rate=5/6&symbol_rate=22000000&polarity=V"}
 *   :returns Promise:
 */
export function updateTune(id, options) {
  return PUT(`/scan/tune/${id}/`, options)
}

/** function:: removeTune(id)
 * Deletes an existing tune request, freeing the tuner device for other requests.
 *
 *   :param Int id: Tune request identifier, returned by addTune
 *   :returns Promise:
 */
export function removeTune(id) {
  return DELETE(`/scan/tune/${id}/`)
}

/** function:: removeAllTune()
 * Deletes all tune, freeing the tuner device for other requests.
 *
 *   :returns Promise:
 */
export function removeAllTune() {
  return DELETE("/scan/tune/removeall/")
}

/** function:: resetScan(id)
 * Removes all the services and transponders matching the specified transponder set identifier.
 *
 *   :param Int id: Transponder set identifier.
 *   :returns Promise:
 */
export function resetScan(id) {
  return PUT(`/scan/transponder_set/${id}/reset`)
}


/** function:: getTransmitterId(id)
 * Get the transmitter_id on a transponder set. The transmitter_id is the id to identify a antenna configuration.
 *
 *   :param Int id: Transponder set identifier.
 *   :returns Promise:
 */
export function getTransmitterId(id) {
  return GET(`/scan/transponder_set/${id}/transmitter_id/`)
}

/** function:: setTransmitterId(tpsId, id)
 * Update the transmitter_id on a transponder set. The transmitter_id is the id to identify a antenna configuration.
 *
 *   :param Int tpsId: Transponder set identifier.
 *   :param Int id: Transmitter identifier.
 *   :returns Promise:
 */
export function setTransmitterId(tpsId, id) {
  return PUT(`/scan/transponder_set/${tpsId}/transmitter_id/`, {"id": id})
}

export function getSvlVersion() {
  return GET("/dvbversion/")
}

export function getDynamicForceSlide() {
  return GET("/scan/dynamicFS/")
}

export function getDynamicLandingChannel() {
  return GET("/scan/defaultLC/")
}

export function getDynamicGracePerods() {
  return GET("/scan/graceLC/")
}

export default {
  start,
  stop,
  commit,
  rollback,
  removeAllServices,
  removeAllServicesWithoutFav,
  removeAllTransponders,
  getAllTransponderSet,
  getTransponderSet,
  getAllTransponders,
  getTransponder,
  softwareUpdate,
  getSoftwareVersion,
  getAntennas,
  getAntenna,
  setAntenna,
  getSvlVersion,
  listTune,
  addTune,
  updateTune,
  removeTune,
  removeAllTune,
  resetScan,
  getTransmitterId,
  setTransmitterId,
  getDynamicForceSlide,
  getDynamicLandingChannel,
  getDynamicGracePerods,
}
