//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {
  POST,
  GET,
  DELETE,
  createQueryString,
  sse,
} from "services/http"
import bus from "services/bus"

/**
 * Criteria class
 * @example
 * const crit = new Criteria()
 * crit.add("title", "==", "The Expendables")
 * crit.add("start_date", ">=", 3481634735)
 * crit.add("service_id", "in", [36258114307591, 36258114307592])
 * crit.toString()
 */
class Criteria {
  /**
   * Criteria constructor
   */
  constructor() {
    /**
     * @type {string[]} criteria
     */
    this.criteria = []

    /**
     * @type {Array<string>} _operators
     */
    this._operators = Object.freeze(["==", "!=", "in", "<", ">", "<=", ">="])
  }

  /**
   * Format a value in a correct criteria string
   * @param {string|number|Array<string|number>} value - The value to format
   * @return {string} A criteria formatted String
   * @throws {TypeError} throw error if value type is not correct
   */
  _formatData(value) {
    if (typeof value === "string") {
      return value
    } else if (typeof value === "number") {
      return String(value)
    } else if (Array.isArray(value)) {
      value = value.map(i => `'${i}'`) // Add quotes around ids
      return `{${value.join(",")}}`
    } else {
      throw new TypeError(`Unknow format of value ${value}`)
    }
  }

  /**
   * Add a criteria
   * @param {string} key - The criteria key
   * @param {string} operator - Criteria._operators to use
   * @param {string|number|Array<string|number>} value - The value to match
   */
  add(key, operator, value) {
    if (this._operators.indexOf(operator) === -1) {
      throw new TypeError(`Unknow operator ${operator} for key ${key}. ` +
        `Operator must be one of ${this._operators.join(", ")}`)
    }
    if (operator === "in" && !Array.isArray(value)) {
      throw new TypeError(`The value for key ${key} and operator ${operator} must be an array`)
    }

    this.criteria.push(`${key} ${operator.toUpperCase()} ${this._formatData(value)}`)
  }

  /**
   * Return the string for all the criterias
   * @return {string} criteria string.
   */
  toString() {
    return this.criteria.join(" AND ")
  }
}

/**
 * CDSQuery class to be used to create CDS queries
 */
class CDSQuery {
  /**
   * constructor
   */
  constructor(type, params) {
    this._type = type
    this._params = params
    this._onOutdatedSignal = this._onOutdatedSignal.bind(this)
    this._onUpdatedSignal = this._onUpdatedSignal.bind(this)
    this._onDelSignal = this._onDelSignal.bind(this)
    this._onAddSignal = this._onAddSignal.bind(this)
  }

  get href() {
    return this._href
  }

  _registerOutdatedSignal() {
    const filter = {
      subtype: `${this._type}_event`,
      content: {
        event_data: "outdated",
      },
      href: this.href,
    }
    sse.on(this._type, this._onOutdatedSignal, filter)
  }

  _registerAddSignal() {
    const filter = {
      subtype: `${this._type}_add`,
      href: this.href,
    }
    sse.on(this._type, this._onAddSignal, filter)
  }

  _registerDelSignal() {
    const filter = {
      subtype: `${this._type}_del`,
      href: this.href,
    }
    sse.on(this._type, this._onDelSignal, filter)
  }

  _registerUpdatedSignal() {
    const filter = {
      subtype: `${this._type}_upd`,
      href: this.href,
    }
    sse.on(this._type, this._onUpdatedSignal, filter)
  }

  _unregisterAddSignal() {
    sse.off(this._type, this._onAddSignal)
  }

  _unregisterDelSignal() {
    sse.off(this._type, this._onDelSignal)
  }

  _unregisterOutdatedSignal() {
    sse.off(this._type, this._onOutdatedSignal)
  }

  _unregisterUpdatedSignal() {
    sse.off(this._type, this._onUpdatedSignal)
  }

  _onOutdatedSignal() {
    this.close()
      .then(() => this.create())
      .then(() => {
        bus.emit("cds_query:outdated", this)
      })
  }

  _onUpdatedSignal() {
    bus.emit("cds_query:updated", this)
  }

  _onDelSignal(event) {
    bus.emit("cds_query:del", this, event.content)
  }

  _onAddSignal(event) {
    bus.emit("cds_query:add", this, event.content)
  }

  create(attempts = 0) {
    const route = `/${this._type}/`
    if (attempts > 0) {
      console.warn("Trying to create CDS query again: " + attempts)
    }
    return POST(route, this._params).then((retVal) => {
      if (retVal.href) {
        return this.onNewQueryCreated(retVal.href)
      } else if (retVal.error) {
        if (attempts < 10) {
          return this.create(attempts + 1)
        }
        return Promise.reject("Aborting creation after failed attempts: " + attempts)
      } else {
        console.error("Unexpected response to query creation")
        return Promise.reject("Unexpected response to query creation")
      }
    })
  }

  onNewQueryCreated(href) {
    this._href = href
    this._registerUpdatedSignal()
    this._registerOutdatedSignal()
    this._registerDelSignal()
    this._registerAddSignal()
    return this.count().then((count) => this.queryCount = count)
  }

  _GET(route) {
    // TODO : Possible that this line return 0 values in returned object...
    return GET(route).then(data => Object.values(data)[0])
  }

  itemIdx(itemHref) {
    const route = `${this._href}index/?href=${itemHref}`
    return this._GET(route)
  }

  data(startIdx, count, metadata) {
    let route = `${this._href}?startIndex=${startIdx}&MaxCount=${count}`
    if (metadata) {
      route += `&metadata=${metadata.toString()}`
    }
    return this._GET(route)
  }

  all() {
    const route = `${this._href}`
    return this._GET(route)
  }

  count() {
    const route = `${this._href}count/`
    return this._GET(route)
  }

  close() {
    this._unregisterDelSignal()
    this._unregisterAddSignal()
    this._unregisterUpdatedSignal()
    this._unregisterOutdatedSignal()
    return DELETE(this._href)
  }
}

/*
 * CDSQueryFactory
 **/
export default class CDSQueryFactory {
  constructor(type) {
    this._type = type

    this._criteria = new Criteria()
    this._metadata = []
    this._params = {}
    this._order = []
    this._limit = 0
  }

  getParams() {
    const params = this._params

    const criteria = this._criteria.toString()
    if (criteria.length) {
      params.criteria = criteria
    }

    if (this._limit > 0) {
      params.max_count = this._limit
    }

    if (this._metadata.length) {
      params.metadata = this._metadata
    }

    if (this._order.length) {
      params.order = this._order
    }

    return params
  }

  direct() {
    const queryEnd = createQueryString(this.getParams())
    const route = `/${this._type}/content/${queryEnd}`
    return GET(route).then(data => Object.values(data)[0])
  }

  create() {
    const cdsQuery = new CDSQuery(this._type, this.getParams())
    return cdsQuery.create().then(() => cdsQuery)

  }

  filter(key, operator, value) {
    this._criteria.add(key, operator, value)

    return this
  }

  order(...order) {
    this._order = order

    return this
  }

  metadata(...metadata) {
    this._metadata = metadata

    return this
  }

  param(param) {
    Object.assign(this._params, param)
    return this
  }

  limit(nb) {
    this._limit = nb

    return this
  }
}
