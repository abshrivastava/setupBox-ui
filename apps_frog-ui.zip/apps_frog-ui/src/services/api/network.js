//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//


import {GET} from "../http"

export function getConfigs() {
  return GET("/network/configs/")
}

export function getConfigDetails(config) {
  return GET(`/network/configs/${config}/`)
    .then((configDetails) => {
      const data = {}
      data[config] = configDetails
      return Promise.resolve(data)
    })
}

export function getDeviceDetails(device) {
  return GET(`/network/devices/${device}/`)
}

export function status() {
  return GET("/network/status/")
}

export function authenticated() {
  return GET("/backend/auth/")
}

export default {
  getConfigs,
  getConfigDetails,
  getDeviceDetails,
  status,
  authenticated,
}
