//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT} from "../http"

/**function:: storage.list()
 * Return a list of unique id(s) for each storage devices connected to the STB.
 *
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    list() // => {"storage_list":["c3RvcmFnZV9tb2RlbF9Wb3lhZ2VyX01pbmk=","c3RvcmFnZV9tb2RlbF9Wb3lhZ2Vy"]}
 */
export function list() {
  return GET("/storage/")
}

/**function:: storage.details(storageId)
 * Return details of specified storage device.
 *
 *   :param str storageId: The id of the storage
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    details() // => {
 *      "name": "DT 101 G2",
 *      "location": "external",
 *      "media_removable": true,
 *      "media_available": true,
 *      "type": "usb.key",
 *      "size": 16037969920
 *    }
 */
export function details(storageId) {
  return GET(`/storage/${storageId}/`)
}

/**function:: storage.partitions(storageId)
 * Return details of specified storage device.
 *
 *   :param str storageId: The id of the storage
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    partitions() // => {"partition_list":["dm9sdW1lX3V1aWRfMzM3NF83MjU2"]}
 */
export function partitions(storageId) {
  return GET(`/storage/${storageId}/partitions/`)
}


/**function:: storage.partitionDetails(partitionId)
 * Return details of specified storage device.
 *
 *   :param str storageId: The id of the storage
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    partitionDetails() // => {
 *      "system_dir": "/media/volume_serial_Kingston_DT_101_G2_001CC07CEB81FBA0E16E5EEA_0_0_part_1048576/.system",
 *      "mount_point": "/media/volume_serial_Kingston_DT_101_G2_001CC07CEB81FBA0E16E5EEA_0_0_part_1048576",
 *      "name": "DT 101 G2 - 1",
 *      "file_system_type": "vfat",
 *      "free_size": 11593187328,
 *      "used_size": 4428070912,
 *      "size": 16036921344
 *    }
 */
export function partitionDetails(storageId) {
  return GET(`/storage/${storageId}/partitions/`)
}

export function partitionDetailType(partitionId) {
  return GET(`/storage/partition/${partitionId}/`)
}

/**function:: storage.data()
 * Retreive storage devices connected to the STB that can be used for timeshift
 *
 *   :param str storageId: The id of the storage
 *   :returns Promise:
 *
 * .. code-block:: js
 *
 *    data() // => {"status":true, "partition_uniqueid": "dm9sdW1lX3V1aWRfMzM3NF83MjU2",
 *                     "storage_uniqueid": "c3RvcmFnZV9tb2RlbF9Wb3lhZ2VyX01pbmk="}
 */
export function data() {
  return GET("/storage/data")
}

export function putUsbUnmount(listId) {
  return PUT("/storage/"+ listId +"/unmount")
}


export function putUsbFormat(listId) {
  return PUT("/storage/"+ listId +"/format",{"type":"ext4"})
}

export default {
  list,
  details,
  partitions,
  partitionDetails,
  data,
  putUsbUnmount,
  putUsbFormat,
  partitionDetailType,
}
