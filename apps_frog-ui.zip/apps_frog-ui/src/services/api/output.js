//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, PUT} from "../http"

export function getData(device) {
  return GET(`/player/config/output/${device}/`)
}

export function setResolution(device, resolution) {
  return PUT(`/player/config/output/${device}/`, {format: resolution})
}

export function setAspectRatio(device, aspectRatio) {
  return PUT(`/player/config/output/${device}/`, {aspect_ratio: aspectRatio})
}

export default {
  getData,
  setResolution,
  setAspectRatio,
}
