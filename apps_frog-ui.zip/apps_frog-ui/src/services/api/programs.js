//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET, POST, DELETE} from "../http"

export function create(params) {
  return POST("/programs/", params)
}

export function get(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return GET(`/programs/${id}/`)
}

export function count(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return GET(`/programs/${id}/count/`)
}

export function destroy(id) {
  if (!id) {
    throw "Missing mandatory ID"
  }

  return DELETE(`/programs/${id}/`)
}

export default {
  create,
  get,
  count,
  destroy,
}
