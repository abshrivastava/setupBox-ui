//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import bus from "./bus"
import * as http from "./http"

/** function:: on(event, filter)
 * A decorator used for listen application events
 *
 *    :param string event: the event to listen
 *    :param ? filter:
 *
 *    :implements: |-ext-js-decorators|_
 *
 * .. code-block:: js
 *
 *    import {on} from "services/events"
 *    import bus from "services/bus"
 *
 *    @on("event")
 *    function onEvent() {
 *      console.log("event catched")
 *    }
 *
 *    bus.emit("event") //=> "event catched"
 */
export function on(event, filter) {
  return function(target, key, descriptor) {
    target._evt = target._evt || []
    target._evt.push({
      dispatcher: bus,
      name: event,
      filter: filter,
      cb: descriptor.value,
    })
    return descriptor
  }
}

/** function:: @rcu(event)
 * A decorator used for listen RCU key events
 *
 *   :implements: |-ext-js-decorators|_
 *
 * .. code-block:: js
 *
 *    import {rcu} from "services/events"
 *
 *    @rcu("up:press")
 *    function onUp() {
 *      console.log("key Up pressed")
 *    }
 */
export function rcu(event) {
  return function(target, key, descriptor) {
    target._evt = target._evt || []
    target._evt.push({
      dispatcher: bus,
      name: "rcu#" + event,
      cb: descriptor.value,
    })
    return descriptor
  }
}

/** function:: @rcuLong(event)
 * A decorator used for listen Long RCU key events
 *
 *   :implements: |-ext-js-decorators|_
 *
 * .. code-block:: js
 *
 *    import {rcuLong} from "services/events"
 *
 *    @rcuLong("up:press")
 *    function onUp() {
 *      console.log("key Long Up pressed")
 *    }
 */
export function rcuLong(event) {
  return function(target, key, descriptor) {
    target._evt = target._evt || []
    target._evt.push({
      dispatcher: bus,
      name: "long_rcu#" + event,
      cb: descriptor.value,
    })
    return descriptor
  }
}

/** function:: @sse(event, filter)
 * A decorator used for listen SSE events
 *
 *    :param string event: the event to listen
 *    :param ? filter:
 *
 *   :implements: |-ext-js-decorators|_
 *
 * .. code-block:: js
 *
 *    import {sse} from "services/events"
 *
 *    @sse("player", {subtype: "epg_update"})
 *    function onEpgUpdate(data) {
 *      console.log("Epg updated", data)
 *    }
 */
export function sse(event, filter) {
  return function(target, key, descriptor) {
    target._evt = target._evt || []
    target._evt.push({
      dispatcher: http.sse,
      name: event,
      filter: filter,
      cb: descriptor.value,
    })
    return descriptor
  }
}


/**function:: enableEvents(o)
 *
 *
 */
export function enableEvents(o) {
  for (const e in o._evt) {
    const evt = o._evt[e]
    evt.dispatcher.on(evt.name, evt.cb.bind(o), evt.filter)
  }

  delete o._evt
}
