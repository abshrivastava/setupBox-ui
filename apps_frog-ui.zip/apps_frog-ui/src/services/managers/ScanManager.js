//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {GET} from "services/http"

import bus from "services/bus"
import {on, sse, enableEvents} from "services/events"

import * as scanApi from "services/api/scan"

import {getDvbUris, setScrambled, setFreeToAir, updateEntryInSection,
   getSvlVersionConf, setSvlVersionConf, getIFtoIF,
   setDvbUris, getEntry, setEntry, setGraceInfo, setDefaultLc,
   deleteSection, createSection} from "services/managers/config"

import * as popUpMsg from "app/utils/PopUpMsg"
import * as FTAapi from "services/api/fta"
import {isObject, isArray} from "utils"

import {
  ChannelManager,
  FtaBlockManager,
  PowerManager,
  PVRManager,
  VersionManagers,
} from "services/managers"


const scanRunning = Symbol("running")

class ScanManager {
  constructor() {
    this[scanRunning] = false
    this.stopped = false
    this.nitVersion = 0
    this.serviceFound = 0
    this.radioFound = 0
    this.tvFound = 0
    this.dataFound = 0
    this.diseqc = "DISEQC_AUTO"
    this.tpSetName = null
    this.satList = []
    this.isFirstInstall = false
    this.antennaConfig = []
    this.scanType = null
    this._showScrambled = true
    this._showFreeToAir = true
    this.alwaysCommit = false
    this.defaultInterval = 0 // Default fake option
    this.svlDvbUri = false
    this.sdtChange = false
    this.revokeOnScanComplete = null
    this.scanTriggered = false
    this.dvbTableUpdateRunning = false
    this.defaultLandingChannel = 95
    enableEvents(this)
  }

  get freqStart() {
    return this._freqStart
  }

  set freqStart(value) {
    this._freqStart = value * 1000
  }

  get freqEnd() {
    return this._freqEnd
  }

  set freqEnd(value) {
    this._freqEnd = value * 1000
  }

  get showFreeToAir() {
    return this._showFreeToAir
  }

  set showFreeToAir(value) {
    this._showFreeToAir = value
    // Store FreeToAir Value in config Store
    setFreeToAir(value)
  }

  get showScrambled() {
    return this._showScrambled
  }

  set showScrambled(value) {
    this._showScrambled = value
    // Store Scrambled Value in config Store
    setScrambled(value)
  }

  get device() {
    return {
      "device_id": 1,
    }
  }

  get running() {
    return this[scanRunning]
  }

  set running(value) {
    this[scanRunning] = typeof value === "boolean" ? value : false
    if (value === false) {
      this.scanTriggered = false
    }
  }

  checkSvlVersionChange() {
    return Promise.all([scanApi.getSvlVersion(),getSvlVersionConf()])
    .then(([v0,v1]) => {
      let option
      this.nitVersion = v1
      const curSvlVersion = parseInt(v0.svlVersion)
      if (curSvlVersion === -1|| curSvlVersion !== parseInt(v1[0])) {
        this.isFirstInstall = false
        FtaBlockManager.svlForFta = curSvlVersion
        if (PowerManager.isStandbyState) {
          option = "resume"
          PowerManager.startEasyScan = true
        } else {
          option = "launchEasyScan"
        }
        return Promise.resolve(option)
      } else {
        this.isFirstInstall = false
        return Promise.resolve("checkCurrentTime")
      }
    })
    .catch((error)=>{
      return Promise.reject(error)
    })

  }

  _getSat(href) {
    return new Promise((resolve) => {
      GET(href)
        .then((data) => {
          const tpSetStr = this._formatTpSetHref(href)
          const tpSetId = parseInt(tpSetStr[tpSetStr.length - 1], 10)
          if (data.type === 2 &&  tpSetId < 9000) {
            const sat = {
              name:data.name,
              href: href,
              type: data.type,
              tpSet: tpSetId,
            }
            this.satList.push(sat)
          }
          resolve()
        })
    })
  }

  _formatTpSetHref(href) {
    return href.replace(/\//g, " ").replace(/^\ +/, "").replace(/ $/,"").split(/\s/)
  }

  /** function:: getSatelliteList()
   * Ask to MW to returns a list of Satellite sorted by TransponderSetID and then, ask for antenna config
   *
   *   :returns Promise:
   */
  getSatelliteList() {
    return new Promise((resolve) => {
      scanApi.getAllTransponderSet()
        .then((response) => {
          return response
        })
        .then((response) => {
          const promises = []
          for (const res of response) {
            promises.push(this._getSat(res.href))
          }
          return Promise.all(promises)
            .then(() => {
              this.satList.sort((a, b) => {
                if (a.href < b.href) {
                  return -1
                }
                if (a.href > b.href) {
                  return 1
                }
                return 0
              })
              resolve(this.satList)
              return this.satList
            })
        })
        .then((satList) => {
          const args = satList.map((sat) => sat.tpSet)
          this.getAntennaConfig(args)
        })
    })
  }

  /** function:: getTransponderList(satHref)
   * Ask to MW to returns a list of Transponder for a specific Satellite
   *
   *   :param String satHref: TpSet Href returned by REST server
   *   :returns Promise:
   */
  getTransponderList(satHref) {
    return new Promise((resolve, reject) => {
      GET(`${satHref}transponder/`)
        .then((response) => {
          if (response.length === 0) {
            reject("No transponders found")
          }
          resolve(response)
        })
    })
  }

  /** function:: getTp(tpHref)
   * Ask to MW to returns Transponder information of a specific Transponder
   *
   *   :param String tpHref: Tp Href returned by REST server
   *   :returns Promise:
   */
  getTp(tpHref) {
    return new Promise((resolve) => {
      GET(tpHref)
        .then(({properties}) => {
          const data = this._formatTPInfos(properties)
          resolve(data)
        })
    })
  }

  /** function:: getAntennaConfig(tpSetIdArray)
   * Ask to MW to returns Antenna Config for a list of Transponder Set Id
   *
   *   :param Array tpSetIdArray: Array of Transponder Set Id
   *   :returns Promise:
   */


  getAntennaConfig() {
    return new Promise((resolve) => {
       // Monotuner configuration , ask for first antenna only
      scanApi.getAntenna(1)
       .then(({antenna_config}) => {
         this.antennaConfig = antenna_config
         resolve(this.antennaConfig)
       })
    })
  }

 @on("scan:diseqcUpdate")
  onDiseqcUpdate(diseqc) {
    this.diseqc = diseqc
  }

  /** function:: saveAntennaConfig(tpSetIdArray)
   * Ask to MW to save Antenna Config for a list of Transponder Set Id
   *
   *   :returns Promise:
   */
  @on("scan:saveAntennaConfig")
  saveAntennaConfig() {
    const config = Object.values(this.antennaConfig)
    const data = {}
    data.antenna_config = config

    // Monotuner configuration, set first antenna only
    return scanApi.setAntenna(1, data)
    .then((rsp) => {
      if (rsp !== void 0 && rsp.error === 11) {
        return false
      } else {
        return true
      }
    })
    .catch(() => {
      return false
    })


  }

  /** function:: start(type, tpSetId, name, nit)
   * Ask to MW to start a DVB Scan
   *
   *   :param Int type: Type of scan (1 => tpset, 2 => blind, 3 => network scan)
   *   :param Int tpSetId: Transponder Set Id
   *   :param String name: Name of the Broadcast
   *   :param Array Boolean: Network Search value
   *   :returns Promise:
   */
  start(type, tpSetId, name, nit, scanTp) {
    this.stopped = false
    if (this.running) {
      return Promise.reject("Scan already running")
    }
    this.scanTp = scanTp
    this.serviceFound = 0
    this.radioFound = 0
    this.tvFound = 0
    this.dataFound = 0
    this.tpSetName = name

    this.scanType = parseInt(type, 10)
    this.transponderSetId = parseInt(tpSetId, 10)

    return new Promise((resolve) => {
      if (this.scanType === 2) {
        resolve([this.freqStart, this.freqEnd])
      } else if (nit) {
        Promise.all([getDvbUris(), getIFtoIF()])
        .then(([scanParam, ifToIf]) => {
          this.If2IF = ifToIf
          resolve([scanParam, ifToIf])
        })
      } else {
        resolve([])
      }
    })
    .then(([scanParam, ifToIf]) => {
      scanParam.push(scanTp)
      scanParam.push(ifToIf)
      scanParam.push(this.diseqc.toUpperCase())
      scanParam.push("D2H_OFF")
      return {
        "device_id": this.device.device_id,
        "scan_type": this.scanType,
        "transponder_set_id": this.transponderSetId,
        "scan_param": scanParam,
      }
    })
    .then((options) => {
      return scanApi.start(options).then(() => {
        this.running = true
        return true
      })
    })
    .catch(() => {
      this.running = false
      return false
    })
  }

  /** function:: stop()
   * Ask to MW to stop a DVB Scan
   *
   *   :returns Promise:
   */
  stop() {
    return new Promise((resolve,reject) => {
      this.stopped = true
      if (!this.running) reject("Scan is not running")
      const alwaysCommit = this.alwaysCommit
      const serviceFound = this.serviceFound
      const isFirstInstall = this.isFirstInstall
      /*  ========== ***
      ** Condition :: Check IF :: First Install & Advance Screen & Factory Reset
      ** and when services found are more than 0 ***
      ** Commit the services to MW Db in these cases**
      */
      /*  ========== ***
      ** Condition :: Check ::when services found are 0
      ** and its not First Install or Advance Screen or Factory Reset
      ** Rollback the services to previously saved in MW Db**
      */

      if (isFirstInstall || alwaysCommit || serviceFound > 0) {
        this.removeAllTransponders()
        .then(() => {
          //  this.isFirstInstall= false
          return scanApi.commit(this.device)
        })
        .then(() => resolve(true))
        .catch(() => reject(false))
      } else if (!isFirstInstall && !alwaysCommit && serviceFound === 0) {
        scanApi.rollback(this.device)
        .then(() => resolve(false))
        .catch(() => reject(false))
      } else {
        reject(false)
      }
    })
  }

  /** function:: commit()
   * Ask to MW to commit a DVB Scan
   *
   *   :returns Promise:
   */
  commit() {
    return scanApi.commit(this.device)
  }

  /** function:: rollback()
   * Ask to MW to rollback a DVB Scan
   *
   *   :returns Promise:
   */
  rollback() {
    return scanApi.rollback(this.device)
  }

  /** function:: removeAllServices()
   * Ask to MW to remove all services from the wyscan DB
   *
   *   :returns Promise:
   */
  removeAllServices() {
    if (this.scanTp === "EASY_SCAN") {
      if (this.scanFromFactoryReset) {
        this.scanFromFactoryReset = false
        return scanApi.removeAllServices()
      } else {
        return scanApi.removeAllServicesWithoutFav()
      }
    } else {
      return scanApi.removeAllServices()
    }
  }

  /** function:: removeAllTransponders()
   * Ask to MW to remove all Transponders from the wyscan DB
   *
   *   :returns Promise:
   */
  removeAllTransponders() {
    switch (this.scanType) {
    case 1:
      return this.removeAllServices()
    case 2:
    case 3:
      return this.removeAllServices()
        .then(() => {
          const promiseList = []
          for (let i = 9994; i <= 9998; i++) {
            promiseList.push(scanApi.removeAllTransponders(i))
          }
          return Promise.all(promiseList)
        //  return scanApi.removeAllTransponders(this.transponderSetId)
        })
    default:
      break
    }
  }

  /** function:: getProgression(tpParams)
   * Compute Scan progression based on Transponder information and Frequency range.
   * Usually used for a frequency scan
   *
   *   :param String tpParams: Transponder information
   *   :returns Int: a value between 0 and 1
   */
  getProgression(tpParams) {
    const r = tpParams.split(" ")
    const freqStart = this.freqStart
    const freqEnd = this.freqEnd
    const max = (freqEnd - freqStart) * 2
    let current = parseInt(r[1], 10) - freqStart
    if (r[2] !== "H") {
      current += (freqEnd - freqStart)
    }
    return Math.min(Math.round(current / max * 100) / 100, 1)
  }

  unTuneWydvbUri() {
    return new Promise((resolve) => {
      return scanApi.listTune().then((options) => {
        if (options.tunes.length > 0) {
          const id = parseInt(options.tunes[0].href.split("/")[3])
          return scanApi.removeTune(id)
        } else {
          resolve(true)
        }
      }).then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  @sse("scan", {subtype: "scan_event_started"})
  onScanStarted() {
    // Default fake option
    if (this.svlDvbUri)
      this.defaultInterval = 0

    bus.emit("scan:after_started")
  }

  @sse("scan", {subtype: "progression"})
  onScanProgress(event) {
    let current = 0
    if (this.scanType === 2) {
      const tpParams = event.content.tp_params
      current = this.getProgression(tpParams)
    } else {
      const totalTp = event.content.total_tp
      current = (event.content.current_tp_index / totalTp)
    }
    const tpInfos = this._formatTPInfos(event.content.tp_params)

    if (!this.svlDvbUri)
      bus.emit("scan:progress", current, tpInfos)

    // Call Default fake function
    if ((this.svlDvbUri) && (this.defaultInterval === 0)) {
      this.defaultInterval = 1
      this.defaultProgress(tpInfos)
    }
  }

/* ********Default fake progress bar ***/
  defaultProgress(tpInfos) {
    if (this.defaultInterval === 1) {
      const setCounter = 1
      let setIncremental = 0.01
      this.startDefaultCounter = setInterval(() => {
        bus.emit("scan:progress", setIncremental, tpInfos)
        if (setCounter <= setIncremental) {
          clearInterval(this.startDefaultCounter)
          this.defaultInterval = 0
        }
        setIncremental = setIncremental + 0.01
      }, 200)
    }
  }
/* ********End of Default fake progress bar ***/

  _filterFreeToAir(services) {
    const freeToAirList = []
    for (const serv of services) {
      if (parseInt(serv.scrambled) === 0) {
        freeToAirList.push(serv)
      }
    }
    return freeToAirList
  }

  _filterScrambled(services) {
    const scrambledList = []
    for (const serv of services) {
      if (parseInt(serv.scrambled) === 1) {
        scrambledList.push(serv)
      }
    }
    return scrambledList
  }

  @sse("scan", {subtype: "service_update"})
  onServiceUpdate(event) {
    let services = event.content.services
    if (this.showFreeToAir && !this.showScrambled) {
      services = this._filterFreeToAir(services)
    } else if (!this.showFreeToAir && this.showScrambled) {
      services = this._filterScrambled(services)
    }

    const serviceList = []

    for (const serv of services) {
      if (serv.obj_class === "CHANNEL_TV") {
        serviceList.push({name: serv.title})
        this.tvFound += 1
      } else if (serv.obj_class === "CHANNEL_AUDIO") {
        this.radioFound += 1
        serviceList.push({name: serv.title})
      } else {
        // serv.obj_class === "CHANNEL_DATA"
        this.dataFound += 1
        serviceList.push({name: serv.title})
      }
    }
    if (serviceList.length > 0) {
      this.serviceFound += serviceList.length
      bus.emit("scan:service_update", serviceList)
    }
  }

  @sse("scan", {subtype: "scan_event_finished"})
  onScanFinished() {

    if (!this.stopped) {
      this.stop()
      .then((status) => {
        bus.emit("scan:finished")
        this.clearFakeInterval()
        if (!status) this.updateCommitService(true)
      })
      .catch(()=> {
        this.setEasyScanFalse()
        this.scanFinished()
      })
    }
  }

  @on("scan:commit_completed")
  updateCommitService(isFromRollback = false) {
    let disableBack = false
    if (this.isFirstInstall) {
      disableBack = true
    }
    const onOpenCall = () => {
      this._updateModel(isFromRollback)
    }
    if (this.svlDvbUri) {
      this._updateModel(isFromRollback)
    }
    if (!this.svlDvbUri) {
      popUpMsg.scanComplete(this.tvFound, this.radioFound,this.dataFound, this.serviceFound, onOpenCall, disableBack)
      if (!this.isFirstInstall) bus.emit("popup:exitTrue")
    }
  }

  _updateModel(isFromRollback) {
    if (isFromRollback) {
      this.scanFinished()
    } else {
      ChannelManager.update(ScanManager.showScrambled, ScanManager.showFreeToAir,false)
      .then(() => this.sdtChange = false)
      .then(() => RadioManager.update())
      .then(() => this.scanFinished())
      .catch(() => this.scanFinished())
    }
  }
  checkSubscriptionStatus() {
    return new Promise((resolve) => {
      return FTAapi.getFTAsubscriptionStatus()
      .then((resp) => {
        return resolve(resp.FTABlockStatus)
      })
      .catch(() => {
        return resolve(true)
      })
    })
  }

  scanFinished() {
    this.running = false
    const isFromFtaBlock = FtaBlockManager.onAdvancedScan
    const isPendingState = FtaBlockManager.pendingState
    FtaBlockManager.onAdvancedScan = false

    this.checkSubscriptionStatus().then((status) => {
      if ((isPendingState || isFromFtaBlock || status) && !this.isFirstInstall) {
        this.initiateLiveAds(true)
        .then(() => {
          this.closePendingState()
        })
      } else {
        this.tuneDefaultChannel()
        .then(() => {
          return this.revokeafterScanComplete()
        })
        .then(() => {
          if (!this.svlDvbUri) bus.emit("popup:hidePicto")
          bus.emit("scan:complete")
          if (this.svlDvbUri) this.closeFakeProcessBar(false)
        })
        .then(() => {
          return this.initiateLiveAds(true)
        })
        .then(() => {
          if (PowerManager.isStandbyState) {
            bus.universe = "standby"
          }
        })
      }
    }).catch(() => {
      this.initiateLiveAds(true)
      .then(() => {
        this.closePendingState()
      })
      if (PowerManager.isStandbyState) {
        bus.universe = "standby"
      }
    })
  }

  initiateLiveAds(toNotify = true) {
    return new Promise((resolve) => {
      VersionManagers.resetAdsRequest(toNotify,this.serviceFound)
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  revokeafterScanComplete() {
    const revoke = this.revokeOnScanComplete
    if (revoke==="home") {
      bus.emit("settings:closeSettingsView")
      bus.openUniverse("home")
      bus.emit("popup:close","home")
    } else if (revoke === "standby") {
      bus.emit("settings:closeSettingsView")
      bus.openUniverse("tv")
      bus.emit("popup:close","tv")
    } else if (revoke === "resume") {
      bus.emit("settings:closeSettingsView")
      bus.openUniverse("tv")
      bus.emit("popup:close","tv")
    }
    this.revokeOnScanComplete = null
    return Promise.resolve(true)
  }

  // fake progress bar remove
  closeFakeProcessBar(pullBlackScreen = true) {
    this.defaultInterval = 0
    this.svlDvbUri = false
    if (pullBlackScreen) this.view.pullBlackScreen()
  }

  clearFakeInterval() {
    if (this.startDefaultCounter) clearInterval(this.startDefaultCounter)
    if (this.svlDvbUri) bus.emit("scan:progress", 1, "null")
  }

  closePendingState() {
    bus.emit("scan:stopHamsterWheel")
    bus.emit("settings:close")
    bus.emit("fta:pending_state")
    if (this.svlDvbUri) this.closeFakeProcessBar()
  }

  tuneDefaultChannel() {
    return new Promise((resolve)=>{
      if (PowerManager.isStandbyState) {
        PowerManager.tuneToHomeTp()
        return resolve(true)
      } else {
        return PowerManager.getDynamicDefaultLC()
        .then((lcn) => {
          if (lcn && !isNaN(lcn)) {
            this.isFirstInstall ? null : PowerManager._playChannel(lcn)
            return resolve(true)
          } else {
            this.isFirstInstall ? null : PowerManager._playChannel(this.defaultLandingChannel)
            return resolve(true)
          }
        })
        .catch(() => {
          this.isFirstInstall ? null : PowerManager._playChannel(this.defaultLandingChannel)
          return resolve(false)
        })
      }
    })
  }


  setEasyScanFalse() {
    if (PowerManager.startEasyScan === true) {
      PowerManager.isEasyScanRunning = false
      PowerManager.startEasyScan = false
    }
  }

  @sse("scan", {subtype: "scan_event_commit_complete"})
  onCommitComplete() {
    let nitVersion = null
    this.setEasyScanFalse()
    scanApi.getSvlVersion()
    .then((response) => {
      nitVersion = response.nitVersion
      return setSvlVersionConf(response.svlVersion)
    })
    .then(() => {
      return this.unTuneWydvbUri()
    })
    .then(() => {
      return getEntry("scan", "easy_scan")
    })
    .then(() => {
      return this.setNitVersion(nitVersion)
    })
    .then((response) => {
      if (response) {
        const freq_sym_rate = ["S"]
        freq_sym_rate.push(response.substring(response.search("frequency=")+10, response.search("&modulation")))
        freq_sym_rate.push(response.substring(response.search("polarity=")+9, response.search("&transmitter_id")))
        freq_sym_rate.push(response.substring(response.search("symbol_rate=")+12, response.search("&iq_mode")))
        this.homeTP = freq_sym_rate.join(" ")
        setEntry("scan", "last_home_TP", freq_sym_rate.join(" "))
      }
    })
    .then(() => {
      bus.emit("transponder:getlist", {diseqc:this.diseqc, IF2IF:this.If2IF})
      bus.emit("download:getIFtoIF",{diseqc:this.diseqc, IF2IF:this.If2IF})
      this.updateCommitService()
      scanApi.removeAllTune()
    })
    .catch(() => {
      bus.emit("transponder:getlist", {diseqc:this.diseqc, IF2IF:this.If2IF})
      bus.emit("download:getIFtoIF",{diseqc:this.diseqc, IF2IF:this.If2IF})
      this.updateCommitService()
      scanApi.removeAllTune()
    })
  }

  @sse("scan", {subtype: "force_channel_info"})
  onForceChannelScan(event) {
    for (const prop in event.content) {
      updateEntryInSection("force_slide", prop, event.content[prop])
    }
  }
  @sse("scan", {subtype: "landing_channel_info"})
  onLandingChannelScan(event) {
    for (const prop in event.content) {
      updateEntryInSection("landing_channel", prop, event.content[prop])
    }
  //  BlockedChannelManager.updateLandingChannel(event.content.channel_num)
  }

  // Please import getDefaultChannel in "services/managers/config" When BlockedChannelManager Active
  // @on("scan:complete")
  // onScanComplete() {
  //   getDefaultChannel()
  //   .then((lcn) => {
  //     return BlockedChannelManager.updateLandingChannel(lcn)
  //   })
  // }

@on("scan:updateDvbUri")
  onUpdateDVBUri(scanType, data) {
    let frequency = "12688000"
    let symbol_rate = "27500000"
    let code_rate = "Auto"
    let polarity = "V"
    let transmitter_id = "-1"

    for (const factor in data) {
      switch (factor) {
      case "frequency": frequency = data[factor]
        break
      case "symbol_rate": symbol_rate = data[factor]
        break
      case "code_rate": code_rate = data[factor]
        break
      case "polarity": polarity = data[factor]
        break
      case "transmitter_id": transmitter_id = data[factor]
        break

      }
    }

    const baseUri = "wydvb://dvbs/?frequency="+ frequency
        +"&modulation=Auto&code_rate="+code_rate+"&symbol_rate="+symbol_rate
        +"&iq_mode=Auto&polarity="+polarity+"&transmitter_id="+transmitter_id

    return setDvbUris(baseUri)
    .then(() => {
      if (scanType === "if2if") {
        bus.emit("scan:startOnIF2IF")
      }
    })
  }

  @sse("scan", {subtype: "DvbTableUpdate"})
  onNITUpdate(response) {
    // Ignore DvbTableUpdate Event When Scan is ongoing || bootTimeRunning || DvbTableUpdate Process
    if (this.running || PowerManager.isEasyScanRunning ||
      this.dvbTableUpdateRunning || PowerManager.bootTimeRunning
    || FtaBlockManager.callFromBoot) return false

    this.dvbTableUpdateRunning = true
    const tableID = parseInt(response.content.table_id)
    const currentSvlVersion = response.content.svl_version
    const OngoingRecording = PVRManager.ongoing.length

    // In standby: a svl version changes is received while recording the flags are set
    // scan is put on hold & is not launched till record completes in standby

    getSvlVersionConf()
    .then((SaveSvlVersion) => {
      if (currentSvlVersion !== SaveSvlVersion && tableID !== 66 && currentSvlVersion !== -1) {
        PowerManager.startEasyScan = true
        if (PowerManager.isStandbyState && !PowerManager.isEasyScanRunning && !this.sdtChange) {
          if (!OngoingRecording) {
            this.svlDvbUri = true
            PowerManager._startEasyScan(PowerManager.startEasyScan, PowerManager.isEasyScanRunning)
          }
        }
      } else if (tableID === 66) {
        if (PowerManager.isStandbyState && !this.sdtChange && !OngoingRecording) {
          ChannelManager.update(this.showScrambled, this.showFreeToAir,true)
          .then(() => {
            this.sdtChange = false
          })
        } else {
          this.sdtChange = true
        }
      }
    })
    .then(() => {
      this.dvbTableUpdateRunning = false
      this.setNitVersionFromLive()
    })
    .catch(() => {
      this.dvbTableUpdateRunning = false
      this.setNitVersionFromLive()
    })
  }

  _formatTPInfos(tpInfos) {
    // "tpInfos": "S 10714037 H 23498473  3/4",
    // frequency = 10714037
    // polarization = H
    // symbolRate = 23498473  3/4

    // "tpInfos": "S 10736861 H 0 AUTO",
    // frequency = 10736861
    // polarization = H
    // symbolRate = 0 AUTO
    const data = {
      satName: "",
      transponder: "",
      polarization: "",
      symbolRate: "",
      fec: "",
    }
    if (typeof tpInfos === "string") {
      tpInfos = tpInfos.replace(/ +/g, " ").split(/\s/)
      data.satName = tpInfos[0] || ""
      data.transponder = tpInfos[2] / 1000
      data.polarization = tpInfos[3].replace(/H/i, "Horizontal").replace(/V/i, "Vertical")
      data.symbolRate = `${tpInfos[4]}`
      data.fec = `${tpInfos[5]}`
    }
    return data
  }

  /* ********** Updating FS, LC & Grace Period On NIT Changes ********* */

  _updateForceLandingChannel() {
    return new Promise((resolve,reject) => {
      return this.checkNitVersion()
      .then((response) => {
        if (response) {
          const self = this
          for (let i=1; i<=4; i++) {
            (function(i) {
              setTimeout(() => {
                // Update Grace Periods
                if (i === 1) self.updateGracePeriods()
                // Update Forced Slide...
                if (i === 2) self.updateFc()
                // Update Landing Channel..
                if (i === 3) self.updateLc()
                // Update NIT Version...
                if (i === 4) self.setNitVersion(response)
              }, i*500)
            })(i)
          }
          resolve(true)
        }
      })
      .catch(() => {
        reject("Fail to Update FC,LC and GracePeriod..")
      })
    })
  }

  updateLc() {
    return new Promise((resolve) => {
      return scanApi.getDynamicLandingChannel()
      .then((data) => {
        this.onDefaultLandingChannel(data)
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  updateFc() {
    return new Promise((resolve) => {
      return scanApi.getDynamicForceSlide()
      .then((data) => {
        this.onForceSlideChannel(data)
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  updateGracePeriods() {
    return new Promise((resolve) => {
      return scanApi.getDynamicGracePerods()
      .then((data) => {
        this.onGraceLandingChannel(data)
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  checkNitVersion() {
    return new Promise((resolve) => {
      let currentNitVersion = -1
      let liveNitVersion = null
      return this.getNitVersion().then((version) => {
        return currentNitVersion = +(version)
      })
      .then(() => {
        return this.getNitLiveVersion()
      })
      .then((version) => {
        liveNitVersion = +(version)
      })
      .then(() => {
        if (currentNitVersion !== liveNitVersion) {
          resolve(liveNitVersion)
        } else {
          resolve(false)
        }
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  getNitVersion() {
    return new Promise((resolve) => {
      getEntry("settings","NIT_Version")
      .then((version) => {
        resolve(+version)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  getNitLiveVersion() {
    return new Promise((resolve) => {
      scanApi.getSvlVersion().then((data) => {
        const version = data
        if (version.nitVersion) {
          resolve(parseInt(version.nitVersion))
        } else {
          resolve(false)
        }
      }).catch(() => {
        resolve(false)
      })
    })
  }

  setNitVersion(version) {
    return new Promise((resolve) => {
      if (version) {
        return setEntry("settings", "NIT_Version", version)
        .then(() => {
          resolve(true)
        })
        .catch(() => {
          resolve(false)
        })
      } else {
        resolve(false)
      }
    })
  }

  setNitVersionFromLive() {
    return new Promise((resolve) => {
      this.getNitLiveVersion()
      .then((version) => {
        if (version) {
          return setEntry("settings", "NIT_Version", version)
        } else {
          return false
        }
      })
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  /* ********** SSE Event handling for SCAN ********* */

  @sse("scan", {subtype: "dynamic_force_slide"})
  onForceSlideChannel(event) {
    if (PowerManager.bootTimeRunning) {
      return false
    }
    PowerManager.blowOutFc(event,false,false,false)
  }

  @sse("scan", {subtype: "default_landing_channel"})
  onDefaultLandingChannel(event) {
    let isFromEvent = null
    let isFromGet = null
    if (PowerManager.bootTimeRunning) {
      return false
    }
    if (isObject(event) === true) {
      isFromEvent = event
    }
    if (isArray(event) === true) {
      isFromGet = event.length > 1 ? event : null
    }

    if (isFromEvent || isFromGet) {
      const option = isFromEvent ? isFromEvent.content.default_lc_parameters :isFromGet
      const length = isFromEvent ? isFromEvent.content.default_lc_parameters.length : isFromGet.length
      let increment = 1
      let out = 0
      let flag = true
      let maxLandingChannel = 0
      let defaultCounter = 1
      if (length) {
        return PowerManager.getDefaultMaxLandingChannels()
        .then((max) => {
          maxLandingChannel = max
          return true
        })
        .then(()=>{
          return PowerManager.getDefaultCounter()
        })
        .then((counter)=>{
          defaultCounter = parseInt(counter)
          return deleteSection("default_lc")
        })
        .then(() => {
          const section = {}
          section["default_lc"] = {}
          return createSection(section)
        })
        .then(() => {
          for (const [index, element] of option.entries()) {
            (function(index) {
              setTimeout(function() {
                if (out === 2) {
                  out = 0
                  increment++
                }
                if (flag) {
                  setDefaultLc(`${increment}_default_channel`,element)
                  flag = false
                } else if (!flag) {
                  setDefaultLc(`${increment}_default_rcu_block`,element)
                  flag = true
                }
                out++
              },index*10)
            })(index)
          }
        })
        .then(() => {
          if (parseInt(maxLandingChannel) !== Math.ceil(length/2)) {
            return setDefaultLc("default_counter",1)
          } else {
            return setDefaultLc("default_counter",defaultCounter || 1)
          }
        })
        .then(() => {
          return setDefaultLc("max_number_of_channels",Math.ceil(length/2))
        })
        .then(() => {
          // Update the Default Counter if LC is under Grace Peroid
          PowerManager._showDefaultChannel(false,false,true,false)
        })
        .catch(() => {
          // No Update...
        })
      }
    }
  }

  @sse("scan", {subtype: "grace_landing_channel"})
  onGraceLandingChannel(event) {
    let isFromEvent = null
    let isFromGet = null
    let data

    if (PowerManager.bootTimeRunning) {
      return false
    }

    if (isObject(event) === true) {
      isFromEvent = event
    }
    if (isArray(event) === true) {
      isFromGet = event.length > 1 ? event : null
    }

    if (isFromEvent || isFromGet) {
      data = isFromEvent ? isFromEvent.content.grace_lc_parameters : isFromGet
      const [gPeriod,gLcn,gRcuBlock] = data
      return deleteSection("grace_lc")
      .then(() => {
        const section = {}
        section["grace_lc"] = {}
        return createSection(section)
      })
      .then(() => {
        return setGraceInfo("grace_default_channel",gLcn)
      })
      .then(() => {
        return setGraceInfo("grace_default_rcu_block",gRcuBlock)
      })
      .then(() => {
        return setGraceInfo("grace_default_offset",gPeriod)
      })
      .then(() => {
        // Update the Default Counter if LC is under Grace Peroid
        PowerManager._showDefaultChannel(false,false,true,false)
      })
      .catch((e) => {
        console.debug("Error : grace_landing_channel",e)
      })

    }
  }
}

export default new ScanManager()
