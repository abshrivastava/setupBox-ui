//
// Copyright (C) 2006-2017 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as browserApi from "services/api/browser"
import bus from "services/bus"
import {sse, enableEvents} from "services/events"

class BrowserManager {
  constructor() {
    this.currentHref = null
    enableEvents(this)
  }

  openNewLayer(url, forwardKeys) {
    return this.openLayer(forwardKeys)
      .then((href) => {
        this.currentHref = href
        return this.setLayerUrl(href, url)
      })
  }

  openLayer(forwardKeys) {
    const params = {
      "zindex": 55, // range of zindex is [55, 100]
      "focus": true,
      "forward": (forwardKeys) ? forwardKeys : ["home"],
    }

    return browserApi.openLayer(params)
  }

  setLayerUrl(href, url) {
    const params = {
      "url" : url,
    }
    return browserApi.setLayerUrl(href, params)
  }

  closeLayer() {
    if (this.currentHref) {
      return browserApi.closeLayer(this.currentHref)
      .then(() => {
        this.currentHref = null
      })
    } else {
      return Promise.resolve()
    }
  }

  @sse("browser", {subtype: "load_started"})
  onLoadStarted(params) {
    bus.emit("browser:load_started", params)
  }

  @sse("browser", {subtype: "load_completed"})
  onLoadCompleted(params) {
    bus.emit("browser:load_completed", params)
  }

  @sse("browser", {subtype: "load_failed"})
  onLoadFailed(params) {
    bus.emit("browser:load_failed", params)
  }
}

export default new BrowserManager()
