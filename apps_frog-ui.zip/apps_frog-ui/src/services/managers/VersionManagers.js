//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import bus from "services/bus"
import {on, enableEvents} from "services/events"

import * as CheckerApi from "services/api/checker"
import {getTransponderCompleteData} from "services/api/transponders"

import {setAdsVersion, setAppsVersion, getAdsVersion, getAppsVersion,
  setEntry, getEntry,deleteEntry} from "services/managers/config"
import config from "utils/config"

import {
  AdsManager,
  DownloaderManager,
  PowerManager,
} from "services/managers"

import {errorAppLaunched, appFileDownloadFailed} from "app/utils/PopUpMsg"

const UNIVERSE = ["home","tv","pvr","epg","settings","bigbang","blackuniverse"]
const PlAY_STORE_PATH =  `http://${config.APP_IP}${config.APPS_PLAY_STORE}`

const Transponder = Object.freeze({
  DISEQC_AUTO: "0",
  DISEQC_PORT1: "1",
  DISEQC_PORT2 : "2",
  DISEQC_PORT3: "3",
  IFTOIF_ON: -1,
})

class VersionManagers {
  constructor() {
    this.appsCatalogVersion = null
    this.adsCatalogVersion = null
    this.downlaodAction = null
    this.currentChecker = null
    this.oldChecker = null
    this.oldCurrentChecker = null
    this.onBootCheckerAdsId = null
    this.onBootCheckerAppsID = null
    this.installationProcess = null
    this.config = {
      ADS:"ads",
      APPS:"apps",
      APP:"app",
      COMPONENT_TAG:"component_tag",
      ADSCATALOG :208,
      APPSCATALOG : 209,
      APPFILE : 210,
      ADSDVBURI: "ads_wydvb_uri",
      APPSDVBURI: "apps_wydvb_uri",
      STANDBY_ADSDVBURI : "standby_ads_wydvb_uri",
      STANDY:"standby",
      "ADS_CHECKER_ID" : null,
      "APPS_CHECKER_ID" : null,
      "APPFILE_CHECKER_ID" : null,
    }
    enableEvents(this)
  }

/* ********************************** *********************
   *                 COMMON METHODS           *
********************************** ***********************/
  setUpdateVersion(type,version) {
    return new Promise((reslove) => {
      if (type === this.config.ADSCATALOG) {
        return setAdsVersion(version).then(() => {
          this.adsCatalogVersion = version
          return reslove(this.adsCatalogVersion)
        })
      } else if (type === this.config.APPSCATALOG) {
        return setAppsVersion(version).then(() => {
          this.appsCatalogVersion = version
          return reslove(this.appsCatalogVersion)
        })
      } else {
        return reslove(false)
      }
    })
  }

  getCurrentVersion(type) {
    if (type === this.config.ADSCATALOG) return getAdsVersion()
    if (type === this.config.APPSCATALOG) return  getAppsVersion()
  }

  getAppsCatalogVersion() {
    return new Promise((resolve) => {
      return this.getCurrentVersion(this.config.APPSCATALOG)
      .then((version) => {
        if (version) {
          this.appsCatalogVersion = version
          DownloaderManager.appsPersist = true
        }
        resolve(true)
      })
      .catch(() => {
        this.appsCatalogVersion = 0
        resolve(false)
      })
    })
  }

  getAdsCatalogVersion() {
    return new Promise((resolve) => {
      return this.getCurrentVersion(this.config.ADSCATALOG)
      .then((version) => {
        this.adsCatalogVersion = version
        resolve(true)
      })
      .catch(() => {
        this.adsCatalogVersion = 0
        resolve(false)
      })
    })
  }

  UpdateVersion(data) {
    return new Promise((reslove) => {

      if (!data) return reslove(false)

      const contentUrl = data.wydvb_uri
      const option = this.getUrlParams(contentUrl)
      const type = parseInt(option.component_tag)
      const version = option.transaction_id

      if (!version || !type) return reslove(false)

      return this.setUpdateVersion(type,version)
      .then((version) => {
        return reslove(version)
      })
      .catch((error) => {
        return reslove(`Fail to Update Version :: ${error}`)
      })
    })
  }

  getUrlParams(url) {
    const hashes = url.slice(url.indexOf("?") + 1).split("&")
    const params = {}
    hashes.map(hash => {
      const [key, val] = hash.split("=")
      params[key] = decodeURIComponent(val)
    })
    return params
  }

  addTransactionId(type, url) {
    return new Promise((resolve) => {
      const catalogType = type
      const contentUrl = url
      let path = contentUrl
      if (catalogType === this.config.ADSCATALOG && this.adsCatalogVersion) {
        path = `${contentUrl}&transaction_id=${this.adsCatalogVersion}`
        resolve(path)
      } else if (catalogType === this.config.ADSCATALOG && !this.adsCatalogVersion) {
        path = `${contentUrl}&transaction_id=1111111111`
        resolve(path)
      } else if (catalogType === this.config.APPSCATALOG && this.appsCatalogVersion) {
        path = `${contentUrl}&transaction_id=${this.appsCatalogVersion}`
        resolve(path)
      } else {
        resolve(path)
      }
    })
  }

  manageDvbUri(uri) {
    return new Promise((reslove) => {
      const tunerId = 0
      let service = null
      let componentTag = null
      let transponderList = null
      let pidID = null
      let broadcastID = null

      const diseqcRef = DownloaderManager.watcher.diseqc || "0"
      const IFtoIF = DownloaderManager.watcher.IFtoIF || "IFTOIF_OFF"
      let tuner = null

      const option = this.getUrlParams(uri)
      service = (option && option.service) ? option.service : null
      pidID = (option && option.pid) ? option.pid : null
      broadcastID = (option && option.broadcast_id) ? option.broadcast_id : 7
      componentTag = (option && option.component_tag) ? option.component_tag : "208"
      tuner = "tuner://dvbs/?tuner_id="+
      `${tunerId}&service=${service}&component_tag=${componentTag}&pid=${pidID}&broadcast_id=${broadcastID}`

      return getTransponderCompleteData(diseqcRef,IFtoIF)
      .then((data) => {
        transponderList = data
        DownloaderManager.watcher.transponder_list = transponderList
      })
      .then(() => {
        reslove(tuner)
      })
      .catch(() => {
        reslove(tuner)
      })
    })
  }

  isOnStandby() {
    const isOnStandby = PowerManager.isStandbyState
    return isOnStandby
  }

  pendingDwTasks() {
    return new Promise((resolve) => {
      DownloaderManager._getDowloaderTasks()
      .then((data) => {
        const length = data.tasks.length
        if (length > 0) {
          const tasks = data.tasks
          DownloaderManager.removePendingDwtasks(tasks)
          .then(() => {
            resolve(true)
          })
        } else {
          resolve(true)
        }
      })
      .catch((error) => {
        resolve(error)
      })
    })
  }

  refressAds() {
    return new Promise((reslove) => {
      return AdsManager.loadAdsCatalogue()
      .then(()=> {
        bus.emit("adbanner:onDownloadComplete")
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  getAssetType(type) {
    let currentStimulation = null
    switch (type) {
    case this.config.ADS:
      currentStimulation = this.config.ADSCATALOG
      break
    case this.config.APPS:
      currentStimulation = this.config.APPSCATALOG
      break
    case this.config.APP:
      currentStimulation = this.config.APPFILE
      break
    }
    return currentStimulation
  }

  appFileDownloadFailed() {
    appFileDownloadFailed()
  }

  getCurrentStimulation() {
    const type = this.downlaodAction
    const currentStimulation = this.getAssetType(type)
    if (currentStimulation === this.config.ADSCATALOG) {
      return this.config.ADSCATALOG
    } else if (currentStimulation === this.config.APPSCATALOG) {
      return this.config.APPSCATALOG
    } else if (currentStimulation === this.config.APPFILE) {
      return this.config.APPFILE
    } else {
      return false
    }
  }

  resetAdsRequest(toNotify = true,serviceFound) {
    return new Promise((reslove) => {
      if (serviceFound > 0) {
        this.appsCatalogVersion = null
        this.adsCatalogVersion = null
        DownloaderManager.download.adsCurrentTask = null
        DownloaderManager.download.appsCurrentTask = null
        DownloaderManager.download.appCurrentTask = null
        DownloaderManager.download.adsCurrentTaskStandy = null
        this.clearAdsAppsConfig()
        if (toNotify) this.onFlyDownload()
        reslove(true)
      } else {
        reslove(false)
      }
    })
  }

  clearAdsAppsConfig() {
    this.deletedAdsVersion()
    this.deletedAppsVersion()
  }

  /* ********************************** *********************
   *                 Download METHODS           *
  ********************************** ***********************/

  @on("download:action")
  downlaodAction(type) {
    let data = null
    switch (type) {
    case "ads":
      data = this.config.ADS
      break
    case "apps":
      data = this.config.APPS
      break
    case "app":
      data = this.config.APP
      break
    default:
      break
    }
    if (data) this.downlaodAction = data
  }

  donwloadActionFinished() {
    this.downlaodAction = null
  }

  onDownloaderStarted() {
    DownloaderManager.isDownloaderStarted = true
  }

  onDownloaderDone(refress = true, istrusted = true, isFrom) {
    bus.emit("appstore:stopLoadingApps")
    if (isFrom === this.config.APPFILE) {
      return this.openApplicationFile(istrusted)
    }
    if (isFrom === this.config.APPSCATALOG) {
      this.openApps(isFrom)
    }
  }

  openApplicationFile(istrusted) {
    if (istrusted) {
      const currentApp = DownloaderManager.playStoreTitle
      const url = `${PlAY_STORE_PATH}${currentApp}/`
      bus.emit("appstore:openApp",url)
      this.closePopup()
    } else {
      // Need to show Untrushed Message..
    }
  }

  @on("downloader:onAdsFailed")
  onAdsFailed() {
    let downloadTask = null
    downloadTask = DownloaderManager.download.adsCurrentTask
    if (downloadTask) {
      DownloaderManager._stopDownload(downloadTask)
      .then(() => {
        DownloaderManager.download.adsCurrentTask = null
        return DownloaderManager._deleteTask(downloadTask)
      })
      .then(() => {
        this.onFlyDownload()
      })
    } else {
      this.onFlyDownload()
    }
  }

  @on("dvbUpdate:cancel")
  onCanceled(status = true, fromBack = false, isFrom = this.config.APPSCATALOG) {
    let downloadTask = null
    if (isFrom === this.config.ADSCATALOG) {
      downloadTask = DownloaderManager.download.adsCurrentTask
      if (downloadTask) {
        DownloaderManager._stopDownload(downloadTask)
        .then(() => {
          DownloaderManager._deleteTask(downloadTask)
          DownloaderManager.download.adsCurrentTask = null
        })
      }
      setTimeout(() => {
        this.showResults(false,true,true,this.config.ADSCATALOG)
      },30000)
    } else {
      if (isFrom === this.config.APPFILE) {
        downloadTask = DownloaderManager.download.appCurrentTask
        if (downloadTask) {
          DownloaderManager._stopDownload(downloadTask)
          .then(() => {
            DownloaderManager._deleteTask(downloadTask)
            DownloaderManager.download.appCurrentTask = null
          })
        }
      }
      if (isFrom === this.config.APPSCATALOG) {
        downloadTask = DownloaderManager.download.appsCurrentTask
        if (downloadTask) {
          DownloaderManager._stopDownload(downloadTask)
          .then(() => {
            DownloaderManager._deleteTask(downloadTask)
            DownloaderManager.download.appsCurrentTask = null
          })
        }
      }
      if (!fromBack) bus.emit("appstore:stopLoadingApps")
      this.versionExit(status,fromBack,isFrom)
    }
  }

  onDownloaderFailed(status,openHome,isFrom = this.config.APPSCATALOG) {
    bus.emit("dvbUpdate:cancel",status,openHome,isFrom)
  }

  @on("downloader:stopAppFileTask")
  onStopAppFileTask() {
    const task = DownloaderManager.download.appCurrentTask
    if (task) {
      DownloaderManager._stopDownload(task)
      .then(() => {
        DownloaderManager.download.appCurrentTask = null
        DownloaderManager._deleteTask(task)
      })
    }
  }

  @on("download:getIFtoIF")
  getIFtoIF(option) {
    let diseqc = 0
    let IF2IF = "IFTOIF_OFF"

    if (option && option.IF2IF !== "IFTOIF_ON") {
      diseqc = Transponder[option.diseqc] ? Transponder[option.diseqc] : diseqc
      DownloaderManager.watcher.diseqc = diseqc
    } else {
      DownloaderManager.watcher.diseqc = Transponder.IFTOIF_ON
    }
    if (option && option.IF2IF) {
      IF2IF = option.IF2IF
      DownloaderManager.watcher.IFtoIF = IF2IF
    } else {
      DownloaderManager.watcher.IFtoIF = IF2IF
    }
  }

  /* ********************************** *********************
   *                 Version Methods              *
  ********************************** ***********************/

  openHome() {
    const isOnStandby = PowerManager.isStandbyState
    if (!isOnStandby) {
      bus.openUniverse("home")
    }
  }

  @on("version:closePopup")
  closePopup() {
    const currentUniverse = bus.universe
    const isOnStandby = PowerManager.isStandbyState
    if (currentUniverse === "popup" && !isOnStandby) {
      bus.emit("popup:close")
    }
  }

  openApps() {
    const isOnStandby = PowerManager.isStandbyState
    const openApps = UNIVERSE.includes(bus.universe)
    if (!isOnStandby && !openApps && !PowerManager.bootTimeRunning) {
      if (bus.universe === "home") {
        bus.closeCurrentUniverse()
      }
      this.closePopup()
      bus.emit("appstore:view")
    }
    this.donwloadActionFinished()
  }

  versionExit(status,fromBack,action) {
    if (status && action !== this.config.APPFILE && fromBack !== true) {
      this.closePopup()
      this.openHome()
      this.errorActiveService()
    } else if (status && action !== this.config.APPFILE && fromBack === true) {
      this.openHome()
    } else if (status && action === this.config.APPFILE && fromBack === false) {
      this.appFileDownloadFailed()
    } else if (!status && action === this.config.APPFILE && fromBack === false) {
      this.appFileDownloadFailed()
    } else {
      // Slient is Golden..
    }
  }

  currentTaskCompleted(href) {
    let type = null
    let flag = null
    if (href && href === DownloaderManager.download.adsCurrentTask) {
      type = this.config.ADS
      flag = this.config.ADSCATALOG
    } else if (href && href === DownloaderManager.download.appsCurrentTask) {
      type = this.config.APPS
      flag = this.config.APPSCATALOG
    } else if (href && href === DownloaderManager.download.appCurrentTask) {
      type = this.config.APP
      flag = this.config.APPFILE
    }

    if (type) {
      bus.emit("download:action",type)
    }
    return flag
  }

  @on("version:inOutStandby")
  onInOutStandby(power) {
    let type = null
    let task = null
    let stoptask = null

    if (power === "awake") {
      type = this.config.ADSCATALOG
      task = DownloaderManager.download.adsCurrentTask
      stoptask = DownloaderManager.download.adsCurrentTaskStandy
    } else if (power === "standby") {
      // type = this.config.ADSCATALOG
      type = this.config.ADSCATALOG
      task = DownloaderManager.download.adsCurrentTaskStandy
      stoptask = DownloaderManager.download.adsCurrentTask
    }

    return this.getDvbUri(type).then((uri) => {
      if (uri && task) {
        if (stoptask) DownloaderManager._stopDownload(stoptask)
        if (task) DownloaderManager._startDownload(task)
      } else {
        this.onFlyDownload()
      }
    })
  }

  errorActiveService() {
    const isOnStandby = PowerManager.isStandbyState
    if (!isOnStandby) {
      errorAppLaunched()
    }
  }

  /* ********************************** *********************
   *                 CHECKER METHODS           *
   ********************************** ***********************/

  getChecker() {
    return CheckerApi.getChecker()
  }

  getCheckerTask(id) {
    return CheckerApi.getCheckerTask(id)
  }

  setChecker(option) {
    return CheckerApi.setChecker(option)
  }

  startChecker(id) {
    return CheckerApi.startChecker(id)
  }

  installChecker(id,option) {
    return CheckerApi.installChecker(id, option)
  }

  unInstallChecker(id) {
    return CheckerApi.unInstallChecker(id)
  }

  cancelChecker(id) {
    return CheckerApi.cancelChecker(id)
  }

  deleteChecker(id) {
    return CheckerApi.deleteChecker(id)
  }

  askForchecker(data) {
    const option = {}
    return new Promise((reslove,reject) => {
      option.path = data.data_path
      option.storage_mode = "storage_mode_permanent"

      const currentStimulation = this.currentTaskCompleted(data.href)
      if (currentStimulation === this.config.ADSCATALOG) option.user_data = ["advertising"]
      if (currentStimulation === this.config.APPSCATALOG) option.user_data = ["application"]
      if (currentStimulation === this.config.APPFILE) {
        option.user_data = ["playStore"]
        option.storage_mode = "storage_mode_temporary"
      }

      // Store for install Process...
      this.installationProcess = parseInt(currentStimulation)
      let currentChecker = null
      return this.setChecker(option)
      .then((response) => {
        currentChecker = response.href.split("/")[2]
        this.currentChecker = currentChecker
        return this.startChecker(this.currentChecker)
      })
      .then(() => {
        reslove(true)
      })
      .catch((error) => {
        this.showResults(false,true,true)
        reject("Error on Checker",error)
      })
    })
  }

  onInstallChecker(checketId) {
    this.askForInstallChecker(checketId)
    .catch(() => {
      this.showResults(false,true,true)
    })
  }

  updateAdsModel(refress) {
    if (refress) this.refressAds()
    if (DownloaderManager.requestDw) {
      this.requestForLiveDownload()
    }
  }

  requestForLiveDownload() {
    this.onFlyDownload()
  }

  showResults(sucess,fail,trusted = true, load = false) {
    const currentStimulation = load || this.getCurrentStimulation()
    const istrusted = trusted
    if (sucess) {
      if (currentStimulation === this.config.ADSCATALOG) {
        this.updateAdsModel(true)
      } else {
        this.onDownloaderDone(true,istrusted,currentStimulation)
      }
    }
    if (fail) {
      if (currentStimulation === this.config.ADSCATALOG) {
        this.updateAdsModel(false)
      } else {
        this.onDownloaderDone(false,istrusted,currentStimulation)
      }
    }
    this.donwloadActionFinished()
  }


  askForInstallChecker() {
    return new Promise ((reslove,reject) => {
      const option = {}
      if (!this.currentChecker) reject("Ignore as no current checker id")
      const currentStimulation = parseInt(this.installationProcess)

      if (currentStimulation === this.config.ADSCATALOG) {
        this.config.ADS_CHECKER_ID = this.currentChecker
        option.path = "adBase"
      } else if (currentStimulation === this.config.APPSCATALOG) {
        this.config.APPS_CHECKER_ID = this.currentChecker
        option.path = "appsBase"
      } else if (currentStimulation === this.config.APPFILE) {
        this.config.APPFILE_CHECKER_ID = this.currentChecker
        option.path = "playStore"
      }

      return this.getOldCheckerID(option.path)
      .then((id) => {
        this.oldChecker = id ? id : null
        return this.oldChecker ? this.unInstallChecker(this.oldChecker) : "noChecker"
      })
      .then(() => {
        return this.installChecker(this.currentChecker,option)
      })
      .then(() => {
        return option.path !== "playStore" ? this.onInstalledComplete(this.currentChecker,option.path) : null
      })
      .then(() => {
        if (this.oldChecker) this.oldChecker = null
        reslove("Installation Process & UnInstallation for old checker is fullfil")
      })
      .catch((error) => {
        reject("Fail To InstallChecker",error)
      })
    })
  }

  @on("checker:unInstalled")
  askForUnInstallChecker(isCurrent = true) {
    return new Promise((reslove,reject) => {
      let checkerID = null
      if (isCurrent) {
        checkerID = this.currentChecker
      } else if (!isCurrent) {
        checkerID = this.oldChecker
      }
      if (!checkerID) reject("Ignore as no current checker id")
      return this.unInstallChecker(checkerID)
      .then(() => {
        reslove("unInstall and Delete is done")
      })
      .catch((error) => {
        reject("UnInstall Error : ",error)
      })
    })
  }

  onInstalledComplete(id,type) {
    return new Promise((reslove) => {
      if (id && type && type !== "playStore") {
        const type_href = `${type}_checker_id`
        const checkerID = id.toString()
        return setEntry("checker",type_href,checkerID)
        .then(() => {
          reslove(true)
        })
        .catch(() => {
          reslove(false)
        })
      } else {
        reslove(false)
      }
    })
  }

  getOldCheckerID(type) {
    return new Promise((reslove) => {
      if (!type || type === "playStore") return reslove(false)
      const type_filed = `${type}_checker_id`
      getEntry("checker",type_filed)
      .then((id) => {
        reslove(id)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  onBootInstallAppsChecker() {
    return new Promise((reslove) => {
      const option = {
        "path" : "appsBase",
      }
      return getEntry("checker","appsBase_checker_id")
      .then((id) => {
        if (id) {
          this.config.APPS_CHECKER_ID = id
          return this.installChecker(id,option)
        } else {
          return false
        }
      })
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  onBootInstallAdsChecker() {
    return new Promise((reslove) => {
      const option = {
        "path" : "adBase",
      }
      return getEntry("checker","adBase_checker_id")
      .then((id) => {
        if (id) {
          this.config.ADS_CHECKER_ID = id
          return this.installChecker(id,option)
        } else {
          return "nochecker"
        }
      })
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  onBootDeletedVersion() {
    return new Promise((reslove) => {
      return this.deletedAdsVersion()
      .then(() => {
        return this.deletedAppsVersion()
      })
      .then(() => {
        reslove()
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAdsVersion() {
    return new Promise((reslove) => {
      return deleteEntry("checker","ads_version")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAppsVersion() {
    return new Promise((reslove) => {
      return deleteEntry("checker","apps_version")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAdsWydvburi() {
    return new Promise((reslove) => {
      return deleteEntry("checker","ads_wydvb_uri")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAppsWydvburi() {
    return new Promise((reslove) => {
      return deleteEntry("checker","apps_wydvb_uri")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedStandbyAdsWydvburi() {
    return new Promise((reslove) => {
      return deleteEntry("checker","standby_ads_wydvb_uri")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAddsBaseCheckerId() {
    return new Promise((reslove) => {
      return deleteEntry("checker","addsBase_checker_id")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  deletedAppsBaseCheckerId() {
    return new Promise((reslove) => {
      return deleteEntry("checker","appsBase_checker_id")
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  onBootChecker() {
    return new Promise((reslove) => {
      const option = {}
      this.onBootInstallAdsChecker()
      .then((id) => {
        if (id) {
          option.path = "adBase"
          return this.installChecker(id,option)
        } else {
          return false
        }
      })
      .then(() => {
        this.onBootInstallAppsChecker()
        .then((id) => {
          if (id) {
            option.path = "appsBase"
            return this.installChecker(id,option)
          } else {
            return false
          }
        })
        .then(() => {
          reslove(true)
        })
        .catch(() => {
          reslove(false)
        })
      })
    })
  }


  /* ********************************** *********************
   *                 OnLive Download            *
   ********************************** ***********************/

  onFlyDownload() {
    DownloaderManager.downloadAdvertise()
  }

  saveDvbUri(catalogType,uri) {
    return new Promise((reslove) => {
      let type
      if (catalogType === this.config.ADSCATALOG) {
        type = this.config.ADSDVBURI
      } else if (catalogType === this.config.APPSCATALOG) {
        type = this.config.APPSDVBURI
      } else if (catalogType === this.config.STANDY) {
        type = this.config.STANDBY_ADSDVBURI
      } else {
        type = null
      }
      try {
        const option = this.getUrlParams(uri)
        if (type && option.hasOwnProperty("component_tag")) {
          return setEntry("checker",type,uri)
          .then(() => {
            reslove(true)
          })
          .catch(() => {
            reslove(false)
          })
        } else {
          reslove(false)
        }
      } catch (error) {
        reslove(false)
      }
    })
  }

  ignoreDwTimmer() {
    return new Promise((reslove) => {
      const isOnStandby = PowerManager.isStandbyState
      const currentStimulation = this.getCurrentStimulation()
      if (currentStimulation === this.config.ADSCATALOG && isOnStandby) {
        reslove(true)
      } else {
        reslove(false)
      }
    })
  }

  getDvbUri(catalogType) {
    return new Promise((reslove) => {
      let type
      if (catalogType === this.config.ADSCATALOG) {
        type = this.config.ADSDVBURI
      } else if (catalogType === this.config.APPSCATALOG) {
        type = this.config.APPSDVBURI
      } else {
        type = null
      }
      if (type === null) return reslove(false)
      return getEntry("checker",type)
      .then((dvbUri) => {
        reslove(dvbUri)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }

  getDownLoadUri() {
    return new Promise((reslove) => {
      const ads = this.config.ADSCATALOG
      const apps = this.config.APPSCATALOG

      return this.getDvbUri(ads).then((response) => {
        if (response) DownloaderManager.download.adsTaskUri = response
        return this.getDvbUri(apps)
      })
      .then((response) => {
        if (response) return DownloaderManager.download.appsTaskUri = response
      })
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        reslove(false)
      })
    })
  }


}

export default new VersionManagers()
