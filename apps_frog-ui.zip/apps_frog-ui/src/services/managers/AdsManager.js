//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import AdsModel from "services/models/ads/Ads"
import bus from "services/bus"
import {GET} from "services/http"
import config from "utils/config"

const PLACEHOLDERS = {
  "home": "Home",
  "tv": "channelList",
  "epg": "tvGrid",
  "pvr": "tvRecording",
  "infoBanner" : "LIVEINFOBANNER",
}

const PATH =  `http://${config.STB_IP}${config.AD_BASE}`
const CATALOG_NAME = "advertisingProgram.json"

class AdsManager {
  constructor() {
    this.homeAds = null
    this.epgAds = null
    this.pvrAds = null
    this.channelListAds = null
    this.infoBannerAds = null
    this.campaigns = []
    this.ad = null
    this.path = null
  }

  getAd() {
    return this.ad
  }

  getMediaPath() {
    return this.ad && this.ad.mediaFile ? PATH + this.ad.mediaFile : null
  }

  loadAdsCatalogue() {
    const path = PATH + CATALOG_NAME
    return GET(path, {
      headers: {
        "Accept": "application/json",
      },
    }).then((json) => {
      return this.fillManager(json)
    }).catch(() => {
      return bus.emit("appstore:stopLoadingApps")
    })
  }

  fillManager(json) {
    this.campaigns = json.campaigns
    this.homeAds = new AdsModel(json.program[PLACEHOLDERS.home], this.path)
    this.epgAds = new AdsModel(json.program[PLACEHOLDERS.epg], this.path)
    this.pvrAds = new AdsModel(json.program[PLACEHOLDERS.pvr], this.path)
    this.channelListAds = new AdsModel(json.program[PLACEHOLDERS.tv], this.path)
    this.infoBannerAds = new AdsModel(json.program[PLACEHOLDERS.infoBanner], this.path)
  }

  fetchAd(universe,isChannelList = false) {
    let currentAdModel = null
    switch (universe) {
    case "home":
      currentAdModel = this.homeAds
      break
    case "epg":
      currentAdModel = this.epgAds
      break
    case "pvr":
      currentAdModel = this.pvrAds
      break
    case "tv":
      if (isChannelList) {
        currentAdModel = this.channelListAds
      } else {
        currentAdModel = this.infoBannerAds
      }
      break
    default:
      this.ad = null
      return Promise.resolve(this.ad)
    }
    this.ad = (currentAdModel) ? this.getModelFromCampaignId(currentAdModel.getCurrentCampaignId()) : null
    return Promise.resolve(this.ad)
  }

  getModelFromCampaignId(campaignId) {
    if (campaignId && this.campaigns[campaignId]) {
      return this.campaigns[campaignId]
    } else {
      return null
    }
  }
}

export default new AdsManager()
