//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//
import bus from "services/bus"
import {sse, on, enableEvents} from "services/events"
import {isDefined, findKey} from "utils"
import config from "utils/config"

import Program from "services/models/Program"
import {dateToCdsTimestamp} from "utils/date"

import * as PlayerApi from "services/api/player"
import * as playerConfigApi from "services/api/player_config"

import * as audiotracks from "services/api/audiotracks"
import AudioTrack from "services/models/AudioTrack"

import * as subtitles from "services/api/subtitles"
import Subtitle from "services/models/Subtitle"
import BlockedChannelManager from "services/managers/BlockedChannelManager"
import ScanManager from "services/managers/ScanManager"

import CasManager from "services/managers/CasManager"
import ChannelManager from "services/managers/ChannelManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import PowerManager from "services/managers/PowerManager"
import * as popUpMsg from "app/utils/PopUpMsg"
import {getEntryFromSection, setLastTunedLcn,getAudioTrackStatus} from "services/managers/config"

const DRM_STATE = Object.freeze({
  OK: 180,
  FAILED: 192,
})

const STATE = Object.freeze({
  STOPPED: 10,
  PLAYING: 11,
  TRANSITIONING: 12,
  PAUSED_PLAYBACK: 13,
  PAUSED_RECORDING: 14,
  RECORDING: 15,
  NO_MEDIA_PRESENT: 16,
})

const SPEEDS = Object.freeze({
  PAUSED: 0,
  NORMAL: 1,
  SLOW: 2,
  MODERATE: 4,
  MEDIUM: 8,
  FAST:16,
  HIGH: 32,
})

const TIMESHIFT_DURATION = 3600 // 60 minutes

class BufferOffsets {
  constructor(min, max) {
    this.min = parseFloat(min, 10)
    this.max = parseFloat(max, 10)
  }
}

class BufferInfo {
  constructor(parts) {
    this.contentPosition = parts.length ? new BufferOffsets(...parts[0]) : null
  }
}

class PlayerPosition {
  constructor(json) {
    this.position = json.position
    this.size = json.size
    this.bufferInfo = new BufferInfo(json.buffer_info)
  }
}

class PlayerManager {
  constructor() {
    this.id = null
    this.speed = null
    this._state = null
    this.channel = null
    this.program = null
    this.showCurrentChannelBanner = true
    this.prevChannelTuned = ""
    this.forceSlideLcn = ""
    this.serviceId = null
    this.finalAnswer = null
    this.audioTrackPersis = []
    this.audioTrackPersisVal = {}
    this.userPerferTrack = null
    this.audioLangPerfix = null
    this.previousChannel = null
    this.timeshiftMode = "play"
    this.callbyStandy = false
    this.playerWidth = null
    this.playerHeight = null
    this.tvType = "Auto"
    this.enablePVR = true
    enableEvents(this)
  }

  _checkAudioPersistance(item) {
    // On Play Request check for Persistance Audio Track and if than set meta to it...
    if (this.audioTrackPersis.length > 0 && this.audioTrackPersis.indexOf(item.serviceId) !== -1) {
      this.userPerferTrack = this.audioTrackPersisVal[item.serviceId]
      return true
    } else {
      return false
    }
  }

  setPersistanceAudio(data) {
    // OnBoot check for the Persistance Channel.. and set AudioTrack....
    const trackServiceId = []
    data.map((section) => {
      const persisTrack = section.href.split("/")[3]
      trackServiceId.push(persisTrack)
      this.audioTrackPersis.push(persisTrack)
      getAudioTrackStatus(persisTrack).then((response) => {
        this.audioTrackPersisVal[persisTrack] = response
      })
    })
  }

  play(item, type="channel", metadata={}) {
    this.enablePVR = false
    bus.emit("channels:clearProgram")
    return new Promise((resolve,reject) => {
      const payload = {}
      if (ScanManager.isFirstInstall) {
        return reject("Cannot perform action during First Install")
      }
      if (!this.id || !item) {
        return reject("No player available")
      }

      // check if audio persistance than set meta data to it...else byPass...
      if (this._checkAudioPersistance(item) !== false) {
        const languageTrack = this.userPerferTrack
        if (languageTrack !== null) {
          this.userPerferTrack = null
          metadata.preferred_audio_languages = {"2":languageTrack}
        }
      }

      this.previousChannel = BlockedChannelManager.getCurrentChannel()
      switch (type) {
      case "channel":
        payload.service_id = item.serviceId
        payload.play_info = item.playInfo
        payload.metadata = metadata
        bus.emit("tv:zap", item)
        // this._emitEpgUpdateSignal(null)
        break
      case "radio":
        payload.service_id = item.serviceId
        payload.play_info = item.playInfo
        payload.metadata = metadata
        bus.emit("radio:zap", item)
        break
      case "pvr":
      case "media":
        payload.play_info = item.playInfo
        payload.metadata = metadata
        break
      default:
      }

      if (type !== "channel") {
        PlayerApi.play(this.id, payload).then(() => {
          this.enablePVR = true
          resolve(true)
        })
      } else {
        this.displaychannel(payload,item).then((res) => {
          this.enablePVR = true
          resolve("PlayerApi",res)
        })
        .then(()=>{
          CasManager.getPlayerSubscribeInfoPlay()
        }).catch((e) => {
          this.enablePVR = true
          reject(e)
        })
        if (this.previousChannel && this.previousChannel !== item && this.previousChannel.lcn !== this.forceSlideLcn) {
          this.prevChannelTuned = this.previousChannel.lcn
        }
      }
    })
  }

  displaychannel(payload,item) {
    return PlayerApi.play(this.id, payload).then((data) => {
      if (isDefined(data)) {
        if (data.error === "conflict") {
          item = this.previousChannel
          CasManager.ModActiveStatus = false
          if (CasManager.isFingerprintActive === true && this.timeshiftMode === "play")
            CasManager.closeFingerprint()
          return Promise.resolve(true)
        } else if (data.debug) {
          return Promise.reject(`MR error: ${data.debug}`)
        }
      } else {
        this.channel = item
        setLastTunedLcn(item.lcn)
        CasManager.ModActiveStatus = false
        if (CasManager.isFingerprintActive === true && this.timeshiftMode === "play")
          CasManager.closeFingerprint()
        return Promise.resolve(true)
      }
    }).catch((error) => {
      return Promise.reject(`Play Error :: ${error}`)
    })
  }

  parentalChannel() {
    if (this.previousChannel && this.previousChannel !== item && this.previousChannel.lcn !== this.forceSlideLcn) {
      this.prevChannelTuned = this.previousChannel.lcn
    }
    //   this._emitEpgUpdateSignal(null)
    return new Promise((resolve) => {
      if (BlockedChannelManager.isChannelBlocked(item,this.previousChannel,this.state)) {
        this.stop()
        bus.emit("tv:open")
        bus.emit("parentalpopup:parentAlert", "BlockChannel", null,function(isPassCorrect) {
          if (isPassCorrect) {
            this.displaychannel(payload,item)
            resolve(true)
          }
        }, "parent", {})
      } else {
        resolve(false)
      }
    })
  }

  playCurrentChannel(currentChannel, type="channel") {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    const isOnStandby = PowerManager.isStandbyState
    if (currentChannel && !isFtaBlock && !isOnStandby) {
      this.play(currentChannel, type)
      .catch((err) => console.log("Fail to Play :: ",err))
    }
  }

  stopCurrentChannel() {
    const isPlayerStop = this._state
    if (isPlayerStop !== 10) {
      this.stop()
      .catch((err) => console.log("Fail to Stop :: ",err))
    }
  }

  pause() {
    // Pause Stream
    return PlayerApi.pause(this.id)
  }

  resume() {
    // Resume Stream
    return PlayerApi.setSpeed(this.id, SPEEDS.NORMAL)
  }

  stop() {
    // Stop Stream
    return PlayerApi.stop(this.id)
  }

  fastForward() {
    // Forward Stream
    let speed

    return PlayerApi.getSpeed(this.id)
     .then(data => {
       if (data.CurrentSpeed <= SPEEDS.NORMAL) {
         speed = SPEEDS.SLOW
       } else if (data.CurrentSpeed <= SPEEDS.SLOW) {
         speed = SPEEDS.MODERATE
       } else if (data.CurrentSpeed <= SPEEDS.MODERATE) {
         speed = SPEEDS.MEDIUM
       } else if (data.CurrentSpeed <= SPEEDS.MEDIUM) {
         speed = SPEEDS.FAST
       } else {
         speed = SPEEDS.HIGH
       }

       if (speed === SPEEDS.SLOW) {
         return PlayerApi.setSpeed(this.id, SPEEDS.NORMAL).then(() => {
           return PlayerApi.setSpeed(this.id, speed)
         })
       } else {
         return PlayerApi.setSpeed(this.id, speed)
       }
     })
      .then(() => Promise.resolve(speed))
  }

  fastRewind() {

    // Rewind Stream
    let speed

    return PlayerApi.getSpeed(this.id)
      .then(data => {
        if (data.CurrentSpeed >= SPEEDS.PAUSED) {
          speed = -SPEEDS.SLOW
        } else if (data.CurrentSpeed >= -SPEEDS.SLOW) {
          speed = -SPEEDS.MODERATE
        } else if (data.CurrentSpeed >= -SPEEDS.MODERATE) {
          speed = -SPEEDS.MEDIUM
        } else if (data.CurrentSpeed >= -SPEEDS.MEDIUM) {
          speed = -SPEEDS.FAST
        } else {
          speed = -SPEEDS.HIGH
        }

        return PlayerApi.setSpeed(this.id, speed)
      })
      .then(() => Promise.resolve(speed))
  }

  backToLive() {
    return this._getEndRelativePosition().then((pos) => {
      // Add 5 sec for safety (requests overhead, processing time, etc.)
      return this._seekRelative(pos.position + 25)
    })
  }

  getDeltaFromLive() {
    return this.getAbsolutePosition().then((info) => {
      const contentPosition = info.bufferInfo.contentPosition
      return contentPosition.max - info.position
    })
  }
  setChannelId(channelItem) {
    this.serviceId = channelItem.serviceId
  }
  getTrack() {
    return getEntryFromSection("audio_lang",this.serviceId)
    .then((traceData) => {
      return traceData
    })

  }
  setDefaultAudio() {
    return this.getTraceIdFromLang().then(() => {
      return this.finalAnswer
    }).then ((traceData) => {
      if (traceData !== null) {
        audiotracks.putTrack(this.id, parseInt(traceData))
      }
    })
    .catch(() => {})
  }
  getTraceIdFromLang() {
    return getEntryFromSection("audio_lang",this.serviceId)
    .then ((traceData) => {
      return audiotracks.getAll(this.id)
      .then ((data) => {
        return data.tracks.map((t) => {
          const track = new AudioTrack(t)
          return track
        })
      }).then ((audios) => {
        this.finalAnswer = null
        bus.emit("programeDetail:traceId",traceData)
        return audios.map((t, i) => {
          if (t._attributes.AudioLang === traceData) {
            this.finalAnswer = i
            return i
          }

        })

      })
    })
  }

  getAudioTracks() {
    // return audio tracks for the current stream
    return Promise.all([audiotracks.getAll(this.id), audiotracks.getTrack(this.id)])
      .then(([data, current]) => {
        return data.tracks.map((t, i) => {
          const track = new AudioTrack(t)
          track.default = (i === current.track_id)
          return track
        })
      })
  }

  findAudioLang(trackId) {
    // find the audio lang through current Track ID
    return Promise.all([audiotracks.getAll(this.id)])
      .then(([data]) => {
        data.tracks.forEach((value,key) => {
          if (key === trackId) {
            this.audioLangPerfix = value.AudioLang
          }
        })
        return this.audioLangPerfix
      })
  }

  setAudioTrack(trackId) {
    // set the audio track for the current stream
    return audiotracks.putTrack(this.id, trackId)
  }

  getSubtitles() {
    // return subtitle tracks for the current stream
    return Promise.all([subtitles.getAll(this.id), subtitles.getTrack(this.id)])
      .then(([data, current]) => {
        // Add OFF subtitle
        data.tracks.splice(0, 0, {SubtitleLang: "OFF"})
        return data.tracks.map((t, i) => {
          const track = new Subtitle(t)
          track.default = (i === current.track_id + 1)
          return track
        })
      })
  }

  setSubtitle(trackId) {
    // set the subtitle track for the current stream
    return subtitles.putTrack(this.id, trackId - 1)
  }

  get state() {
    if (!this._state) {
      return PlayerApi.getSpeed(this.id)
       .then(data => {
         this._state = data.TransportState
         return findKey(STATE, this._state)
       })
    } else {
      return findKey(STATE, this._state)
    }
  }

  getInitialId() {
    if (this.initialId) {
      return Promise.resolve(this.initialId)
    }
    return PlayerApi.get(this.id).then((response) => {
      this.initialId = response["3117"] || null
      return Promise.resolve(this.initialId)
    })
  }

  onBoot() {
    PlayerApi.create({"user_name": document.title})
      .then((response) => {
        this.id = response.href.split("/")[2]
      })
  }

  setTimeshiftDuration() {
    return playerConfigApi.setTimeshiftDuration(TIMESHIFT_DURATION)
  }

  @on("pvr:ready")
  _onPvrReady(value) {
    let medium = "NONE"
    if (value) {
      medium = "AUTO"
    }
    this.setStorageMedium(medium)
  }

  setStorageMedium(medium) {
    if (medium && (medium === "AUTO" || medium === "NONE")) {
      return playerConfigApi.setStorageMedium(medium)
    } else {
      return Promise.reject(`medium value can only be 'AUTO' or 'NONE', not ${medium}`)
    }
  }

  setFullScreen() {
    /* At the time being, only hdmi0 can be manipulated */
    return playerConfigApi.resizeVideo("hdmi0", 0, 0, 0, 0)
  }

  setDownMix() {
    /* At the time being, only hdmi0 can be manipulated */
    return playerConfigApi.setAudioMode("hdmi0", "stereo_downmix")
  }

  _getEndRelativePosition() {
    return new Promise((resolve, reject) => {
      PlayerApi.getPosition(this.id, "mr_pos_end_time")
        .then((positionData) => {
          if (positionData.debug) {
            reject("_getEndRelativePosition: MR error: " + positionData.debug)
          } else {
            resolve(new PlayerPosition(positionData))
          }
        })
    })
  }

  getAbsolutePosition() {
    return new Promise((resolve, reject) => {
      PlayerApi.getPosition(this.id, "mr_pos_abs_time")
        .then((positionData) => {
          if (positionData.debug) {
            reject("getAbsolutePosition: MR error: " + positionData.debug)
          } else {
            resolve(new PlayerPosition(positionData))
          }
        })
    })
  }

  getAbsoluteTimestampPosition() {
    return new Promise((resolve, reject) => {
      PlayerApi.getPosition(this.id, "mr_pos_abs_timestamp")
        .then((positionData) => {
          if (positionData.debug) {
            reject("getAbsoluteTimestampPosition: MR error: " + positionData.debug)
          } else {
            resolve(new PlayerPosition(positionData))
          }
        })
    })
  }

  _seekRelative(target) {
    return PlayerApi.seek(this.id, {
      "seek_mode": "mr_skm_rel_time",
      "seek_target": target,
    })
  }

  _seekAbsolute(target) {
    return PlayerApi.seek(this.id, {
      "seek_mode": "mr_skm_abs_time",
      "seek_target": target,
    })
  }

  _seekFromEnd(target) {
    return PlayerApi.seek(this.id, {
      "seek_mode": "mr_skm_from_end",
      "seek_target": target,

    })
  }

  _emitEpgUpdateSignal(program) {
    if (this.state === STATE.STOPPED) {
      return
    }
    this.program = program
    bus.emit("player:program:update", this.program)
    this.program = null
  }

  @sse("player", {subtype: "playback", content: {tvsignal: () => true}})
  _onTvSignal(data) {
    const isFtaBlock = FtaBlockManager.isNavigationRestricted()
    if (data.content.tvsignal === 0) {
      if (!isFtaBlock) {
        FtaBlockManager.updateFtaPopupStatus(false,false,-1,null,null)
        if (bus.universe !== "pvr") {
          bus.emit("tv:timeshiftNoSignal")
          if (config.SD_ZAPPER && ChannelManager.current.serviceType === "HD") {
            popUpMsg.UnsubscribeHDChannelPromotion()
          } else {
            popUpMsg.ftaSignalNotFound(CasManager.vscNumber,true)
          }
        }
      }
    } else if (data.content.tvsignal === 1) {
      if (!isFtaBlock) {
        FtaBlockManager.ftaPopupStatus.setDefault()
        bus.emit("UnsubscribedErrorMsg:close")
        setTimeout(() => {
          if (!CasManager.timeoutID) {
            if (ChannelManager.current) {
              CasManager.getPlayerSubscribeInfo(Number(ChannelManager.current.lcn))
            }
          }
        },1000)
      }
      if (FtaBlockManager.isFtaActiveState === true) {
        FtaBlockManager._closeLegacyUniverse()
        setTimeout(function() {
          FtaBlockManager.isFtaBlockMode()
        },1000)

      }
    } else {}
  }

  @sse("player", {subtype: "playback", content: {drmstate: () => true}})
  _onScrambledSignal(data) {
    if (data.content.drmstate === DRM_STATE.FAILED) {
      // bus.emit("player:scrambled")
    } else if (data.content.drmstate === DRM_STATE.OK) {
      // bus.emit("player:descrambled")
    }
  }

  @sse("player", {subtype: "playback", content: {parentalcontrolstatus: () => true}})
  _onParentalControlStatus(data) {
    bus.emit("player:program:parental", data.content)
  }

  @sse("player", {subtype: "epg_update"})
  _onEpgUpdate(data) {
    const progData = data.content
    progData.href = "//"+progData.program_id
    if (progData.start_date && progData.end_date) {
      progData.start_date = dateToCdsTimestamp(progData.start_date * 1000)
      progData.end_date = dateToCdsTimestamp(progData.end_date * 1000)
    }

    const program = new Program(progData)
    this._emitEpgUpdateSignal(program)
  }

  @sse("player", {subtype: "playback", content: {state: () => true}})
  _onState(data) {
    this._state = data.content.state
    if (this._state === STATE.STOPPED) {
      if (!((bus.universe === "pvr") && (data.content.hasOwnProperty("recordrealstoptime")))) {
        bus.emit("player:state:stopped", {universe: bus.universe})
      }
    }
  }

  @sse("player", {subtype: "playback", content: {speed: () => true}})
  _onSpeedChange(data) {
    this.speed = data.content.speed
    if (this.speed === SPEEDS.NORMAL) {
      bus.emit("player:speed:normal", {universe: bus.universe})
    }
    if (data.content.speed === 1 && CasManager.isFingerprintActive === true && this.timeshiftMode === "fastForward") {
      console.log("player speed changed and fingerprint is ON")
      CasManager.closeFingerprint()
    }
    if (CasManager.isFingerprintActive === false) {
      // CasManager.closeFingerprint()
    }

  }

  @sse("player", {subtype: "playback", content: {firstframeondisplay: () => true}})
  _onPlayerPostion() {
    PlayerApi.frameDisplay().then((resp) => {
      this.playerWidth = resp.source_resolution[0]
      this.playerHeight = resp.source_resolution[1]
    })
  }

}

export default new PlayerManager()
