//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved.
// This source code and any compilation or derivative thereof is the
// proprietary information of Wyplay and is confidential in nature.
// Under no circumstances is this software to be exposed to or placed under
// an Open Source License of any type without the expressed written permission
// of Wyplay.
//


import {enableEvents} from "services/events"
import bus from "services/bus"
import * as ReminderPopUp from "app/utils/PopUpMsg"
import ChannelManager from "services/managers/ChannelManager"


class ProgramReminder {
  constructor() {
    this.iconDetail= {}
    this.lastlegency = null
    enableEvents(this)
  }

  onDisplayReminder(data) {
    const channel = ChannelManager.getChannelFromServiceId(data.content.meta_service_id)
    if (data.content.channel_number && (ChannelManager.current.lcn === Number(data.content.channel_number))) {
      // Not to do if already tuned on desired lcn...
    } else {
      const buttons = [
        {
          label: "OK",
          action: () => {
            bus.closeCurrentUniverse()
            if (this.lastlegency) {
              bus.emit(`${this.lastlegency}:close`)
            }
            if (ChannelManager.useFav && ChannelManager.favoriteChannels.indexOf(channel) === -1) {
              ChannelManager.toggleFavoriteListAsChannelList(channel)
              .then(() => {
                bus.emit("channels:updated")
                bus.emit("epg:watch_channel",{channel_number:data.content.channel_number})
              })
            } else {
              bus.emit("epg:watch_channel",{channel_number:data.content.channel_number})
              this.lastlegency
            }
          },
        },
        {
          label: "BACK",
          action: () => {
          },
        },
      ]
      console.log("ChannelManager=",ChannelManager)
      console.log("channel=",channel)
      if (channel !== ChannelManager.current.lcn) {
        const currentUniverse = bus.universe
        if (currentUniverse && currentUniverse !== "bigbang") {
          ReminderPopUp.showReminderMessage(data.content.title, data.content.channel_name,
            data.content.channel_number, data.content.start_hour, 60000, buttons)
        }
      }
    }
  }
}
export default new  ProgramReminder()
