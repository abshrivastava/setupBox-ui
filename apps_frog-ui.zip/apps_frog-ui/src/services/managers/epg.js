//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {dateToCdsTimestamp} from "utils/date"
import {Programs, Program} from "services/models/"

const DEFAULT_OPTIONS = {
  metadata: [
    "service_id", "title", "start_date", "end_date",
    "content_nibble_level_1", "description",
    "short_description", "program_id",
  ],
}

export function getCurrentPrograms(channels) {
  const serviceIds = channels.map(c => c.serviceId)
  const now = dateToCdsTimestamp(new Date())
  const options = Object.assign({}, DEFAULT_OPTIONS)

  options.criteria = [
    `service_id IN {${serviceIds.join(";")}}`,
    `start_date<${now}`,
    `end_date>${now}`,
  ].join(" AND ")

  return queryPrograms(options)
    .then((programs) => {
      const programsByServiceId = programs.items.reduce((map, program) => {
        return Object.assign(map, {[program.serviceId]: program})
      }, {})

      return serviceIds.reduce((map, serviceId) => {
        const program = programsByServiceId[serviceId] || new Program({service_id: serviceId})
        return Object.assign(map, {[serviceId]: program})
      }, {})
    })
    .catch(err => console.error(err))
}

export function getCurrentProgram(channel) {
  if (!channel) {
    return Promise.resolve(null)
  }
  return getCurrentPrograms([channel])
    .then((programs) => {
      const currentProgram = programs[channel.serviceId]
      return currentProgram || null
    })
}

export function getProgramFromServiceId(serviceId, startDate, endDate) {
  const options = Object.assign({}, DEFAULT_OPTIONS, {
    "criteria": `service_id==${serviceId} AND
      start_date>${dateToCdsTimestamp(startDate.getTime())} AND end_date>${dateToCdsTimestamp(endDate.getTime())}`,
    "max_count": 1,
  })

  return queryPrograms(options)
    .then((programs) => {
      return programs.items[0]
    })
}

export function getNextProgram(channel) {
  const serviceId = channel.serviceId
  const now = dateToCdsTimestamp(new Date())

  const options = Object.assign({}, DEFAULT_OPTIONS, {
    "criteria": `service_id==${serviceId} AND start_date>${now}`,
    "max_count": 1,
  })

  return queryPrograms(options)
    .then(programs => programs.items[0])
}

export function queryPrograms(options) {
  const programsQuery = new Programs()

  return new Promise((resolve) => {
    programsQuery.create(options)
      .then((programs) => {
        programsQuery.destroy()
        resolve(programs)
      })
  })
}

export default {
  getCurrentPrograms,
  getCurrentProgram,
  getProgramFromServiceId,
  getNextProgram,
  queryPrograms,
}
