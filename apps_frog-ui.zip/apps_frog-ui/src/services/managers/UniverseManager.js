//
// Copyright (C) 2006-2017 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import AdvertisementController from "app/controllers/Advertisement"
import ApplicationController from "app/controllers/Apps"
import AppsController from "app/controllers/Application"
import EpgGridController from "app/controllers/EpgGrid"
import HomeController from "app/controllers/Home"
import PVRController from "app/controllers/PVR"
import SettingsController from "app/controllers/Settings"
import TelevisionController from "app/controllers/Television"
import FirstInstallController from "app/controllers/FirstInstall"

import Singleton from "utils/Singleton"
import {enableEvents} from "services/events"
import config from "utils/config"
import bus from "services/bus"

/**
 * Default UNIVERSES list
 * @type {[object]} UNIVERSES
 */
let UNIVERSES = [
  {
    label: "Advertisement",
    controller: AdvertisementController,
  },
  {
    label: "Application",
    controller: ApplicationController,
  },
  {
    label: "Apps",
    controller: AppsController,
  },
  {
    label: "EpgGrid",
    controller: EpgGridController,
  },
  {
    label: "Home",
    controller: HomeController,
  },
  {
    label: "PVR",
    controller: PVRController,
  },
  {
    label: "Settings",
    controller: SettingsController,
  },
  {
    label: "Television",
    controller: TelevisionController,
  },
  {
    label: "FirstInstall",
    controller: FirstInstallController,
  },
]

if (config.PVR_DISABLED) {
  UNIVERSES = UNIVERSES.filter(item => item !== UNIVERSES[5])
}

/**
 * class for manager universe navigation.
 */
class UniverseManager extends Singleton {

  /**
   * UniverseManager constructor
   *
   */
  constructor() {
    super()
    /**
     * @type {object}
     * @private
     */
    this._currentUniverse = null
    /** @type {object} **/
    this.previousUniverse = null
    /** @type {object} **/
    this.application = null
    /** @type {object} **/
    this.universes = {}
    /** @type {boolean} **/
    this.isInStandby = false
    /** @type {boolean} **/
    this.isFirstboot = true
  }

  /* ************************************************************************ */

  /* ********* Getters / Setters ********* */
  /** @type {object} **/
  get currentUniverse() {
    return this._currentUniverse
  }

  /** @type {string} **/
  set currentUniverse(value) {
    bus.universe = value
    this._currentUniverse = this.universes[value]
  }

  /* ************************************************************************ */

  /* ********* Controllers initialization ********* */

  /**
   * Call when application started to show splash and load application controllers
   */
  startApplication() {
    this._initAppControllers()
    // this.application = this.universes.application
  }

  /**
   * Instanciate all application controllers
   *
   * @private
   */
  _initAppControllers() {
    UNIVERSES.forEach((universe) => {
      this.universes[universe.label] = new universe.controller()
      return this._enableControllerEvents(this.universes[universe.label])
    })
  }

  /**
   * Enable events on controllers and on their delegates
   *
   * @param {object<Controller>} controller - A Controller instance
   * @private
   */
  _enableControllerEvents(controller) {
    enableEvents(controller)
    for (const delegate of controller.delegates) {
      this._enableControllerEvents(delegate)
    }
  }
}

export default new UniverseManager()