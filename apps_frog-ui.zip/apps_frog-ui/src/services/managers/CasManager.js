//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {$} from "widgets/Component"
import bus  from "services/bus"
import {on, sse, enableEvents} from "services/events"
import * as casApi from "services/api/cas"
import {getVCno} from "services/api/config"
import * as ChannelApi from "services/api/channels"
import * as popUpMsg from "app/utils/PopUpMsg"
import ChannelManager from "services/managers/ChannelManager"
import FtaBlockManager from "services/managers/FtaBlockManager"
import ScanManager from "services/managers/ScanManager"
import {wait} from "utils"
import config from "utils/config"

const DEFAULT_QUERY_CHANNELTYPE = {
  order: ["lcn"],
  metadata: [
    "service_id", "lcn", "service_type",
  ],
}

const CRI_VALUE = ["FTA","SCRMBLD_WO_CRI","SCRMBLD_CRI"]

class CasManager {
  constructor() {
    this.vscNumber = "NOT AVAILABLE"
    enableEvents(this)
    this.cashActive = true
    this.unsubscribedPopupOpen = false
    this.isFingerprintActive = false
    this.fingerprintTimer = null
    this.fingerprintCheckTimer = null
    this.BackgroundShow = false
    this.isPopUpOn = false
    this.ModState = false
    this.ModActiveStatus = false
    this.Currency = "NOT AVAILABLE"
    this.PriceInUnit = "NOT AVAILABLE"
    this.PurchaseCode = "NOT AVAILABLE"
    this.EventName = "NOT AVAILABLE"
    this.PriceDecimalForm = "NOT AVAILABLE"
    this.currentHDMI = null
    this.currentCriStatus = CRI_VALUE[0]
    this.holdExtraCall = false
    this.timeoutID = null
  }

  /* *************** VC Number Information ********************* */
  setVSCnumber() {
    getVCno().then((response) => {
      this.vscNumber = response.vscNumString
    }).catch(()=> {
      this.vscNumber = "NOT AVAILABLE"
    })
  }

    /* *************** Current TUNED Channel CRI Status ********************* */
  fetchCriStatus() {
    return casApi.getCriStatus()
    .then((data) => {
      if (data.cristatus >= 0 && data.cristatus < CRI_VALUE.length) {
        return Promise.resolve(CRI_VALUE[data.cristatus])
      } else {
        return Promise.resolve(CRI_VALUE[0])
      }
    })
    .catch(()=>{
      return Promise.resolve(CRI_VALUE[0])
    })
  }

  getPlayerSubscribeInfoPlay() {
    casApi.getAccessStatus().then((data) => {
      if (data.Access_status === 9 || data.Access_status === 0) {
        bus.emit("UnsubscribedErrorMsg:close")
      }
    })
  }

/* *************** Unsubscribe PopUp Information ********************* */
  showUnsubscribeHDPopUp(data) {
    // Handling for price information
    const channelInfo = data.channels
    const serviceId = data.channels[0].service_id
    wait(500).then(() => {
      return casApi.getPriceTag(serviceId)
    })
    .then((detail) => {
      let priceTag = detail.priceTag
      // when price information is zero
      if (priceTag === 0) priceTag = "_"
      // when price information is undefined
      if (priceTag=== undefined || priceTag === null) priceTag = "NOT AVAILABLE"

      const noOfHdChannels = detail.numHDChannels || null

      if (ChannelManager.current && detail) {
        if (ChannelManager.current.serviceId === channelInfo[0]["service_id"]) {
          const channelNum = ChannelManager.current.lcn
          if (config.SD_ZAPPER)
            popUpMsg.UnsubscribeHDChannelPromotion()
          else
            popUpMsg.UnsubscribeHDChannel(priceTag, noOfHdChannels, channelNum, this.vscNumber)

        }
      }
    })
    .catch(() => {
      if (ChannelManager.current.serviceId === channelInfo[0]["service_id"]) {
        const priceTag = "NOT AVAILABLE"
        if (config.SD_ZAPPER)
          popUpMsg.UnsubscribeHDChannelPromotion()
        else
          popUpMsg.UnsubscribeHDChannel(priceTag, this.vscNumber)
      }
    })
  }

  getPlayerSubscribeInfo(channelNumber) {
    if (ScanManager.isFirstInstall && FtaBlockManager.isFtaActiveState) return
    if (this.holdExtraCall) return
    if (!this.holdExtraCall) this.holdExtraCall = true

    casApi.getAccessStatus().then((data) => {
      this.BackgroundShow = false
      this.ModState = false
      this.isPopUpOn = false

      switch (data.Access_status) {
      case 1:
        /* ****** Access is Denied Information For Unsubscribe PopUp********** */
        bus.emit("tv:ZapOnTimeshift")
        DEFAULT_QUERY_CHANNELTYPE.criteria = "lcn=="+channelNumber
        ChannelApi.getChannels(DEFAULT_QUERY_CHANNELTYPE).then((data) => {
          /* ******* HD Unsubscribe PopUp Information ******** */
          if (data.channels[0].service_type === "HD" && !FtaBlockManager.isFtaActiveState) {
            this.showUnsubscribeHDPopUp(data)
          }

          /* ******* SD Unsubscribe PopUp Information ******** */
          if (data.channels[0].service_type === "SD" && !FtaBlockManager.isFtaActiveState) {
            popUpMsg.UnsubscribeChannel(channelNumber, this.vscNumber)
          }
        })
        break
      case 5:
      case 6:
        // Conditional Access functionality for MOD when getting PPV
        if (data.Access_status === 6) {
          if (data.data_str.Currency !== undefined && data.data_str.Currency !== null
            &&  data.data_str.Currency !== "")
            this.Currency = data.data_str.Currency
          if (data.data_str.PriceInUnit !== undefined && data.data_str.PriceInUnit !== null
            &&  data.data_str.PriceInUnit !== "")
            this.PriceInUnit = data.data_str.PriceInUnit.replace(/^0+/, "")
          if (data.data_str.ProductID !== undefined && data.data_str.ProductID !== null
            &&  data.data_str.ProductID !== "")
            this.PurchaseCode = data.data_str.ProductID.replace(/^0+/, "")
          if (data.data_str.PriceInDecimal !== undefined
              && data.data_str.PriceInDecimal !== null &&  data.data_str.PriceInDecimal !== "")
            this.PriceDecimalForm = data.data_str.PriceInDecimal
          if (data.data_str.Text !== undefined && data.data_str.Text !== null  &&  data.data_str.Text !== "")
            this.EventName = data.data_str.Text
        }
        this.ModState = true
        if (!this.ModActiveStatus) {
          this.BackgroundShow = true
          this.isPopUpOn = true
          popUpMsg.ModChannelAccess(this.Currency, this.PriceInUnit, this.PurchaseCode,
            this.PriceDecimalForm, this.EventName, this.vscNumber)
        }
        break
      case 10:
        // Conditional Access functionality for MOD when getting transparent popUp
        this.BackgroundShow = true
        this.isPopUpOn = true
        popUpMsg.ModChannelAccess(this.Currency, this.PriceInUnit, this.PurchaseCode,
          this.PriceDecimalForm, this.EventName, this.vscNumber)
        this.ModState = true
        this.ModActiveStatus = true
        break
      case 11:
        // Conditional Access functionality for MOD when getting solid popUp
        this.isPopUpOn = true
        popUpMsg.ModChannelAccess(this.Currency, this.PriceInUnit, this.PurchaseCode,
          this.PriceDecimalForm, this.EventName, this.vscNumber)
        this.ModState = true
        this.ModActiveStatus = true
        break
      case 9:
      case 0:
        /* ****** Access is Granted/Clear Information For Unsubscribe PopUp********** */
        if (FtaBlockManager.ftaPopupStatus.popcode !== -1) {
          wait(700).then(() => {
            if (!FtaBlockManager.isFtaActiveState) bus.emit("UnsubscribedErrorMsg:close")
          })
        }
        break
      default:
        break
      }
      this.holdExtraCall = false

    })
    .catch(() => {
      this.holdExtraCall = false
    })
  }

  // Handling for CA Menu in STB infosheet
  getCaMenuInformation() {
    return casApi.getCaMenu().then((data) => {
      const Casdata = {
        "CA_SYS_ID:": "0x"+data.sys_id.toString(16).slice(-3).toUpperCase().replace(/^/g, "0"),
        "Chip ID:": data.chipId,
        "Security client version:": data.client_version,
      }
      return Casdata
    })
    .catch(() => {
      const Casdata = {
        "CA_SYS_ID:": "NOT AVAILABLE",
        "Chip ID:": "NOT AVAILABLE",
        "Security client version:": "NOT AVAILABLE",
      }
      return Casdata
    })
  }

  /* ********** SSE Event handling for Unsubscribe PopUp Information ********* */
  @sse("scan", {subtype: "CurrentAccess_info"})
  _onScanAccess(event) {
    if (ScanManager.isFirstInstall && FtaBlockManager.isFtaActiveState) return

    if (this.cashActive === true && ChannelManager.current &&
      ChannelManager.current.lcn && ChannelManager.current.serviceId) {

      const eventServiceId = event.content.serviceId
      const currentServiceId =  +(+(ChannelManager.current.serviceId) & 0xFFFF)

      if (eventServiceId === currentServiceId) {
        if (this.timeoutID) {
          clearTimeout(this.timeoutID)
          this.timeoutID = null
        }
        this.timeoutID = setTimeout(() => {
          this.timeoutID = null
          const lcnNum = ChannelManager.current.lcn
          if (!FtaBlockManager.isFtaActiveState) this.getPlayerSubscribeInfo(lcnNum)
        },2000)
      }
    }
  }

/* ************* SSE Event handling for Fingerprint Information ************** */
  @sse("scan", {subtype: "fingerprint_info"})
  _onFingerprintReceived(data) {
    if (this.isFingerprintActive) return
    $("fingerprint").showFingerprint(data.content)
  }

  @on("fingerprint:timeshiftopen")
  _onFingerprintTimeshift() {
    this._onFingerprintTimeshiftDisplay()
    this.isFingerprintActive = true
    this.fingerprintCheckTimer = setTimeout(()=>{
      bus.emit("fingerprint:close")
      this._onFingerprintTimeshift()
    }, 600000)

  }

  _onFingerprintTimeshiftDisplay() {

    $("fingerprint").showFingerprintTimeshift(this.vscNumber)


    this.fingerprintTimer = setTimeout(()=>{
      bus.emit("fingerprint:close")
      if (this.fingerprintTimer) clearTimeout(this.fingerprintTimer)
    }, 10000)
  }

  @on("fingerprint:resettimer")
  fingerprintReset() {
    if (this.fingerprintCheckTimer) clearTimeout(this.fingerprintCheckTimer)
    this.isFingerprintActive = false
  }

  @on("fingerprint:finalclose")
  closeFingerprint() {
    this.fingerprintReset()
  }

}

export default new CasManager()
