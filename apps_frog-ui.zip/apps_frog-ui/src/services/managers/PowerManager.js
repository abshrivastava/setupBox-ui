//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.


import {$} from "widgets/Component"
import bus from "services/bus"
import {on, sse, enableEvents} from "services/events"

import * as ChannelApi from "services/api/channels"
import * as FTAapi from "services/api/fta"
import {listTune, removeAllTune} from "services/api/scan"
import {getTransponderStatus} from "services/api/transponders"
import {getState,setState} from "services/api/power"
import {play} from "services/api/player"

import {getForceSlideRcuBlockTime, getForceSlidePlayTime, getServiceID,
  getLastTunedLcn, getHomeTpWydvbUrl, setLastTunedLcn,getDefaultCounter,
  setDefaultCounter,getGraceLcn, getSection,getDefaultLcn, getGraceoffset,
  deleteSection, createSection,getMaxForceSlide, setEntry, updateEntryInSection,
  getCurrentForceSlideRow, getFcSlider,
  getDefaultMaxLandingChannels} from "services/managers/config"

import {
  PlayerManager,
  ChannelManager,
  LedManager,
  PVRManager,
  FtaBlockManager,
  CamManager,
  ScanManager,
} from "services/managers"

import {isObject, isArray} from "utils"
import {getCurrentProgram} from "services/managers/epg"
import {mute, unmute} from "services/managers/volume"

/**
 * STANDBYEXIT : 5400000 @90min
 * REBOOTTIMEOUT:300000 @5min
 * BACKGROUNDLOAD:600000 @10 min
 * Loadcatalog_Instandby : 120000 @12 min
 * Loadcatalog_InLive : 5000 @5 Milli Second
 */
const TIMEOUT = Object.freeze({
  STANDBYEXIT: 5400000,
  REBOOTTIMEOUT:300000,
  RESETLENGTH:3,
  BACKGROUNDLOAD:600000,
  Loadcatalog_Instandby : 120000,
  Loadcatalog_InLive : 5000,
})

const SUBSCRIPTION_TIME = Object.freeze({
  ONEHOUR: 3600,
  TWOHOUR: 7200,
  DAY: 86400,
  MINUSONEDAY : -86400,
  MINUSTWODAY : -172800,
  MINUSTHREEDAY : -259200,
  MINUSFOURDAY : -345600,
  FIVEDAY: 432000,
  SIXDAY: 518400,
  SEVENDAY: 604800,
  EIGHTDAY : 691200,
  GRACEPERIODS : -1,
  DEFAULT_LC : 95,
})

const DEFAULT_QUERY_SERVICEID = {
  order: ["lcn"],
  metadata: [
    "id", "play_info", "service_id", "title", "lcn", "obj_class",
    "scrambled",
  ],
}

const ALL_UNIVERSE = ["home"]

class StandbyControl {
  constructor() {
    this.bootTimeRunning = false
    this.startCounter = null
    this.startCounterForceSlider = null
    this.startRcuBlcokTimmer = null
    this.showLandingChannel = true
    this.showForceChannel = false
    this.forceChannelId = -1
    this.lcnChannel = null
    this._legacyUniverse = null
    this.startEasyScan = false
    this.isEasyScanRunning = false
    this.ctrlPowerOnStandbyScan = false
    this.isStandbyState = false
    this.isNonImmediate = false
    this.isImmediate = false
    this.rebootTimer = null
    this.swTakeAdvantage = false
    this.holdHomeTPTimer = null
    this.isSubFtaBlockStatus = false
    this.isDesFtaBlocking = false
    this.subscriptionStatus = true
    this.isFtaStimulate = false
    this.intrimUniverse = null
    this.downloadCatalogTimmer = null
    this.loadBackgroundCatalog = null
    enableEvents(this)
  }

  /** function:: _startStandbyTimmer()
   * Trigger.. Whenever STB is Put in standby..
   *
   *   :param Function _resetTimmer: Reset the timmer if its exit..
   *   :param Function _startEasyScan: Look for Higher SVL Version if exits than start a EasyScan...
   *   :param Function _requestSwUpdate: Look for SW Update and start timmer for Reboot
   *   :returns : Start the Counter for Standby...
   */
  _startStandbyTimmer() {
    this._resetTimmer()
    this._startEasyScan(this.startEasyScan, this.isEasyScanRunning)
    this._requestSwUpdate(this.swTakeAdvantage)
    this.startCounter = new Date()
    this.checkFtaStatus().catch(() => console.log("Error checkFtaStatus"))
    if (this.downloadCatalogTimmer) clearTimeout(this.downloadCatalogTimmer)
  }

  checkTunner() {
    return new Promise((resolve) => {
      listTune().then((list) => {
        try {
          if (list.tunes[0].frontend_state) {
            const state = list.tunes[0].frontend_state
            const href = list.tunes[0].href
            const id = href.split("/")[3]
            if (state === "allowed_locked") {
              removeTune(id)
              resolve(true)
            } else {
              resolve(false)
            }
          }
        } catch (err) {
          resolve(false)
        }
      })
    })
  }

  isCamInserted() {
    const isCamInsert = CamManager.insertStatus ? true : false
    return isCamInsert
  }

  checkFtaStatus() {
    const isCamInserted = this.isCamInserted()
    return new Promise((resolve, reject) => {
      FTAapi.getFTAdescriptorStatus()
      .then((status) => {
        if (!this.isStandbyState)!status.ftaBlocking ? this.isDesFtaBlocking = false : this.isDesFtaBlocking = true
        if (this.isStandbyState)status.ftaBlocking === this.isDesFtaBlocking ?
        this.isFtaStimulate = false : this.isFtaStimulate = true
        return FTAapi.getFTAsubscriptionStatus()
      })
      .then((status) => {
        if (!this.isStandbyState) status.FTABlockStatus === false ?
        this.isSubFtaBlockStatus = false : this.isSubFtaBlockStatus = true
        if (this.isStandbyState) status.FTABlockStatus === this.isSubFtaBlockStatus ?
        this.isFtaStimulate = false : this.isFtaStimulate = true
        resolve(true)
      })
      .catch(() => {
        if (isCamInserted) {
          resolve(true)
        } else {
          reject(false)
        }
      })
    })
  }

  /** function:: _stopStandbyTimmer()
   * Trigger.. Whenever STB is awake..
   * Clear the Timmer Counter..
   * Clear the Reboot Timmer for Sw update..
   * Check for Sw Update if exit..show the Sw Update Meassage..
   *
   *   :param  SW Update :: Return Sw Udate Request if Sw Immediate Describution is there...
   *   :param  Record pvr :: if Recoding is ongoing bypass the Standby feature and tune to Recoding Channel...
   */
  _stopStandbyTimmer() {
    if (this.rebootTimer) {
      clearTimeout(this.rebootTimer)
    }
    if (this.scanTimer) {
      clearTimeout(this.scanTimer)
    }
    if (this.isImmediate) {
      bus.emit("software:rebootRequest")
      return
    }
    const showStandbyFeature = this.showStandbyFeature()
    const isFtaBlockStatus =  FtaBlockManager.isNavigationRestricted()
    const isPandingState = FtaBlockManager.pendingState
    const isCamInserted = this.isCamInserted()

    this.checkFtaStatus()
    .then(() => {
      if (isFtaBlockStatus && !isCamInserted) {
        this.isFtaBlockMode()
        this.leastCall()
      } else {
        if ((this.isFtaStimulate || isPandingState) && !isCamInserted && !this.isEasyScanRunning) {
          FtaBlockManager.pendingState = false
          this.isFtaBlockMode()
          this.leastCall()
        } else {
          if (showStandbyFeature && !isFtaBlockStatus) {
            if (((new Date() - (this.startCounter)) > TIMEOUT.STANDBYEXIT)) {
              this.showLandingChannel = false
              this.showForceChannel = true
            }
            this.intrimUniverse = bus.universe
            bus.universe = "standbypower"
            this._tuneTo(this.showLandingChannel, this.showForceChannel)
          }
          this.leastCall()
        }
      }
    })
    .catch(() => {
      this.isFtaBlockMode()
      this.leastCall()
    })
  }

  leastCall() {
    if (PVRManager.ongoing.length) bus.universe = "tv"
    this.showLandingChannel = true
    this.showForceChannel = false
    this.startCounter = null
    if (this.downloadCatalogTimmer) clearTimeout(this.downloadCatalogTimmer)
  }

  /** function:: _startEasyScan()
   * Trigger... IF Get Higher SVL version...
   *
   *   :param  startEasyScan :: if True set for Launch Easy Scan
   *   :param  isEasyScanRunning :: if True bypass the Easy Scan as its is already Running...
   *   Record pvr :: if Recoding is ongoing cancel the Recoding...
   *   launchEasyScan :: Start the EasyScan...
   */

  _startEasyScan(startEasyScan,isEasyScanRunning) {
    const isFtaBlockMode =  FtaBlockManager.isNavigationRestricted()
    if (isFtaBlockMode) return
    if (!this.isStandbyState) return
    if (PVRManager.ongoing.length > 0) return
    if (startEasyScan && ScanManager.sdtChange) ScanManager.sdtChange = false
    if (startEasyScan === true && isEasyScanRunning === false && !ScanManager.sdtChange) {
      this.ctrlPowerOnStandbyScan = true
      PlayerManager.stopCurrentChannel()
      this.scanTimer = setTimeout(() => {
        bus.openUniverse("settings")
        bus.emit("scan:launchEasyScan",{"univ":"standby","scanType":"EASY_SCAN"})
        ScanManager.sdtChange = false
      },500)
    } else if (ScanManager.sdtChange && !startEasyScan && !isEasyScanRunning) {
      ChannelManager.update(ScanManager.showScrambled, ScanManager.showFreeToAir,true)
      .then(() => {
        ScanManager.sdtChange = false
      })
    } else { /* Just wake-up without easy scan or ChannelManager Update */ }
  }

  @on("power:activeScan")
  onActiveScan() {
    this.isEasyScanRunning = true
  }

  @on("power:deactiveScan")
  onDeActiveScan() {
    this.isEasyScanRunning = false
  }

  /** function:: _requestSwUpdate()
   * Trigger... IF Get Higher Sw Updater Higger version...
   *
   *   :param requestForSwUpdate :: if True Start the Timmer for 5min..
   *   :: Reboot Request After 5min...
   */
  _requestSwUpdate(requestForSwUpdate) {
    if (requestForSwUpdate) {
      this._setRebootTimer()
    }
  }

  isRecOngoing() {
    if (PVRManager.ongoing.length) {
      return true
    } else {
      return false
    }
  }

  showStandbyFeature() {
    if (this.isEasyScanRunning && ScanManager.running && !PVRManager.ongoing.length) {
      return false
    } else if (PVRManager.ongoing.length > 0) {
      return false
    } else {
      return true
    }
  }

  isFtaBlockMode() {
    FtaBlockManager.isFtaBlockMode()
  }

  setLegacy(isFromFs = false) {
    if (this.intrimUniverse === "popup") {
      bus.emit("popup:setLegacy", "tv")
      bus.universe = "popup"
    } else if (bus.universe !== "tv" && isFromFs === false) {
      bus.universe = "tv"
    } else {
      if (!this.isStandbyState && bus.universe === "bigbang") bus.universe = "tv"
    }
  }

  /** function:: _showForceChannel()
   * Trigger.. When ever Standby Timmer exit 90min
   *
   *   :function  getForceSlidePlayTime :: Return for FS play time...
   *   :function  getForceSlideRcuBlockTime :: Return for RCU block  time...
   *   :function  getServiceID :: Return service ID for FS...
   */

  _showForceChannel() {
    Promise.all([
      getForceSlidePlayTime(), getForceSlideRcuBlockTime(),getServiceID(),
    ])
    .then(([playtimes, blockTimes, serviceID]) => {
      const playtime = playtimes * 1000
      const blockTime = blockTimes * 1000

      DEFAULT_QUERY_SERVICEID.criteria = "service_id=="+serviceID
      ChannelApi.getChannels(DEFAULT_QUERY_SERVICEID).then((data) => {
        const option = {}
        if (data.channels.length > 0) {
          const lcnNo = data.channels[0].lcn
          const serviceId = data.channels[0].service_id
          const playInfo = data.channels[0].play_info
          option["service_id"] = serviceId
          option["play_info"] = playInfo
          PlayerManager.forceSlideLcn = lcnNo
          this._playForceSlide(option,playtime,blockTime)
          getLastTunedLcn().then((lastTuneChannel) => {
            this.lcnChannel = lastTuneChannel
          })
        } else {
          this._showDefaultChannel()
        }
      })
      .catch (() => {
        this._showDefaultChannel()
      })
    })
    .catch (() => {
      this._showDefaultChannel()
    })
  }

  /** function:: _playForceSlide(option,playtime,blockTime)
   * tune to FS...
   *
   * param : option :: pass the parameter for player
   * param : playtime :: pass the playtime for player
   * param : blockTime :: pass the blockTime for player
   */

  _playForceSlide(option,playtime,blockTime) {
    const id = PlayerManager.id
    play(id, option).then(() => {
      PlayerManager.callbyStandy = true
      this._startForceSliderTimmer(playtime)
      this._startRcuBlockTimmer(blockTime)
    })
    .catch(() => {
      this._showDefaultChannel()
    })
  }

  /** function:: _playChannel(channel)
   * tune to Channel...
   *
   * param : channel :: Pass the channel to Tune...
   */

  _playChannel(channel) {
    let data
    ChannelManager.getChannelZapInformation(channel)
   .then((response) => {
     data = response.resource.real || response.resource.fallback
     if (data) {
       this.play(data)
     } else {
       getLastTunedLcn().then((lcn) => {
         return ChannelManager.getChannelZapInformation(lcn)
       })
       .then((response) => {
         data = response.resource.real || response.resource.fallback
         this.play(data)
       })
     }
   })
  }

  play(channel) {
    if (!channel) return
    const option = {}
    const id = PlayerManager.id
    option["service_id"] = channel.serviceId
    option["play_info"] = channel.playInfo
    bus.emit("tv:zap", channel)
    play(id, option).then(() => {
      getCurrentProgram(channel)
      if (channel) setLastTunedLcn(channel.lcn)
    })
    .catch(() => {})
  }

  /** function:: _startRcuBlockTimmer(blockTime)
   * Block the RCU on FS...
   *
   * param : blockTime :: Block the RCU on FS till blockTime
   */

  _startRcuBlockTimmer(blockTime) {
    if (this.startRcuBlcokTimmer) {
      clearTimeout(this.startRcuBlcokTimmer)
    }
    this.startRcuBlcokTimmer = setTimeout(() => {
      bus.universe = "tv"
    }, blockTime)
  }

  /** function:: _startForceSliderTimmer(playtime)
   * tune to FS...
   *
   * param : playtime :: play the FS upto playtime
   */

  _startForceSliderTimmer(playtime) {
    if (this.startCounterForceSlider) {
      clearTimeout(this.startCounterForceSlider)
    }
    this.startCounterForceSlider = setTimeout(() => {
      PlayerManager.callbyStandy = false
      getLastTunedLcn().then((lastTuneChannel) => {
        if (lastTuneChannel === this.lcnChannel) {
          this._showDefaultChannel(true)
          this.lcnChannel = null
        }
      })
    }, playtime)
  }

  /** function:: _tuneTo()
   * Play to FS or Either LC...
   *
   */

  _tuneTo(landingChannel, forceChannel) {
    if (landingChannel) {
      this._showDefaultChannel()
    }
    if (forceChannel) {
      this.CheckForceSliderGracePeriods()
      .then(() => {
        this._showForceChannel()
      })
      .catch(() => {
        this._showDefaultChannel()
      })
    }
  }

  compareHomeTP(homeURI, curURI) {
    const {frequency : frequencyHom, symbol_rate : symbol_rateHom, polarity : polarityHom} =  this.getUrlParams(homeURI)
    const {frequency : frequencyCur, symbol_rate : symbol_rateCur, polarity : polarityCur} = this.getUrlParams(curURI)
    if (frequencyHom === frequencyCur && symbol_rateHom === symbol_rateCur && polarityHom === polarityCur) {
      return true
    } else {
      return false
    }
  }

  getUrlParams(uri) {
    const hashes = uri.slice(uri.indexOf("?") + 1).split("&")
    const params = {}
    hashes.map(hash => {
      const [key, val] = hash.split("=")
      params[key] = decodeURIComponent(val)
    })
    return params
  }

  /** function:: tuneToHomeTp()
   * Tune to HTP when ever Stv put in standby...
   *
   *   : PVR Recoding :: if Recoding is going Stop Tuneing to HTP...
   */
  tuneToHomeTp() {
    let homeTpUri = null
    return new Promise((resolve) => {
      if (!PVRManager.ongoing.length) {
        getHomeTpWydvbUrl()
        .then((uri) => {
          homeTpUri = uri
          return listTune()
        })
        .then((tuner) => {
          let currentTPUri = false
          if (tuner && tuner.tunes[0] && tuner.tunes[0].wydvb_uri) {
            currentTPUri = tuner.tunes[0].wydvb_uri
          }
          // Condition :: if : No need to tune to Home Tp as we're already in Home TP
          // Condition :: Else :: we're not in HomeTp so tune to HomeTp is needed
          if (homeTpUri && currentTPUri && this.compareHomeTP(homeTpUri,currentTPUri)) {
            resolve()
          } else {
            PlayerManager.stop().then(() => {
              const wydvbUri = encodeURIComponent(homeTpUri)
              getTransponderStatus(wydvbUri).then(() => resolve())
              .catch(() => resolve())
            })
          }
        })
        .catch((error) => {
          console.log("Fail to Tune Home Tp :: ",error)
          resolve()
        })
      } else {
        resolve()
      }
    })
  }
  _checkStandbyPower() {
    return new Promise((resolve, reject) => {
      getState().then((response) => {
        if (response.state === "awake") {
          resolve("isOn")
        } else if (response.state === "standby") {
          reject("isOff")
        } else {
          reject("isOff")
        }
      }).catch(() => {
        reject("isOff")
      })
    })
  }

  /** function:: _checkPowerCurrenState()
   * Set the state standby/awake
   *
   *   : Return :: Current powerManagement State of Stv..
   */

  _checkPowerCurrenState() {
    return new Promise((reslove) => {
      getState().then((response) => {
        if (response.state === "standby") {
          this.isStandbyState = true
        }
        reslove()
      }).catch(() => {
        reslove()
      })
    })
  }

  /** function:: _closeLegacyUniverse()
   * Close the Current Universes When STP put to standby...
   *
   *   :function  getForceSlidePlayTime :: Return for FS play time...
   *   :param  getForceSlideRcuBlockTime :: Return for RCU block  time...
   *   :param  getServiceID :: Return service ID for FS...
   */

  _closeLegacyUniverse() {
    let i = 0
    do {
      i += 1
      const busUniverse = bus.universe
      if (busUniverse === "popup" || busUniverse === "parentalpopup") {
        bus.emit(`${busUniverse}:close`)
      } else {
        bus.closeCurrentUniverse()
        bus.emit("home:close")
        break
      }
    } while (i < TIMEOUT.RESETLENGTH)
  }

  /** function:: _setRebootTimer()
   * Set the Timmer for 5min of Software Update Descriptor...
   *
   *   :: Clear the Timmer... if exits..
   *   : Pvr Recoding :: cancel the Recoding...than Make Request for Rebbot
   *   : Return :: Reboot Request...
   */

  _setRebootTimer() {
    if (this.rebootTimer) {
      clearTimeout(this.rebootTimer)
    }
    this.rebootTimer = setTimeout(() => {
      if (PVRManager.ongoing.length) {
        PVRManager.cancel(PVRManager.ongoing[0].programId)
        .then(()=> {
          setState({"state":"reboot"})
        })
        .catch(() => {
          setState({"state":"reboot"})
        })
      } else {
        setState({"state":"reboot"})
      }
    }, TIMEOUT.REBOOTTIMEOUT)
  }

  /** function:: _resetTimmer()
   * Reset All the Timmer in Standby...
   *
   *   :: Param startCounter : clear...
   *   :: Param startCounterForceSlider : clear...
   *   :: Param startRcuBlcokTimmer : clear...
   *   :: Param rebootTimer : clear...
   */

  _resetTimmer() {
    const isFtaBlockMode =  FtaBlockManager.isNavigationRestricted()
    this.isFtaStimulate = false
    if (this.startCounterForceSlider) {
      clearTimeout(this.startCounterForceSlider)
    }
    if (this.startRcuBlcokTimmer) {
      clearTimeout(this.startRcuBlcokTimmer)
    }
    if (this.rebootTimer) {
      clearTimeout(this.rebootTimer)
    }
    if (this.scanTimer) {
      clearTimeout(this.scanTimer)
    }
    if (isFtaBlockMode) {
      bus.emit("blackuniverse:standby")
    }

    if (this.loadBackgroundCatalog) {
      clearTimeout(this.loadBackgroundCatalog)
    }
  }


  /** function:: _resetAllUniverse()
   * close the Universe..
   *
   *   :: Param ALL_UNIVERSE : Colse all the Universes exits on cont ALL_UNIVERSE...
   */

  _resetAllUniverse() {
    for (const value of ALL_UNIVERSE) {
      bus.emit(`${value}:close`)
    }
  }

  /** function:: controlPowerMangemant()
  * Control the PowerManager awake/standby
  *
  *   LED Management : SetStandOff() || SetStandOn()
  *   setState :: Put STB state to MW
  *   STB is awake Rec is ongoing & Player is STOPPED...Tune to Current channel
  *   STB is in standby Stop the Player
  *   OnPowerAwake/OnPowerStandby ::
  */
  controlPowerMangemant() {
    this.holdPowerBtn?this.holdPowerBtn:false
    if (this.holdPowerBtn) return
    this.holdPowerBtn = true
    this.isStandbyState?LedManager.SetStandOff():LedManager.SetStandOn()
    if (this.holdHomeTPTimer) clearTimeout(this.holdHomeTPTimer)
    if (this.ctrlPowerOnStandbyScan) this.ctrlPowerOnStandbyScan = false
    const powerState = this.isStandbyState ? "awake" : "standby"
    setState({state: powerState}).then(() => {
      this.isStandbyState = this.isStandbyState ? false : true
      if (!this.isStandbyState && PVRManager.ongoing.length &&
        PlayerManager.state !== "PLAYING")PlayerManager.play(ChannelManager.current)
      if (this.isStandbyState && !PVRManager.ongoing.length) PlayerManager.stop()
      this.isStandbyState?this.OnPowerStandby():this.OnPowerAwake()
    }).catch(() => {
      LedManager.SetStandOff()
    })
  }

  moveToStandby() {
    this.OnPowerStandby()
  }

  loadCatalog(power) {
    let loadingTime = null
    if (this.isStandbyState) {
      loadingTime = TIMEOUT.Loadcatalog_Instandby
    } else {
      loadingTime = TIMEOUT.Loadcatalog_InLive
    }
    if (this.downloadCatalogTimmer) clearTimeout(this.downloadCatalogTimmer)
    this.downloadCatalogTimmer = setTimeout(() => {
      bus.emit("version:inOutStandby",power)
      this.downloadCatalogTimmer = null
    },loadingTime)
  }

  isConflictDnCatalogAssets() {
    const isScanRunning = this.startEasyScan && this.isEasyScanRunning ? true : false
    const isRecOngoing = this.isRecOngoing()
    const isSoftwareActive = this.swTakeAdvantage ? true : false

    if (isScanRunning || isRecOngoing || isSoftwareActive) {
      return true
    } else {
      return false
    }
  }

  @on("power:standby")
  OnPowerStandby() {
    this._closeLegacyUniverse()
    bus.openUniverse("standby")
    bus.emit("home:reset")
    this._startStandbyTimmer()
    mute()
    this.holdHomeTPTimer = setTimeout(() => {
      this.tuneToHomeTp()
    },500)
  }

  @on("power:awake")
  OnPowerAwake() {
    this._stopStandbyTimmer()
    if (FtaBlockManager.isNavigationRestricted()) return
    const volume = $("volumeBar")
    if (volume) {
      if (volume.isMute === false) {
        unmute()
      }
    } else {
      unmute()
    }
    bus.emit("tv:showOperatorLogo")
  }

  /* ******************** Landing Channel *************************************** */

  _showDefaultChannel(isFromFs= false, tune = true, increaseCounter = true, callFromStandby = true) {
    let maxNumberChannels = null
    let defaultCounter = null
    let currentLcn = null

    this.isGracePeriods()
    .then((value) => {
      if (value) {
        if (tune && !ScanManager.isFirstInstall) this.playGraceLcn()
        if (increaseCounter)setDefaultCounter(SUBSCRIPTION_TIME.GRACEPERIODS)
        if (callFromStandby) this.setLegacy(isFromFs)
      } else {
        this.computeDynamicLC()
        .then((data) => {
          if (data && data.length) maxNumberChannels = (data.length - 2)/2
          return getDefaultCounter()
        })
        .then((counter) => {
          currentLcn = counter
          return this.setCounter(parseInt(counter),maxNumberChannels)
        })
        .then((counterFlag) => {
          defaultCounter = counterFlag
          return getDefaultLcn(`${currentLcn}_default_channel`)
        })
        .then((lcn) => {
          if (tune && !ScanManager.isFirstInstall) this._playChannel(lcn || SUBSCRIPTION_TIME.DEFAULT_LC)
          if (increaseCounter)setDefaultCounter(!isNaN(defaultCounter) ? defaultCounter : 1)
          if (callFromStandby) this.setLegacy(isFromFs)
        })
        .catch(() => {
          if (tune && !ScanManager.isFirstInstall) this._playChannel(SUBSCRIPTION_TIME.DEFAULT_LC)
          if (increaseCounter)setDefaultCounter(1)
          if (callFromStandby) this.setLegacy(isFromFs)
        })
      }
    })
  }

  updateLcCounter(defaultcounter) {
    return new Promise((reslove) => {
      return this.getDefaultMaxLandingChannels()
      .then((max) => {
        return this.setCounter(+defaultcounter,+max)
      })
      .then((counterFlag) => {
        return setDefaultCounter(+counterFlag || 1)
      })
      .then(() => {
        reslove(true)
      })
      .catch(() => {
        setDefaultCounter(1)
        reslove(false)
      })
    })
  }

  isGracePeriods() {
    return new Promise((resolve) => {
      let absoluteEndDate
      let currentDate
      let diffDays
      let remainDay
      let offsetOccur
      FTAapi.getFTAsubscriptionStatus()
      .then((data) => {
        absoluteEndDate = data.ActualEndDate
        currentDate = Math.round(new Date().getTime()/1000.0)
        diffDays = ((absoluteEndDate - currentDate))
        return getGraceoffset()
      })
      .then((offset) => {
        offsetOccur = parseInt(offset)
        if (offsetOccur !== 0) {
          remainDay = offset * SUBSCRIPTION_TIME.DAY
          if (diffDays < remainDay) {
            resolve(true)
          } else {
            resolve(false)
          }
        } else {
          resolve(false)
        }
      })
    })
  }

  setCounter(counter,maxconter) {
    return new Promise((resolve) => {
      const x = maxconter/counter
      let y = null
      if (x === 1) {
        resolve(1)
      } else {
        if (counter > maxconter) {
          resolve(1)
        } else  {
          y = (counter + 1)
          resolve(y)
        }
      }
    })
  }

  computeDynamicLC() {
    return new Promise((resolve,reject) => {
      getSection("default_lc")
      .then((data) => {
        resolve(data)
      })
      .catch(() => {
        reject("no default Lc available")
      })
    })
  }

  playGraceLcn() {
    getGraceLcn().then((lcn) => {
      this._playChannel(lcn)
    })
  }

  getDynamicDefaultLC() {
    return getDefaultCounter()
    .then((counter) => {
      if ((parseInt(counter)) === -1) {
        return getGraceLcn()
      } else {
        return getDefaultLcn(`${counter}_default_channel`)
      }
    })
    .then((lcn) => {
      if (lcn) {
        return lcn
      } else {
        return 0
      }
    })
    .catch(() => {
      return 0
    })
  }

  getDefaultMaxLandingChannels() {
    return new Promise((reslove) => {
      getDefaultMaxLandingChannels()
      .then((max) => {
        if (max) {
          reslove(parseInt(max))
        } else {
          reslove(0)
        }
      })
      .catch(() => {
        reslove(0)
      })
    })
  }

  getDefaultCounter() {
    return new Promise((reslove) => {
      getDefaultCounter()
      .then((counter) => {
        if (counter) {
          reslove(parseInt(counter))
        } else {
          reslove(1)
        }
      })
      .catch(() => {
        reslove(1)
      })
    })
  }

  /* ******************** Force Channel *************************************** */

  blowOutFc(fromEvent = false) {
    return this.setFclist(fromEvent)
    .then(() => {
      return this.CheckForceSliderGracePeriods(true)
    })
    .catch(() => {
      // Ignore if  Error occur..
    })
  }

  setFclist(event) {
    return new Promise((resolve) => {
      let channel
      let size
      const createSize = []
      if (event) {
        channel = this.formatFc(event,6)
        size = channel.length
        return this.getMaxForceSlide()
        .then((value) => {
          return this.controlDeleteSection(value)
        })
        .then(() => {
          for (let i = 0; i < size; i++) {
            createSize.push(i+1)
          }
          return this.controlCreateSection(createSize)
        })
        .then(() => {
          return this.controlFcSectionList(channel)
        })
        .then(() => {
          return this.setMaxForceSlide(size)
        })
        .then(() => {
          reslove(true)
        })
        .catch(() => {
          resolve(true)
        })
      } else {
        resolve(false)
      }
    })
  }

  CheckForceSliderGracePeriods(isFromEvent = false) {
    return new Promise((resolve) => {
      let absoluteEndDate
      let currentDate
      let diffDays
      let currentOffset = null
      let fcNumber
      FTAapi.getFTAsubscriptionStatus()
      .then((data) => {
        absoluteEndDate = data.ActualEndDate
        currentDate = Math.round(new Date().getTime()/1000.0)
        diffDays = ((absoluteEndDate - currentDate))
        return getMaxForceSlide()
      })
      .then((offset) => {
        currentOffset = offset
        if (currentOffset === "emptyMaxSlide") {
          throw "Max Slide is not Available"
        } else {
          return this.checkFcChannel(parseInt(offset), diffDays)
        }
      })
      .then((option) => {
        return this.getFCQueue(option, currentOffset)
      })
      .then((value) => {
        fcNumber = parseInt(value)
        return this.getCurrentFsRow()
      })
      .then((value) => {
        const x = parseInt(value)
        if (x === fcNumber && !isFromEvent) {
          return "noUpdated"
        } else {
          return this.setCurrentFsRow(fcNumber)
        }
      })
      .then((value) => {
        const y = value
        if (y === "noUpdated" && !isFromEvent) {
          return "noChanges"
        } else {
          return this.setCurrentFcSectionList(fcNumber)
        }
      })
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
    })
  }

  setCurrentFsRow(value) {
    return new Promise((reslove) => {
      if (value) {
        setEntry("settings","current_force_slide_row",value)
        .then(() => {
          reslove(true)
        })
        .catch(() => {
          reslove(false)
        })
      } else {
        reslove(false)
      }
    })
  }

  getCurrentFsRow() {
    return new Promise((reslove) => {
      getCurrentForceSlideRow()
      .then((value) => {
        reslove(value)
      })
      .catch(() => {
        reslove(0)
      })
    })
  }

  setMaxForceSlide(value) {
    return new Promise((reslove) => {
      if (value) {
        setEntry("settings","max_force_slide",value)
        .then(() => {
          reslove(true)
        })
        .catch(() => {
          reslove(false)
        })
      } else {
        reslove(false)
      }
    })
  }

  checkFcChannel(offset,diffDays) {
    let remainDay = null
    const retainObj = {}
    if (diffDays > 0) {
      for (let x = 1; x < offset; x++) {
        if (diffDays < (SUBSCRIPTION_TIME.DAY * x)) {
          remainDay = (x + 1)
          break
        }
      }
      retainObj["expired"] = false
      retainObj["value"] = remainDay ? remainDay : "normal"

    } else {
      retainObj["expired"] = true
      retainObj["value"] = (offset >= 2) ? 2 : 1
    }
    return retainObj
  }

  formatFc(option, size) {
    let isFromEvent = null
    let isFromGet = null

    if (isObject(option) === true) {
      isFromEvent = option
    }
    if (isArray(option) === true) {
      isFromGet = option.length > 1 ? option : null
    }
    const options = isFromEvent ? isFromEvent.content.dynamic_force_slide : isFromGet
    const results = []
    while (options.length) {
      results.push(options.splice(0, size))
    }
    return results
  }

  getFCQueue(option, currentOffset) {
    const value = option.value
    const expired = option.expired
    if (value === "normal" && !expired) {
      return 1
    } else if (isFinite(value) && !expired) {
      return currentOffset >= 2 ? value : 1
    } else if (expired) {
      return currentOffset >= 2 ? 2 : 1
    }
  }

  controlFcSectionList(channel) {
    const createPromises = []
    channel.forEach((option,index) => {
      if (option[0] && option[1]) {
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"uri",option[0]))
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"service_id",option[1]))
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"delay_time",option[2]))
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"rcu_block_time",option[3]))
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"start_time",option[4]))
        createPromises.push(updateEntryInSection(`force_slide_${index+1}`,"end_time",option[5]))
      }
    })
    if (createPromises) {
      return Promise.all(createPromises)
    } else {
      return false
    }
  }

  setCurrentFcSectionList(value) {
    const createPromises = []
    Promise.all([
      getFcSlider(value,"uri"), getFcSlider(value,"service_id"),getFcSlider(value,"delay_time"),
      getFcSlider(value,"rcu_block_time"),getFcSlider(value,"start_time"),getFcSlider(value,"end_time"),
    ])
    .then(([uri, serviceId,delayTime,rcu,startTime,endTime]) => {
      if (uri && serviceId) {
        createPromises.push(updateEntryInSection("force_slide","uri",uri))
        createPromises.push(updateEntryInSection("force_slide","service_id",serviceId))
        createPromises.push(updateEntryInSection("force_slide","delay_time",delayTime))
        createPromises.push(updateEntryInSection("force_slide","rcu_block_time",rcu))
        createPromises.push(updateEntryInSection("force_slide","start_time",startTime))
        createPromises.push(updateEntryInSection("force_slide","end_time",endTime))
      }
      if (createPromises) {
        return Promise.all(createPromises)
      } else {
        return false
      }
    })
  }

  controlDeleteSection(channel) {
    return Promise.all(channel.map((value) => {
      return this.deleteSection(`force_slide_${value}`)
    }))
    .then(() => {
      return Promise.resolve(true)
    })
    .catch(() => {
      return Promise.resolve(false)
    })
  }

  controlCreateSection(option) {
    return Promise.all(option.map((value) => {
      const section = {}
      section[`force_slide_${value}`] = {}
      return this.createSection(section)
    }))
    .then(() => {
      return Promise.resolve(true)
    })
    .catch(() => {
      return Promise.resolve(false)
    })
  }


  getMaxForceSlide() {
    return new Promise((reslove) => {
      const option = []
      getMaxForceSlide().then((value) => {
        for (let i = 0; i < value; i++) {
          option.push(i+1)
        }
        reslove(option)
      }).catch(() => {
        reslove(option)
      })
    })
  }

  deleteCurrentSection(section) {
    return new Promise((resolve) => {
      deleteSection(section).then(() => {
        resolve(true)
      }).catch(() => {
        resolve(false)
      })
    })
  }

  deleteSection(section) {
    return deleteSection(section)
  }

  createCurrentSection(section) {
    return new Promise((resolve) => {
      createSection(section).then(() => {
        resolve(true)
      }).catch(() => {
        resolve(false)
      })
    })
  }

  createSection(section) {
    return createSection(section)
  }

  /* ********** SSE Event handling for GlobalPowerStateChanged ********* */

  @sse("powerManagement", {subtype: "GlobalPowerStateChanged", content: {state: "standby"}})
  _onStandby() {
    this.isStandbyState = true
    setTimeout(() => {
      this.holdPowerBtn = false
    },1200)
    if (!this.isConflictDnCatalogAssets()) {
      // this.loadCatalog("standby")
    }
  }

  @sse("powerManagement", {subtype: "GlobalPowerStateChanged", content: {state: "awake"}})
  _onAwake() {
    this.isStandbyState = false
    setTimeout(() => {
      this.holdPowerBtn = false
    },1200)
    removeAllTune()
    // this.loadCatalog("awake")
  }
}

export default new StandbyControl()
