//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"

@Model.defineAttributes({
  id: {
    from: "id",
  },
  scheduleId: {
    from: "record_schedule_id",
  },
  phase: {
    from: "task_state_phase",
  },
  _serviceId: {
    from: "meta_service_id",
  },
  userContent: {
    from: "user_content",
    convert: (x) => JSON.parse(x),
  },
})
export default class Task extends Model {
  get title() {
    try {
      if (this.userContent.title) {
        return this.userContent.title
      }
    } catch (e) {
      console.debug("Error title",e)
      return null
    }
    // return this.userContent.title
  }

  get description() {
    return this.userContent.description
  }

  get category() {
    return this.userContent.category || ""
  }

  get channelTitle() {
    try {
      if (this.userContent.channelTitle) {
        return this.userContent.channelTitle
      }
    } catch (e) {
      console.debug("Error channelTitle",e)
      return ""
    }
  }

  get serviceId() {
    return this._serviceId || (this.userContent && this.userContent.serviceId)
  }

  get startDate() {
    try {
      if (this.userContent.startDate) {
        return new Date(this.userContent.startDate)
      }
    } catch (e) {
      console.debug("Error startDate",e)
      return null
    }
  }

  get endDate() {
    try {
      if (this.userContent.endDate) {
        return new Date(this.userContent.endDate)
      }
    } catch (e) {
      console.debug("Error endDate",e)
      return null
    }
  }
}
