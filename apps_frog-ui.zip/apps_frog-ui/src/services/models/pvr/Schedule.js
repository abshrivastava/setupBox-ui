//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"


@Model.defineAttributes({
  id: {
    from: "id",
  },
  programId: {
    from: "matching_id",
  },
  state: {
    from: "state",
  },
  _title: {
    from: "title",
  },
})
export default class Schedule extends Model {
  constructor(data) {
    super(data)
    this.task = null
  }

  get title() {
    return this.task.title || this._title
  }

  get description() {
    return this.task.userContent._description || this.task.userContent._short_description || ""
  }

  set description(description) {
    this.task.userContent._description = description
  }

  get category() {
    return this.task.category || ""
  }

  get channelTitle() {
    return this.task.channelTitle
  }

  get serviceId() {
    if (!this.task) {
      return null
    }
    return this.task.serviceId
  }

  get startDate() {
    return this.task.startDate
  }

  get endDate() {
    return this.task.endDate
  }

  get duration() {
    if (this.endDate < this.startDate) {
      return null
    }
    return ~~((this.endDate - this.startDate) / 1000)
  }
}
