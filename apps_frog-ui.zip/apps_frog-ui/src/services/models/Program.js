//
// Copyright (C) 2006-2018 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as programApi from "services/api/program"
import Model from "services/Model"
import {isDefined} from "utils"
import {getCategory} from "utils/dvb"
import {cdsTimestampToDate, dateToCdsTimestamp} from "utils/date"

import PVRManager from "services/managers/PVRManager"

@Model.defineAttributes({
  id: {
    from: "href",
    convert: x => x.split("/")[2],
  },
  title: {
    default: "No Information",
  },
  _description: {
    from: "description",
  },
  _short_description: {
    from: "short_description",
  },
  serviceId: {
    from: "service_id",
  },
  serviceType: {
    from: "service_type",
  },
  programId: {
    from: "program_id",
  },
  startDate: {
    from: "start_date",
    default: () => new Date(),
    convert: (x) => cdsTimestampToDate(x),
  },
  endDate: {
    from: "end_date",
    default: () => new Date(),
    convert: (x) => cdsTimestampToDate(x),
  },
  cdsStartDate: {
    from: "start_date",
    default: () => dateToCdsTimestamp(new Date()),
  },
  cdsEndDate: {
    from: "end_date",
    default: () => dateToCdsTimestamp(new Date()),
  },
  category: {
    from: "content_nibble_level_1",
    convert: (x) => getCategory(x),
  },
})
export default class Program extends Model {
  constructor(props = {}) {
    super(props)
    this.updated = false
  }

  get description() {
    return this._description || this._short_description
  }

  get duration() {
    return (this.cdsEndDate - this.cdsStartDate)
  }

  getDetails() {
    return new Promise((resolve) => {
      if (!isDefined(this.id)) {
        this.updated = true
      }

      if (this.updated) {
        return resolve(this)
      }

      programApi.updateProgram(this.id)
        .then((response) => {
          const newProgram = (response.programs.length) ? response.programs[0] : {}
          this.setAttributes(Object.assign(newProgram, this))
          this.updated = true
          return resolve(this)
        })
    })
  }

  get isScheduled() {
    return PVRManager.isScheduled(this.programId, this.serviceId, this.startDate)
  }

  get isRecording() {
    return PVRManager.isRecording(this.programId, this.serviceId, this.startDate)
  }

  get isOngoing() {
    const now = new Date()
    return (this.startDate < now) && (now  < this.endDate)
  }

  get isReminder() {
    return PVRManager.isReminder(this.programId, this.serviceId, this.startDate)
  }
}
