//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Model from "services/Model"
import VodManager from "services/managers/VodManager"

@Model.defineAttributes({
  idAsset: {
    from: "idAsset",
  },
  id: {
    from: "idAsset",
  },
  validityEndDate: {
    from: "validityEndDate",
  },
  directMetadata: {
    from: "directMetadata",
  },
})

export default class VodItem extends Model {
  constructor(asset, category) {
    super(asset)
    this.categoryId = category.idCatalog
    this._stringifyActors()
    this._getPack()
  }

  get title() {
    return this.directMetadata.AD_ASSTITLE
  }

  get description() {
    return this.directMetadata.AD_SYNO600C
  }

  get price() {
    return this.directMetadata.AD_TCMPRICE
  }

  get duration() {
    return parseInt(this.directMetadata.TS_DURATION, 10) * 60
  }

  get rating() {
    const rating = parseInt(this.directMetadata.AD_SCORPRES, 10)
    return (Number.isInteger(rating)) ? rating : 0
  }

  get assetIcon() {
    return VodManager.getAssetImageUrl(this.id)
  }

  get actors() {
    return this.directMetadata.AD_LIACTORS
  }

  get option() {
    return VodManager.getOfferFromAsset(this.id)
  }

  getFormattedUrl() {
    return {
      playInfo: "hls://?source=" + this.url,
    }
  }

  isPlayable() {
    return this.alreadyBuy || VodManager.isAssetRented(this.id)
  }

  isRented() {
    return VodManager.isAssetRented(this.id)
  }

  hasPackToSubscribe() {
    return this.pack !== null && VodManager.getActivePackFromAsset(this.id) === null
  }

  hasActivePack() {
    return VodManager.getActivePackFromAsset(this.id) !== null
  }

  getFormattedActors() {
    return this.actorList
  }

  _getPack() {
    this.pack = VodManager.getPackFromAsset(this.id)
  }

  _stringifyActors() {
    this.actorList = ""
    if (this.actors) {
      this.actors.forEach((actor, i) => {
        if (i > 0) {
          this.actorList += ", "
        }
        this.actorList += actor
      })
    }
  }
}
