//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import * as programsApi from "services/api/programs"
import Model from "services/Model"
import Program from "./Program"

const DEFAULT_QUERY = {
  order: ["start_date"],
  metadata: [
    "id", "title", "service_id", "start_date", "end_date",
    "content_nibble_level_1", "content_nibble_level_2",
    "size",
  ],
}

const itemsSym = Symbol("items")

@Model.defineAttributes({
  id: {
    from: "href",
    convert: x => x.split("/")[2],
  },
})
export default class Programs extends Model {
  constructor() {
    super()
    this[itemsSym] = []
  }

  create(params = {}) {
    const query = Object.assign({}, DEFAULT_QUERY, params)

    return programsApi.create(query)
      .then(attrs => this.setAttributes(attrs))
      .then(() => this.fetch())
  }

  fetch() {
    return programsApi.get(this.id)
      .then((response) => {
        const rawPrograms = response.programs || []
        this[itemsSym] = rawPrograms.map(p => new Program(p))

        return this
      })
  }

  get items() {
    return this[itemsSym]
  }

  count() {
    return programsApi.count(this.id)
      .then(response => response.count)
  }

  destroy() {
    return programsApi.destroy(this.id)
  }
}
