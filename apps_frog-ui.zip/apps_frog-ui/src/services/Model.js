//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import {isFunction} from "utils"


/**
 * Model
 */
export default class Model {
  /**
   * Initialize Model variables
   */
  constructor(attributes = {}) {
    /**
     * attributes
     * @type {object}
     * @private
     */
    this._attributes = {}
    this.setAttributes(attributes)
  }

  /**
   * Set attributes
   * @param {object} attributes
   */
  setAttributes(attributes) {
    applyAttributeSpec(this, this.constructor.attributes, attributes)
  }
  /**
   * Update attributes
   * @param {object} attributes
   */
  updateAttributes(attributes) {
    applyAttributeSpec(this, this.constructor.attributes, attributes, true)
  }
  /**
   * Get attributes
   * @return {object}
   */
  getAttributes() {
    const attrs = {}
    for (const attrName in this.constructor.attributes) {
      attrs[attrName] = this[attrName]
    }
    return attrs
  }
  /**
   * Define attributes
   * @return {object}
   */
  static defineAttributes(attributeSpec) {
    return function(target, name, descriptor) {
      target.attributes = attributeSpec
      return descriptor
    }
  }
}
/**
 * Apply Attribute conversion
 * @param {object} instance
 * @param {object} spec
 * @param {object} attributes
 * @param {boolean} [update=false]
 * @return {object}
 */
function applyAttributeSpec(instance, spec, attributes, update = false) {
  if (!spec) {
    return attributes
  }

  const modelClass = instance.constructor.name
  const identity = x => x

  for (const attrName in spec) {
    const attrSpec = spec[attrName]
    const sourceName = attrSpec.from || attrName
    const attr = attributes[sourceName]
    const convert = attrSpec.convert || identity

    if (!update && attrSpec.required && attr === undefined) {
      throw new Error(`Missing required field ${attrName} on ${modelClass}`)
    }

    if (!update && attr === undefined && "default" in attrSpec) {
      if (isFunction(attrSpec.default)) {
        instance[attrName] = attrSpec.default(attributes)
      } else {
        instance[attrName] = attrSpec.default
      }
    } else if (attr === undefined && instance[attrName] === undefined) {
      instance[attrName] = null
    } else if (attr !== undefined) {
      instance[attrName] = convert(attr)
    }
  }

  instance._attributes = attributes
}
