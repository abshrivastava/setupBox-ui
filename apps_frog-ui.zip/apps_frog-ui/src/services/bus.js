//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import Emitter from "component-emitter"
import config from "utils/config"
import {findKey, matchFilters} from "utils"

/** class:: Bus()
 *
 * Extends Emitter class
 *
 * `Singleton`
 *
 * .. code-block:: js
 *
 *    import bus from "services/bus"
 *
 *    bus.emit("home:stop:release") //=> Fire a simple event: "home:stop:release"
 *    bus.emit("message", {foo: "bar"}) //=> Fire an event "message" with data: {foo: "bar"}
 *
 * Register/ Unregister to events
 *
 * .. code-block:: js
 *
 *    import bus from "services/bus"
 *
 *    function sayHello(name) {
 *      console.log("Hello ", name")
 *      bus.off("login", sayHello)
 *    }
 *    bus.on("login", sayHello)
 *
 *    bus.emit("login", "John") //=> The console prints: Hello John
 *
 * .. code-block:: js
 *
 *    bus.openUniverse("tv") //=> fire event "tv:open" , current universe is now "tv"
 *    bus.universe //=> "tv"
 *    bus.closeCurrentUniverse() //=> fire event: "tv:close", current universe is null
 *    bus.universe //=> null
 */
export class Bus extends Emitter {
  constructor() {
    super()

    /** attribute:: universe
     * Current existing universes:
     *  - `tv`
     *  - `vod`
     *  - `epg`
     *  - `settings`
     *  - `mediacenter`
     *  - `radio`
     *  - `pvr`
     *  - `home`
     *  - `ad`
     *  - `standby`
     *  - `popup`
     *
     *  And one special during UI creation/loading:
     *  - `bigbang`
     *
     *   :type: String
     *   :private:
     */
    this._universe = "bigbang"
    this._stopEventEmit = false
    this._pressKeys = {}
    this._longPressKeys = {}
  }

  /** function:: on(event, fn, filters)
   * Register an event handler fn.
   *
   *   :param String event: Event to register
   *   :param Function fn: handler
   *   :param Object filters: An object used for filtering
   *   :returns Emitter:
   */
  on(event, fn, filters) {
    const callback = (...args) => {
      if (!filters || matchFilters(filters, ...args)) {
        fn.apply(this, args)
      }
    }
    super.on(event, callback)
  }

  /** function:: once(event, fn, filters)
   * Register a single-shot event handler fn, removed immediately after it is invoked the first time.
   *
   *   :param String event: Event to register
   *   :param Function fn: handler
   *   :param Object filters: An object used for filtering
   *
   *   :returns Emitter:
   */
  once(event, fn, filters) {
    const callback = (...args) => {
      if (!filters || matchFilters(filters, ...args)) {
        fn.apply(this, args)
      }
    }
    super.once(event, callback)
  }

  /** function:: off(event, fn)
   * Pass event and fn to remove a listener.
   * Pass event to remove all listeners on that event.
   * Pass nothing to remove all listeners on all events.
   *
   *   :param String event: Event to register
   *   :param Function fn: handler
   *
   *   :returns Emitter:
   */
  off(event, fn) {
    super.off(event, fn)
  }

  /** function:: emit(event, ...)
   * Emit an event with variable option args.
   *
   *   :param String event: Event
   *
   *   :returns Emitter:
   */
  emit(event, ...data) {
    if (!this._stopEventEmit) {
      super.emit(event, ...data)
    } else if (this._stopEventEmit && (data[0] === "OK" || data[0] === 13)) {
      super.emit(event, ...data)
    } else {
      // Do Nothing
    }
  }

  /** function:: listeners(event)
   * Return an array of callbacks, or an empty array.
   *
   *   :param String event: Event
   *   :returns Array:
   */
  listeners(event) {
    super.listeners(event)
  }

  /** function:: hasListenerss(event)
   * Check if this emitter has event handlers.
   *
   *   :param String event: Event
   *   :returns Boolean:
   */
  hasListenerss(event) {
    super.listeners(event)
  }

  /** function:: handleRcuEvent(key, type, kbd)
   * Handle all RCU key events
   * and return an event:
   *
   *   :param ? key:
   *   :param String type: the type of Rcu event (press/release)
   *   :param ? kbd:
   *   :returns Emitter:
   *
   * .. code-block:: js
   *
   *    bus.handleRcuEvent(7, "press", 7) //=> "rcu:bigbang:up:press"
   */
  handleRcuEvent(key, type, kbd) {
    let emitString = ""
    let keyname = findKey(config.KEYMAP, key)

    if (keyname) {
      if (config.KEYMAP.ANY_NUMERIC.indexOf(key) > -1) {
        emitString = `${this._universe}:numeric:${type}`
        keyname = parseInt(keyname.slice(-1), 10)
      } else {
        emitString = `${this._universe}:${keyname.toLowerCase()}:${type}`
      }
    } else {
      console.warn(`Key not catch ! (keycode: ${key})`)
      return
    }

    if (type === "release") {
      this._pressKeys[key] = 0
      this._longPressKeys[key] = false
    }

    let press = undefined
    if (type === "press") {
      press = this._managePress(key)
      if (press === null) {
        return
      }
    }

    this._sendRcuEvent(emitString, keyname, kbd, type, press)
  }

  /** function:: _managePress(keycode)
   * Return true if keycode is in long press
   * Return false if keycode just pressed for the first time
   * Return null otherwise
   *
   *   :param Number keycode: Keycode Event
   *   :returns Boolean | null:
   */
  _managePress(keycode) {
    if (!this._pressKeys[keycode]) {
      this._pressKeys[keycode] = Date.now()
      return false
    } else {
      if (!this._longPressKeys[keycode] &&
        Date.now() - this._pressKeys[keycode] >= 500) {
        this._longPressKeys[keycode] = true
        return true
      } else {
        return null
      }
    }
  }

  _sendRcuEvent(emitString, keyname, kbd, type, longPress) {
    const title = (longPress) ? "[RCU LONG]" : "[RCU]"
    const signal = (longPress) ? "long_rcu" : "rcu"
    console.debug(`${title} ${this._universe} ${keyname} ${type}`)
    this.emit(`${signal}#${emitString}`, keyname, kbd)
  }

  /** attribute:: universe
   * Returns the current universe
   *
   *   :returns String: current universe
   */
  get universe() {
    return this._universe
  }

  /** setter: universe
   * Set the current universe
   *
   *   :param String: universe
   */
  set universe(u) {
    if (!this._stopEventEmit) {
      this.emit("bus:universe", u)
      this._universe = u
    }
  }

  /** setter: stopEvents
   * Set the Stops the event
   *
   *   :param String: Boolean
   */
  set stopEventEmit(v) {
    this._stopEventEmit = v
  }


  /** function:: openUniverse(universe)
   * Open an universe, set it as current and emit a message `universe:open`
   *
   *   :param String: universe
   *   :returns Emitter:
   */
  openUniverse(universe) {
    this.universe = universe
    this.emit(`${this._universe}:open`)
  }

  /** function:: closeCurrentUniverse()
   * Close current universe, set it to null  and emit a message `universe:close`
   *
   *   :returns Emitter:
   */
  closeCurrentUniverse() {
    this.emit(`${this._universe}:close`)
    this.universe = null
  }
}

export default new Bus()
