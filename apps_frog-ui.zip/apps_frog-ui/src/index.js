//
// Copyright (C) 2006-2016 Wyplay, All Rights Reserved. This source code and
// any compilation or derivative thereof is the proprietary information of
// Wyplay and is confidential in nature. Under no circumstances is this
// software to be exposed to or placed under an Open Source License of any type
// without the expressed written permission of Wyplay.
//

import "./index.html"
import "./index.css"

import "babel-polyfill"
import "utils/polyfill"
import * as utils from "utils"
import bus from "services/bus"

import config from "utils/config"
import {appConfig} from "app/config"
import * as services from "services/managers"
import * as http from "services/http"


import {locale} from "utils/locale"

import Application from "app/components"

import UniverseManager from "services/managers/UniverseManager"
import standby from "services/managers/PowerManager"
import LedManager from "services/managers/LedManager"

import avoidMultiEvent from "services/avoidMultipleEvent"

locale.current = "eng"

// Prevent HOME key override when running in dev mode
window.WYPLAY_NO_HOME_KEY_OVERRIDE = true

// Create Application
const application = new Application()
application.build()
document.body.appendChild(application.dom)

// Initialize the controllers
UniverseManager.startApplication()

// Fielder the LED Call In Case of Power/Rec Btn....
const ledField = config.KEYMAP
ledField[Symbol.iterator] = function *() {
  const properties = Object.keys(this)
  for (const p of properties) {
    if (typeof this[p] === "number" && (p === "POWER" || p === "REC")) yield this[p]
  }
}
const ledFielder = [...ledField]
const ledNumZapThrottle = utils.throttle(LedManager.LedNumZap, 200, LedManager)

// Listen User Inputs
// :: LedManager.LedNumZap : PUT Request for LED call in Every Listen User Inputs...
document.body.addEventListener("keydown", (ev) => {

  if (!standby.isStandbyState) {
    let keyflag = true
    if (ledFielder.indexOf(ev.keyCode) > -1) keyflag = false
    if (keyflag === true && utils.findKey(ledField,ev.keyCode)) {
      ledNumZapThrottle()
    }
  }

  if (utils.findKey(ledField,ev.keyCode)) {
    avoidMultiEvent.filterEvent(ev) && bus.handleRcuEvent(ev.keyCode, "press", ev)
  }

  ev.preventDefault()
}, true)

document.body.addEventListener("keyup", (ev) => {
  if (avoidMultiEvent.avoidKey === ev.keyCode) return

  if (utils.findKey(ledField,ev.keyCode)) {
    bus.emit("window:keyPressed", ev.keyCode, ev.key)
    bus.handleRcuEvent(ev.keyCode, "release", ev)
  }

  ev.preventDefault()
}, true)

document.body.addEventListener("keypress", (ev) => {
  ev.preventDefault()
}, true)

// Enable on-screen UI logs in development mode
window.log = () => {}
const uiLog = {
  elm: "", cnt: 0,
  log: (msg) => {
    uiLog.cnt++
    if (!uiLog.elm) {
      uiLog.elm = document.createElement("div")
      uiLog.elm.classList.add("uiLog")
      document.body.appendChild(uiLog.elm)
    }
    msg = (typeof msg === "object")?JSON.stringify(msg):msg
    uiLog.elm.innerHTML += "\n <br/> [ui-logs] "+ uiLog.cnt+ ") "+ msg
    if (uiLog.cnt>40) uiLog.elm.scrollTop += 30
  },
}

// Expose debug helpers if needed
if (config.DEBUG) {
  window.application = application
  window.bus = bus
  window.config = config
  window.utils = utils
  window.services = services
  window.http = http
  window.log = uiLog.log
}

// Finally, Application is ready
bus.emit("application:open")

